package lapp

import "strings"

func commitDrive(c *ctx, access *driveAccess) (string, error) {
	cid, err := c.api.FilesFlush(access.authorSID, driveWorkRoot)
	if err != nil {
		return "", err
	}
	return c.api.MFSetCid(access.authorSID, access.driveMID, cid)
}

func entryFolderCreate(c *ctx) (any, error) {
	name := cleanName(c.str("name"))
	if name == "" {
		return fail(c, "lifedrive.request.invalid_folder", "error.request.invalid_folder", false), nil
	}
	parent, err := normalizeDirectory(c.str("parent_path"))
	if err != nil {
		return fail(c, "lifedrive.request.invalid_folder", "error.request.invalid_folder", false), nil
	}
	path := joinPath(parent, name)
	access, err := requireAccess(c, "modify", "folder")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	if _, err := ensureDriveRoot(c, access.authorSID, access.driveMID); err != nil {
		return fail(c, "lifedrive.folder.create_failed", "error.folder.create_failed", true), nil
	}
	created, err := ensureDirectory(c, access.authorSID, workPath(path))
	if err != nil {
		if len(created) > 0 {
			_ = c.api.FilesRm(access.authorSID, created[0], true, false)
			_, _ = c.api.FilesFlush(access.authorSID, driveWorkRoot)
		}
		return fail(c, "lifedrive.folder.create_failed", "error.folder.create_failed", true), nil
	}
	var version any
	if len(created) > 0 {
		version, err = commitDrive(c, access)
		if err != nil {
			_ = c.api.FilesRm(access.authorSID, created[0], true, false)
			_, _ = c.api.FilesFlush(access.authorSID, driveWorkRoot)
			return fail(c, "lifedrive.folder.create_failed", "error.folder.create_failed", true), nil
		}
	}
	now := serverTime()
	return ok(c, map[string]any{
		"drive_mid": access.driveMID, "version": version, "changed": len(created) > 0,
		"object": map[string]any{
			"object_id": path, "path": path, "kind": "folder", "display_name": name,
			"parent_id": parentID(path), "parent_path": parentID(path), "media_type": "inode/directory",
			"plaintext_size": 0, "created_at": now, "modified_at": now,
		},
	}), nil
}

func moveOrCopy(c *ctx, copyObject bool) (any, error) {
	source, err := normalizeObjectPath(c.str("source_path"))
	if err != nil {
		return fail(c, operationCode(copyObject), operationMessage(copyObject), true), nil
	}
	destinationParent, err := normalizeDirectory(c.str("destination_parent"))
	if err != nil {
		return fail(c, operationCode(copyObject), operationMessage(copyObject), true), nil
	}
	nameValue := c.str("name")
	if nameValue == "" && !copyObject {
		nameValue = baseName(source)
	}
	name := cleanName(nameValue)
	if name == "" {
		return fail(c, operationCode(copyObject), operationMessage(copyObject), true), nil
	}
	destination := joinPath(destinationParent, name)
	if !copyObject && destination == source {
		return ok(c, map[string]any{"source_path": source, "destination_path": destination, "changed": false}), nil
	}
	if destinationParent == source || strings.HasPrefix(destinationParent, source+"/") {
		return fail(c, "lifedrive.folder.cycle", "error.folder.cycle", false), nil
	}
	access, err := requireAccess(c, "modify", "file")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	sourceWork := workPath(source)
	destinationWork := workPath(destination)
	if _, err := c.api.FilesStat(access.authorSID, sourceWork); err != nil {
		return fail(c, operationCode(copyObject), operationMessage(copyObject), true), nil
	}
	if _, err := c.api.FilesStat(access.authorSID, workPath(destinationParent)); err != nil {
		return fail(c, operationCode(copyObject), operationMessage(copyObject), true), nil
	}
	if _, err := c.api.FilesStat(access.authorSID, destinationWork); err == nil {
		return failDetails(c, "lifedrive.file.already_exists", "error.file.already_exists", false, map[string]any{"path": destination}), nil
	}
	if copyObject {
		err = c.api.FilesCopy(access.authorSID, sourceWork, destinationWork, false)
	} else {
		err = c.api.FilesMv(access.authorSID, sourceWork, destinationWork, false)
	}
	if err != nil {
		return fail(c, operationCode(copyObject), operationMessage(copyObject), true), nil
	}
	version, err := commitDrive(c, access)
	if err != nil {
		if copyObject {
			_ = c.api.FilesRm(access.authorSID, destinationWork, true, false)
		} else {
			_ = c.api.FilesMv(access.authorSID, destinationWork, sourceWork, false)
		}
		_, _ = c.api.FilesFlush(access.authorSID, driveWorkRoot)
		return fail(c, operationCode(copyObject), operationMessage(copyObject), true), nil
	}
	data := map[string]any{
		"drive_mid": access.driveMID, "version": version, "source_path": source, "destination_path": destination,
	}
	if !copyObject {
		data["changed"] = true
	}
	return ok(c, data), nil
}

func operationCode(copyObject bool) string {
	if copyObject {
		return "lifedrive.object.copy_failed"
	}
	return "lifedrive.object.move_failed"
}

func operationMessage(copyObject bool) string {
	if copyObject {
		return "error.object.copy_failed"
	}
	return "error.object.move_failed"
}

func entryObjectMove(c *ctx) (any, error) { return moveOrCopy(c, false) }
func entryObjectCopy(c *ctx) (any, error) { return moveOrCopy(c, true) }

func entryObjectTrash(c *ctx) (any, error) {
	pathValue := c.str("path")
	if pathValue == "" {
		pathValue = c.str("object_id")
	}
	source, err := normalizeObjectPath(pathValue)
	if err != nil {
		return fail(c, "lifedrive.object.trash_failed", "error.object.trash_failed", true), nil
	}
	trashPath := trashRoot + "/" + percentEncode(source)
	access, err := requireAccess(c, "delete", "file")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	if _, err := c.api.FilesStat(access.authorSID, workPath(trashRoot)); err != nil {
		if err := c.api.FilesMkdir(access.authorSID, workPath(trashRoot), false); err != nil {
			return fail(c, "lifedrive.object.trash_failed", "error.object.trash_failed", true), nil
		}
	}
	if _, err := c.api.FilesStat(access.authorSID, workPath(source)); err != nil {
		return fail(c, "lifedrive.object.trash_failed", "error.object.trash_failed", true), nil
	}
	if _, err := c.api.FilesStat(access.authorSID, workPath(trashPath)); err == nil {
		return failDetails(c, "lifedrive.trash.already_contains_path", "error.trash.already_contains_path", false, map[string]any{"path": source}), nil
	}
	if err := c.api.FilesMv(access.authorSID, workPath(source), workPath(trashPath), false); err != nil {
		return fail(c, "lifedrive.object.trash_failed", "error.object.trash_failed", true), nil
	}
	version, err := commitDrive(c, access)
	if err != nil {
		_ = c.api.FilesMv(access.authorSID, workPath(trashPath), workPath(source), false)
		_, _ = c.api.FilesFlush(access.authorSID, driveWorkRoot)
		return fail(c, "lifedrive.object.trash_failed", "error.object.trash_failed", true), nil
	}
	if _, err := c.api.FilesStat(access.authorSID, mimeiURL(access.driveMID, "last", trashPath)); err != nil {
		return fail(c, "lifedrive.object.trash_failed", "error.object.trash_failed", true), nil
	}
	return ok(c, map[string]any{
		"drive_mid": access.driveMID, "version": version, "original_path": source, "trash_path": trashPath,
	}), nil
}

func entryTrashRestore(c *ctx) (any, error) {
	trashPath, original, err := normalizeTrashPath(c.str("trash_path"))
	if err != nil {
		return fail(c, "lifedrive.trash.restore_failed", "error.trash.restore_failed", true), nil
	}
	destinationParentValue := c.str("destination_parent")
	if destinationParentValue == "" {
		destinationParentValue = parentPath(original)
	}
	destinationParent, err := normalizeDirectory(destinationParentValue)
	if err != nil {
		return fail(c, "lifedrive.trash.restore_failed", "error.trash.restore_failed", true), nil
	}
	nameValue := c.str("name")
	if nameValue == "" {
		nameValue = baseName(original)
	}
	name := cleanName(nameValue)
	if name == "" {
		return fail(c, "lifedrive.trash.restore_failed", "error.trash.restore_failed", true), nil
	}
	destination := joinPath(destinationParent, name)
	access, err := requireAccess(c, "modify", "file")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	if _, err := c.api.FilesStat(access.authorSID, workPath(trashPath)); err != nil {
		return fail(c, "lifedrive.trash.restore_failed", "error.trash.restore_failed", true), nil
	}
	if _, err := c.api.FilesStat(access.authorSID, workPath(destinationParent)); err != nil {
		return fail(c, "lifedrive.trash.restore_failed", "error.trash.restore_failed", true), nil
	}
	if _, err := c.api.FilesStat(access.authorSID, workPath(destination)); err == nil {
		return failDetails(c, "lifedrive.file.already_exists", "error.file.already_exists", false, map[string]any{"path": destination}), nil
	}
	if err := c.api.FilesMv(access.authorSID, workPath(trashPath), workPath(destination), false); err != nil {
		return fail(c, "lifedrive.trash.restore_failed", "error.trash.restore_failed", true), nil
	}
	version, err := commitDrive(c, access)
	if err != nil {
		_ = c.api.FilesMv(access.authorSID, workPath(destination), workPath(trashPath), false)
		_, _ = c.api.FilesFlush(access.authorSID, driveWorkRoot)
		return fail(c, "lifedrive.trash.restore_failed", "error.trash.restore_failed", true), nil
	}
	return ok(c, map[string]any{
		"drive_mid": access.driveMID, "version": version, "original_path": original, "destination_path": destination,
	}), nil
}

func entryObjectPurge(c *ctx) (any, error) {
	trashPath, _, err := normalizeTrashPath(c.str("trash_path"))
	if err != nil {
		return fail(c, "lifedrive.object.purge_failed", "error.object.purge_failed", true), nil
	}
	access, err := requireAccess(c, "delete", "file")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	if _, err := c.api.FilesStat(access.authorSID, workPath(trashPath)); err != nil {
		return fail(c, "lifedrive.object.purge_failed", "error.object.purge_failed", true), nil
	}
	if err := c.api.FilesRm(access.authorSID, workPath(trashPath), true, false); err != nil {
		return fail(c, "lifedrive.object.purge_failed", "error.object.purge_failed", true), nil
	}
	version, err := commitDrive(c, access)
	if err != nil {
		logError(c, "purge commit failed after removing %s: %v", trashPath, err)
		return fail(c, "lifedrive.object.purge_failed", "error.object.purge_failed", true), nil
	}
	return ok(c, map[string]any{
		"drive_mid": access.driveMID, "version": version, "trash_path": trashPath, "purged": true,
	}), nil
}
