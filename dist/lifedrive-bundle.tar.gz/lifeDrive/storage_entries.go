package lapp

import (
	"encoding/json"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"

	"Leither/lapi"
)

const decimalGigabyte = uint64(1000 * 1000 * 1000)

type repoStatter interface {
	RepoStat(sid string) (*lapi.RepoStat, error)
}

type datastoreConfigEnvelope struct {
	Datastore struct {
		StorageMax string `json:"StorageMax"`
	} `json:"Datastore"`
}

func entryStorageGet(c *ctx) (any, error) {
	if failure := versionFailure(c); failure != nil {
		return failure, nil
	}
	access, err := requireAccess(c, "manage_access", "drive")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	configured, configuredBytes, err := readStorageMax()
	if err != nil {
		logError(c, "storage configuration unavailable request_id=%s", requestID(c))
		return fail(c, "lifedrive.storage.configuration_unavailable", "error.storage.configuration_unavailable", true), nil
	}
	return ok(c, storageStatus(c, access.authorSID, configured, configuredBytes, false)), nil
}

func entryStorageSetLimit(c *ctx) (any, error) {
	if failure := versionFailure(c); failure != nil {
		return failure, nil
	}
	access, err := requireAccess(c, "manage_access", "drive")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	gigabytes, err := strconv.ParseUint(strings.TrimSpace(c.str("storage_max_gb")), 10, 64)
	if err != nil || gigabytes == 0 || gigabytes > ^uint64(0)/decimalGigabyte {
		return fail(c, "lifedrive.storage.invalid_limit", "error.storage.invalid_limit", false), nil
	}
	desiredBytes := gigabytes * decimalGigabyte
	if stat := readRepoStat(c, access.authorSID); stat != nil && desiredBytes < stat.RepoSize {
		return failDetails(c, "lifedrive.storage.limit_below_usage", "error.storage.limit_below_usage", false,
			map[string]any{"used_bytes": stat.RepoSize}), nil
	}
	configured := strconv.FormatUint(gigabytes, 10) + "GB"
	if err := writeStorageMax(configured); err != nil {
		logError(c, "storage configuration update failed request_id=%s", requestID(c))
		return fail(c, "lifedrive.storage.update_failed", "error.storage.update_failed", false), nil
	}
	return ok(c, storageStatus(c, access.authorSID, configured, desiredBytes, true)), nil
}

func storageStatus(c *ctx, sid, configured string, configuredBytes uint64, restartRequired bool) map[string]any {
	result := map[string]any{
		"storage_max": configured, "storage_max_bytes": configuredBytes,
		"storage_max_gb":  configuredBytes / decimalGigabyte,
		"usage_available": false, "restart_required": restartRequired,
		"data_distribution": "private-local", "published": false, "provider_advertised": false,
	}
	if stat := readRepoStat(c, sid); stat != nil {
		result["used_bytes"] = stat.RepoSize
		result["object_count"] = stat.NumObjects
		result["usage_available"] = true
		if stat.StorageMax > 0 && stat.StorageMax != configuredBytes {
			result["restart_required"] = true
		}
	}
	return result
}

func readRepoStat(c *ctx, sid string) *lapi.RepoStat {
	statter, ok := any(c.api).(repoStatter)
	if !ok {
		return nil
	}
	stat, err := statter.RepoStat(sid)
	if err != nil {
		return nil
	}
	return stat
}

func readStorageMax() (string, uint64, error) {
	path, err := leitherConfigPath()
	if err != nil {
		return "", 0, err
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return "", 0, err
	}
	var config datastoreConfigEnvelope
	if err := json.Unmarshal(data, &config); err != nil {
		return "", 0, fmt.Errorf("invalid Leither datastore configuration: %w", err)
	}
	configured := strings.TrimSpace(config.Datastore.StorageMax)
	configuredBytes, err := parseStorageSize(configured)
	if err != nil {
		return "", 0, err
	}
	return configured, configuredBytes, nil
}

func writeStorageMax(value string) error {
	path, err := leitherConfigPath()
	if err != nil {
		return err
	}
	info, err := os.Lstat(path)
	if err != nil {
		return err
	}
	if !info.Mode().IsRegular() {
		return fmt.Errorf("Leither datastore configuration is not a regular file")
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	next, err := replaceStorageMax(data, value)
	if err != nil {
		return err
	}
	temporary := path + ".lifedrive-tmp-" + strconv.FormatInt(time.Now().UnixNano(), 10)
	file, err := os.OpenFile(temporary, os.O_CREATE|os.O_EXCL|os.O_WRONLY, info.Mode().Perm())
	if err != nil {
		return err
	}
	removeTemporary := true
	defer func() {
		if removeTemporary {
			_ = os.Remove(temporary)
		}
	}()
	if _, err = file.Write(next); err == nil {
		err = file.Sync()
	}
	closeErr := file.Close()
	if err == nil {
		err = closeErr
	}
	if err != nil {
		return err
	}
	if err := os.Rename(temporary, path); err != nil {
		return err
	}
	removeTemporary = false
	if directory, err := os.Open(directoryName(path)); err == nil {
		_ = directory.Sync()
		_ = directory.Close()
	}
	return nil
}

func replaceStorageMax(data []byte, value string) ([]byte, error) {
	var config datastoreConfigEnvelope
	if err := json.Unmarshal(data, &config); err != nil {
		return nil, fmt.Errorf("invalid Leither datastore configuration: %w", err)
	}
	currentJSON, _ := json.Marshal(config.Datastore.StorageMax)
	nextJSON, _ := json.Marshal(value)
	source := string(data)
	key := `"StorageMax"`
	keyIndex := strings.Index(source, key)
	if keyIndex < 0 || strings.Index(source[keyIndex+len(key):], key) >= 0 {
		return nil, fmt.Errorf("Leither datastore StorageMax must occur exactly once")
	}
	valueStart := strings.Index(source[keyIndex+len(key):], string(currentJSON))
	if valueStart < 0 {
		return nil, fmt.Errorf("Leither datastore StorageMax is not a string")
	}
	valueStart += keyIndex + len(key)
	next := source[:valueStart] + string(nextJSON) + source[valueStart+len(currentJSON):]
	if err := json.Unmarshal([]byte(next), &config); err != nil || config.Datastore.StorageMax != value {
		return nil, fmt.Errorf("updated Leither datastore configuration did not validate")
	}
	return []byte(next), nil
}

func leitherConfigPath() (string, error) {
	candidates := []string{}
	if root := strings.TrimSpace(os.Getenv("LIFEDRIVE_LEITHER_ROOT")); root != "" {
		candidates = append(candidates, joinUnixPath(root, "ds/config"))
	}
	if executable, err := os.Executable(); err == nil {
		candidates = append(candidates, joinUnixPath(directoryName(executable), "ds/config"))
	}
	if workingDirectory, err := os.Getwd(); err == nil {
		candidates = append(candidates,
			joinUnixPath(workingDirectory, "ds/config"),
			joinUnixPath(directoryName(workingDirectory), "ds/config"))
	}
	seen := map[string]bool{}
	for _, candidate := range candidates {
		if seen[candidate] {
			continue
		}
		seen[candidate] = true
		if info, err := os.Stat(candidate); err == nil && info.Mode().IsRegular() {
			return candidate, nil
		}
	}
	return "", fmt.Errorf("Leither datastore configuration was not found beside the running service")
}

func directoryName(path string) string {
	path = strings.TrimRight(path, "/")
	index := strings.LastIndex(path, "/")
	if index <= 0 {
		return "/"
	}
	return path[:index]
}

func joinUnixPath(root, child string) string {
	return strings.TrimRight(root, "/") + "/" + strings.TrimLeft(child, "/")
}

func parseStorageSize(value string) (uint64, error) {
	upper := strings.ToUpper(strings.TrimSpace(value))
	units := []struct {
		suffix string
		factor uint64
	}{
		{"TIB", 1024 * 1024 * 1024 * 1024}, {"GIB", 1024 * 1024 * 1024},
		{"MIB", 1024 * 1024}, {"KIB", 1024}, {"TB", 1000 * 1000 * 1000 * 1000},
		{"GB", decimalGigabyte}, {"MB", 1000 * 1000}, {"KB", 1000}, {"B", 1},
	}
	for _, unit := range units {
		if !strings.HasSuffix(upper, unit.suffix) {
			continue
		}
		number := strings.TrimSpace(strings.TrimSuffix(upper, unit.suffix))
		amount, err := strconv.ParseUint(number, 10, 64)
		if err != nil || amount == 0 || amount > ^uint64(0)/unit.factor {
			return 0, fmt.Errorf("invalid Leither StorageMax value")
		}
		return amount * unit.factor, nil
	}
	return 0, fmt.Errorf("unsupported Leither StorageMax unit")
}
