package lapp

import (
	"fmt"
	"os"
	"strings"
)

// authorizedDevices reports the device UIDs the installer has authorized to
// change drive data.
//
// Leither cannot answer this question from inside the MApp. Verified on
// V0.24.12: MMOpen admits any authenticated UID for both last and cur;
// MMGetRight returns the same read-only default for granted and ungranted UIDs
// alike, even though the node stores the grant; and MMBackup, the one call that
// does discriminate, is author-only, so a device can never commit for itself.
// Every mutation therefore runs on the author session, which means Leither only
// ever sees the author writing and the decision has to be made here.
//
// The registry is the device file the installer already maintains beside the
// Leither service: lifeDrive-owner.sh appends a line when it issues a device,
// and lifeDrive-device.sh removes one on revocation. Each line is
// "<uid>\t<label>\t<created-at>".
//
// This is application-level enforcement executed with the author's key. Anyone
// holding the author key, or able to write that file, bypasses it. That
// limitation is the subject of LIFEDRIVE_INTERIM_SECURITY.md and must not be
// described as native Leither enforcement.
func authorizedDevices() (map[string]bool, error) {
	path, err := leitherRootFile(driveID + ".devices")
	if err != nil {
		return nil, err
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read device registry: %w", err)
	}
	allowed := map[string]bool{}
	for _, line := range strings.Split(string(data), "\n") {
		uid := strings.TrimSpace(line)
		if index := strings.IndexByte(uid, '\t'); index >= 0 {
			uid = strings.TrimSpace(uid[:index])
		}
		if uid != "" {
			allowed[uid] = true
		}
	}
	return allowed, nil
}

// deviceMayModify fails closed: a missing or unreadable registry authorizes
// nobody, and an empty registry authorizes nobody.
func deviceMayModify(uid string) (bool, error) {
	if uid == "" {
		return false, nil
	}
	allowed, err := authorizedDevices()
	if err != nil {
		return false, err
	}
	return allowed[uid], nil
}
