package lapp

import (
	"fmt"
	"os"
	"strings"
)

// driveAccess carries the session every operation runs on. That is the caller's
// own session rather than the application author's: a drive belongs to the
// owner's device key, so Leither enforces rights against the caller natively and
// one published application can serve every household. Verified on V0.24.12 that
// a device key can MMCreate, FilesFlush, MFSetCid and read back its own MiMei
// with no author session involved.
type driveAccess struct {
	sid      string
	driveMID string
	userID   string
	version  string
}

// driveMIDForNode reads the drive this node owns, recorded beside the Leither
// service the first time an owner signs in.
//
// It is read rather than derived. MMCreate is deterministic in its author, so
// deriving it under the caller's session would hand every paired device a
// different MiMei, and an owner's second device would open an empty drive. The
// household has one drive and every authorized device opens that same MID.
// driveMIDStatePath names the drive pointer beside the running service.
func driveMIDStatePath() (string, error) {
	root, err := leitherRootDirectory()
	if err != nil {
		return "", err
	}
	return joinUnixPath(root, driveID+".drivemid"), nil
}

func driveMIDForNode() (string, string, error) {
	path, err := driveMIDStatePath()
	if err != nil {
		return "", "", err
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return "", path, nil
	}
	mid := strings.TrimSpace(string(data))
	if mid == "" {
		return "", path, nil
	}
	if !validMID(mid) {
		return "", path, fmt.Errorf("invalid drive id recorded for this node")
	}
	return mid, path, nil
}

// openDrive resolves the household drive for this caller, creating it the first
// time an owner signs in.
//
// The drive is created under the caller's own session so the owner's key is its
// author: only the author may commit a MiMei with MFSetCid, so a drive authored
// by anyone else could be read by its owner but never written to. The MID is
// then recorded beside the Leither service, because MMCreate is deterministic in
// its author and a second paired device would otherwise derive a different
// MiMei and open an empty drive.
//
// A recorded MID that will not open is an error rather than a reason to create a
// replacement: silently minting a second drive would strand the first one's
// contents.
func openDrive(c *ctx, callerSID, appID, version string) (string, string, error) {
	if c.household != nil {
		return c.household.DriveMID, version, nil
	}
	mid, statePath, err := driveMIDForNode()
	if err != nil {
		return "", "", err
	}
	if mid != "" {
		handle, openErr := c.api.MMOpen(callerSID, mid, version)
		if openErr != nil && version == "last" {
			version = "cur"
			handle, openErr = c.api.MMOpen(callerSID, mid, version)
		}
		if openErr != nil {
			return "", "", nil
		}
		closeHandle(c, handle)
		return mid, version, nil
	}
	created, err := c.api.MMCreate(callerSID, appID, driveExt, driveID, fileType, c.creationRight())
	if err != nil {
		return "", "", fmt.Errorf("create drive: %w", err)
	}
	if err := os.WriteFile(statePath, []byte(created+"\n"), 0o600); err != nil {
		return "", "", fmt.Errorf("record drive id: %w", err)
	}
	return created, "cur", nil
}

func authorize(c *ctx, action, resourceKind string) (*driveAccess, bool, error) {
	appID := c.str("aid")
	if appID == "" || len(appID) > 128 {
		return nil, false, fmt.Errorf("missing app id")
	}
	callerSID := c.str("owner_sid")
	if callerSID == "" {
		callerSID = c.str("sid")
	}
	if callerSID == "" || len(callerSID) > 1024 {
		return nil, false, nil
	}
	version := "cur"
	if action == "view" {
		version = "last"
	}
	// A newly created drive has writable state before its first committed
	// version exists, so openDrive falls back to cur when last will not open.
	mid, version, err := openDrive(c, callerSID, appID, version)
	if err != nil {
		return nil, false, err
	}
	if mid == "" {
		return nil, false, nil
	}
	uidValue, err := c.api.GetVar(callerSID, "userid")
	if err != nil {
		return nil, false, err
	}
	uid, _ := uidValue.(string)
	// Reads stay open: the drive's default right already lets any authenticated
	// UID read. Writes need no check here either. Every mutation commits with
	// MFSetCid on this caller's own session, and Leither admits only the drive's
	// author, so an unauthorized device is refused by the node rather than here.
	//
	// This replaced an installer-maintained device file. That file emulated the
	// check back when every mutation ran on the author session and Leither only
	// ever saw the author writing. It also could not exist on a node that never
	// installed LifeDrive, where it failed closed and locked the owner out.
	return &driveAccess{sid: callerSID, driveMID: mid, userID: uid, version: version}, true, nil
}

func requireAccess(c *ctx, action, resourceKind string) (*driveAccess, error) {
	access, allowed, err := authorize(c, action, resourceKind)
	if err != nil {
		return nil, err
	}
	if !allowed {
		return nil, fmt.Errorf("permission denied")
	}
	return access, nil
}

func entryAccessCheck(c *ctx) (any, error) {
	if failure := versionFailure(c); failure != nil {
		return failure, nil
	}
	action := c.str("action")
	resourceKind := c.str("resource_kind")
	if !contains([]string{"view", "modify", "publish", "delete", "manage_access"}, action) ||
		!contains([]string{"drive", "folder", "file", "mimei"}, resourceKind) || c.str("aid") == "" {
		return fail(c, "lifedrive.request.invalid_authorization_scope", "error.request.invalid_authorization_scope", false), nil
	}
	access, allowed, err := authorize(c, action, resourceKind)
	if err != nil {
		logError(c, "access check failed request_id=%s: %v", requestID(c), err)
		allowed = false
	}
	if !allowed {
		reason := "lifedrive.security.permission_denied"
		if c.str("sid") == "" && c.str("owner_sid") == "" {
			reason = "lifedrive.auth.required"
		}
		return ok(c, map[string]any{
			"allowed": false, "decision": "deny", "reason_code": reason,
			"security_backend": "leither-native/v1", "action": action, "resource_kind": resourceKind,
		}), nil
	}
	return ok(c, map[string]any{
		"allowed": true, "decision": "allow", "reason_code": "lifedrive.security.native_mimei_right",
		"security_backend": "leither-native/v1", "action": action, "resource_kind": resourceKind,
		"uid": access.userID, "drive_mid": access.driveMID, "required_version": access.version,
	}), nil
}

func entryAccessGetSecurityMode(c *ctx) (any, error) {
	if failure := versionFailure(c); failure != nil {
		return failure, nil
	}
	return ok(c, map[string]any{
		"mode": "key", "backend_version": "leither-key/v1", "status": "device_key_authentication_active",
		"owner_device_proof": true, "short_lived_passports": true, "short_lived_sessions": true, "delegated_access": false,
		"key_type": "sodiumv2", "credential_scope": "per-device", "password_login": false,
		"native_leither_enforcement": true, "protected_operations": "MiMei rights enforced for every file operation",
		"private_network_only": true, "disclosure_key": "security.leither.native_owner",
	}), nil
}

func entryHealth(c *ctx) (any, error) {
	if failure := versionFailure(c); failure != nil {
		return failure, nil
	}
	// The identifier this node answers as -- the first line of "Leither swarm
	// id". It names the node itself rather than whatever address the browser
	// happened to reach it through, so it stays true however the client is
	// routed. Empty when the runtime does not supply it; the client shows the
	// row only when it has a value.
	nodeID, _ := c.api.GetVar("", "hostid")
	hostID, _ := nodeID.(string)
	return ok(c, map[string]any{
		"service": "LifeDriveServerApp", "server_version": serverVersion, "status": "ok",
		"household_protocol":  1,
		"household_transport": 1,
		"household_rpc":       1,
		"household_active":    householdActive(),
		"node_id":             hostID,
		"development_stage":   "file-storage-api", "storage_authority": "file-type-mimei",
		"runtime": "leither-go-mapp", "module_loading": false,
		"mutation_commit": "FilesFlush+MFSetCid", "database_mimei_allowed": false,
		"security_mode": "leither-key/v1", "protected_operations": "signed device PPT, expiring SID, and MiMei rights",
		"upload_transport": "leither-hprose-chunks", "upload_chunk_size": uploadInitialChunkSize,
		"upload_max_chunk_size": uploadMaxChunkSize, "upload_chunk_strategy": "adaptive",
		"data_distribution": "private-local", "drive_published": false, "provider_advertised": false,
	}), nil
}

func trueMap(names ...string) map[string]bool {
	result := map[string]bool{}
	for _, name := range names {
		result[name] = true
	}
	return result
}

func entryServerCapabilities(c *ctx) (any, error) {
	if failure := versionFailure(c); failure != nil {
		return failure, nil
	}
	runtime := trueMap("BELoginAsAuthor", "GetVar", "Debug", "Error")
	mimei := trueMap("MMCreate", "MMOpen", "MMOpenUrl", "MMClose")
	file := trueMap("MFOpenTempFile", "MFTemp2Files", "MFSetCid", "MFSetData", "MFGetData", "MFGetSize", "MFStat", "MFGetMimeType")
	tree := trueMap("FilesCopy", "FilesLs", "FilesMkdir", "FilesRm", "FilesMv", "FilesFlush", "FilesStat")
	return ok(c, map[string]any{
		"service": "LifeDriveServerApp", "storage_type": "file", "storage_model": "direct-filesystem/v1",
		"drive_mark": driveID, "mimei_data_type_value": fileType,
		"runtime_contract": map[string]any{
			"language": "go", "execution": "ixgo-interpreted", "flat_package": "lapp",
			"module_loading": false, "self_contained_entries": false, "dispatcher": "RunMApp",
		},
		"mutation_contract": map[string]any{
			"work_root": c.workRoot(), "commit": "FilesFlush+MFSetCid", "mix_mmbackup_with_setcid": false,
			"distribution": "private-local", "publish_drive": false, "advertise_provider": false,
		},
		"storage_limit": map[string]any{
			"source": "Leither ds/config Datastore.StorageMax", "owner_managed": true, "restart_required": true,
		},
		"upload_contract": map[string]any{
			"transport": "RunMApp binary args", "chunk_size": uploadInitialChunkSize,
			"min_chunk_size": uploadMinChunkSize, "max_chunk_size": uploadMaxChunkSize,
			"strategy": "adaptive", "resumable_offsets": true,
		},
		"groups": map[string]any{"runtime": runtime, "mimei": mimei, "file": file, "current_file_tree": tree},
		"readiness": map[string]any{
			"file_read": true, "temporary_write": true, "directory_mutation": true, "commit": true,
			"private_development_operations": true, "production_authorization": true,
		},
		"missing": map[string]any{"runtime": []string{}, "mimei": []string{}, "file": []string{}, "current_file_tree": []string{}},
	}), nil
}

func validMID(value string) bool {
	if len(value) < 8 || len(value) > 256 {
		return false
	}
	for _, char := range value {
		if !((char >= 'a' && char <= 'z') || (char >= 'A' && char <= 'Z') ||
			(char >= '0' && char <= '9') || strings.ContainsRune("_-", char)) {
			return false
		}
	}
	return true
}

func entryDriveGetState(c *ctx) (any, error) {
	if failure := versionFailure(c); failure != nil {
		return failure, nil
	}
	mid := c.str("drive_mid")
	if !validMID(mid) {
		return fail(c, "lifedrive.request.invalid_drive_mid", "error.request.invalid_drive_mid", false), nil
	}
	access, err := requireAccess(c, "view", "drive")
	if err != nil || mid != access.driveMID {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	info, err := c.api.GetVar("", "mminfo", mid)
	if err != nil {
		return fail(c, "lifedrive.drive.state_unavailable", "error.drive.state_unavailable", true), nil
	}
	versions, err := c.api.GetVar("", "mmversions", mid)
	if err != nil {
		return fail(c, "lifedrive.drive.state_unavailable", "error.drive.state_unavailable", true), nil
	}
	return ok(c, map[string]any{"drive_mid": mid, "storage_type": "file", "mimei_info": info, "versions": versions}), nil
}

// entryNodeIPs resolves a node id to the addresses it currently answers on.
//
// This is the lookup the node-id gateway needs: a browser on an HTTPS origin
// cannot use these addresses itself, because Leither advertises them as bare
// host:port and a browser blocks http:// subresources from a secure page. The
// gateway calls this, connects on the browser's behalf, and the address never
// reaches the page. See docs/LIFEDRIVE_NODE_ID_GATEWAY.md.
//
// Public by design and public already: TweetWeb serves the same value from its
// own get_node_ips entry. It reveals nothing the DHT does not.
func entryNodeIPs(c *ctx) (any, error) {
	if failure := versionFailure(c); failure != nil {
		return failure, nil
	}
	nodeID := c.str("node_id")
	if !validMID(nodeID) {
		return fail(c, "lifedrive.request.invalid_node_id", "error.request.invalid_node_id", false), nil
	}
	raw, err := c.api.GetVar("", "ips", nodeID)
	if err != nil {
		logError(c, "resolve node %s: %v", nodeID, err)
		return fail(c, "lifedrive.node.unresolved", "error.node.unresolved", true), nil
	}
	list, _ := raw.(string)
	addresses := []string{}
	for _, address := range strings.Split(list, ",") {
		if address = strings.TrimSpace(address); address != "" {
			addresses = append(addresses, address)
		}
	}
	return ok(c, map[string]any{"node_id": nodeID, "addresses": addresses}), nil
}
