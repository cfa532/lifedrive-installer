package lapp

import (
	"fmt"
	"strings"
)

type driveAccess struct {
	authorSID string
	driveMID  string
	userID    string
	version   string
}

func authorize(c *ctx, action, resourceKind string) (*driveAccess, bool, error) {
	appID := c.str("aid")
	if appID == "" || len(appID) > 128 {
		return nil, false, fmt.Errorf("missing app id")
	}
	callerSID := c.str("owner_sid")
	if callerSID == "" {
		callerSID = c.str("sid")
	}
	if callerSID == "" || len(callerSID) > 1024 {
		return nil, false, nil
	}
	author, err := authSID(c)
	if err != nil {
		return nil, false, err
	}
	mid, err := c.api.MMCreate(author, appID, driveExt, driveID, fileType, driveRight)
	if err != nil {
		return nil, false, err
	}
	version := "cur"
	if action == "view" {
		version = "last"
	}
	handle, err := c.api.MMOpen(callerSID, mid, version)
	// A newly granted drive has writable state before its first committed
	// version exists. Verify the same MiMei right against cur so the owner can
	// initialize that first version after signing in.
	if err != nil && version == "last" {
		version = "cur"
		handle, err = c.api.MMOpen(callerSID, mid, version)
	}
	if err != nil {
		return nil, false, nil
	}
	closeHandle(c, handle)
	uidValue, err := c.api.GetVar(callerSID, "userid")
	if err != nil {
		return nil, false, err
	}
	uid, _ := uidValue.(string)
	// Reads stay open: the drive's default right already lets any authenticated
	// UID read. Writes are gated against the installer's device registry, because
	// no Leither call available to the MApp distinguishes an authorized device.
	// See device_registry.go.
	if action != "view" {
		mayModify, registryErr := deviceMayModify(uid)
		if registryErr != nil {
			return nil, false, registryErr
		}
		if !mayModify {
			return nil, false, nil
		}
	}
	return &driveAccess{authorSID: author, driveMID: mid, userID: uid, version: version}, true, nil
}

func requireAccess(c *ctx, action, resourceKind string) (*driveAccess, error) {
	access, allowed, err := authorize(c, action, resourceKind)
	if err != nil {
		return nil, err
	}
	if !allowed {
		return nil, fmt.Errorf("permission denied")
	}
	return access, nil
}

func entryAccessCheck(c *ctx) (any, error) {
	if failure := versionFailure(c); failure != nil {
		return failure, nil
	}
	action := c.str("action")
	resourceKind := c.str("resource_kind")
	if !contains([]string{"view", "modify", "publish", "delete", "manage_access"}, action) ||
		!contains([]string{"drive", "folder", "file", "mimei"}, resourceKind) || c.str("aid") == "" {
		return fail(c, "lifedrive.request.invalid_authorization_scope", "error.request.invalid_authorization_scope", false), nil
	}
	access, allowed, err := authorize(c, action, resourceKind)
	if err != nil {
		logError(c, "access check failed request_id=%s: %v", requestID(c), err)
		allowed = false
	}
	if !allowed {
		reason := "lifedrive.security.permission_denied"
		if c.str("sid") == "" && c.str("owner_sid") == "" {
			reason = "lifedrive.auth.required"
		}
		return ok(c, map[string]any{
			"allowed": false, "decision": "deny", "reason_code": reason,
			"security_backend": "leither-native/v1", "action": action, "resource_kind": resourceKind,
		}), nil
	}
	return ok(c, map[string]any{
		"allowed": true, "decision": "allow", "reason_code": "lifedrive.security.native_mimei_right",
		"security_backend": "leither-native/v1", "action": action, "resource_kind": resourceKind,
		"uid": access.userID, "drive_mid": access.driveMID, "required_version": access.version,
	}), nil
}

func entryAccessGetSecurityMode(c *ctx) (any, error) {
	if failure := versionFailure(c); failure != nil {
		return failure, nil
	}
	return ok(c, map[string]any{
		"mode": "key", "backend_version": "leither-key/v1", "status": "device_key_authentication_active",
		"owner_device_proof": true, "short_lived_passports": true, "short_lived_sessions": true, "delegated_access": false,
		"key_type": "sodiumv2", "credential_scope": "per-device", "password_login": false,
		"native_leither_enforcement": true, "protected_operations": "MiMei rights enforced for every file operation",
		"private_network_only": true, "disclosure_key": "security.leither.native_owner",
	}), nil
}

func entryHealth(c *ctx) (any, error) {
	if failure := versionFailure(c); failure != nil {
		return failure, nil
	}
	return ok(c, map[string]any{
		"service": "LifeDriveServerApp", "server_version": serverVersion, "status": "ok",
		"development_stage": "file-storage-api", "storage_authority": "file-type-mimei",
		"runtime": "leither-go-mapp", "module_loading": false,
		"mutation_commit": "FilesFlush+MFSetCid", "database_mimei_allowed": false,
		"security_mode": "leither-key/v1", "protected_operations": "signed device PPT, expiring SID, and MiMei rights",
		"upload_transport": "leither-hprose-chunks", "upload_chunk_size": uploadInitialChunkSize,
		"upload_max_chunk_size": uploadMaxChunkSize, "upload_chunk_strategy": "adaptive",
		"data_distribution": "private-local", "drive_published": false, "provider_advertised": false,
	}), nil
}

func trueMap(names ...string) map[string]bool {
	result := map[string]bool{}
	for _, name := range names {
		result[name] = true
	}
	return result
}

func entryServerCapabilities(c *ctx) (any, error) {
	if failure := versionFailure(c); failure != nil {
		return failure, nil
	}
	runtime := trueMap("BELoginAsAuthor", "GetVar", "Debug", "Error")
	mimei := trueMap("MMCreate", "MMOpen", "MMOpenUrl", "MMClose")
	file := trueMap("MFOpenTempFile", "MFTemp2Files", "MFSetCid", "MFSetData", "MFGetData", "MFGetSize", "MFStat", "MFGetMimeType")
	tree := trueMap("FilesCopy", "FilesLs", "FilesMkdir", "FilesRm", "FilesMv", "FilesFlush", "FilesStat")
	return ok(c, map[string]any{
		"service": "LifeDriveServerApp", "storage_type": "file", "storage_model": "direct-filesystem/v1",
		"drive_mark": driveID, "mimei_data_type_value": fileType,
		"runtime_contract": map[string]any{
			"language": "go", "execution": "ixgo-interpreted", "flat_package": "lapp",
			"module_loading": false, "self_contained_entries": false, "dispatcher": "RunMApp",
		},
		"mutation_contract": map[string]any{
			"work_root": driveWorkRoot, "commit": "FilesFlush+MFSetCid", "mix_mmbackup_with_setcid": false,
			"distribution": "private-local", "publish_drive": false, "advertise_provider": false,
		},
		"storage_limit": map[string]any{
			"source": "Leither ds/config Datastore.StorageMax", "owner_managed": true, "restart_required": true,
		},
		"upload_contract": map[string]any{
			"transport": "RunMApp binary args", "chunk_size": uploadInitialChunkSize,
			"min_chunk_size": uploadMinChunkSize, "max_chunk_size": uploadMaxChunkSize,
			"strategy": "adaptive", "resumable_offsets": true,
		},
		"groups": map[string]any{"runtime": runtime, "mimei": mimei, "file": file, "current_file_tree": tree},
		"readiness": map[string]any{
			"file_read": true, "temporary_write": true, "directory_mutation": true, "commit": true,
			"private_development_operations": true, "production_authorization": true,
		},
		"missing": map[string]any{"runtime": []string{}, "mimei": []string{}, "file": []string{}, "current_file_tree": []string{}},
	}), nil
}

func validMID(value string) bool {
	if len(value) < 8 || len(value) > 256 {
		return false
	}
	for _, char := range value {
		if !((char >= 'a' && char <= 'z') || (char >= 'A' && char <= 'Z') ||
			(char >= '0' && char <= '9') || strings.ContainsRune("_-", char)) {
			return false
		}
	}
	return true
}

func entryDriveGetState(c *ctx) (any, error) {
	if failure := versionFailure(c); failure != nil {
		return failure, nil
	}
	mid := c.str("drive_mid")
	if !validMID(mid) {
		return fail(c, "lifedrive.request.invalid_drive_mid", "error.request.invalid_drive_mid", false), nil
	}
	if _, err := requireAccess(c, "view", "drive"); err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	info, err := c.api.GetVar("", "mminfo", mid)
	if err != nil {
		return fail(c, "lifedrive.drive.state_unavailable", "error.drive.state_unavailable", true), nil
	}
	versions, err := c.api.GetVar("", "mmversions", mid)
	if err != nil {
		return fail(c, "lifedrive.drive.state_unavailable", "error.drive.state_unavailable", true), nil
	}
	return ok(c, map[string]any{"drive_mid": mid, "storage_type": "file", "mimei_info": info, "versions": versions}), nil
}
