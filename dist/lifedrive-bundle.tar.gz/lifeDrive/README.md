# LifeDriveServerApp

LifeDriveServerApp is the Leither-hosted backend for the Inoku foreground clients. It is one flat Go package named `lapp`. Leither compiles its source with the `ixgo` interpreter and calls the exported `RunMApp` dispatcher for every entry.

## Runtime contract

- Interpreted Go source only; this is not a native binary or a Leither server plugin.
- One flat `lapp` package with no subpackages, package initializers, downloaded modules, or third-party runtime dependencies.
- `RunMApp` dispatches entries to ordinary Go functions. Internal entry reuse stays inside the same invocation and does not recursively compile another MApp request.
- File-type MiMei only for authoritative persistence.
- No database-style `Get`, `Set`, hash, list, set, or sorted-set persistence.
- Normal storage reads use committed `last` or an explicit immutable version.
- Privileged operations pass through `access_check`, require an expiring native Leither SID, and fail closed unless that identity can open the drive with the required MiMei rights.
- Responses use the LifeDrive v1 envelope and never serialize raw exceptions or requests.

The ordinary Go compiler may be used for syntax and type checking. Leither remains the only deployed server dependency.

## Entries

| Entry | Exposure | Purpose |
|---|---|---|
| `health` | Public | Basic service liveness and architecture identity |
| `server_capabilities` | Public | Report the installed Go-MApp and `lapi` contract required by LifeDrive |
| `access_get_security_mode` | Public | Disclose the active native-security state |
| `access_check` | Internal | Central fail-closed authorization decision boundary |
| `drive_get_state` | Protected | Read MiMei information and version state after authorization |
| `drive_open` | Development protected | Resolve the deterministic File MiMei marked `lifeDrive` |
| `drive_list` | Development protected | Walk the committed directory tree in `last` |
| `folder_create` | Development protected | Create a directory path in `/appDrive`, flush the tree, and commit its CID |
| `upload_begin` | Protected | Validate a destination path, authorize the owner, and open a temporary upload file |
| `upload_write` | Protected | Write a negotiated binary chunk at an authoritative offset with `MFSetData` |
| `upload_complete` | Protected | Attach the verified file under `/appDrive`, flush the tree, and commit its CID to the File MiMei |
| `upload_abort` | Protected | Close an abandoned temporary upload |
| `file_get_info` | Development protected | Inspect a committed file by path |
| `file_read` | Development protected | Read a bounded file range from `last` with `MFGetData` |
| `object_move` | Development protected | Rename or move a committed file or directory by canonical path |
| `object_copy` | Development protected | Copy a committed file or directory to a new canonical path |
| `object_trash` | Development protected | Move an item into the hidden drive trash and commit the updated tree |
| `trash_list` | Development protected | List reversible top-level trash entries without a metadata catalog |
| `trash_restore` | Development protected | Restore a trash entry to its original or selected parent |
| `object_purge` | Development protected | Recursively remove one trash entry and commit the updated tree |

`access_check` derives the deterministic drive with the application author identity, then calls `MMOpen` with the browser caller's SID. Views require access to `last`; mutations and deletion require access to `cur`. The caller UID is obtained from that same SID. A missing, expired, or unauthorized session is denied without falling back to an application secret.

## File MiMei layout

The deterministic root is created or resolved with `MMCreate(authorSid, request.aid, "lifedrive.app-drive/v1", "lifeDrive", 1, 0x07276704)`. The application ID comes from the active Leither runtime request, so each publisher's `lifeDrive` application resolves its own household drive. A native node-local account is registered once and granted rights to that MiMei by `lifeDrive-owner.sh`.

The MiMei directory tree is the data model. A visible path such as `/Family photos/picnic.jpg` is the stored file path, and directory nesting is the parent-child relationship. There is no global catalog, per-object JSON, relationship JSON, or separate payload MiMei in the fundamental drive layer.

LifeDrive uses the node Files tree at `/appDrive` as its single mutable assembly surface. Folder creation, upload completion, move, copy, trash, restore, and purge mutate paths below that root, call `FilesFlush` once for the completed mutation, and pass the resulting root CID to `MFSetCid`. These operations do not also call `MMBackup`: direct File-MiMei `cur` mutation plus `MMBackup` is a separate valid Leither workflow, but mixing both commit paths in one drive can commit a stale tree.

Upgrade note: a node that ran an earlier LifeDrive build may already have differences between its committed `last` tree and `/appDrive`, because older folder, move, and copy entries used the separate `cur`/`MMBackup` workflow. Before deploying this revision over real data, the operator must compare those trees and rebuild `/appDrive` from the intended committed version when they differ. The application does not guess which divergent tree should win.

The web client sends file bytes through Leither's configured `/webapi/` endpoint. `upload_begin` opens a Leither temporary file, `upload_write` carries binary chunks in `RunMApp` arguments, and `upload_complete` validates the assembled size before referencing it under `/appDrive`, flushing once, and assigning the resulting root CID to the File MiMei. Ordinary lists and reads therefore never expose an unfinished upload. The MApp negotiates an adaptive upload range: the browser starts at 1 MiB, may grow successful fast transfers to 4 MiB, and reduces the next chunk after a slow request. The server rejects chunks above 4 MiB.

Trash is implemented without JSON metadata. Each trashed root is moved to `/.lifedrive-trash/<encoded-original-path>`. The encoded name makes the original path reversible, keeps trashed folder subtrees intact, and prevents the hidden trash directory from appearing in normal drive listings.

## Private development client

When served through a Leither-bound domain, the web client reads the application ID and provider addresses from the bootstrap page's `window.getParam()` block. The selected node and its configured Leither port are used for metadata, reads, mutations, and uploads through `/webapi/`.

The production browser build follows TweetWeb's proven Leither entry layout: top-level `index.html` with inline CSS and a top-level `lifedrive.js` browser object. LifeDrive uses `lifedrive.js` instead of TweetWeb's `index_entry.js` because Tahoe V0.24.05 derives the same entry short name, `index`, from `index.html`, `index_entry.js`, and `index.css`, then rejects the package. A Leither-bound domain supplies TweetWeb's provider-selecting `window.getParam()` bootstrap. Tahoe's direct `http://<node-ip>:<port>/entry?aid=<app-mid>&ver=last` response instead supplies `index.html` without that bootstrap or asset rebasing, so LifeDrive's small inline loader reads `aid` and `ver` from the URL and loads `/mm/<app-mid>:last/lifedrive.js` itself. No node-root route or `lifeDrive` URL prefix is required.

Local development falls back to the current gen8 private-network target:

```text
RPC endpoint: http://192.168.99.1:8002/webapi/
Application:  FKI2uZtAp6ZjUeecxQ4PvBq4bvK
Version:      last
RPC method:   RunMApp
```

Each MApp call has the form `RunMApp(entry, request, args)`. The request includes the application ID, `ver: "last"`, LifeDrive API version, request ID, and the SID returned by native `Login(username, password)`. Upload chunks use the same call with a `Uint8Array` in `args` and an explicit offset in the request.

This private address is intentionally temporary. It is reachable only from a network that can route to gen8 and cannot be called by a normal public HTTPS page because of browser mixed-content and private-network restrictions.

## Leither API mapping

The capability entry recognizes the installed API families verified in the local Leither source:

- MiMei lifecycle: `MMCreate`, `MMOpen`, `MMClose`, `MMBackup`, `MMRelease`, `MMRestore`, `MMDelVers`.
- File sessions: `MMOpenUrl` for committed `mm://<mid>:last/...` reads. Uploads use `MFOpenTempFile`, `MFSetData`, `MFTemp2Files`, `FilesFlush`, and `MFSetCid` inside the MApp.
- File data: `MFSetData`, `MFGetData`, `MFGetSize`, `MFStat`, `MFGetMimeType`, and `MFReaddir`.
- Mutable file tree: current `Files*` names and legacy `FS*` names are detected separately so the adapter can be frozen against the installed runtime.
- Distribution: `MiMeiPublish`, `MiMeiProvide`, `MiMeiFindProvs`, `MiMeiSync`, `MiMeiIsProvider`, `MiMeiUnprovide`, and `MiMeiUnpublish` are probed independently. LifeDrive does not yet expose synchronization to clients. Any future synchronization entry must resolve the owner/provider first and skip `MiMeiSync` when the MiMei is owned by the same node; V0.24.02 can panic when self-sync has no other provider.

File-type MiMei uses the runtime data-type value `1`. This constant will be used only inside the future Leither adapter and will never be accepted from a client request.

## Deployment

The public npm launcher is the shortest installation path and may be run from any directory on the Leither server:

```bash
npx --yes @inoku/lifedrive
```

It first requires a running Leither service and discovers that process's executable directory automatically. If multiple Leither services intentionally run on one server, select the target explicitly:

```bash
npx --yes @inoku/lifedrive --leither-root /path/to/leither
```

The npm package includes its versioned installer, checksum, and LifeDrive bundle. The launcher checks for Leither before reading those local package assets, so setup does not require a second download from GitHub's release-asset host. A node without npm can invoke the GitHub bootstrap directly; the bootstrap performs the same running-service check and automatic root discovery:

```bash
curl -fLO https://github.com/cfa532/lifedrive-installer/releases/latest/download/lifedrive-install.sh
chmod +x lifedrive-install.sh
./lifedrive-install.sh
```

The private source repository publishes these assets and synchronizes the dependency-free npm launcher to the separate public `cfa532/lifedrive-installer` repository. The release workflow requires a `LIFEDRIVE_RELEASE_TOKEN` repository secret with permission to push source and workflow changes and create releases in that public repository; the source repository's default workflow token cannot publish across repositories.

The npm package is `@inoku/lifedrive`. The public repository's `publish-npm.yml` workflow publishes the package when a LifeDrive release is created. npm trusted publishing must authorize the public repository and that workflow; the workflow requests an OIDC identity and publishes with provenance. The npm scope and first package publication must be established once by the Inoku npm owner before automatic releases can continue.

The installer uses the built-in AV1 endpoint `https://registry.inoku.uk/v1/usernames/register`; ordinary users are never asked to supply an internal service URL, AV1 login, or developer-issued enrollment code. On a fresh registered installation, setup asks once for the LifeDrive username and password and checks `<username>` with AV1 before beginning the lengthy application publication. It then publishes the app, creates the owner with that same username, and immediately asks AV1 to reserve and bind `<username>.inoku.uk` to the returned app MID. On a rerun where the local owner exists but domain registration was not completed, setup distinguishes the saved local owner from the still-available public address instead of reporting the owner name itself as available. The final reservation rechecks availability under AV1's registration lock. Successful registered setup ends by printing `https://<username>.inoku.uk/` as the user's LifeDrive entrance. `--registry-url` remains available for development deployments. `--skip-domain` completes a fully usable local installation without a public address and prints a direct `http://<LAN-IP>:<Leither-port>/entry?aid=<app-mid>&ver=last` URL. `--recover` resets the saved owner's password through the retained node identity and restores the existing drive grant without changing the app MID or domain.

The deployed Leither application name is `lifeDrive`. On the current node, the Leither root is `/home/pi/demo`, the application source directory is `/home/pi/demo/lifeDrive`, and the operator script is `/home/pi/demo/lifeDrive.sh`.

Deployment follows this order:

1. Request the MiMei service required by the target node.
2. Upload the `lifeDrive` application directory with `lapp uploadapp`.
3. Back up the uploaded application with `lapp backup -a lifeDrive`.
4. Query `lapp showapp --json` with the same publisher identity and extract the authoritative `app_id`.
5. Publish that `app_id` with the same publisher identity using `mimei publish --mid <appId>`.

The application `appId` is determined by the publisher identity and application directory name and becomes publishable after backup. The value passed to `mimei publish --mid` must therefore be queried after the successful backup; it must not be hardcoded or copied from another publisher's application.

The included `lifeDrive.sh` implements this sequence. It defaults to the node identity from `hostkey.cfg`; an existing installation created with a separate publisher key can set `LIFEDRIVE_PUBLISHER_KEY` and `LIFEDRIVE_PUBLISHER_CERT`. After a successful keyed publication, the script saves only the key path in the protected `lifeDrive.publisher-key` state file. Publication and owner recovery automatically reuse that path. If the selected identity's derived app MID disagrees with the saved app MID, publication stops before upload instead of creating an accidental second application.

`@inoku/lifedrive` is a small, self-contained Node.js launcher package holding `lifedrive-install.sh`, the checksum, and the matching release bundle. It requires a running Leither service, then executes the packaged bootstrap without contacting GitHub. The bootstrap independently confirms that service, derives the Leither root from its executable, verifies the bundled archive SHA-256, and installs the application beneath the detected root. `--leither-root` is only needed to disambiguate multiple running instances. `lifeDrive-setup.sh` coordinates the AV1 availability check, app publication, local owner creation, immediate AV1 reservation/domain binding, and removal of any retired 8011 companion. Setup and recovery are terminal operations on the physically controlled node; there is no temporary web setup service.

Globally unique username checking, reservation, and domain binding execute on AV1 under AV1's retained program identity. The read-only check sends only the normalized username. The final self-service registration sends AV1 only that username and the published app MID. It never sends the owner password, SID, UID, publisher key, or node host key. AV1 rate-limits requests and serializes the final first-claim uniqueness check. If final binding fails after local owner creation, the local owner remains usable and setup can retry the idempotent reservation for the same app MID.

`lifeDrive-owner.sh` does not assume that an interactive shell loaded NVM. It checks `LIFEDRIVE_NODE_PATH`, then the executable `node` on `PATH`, then installed NVM versions in the operating-system account's real home directory. This remains correct when the Leither work directory is a mounted volume or symlink, and keeps setup working from SSH and system services. An unusual installation can set `LIFEDRIVE_NODE_PATH` explicitly.

On Leither V0.24.04, native account creation uses `auth.SetUserInfo(authorSid, {newname, newpass})`. This binds the login to the node identity, so the helper obtains that UID with `lapi.GetVar(authorSid, "userid")`; the Lua `auth` module does not expose `Login`. The CLI wraps the Lua return value under `data.result`; the helper validates that envelope and reports a safe native error before saving owner state. It must not silently treat a JSON error envelope as a successful command.

`lpki runscript -r` consumes semicolon-delimited `key=value` fields rather than JSON or URL query encoding. Because a password may itself contain semicolons, equals signs, spaces, or Unicode, the helper converts all user-controlled values to hexadecimal fields and decodes their UTF-8 bytes inside Lua. This preserves the owner's unrestricted password choice while keeping it separate from Leither's injected SID.

LifeDrive does not impose a password-length rule. The owner controls the physical node and chooses the local account password, including accepting the consequences of a short or empty value. If the installed Leither runtime has its own credential constraint, owner setup reports that native error rather than substituting a LifeDrive policy.

This application-package backup is separate from the File-type MiMei backups used as commit boundaries for users' drive data.

A private key or passport used for deployment must remain outside the application directory and repository. The deployment script may refer to a configured key basename or path, but key and certificate material must never be copied into this directory or committed, regardless of filename.

## Current limitation

This revision implements native owner login and direct folder creation, upload, list, read, rename, move, copy, trash, restore, and permanent deletion. Quotas, persisted resumable uploads, delegated sharing, anonymous upload links, and multi-server owner identity remain future work. Losing the browser session or password does not make data unreadable; the physically owned node and its publisher/host key can rerun owner setup to recover the grant.
