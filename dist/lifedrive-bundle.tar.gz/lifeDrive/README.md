# LifeDriveServerApp

LifeDriveServerApp is the Leither-hosted backend for the Inoku foreground clients. It is one flat Go package named `lapp`. Leither compiles its source with the `ixgo` interpreter and calls the exported `RunMApp` dispatcher for every entry.

## Runtime contract

- Interpreted Go source only; this is not a native binary or a Leither server plugin.
- One flat `lapp` package with no subpackages, package initializers, downloaded modules, or third-party runtime dependencies.
- `RunMApp` dispatches entries to ordinary Go functions. Internal entry reuse stays inside the same invocation and does not recursively compile another MApp request.
- File-type MiMei only for authoritative persistence.
- No database-style `Get`, `Set`, hash, list, set, or sorted-set persistence.
- Normal storage reads use committed `last` or an explicit immutable version.
- Privileged operations pass through `access_check`, require an expiring native Leither SID, and fail closed unless that identity can open the drive with the required MiMei rights.
- A newly granted empty drive may verify the same MID's `cur` right when `last` does not exist; the web client then calls `drive_open` to create the first committed root before normal reads.
- Responses use the LifeDrive v1 envelope and never serialize raw exceptions or requests.

The ordinary Go compiler may be used for syntax and type checking. Leither remains the only deployed server dependency.

## Entries

| Entry | Exposure | Purpose |
|---|---|---|
| `health` | Public | Basic service liveness and architecture identity |
| `server_capabilities` | Public | Report the installed Go-MApp and `lapi` contract required by LifeDrive |
| `android_update_info` | Public | Report the server release's direct Android update flag, version and package MiMei |
| `android_update_providers` | Public | Resolve providers for the one advertised Android package MiMei |
| `android_update_publish` | Public, fixed input | Import and publish only the APK CID embedded in this server release |
| `access_get_security_mode` | Public | Disclose the active native-security state |
| `access_check` | Internal | Central fail-closed authorization decision boundary |
| `drive_get_state` | Protected | Read MiMei information and version state after authorization |
| `storage_get` | Owner protected | Read the active Leither datastore limit and optional runtime usage without exposing the config path |
| `storage_set_limit` | Owner protected | Atomically update local `Datastore.StorageMax` in whole GB and report that the Leither service or server must restart |
| `profile_get` | Owner protected | Read the authenticated owner's JSON profile from its deterministic File-type MiMei |
| `profile_set` | Owner protected | Commit profile JSON and maintain the avatar CID reference with `MMAddRef`/`MMDelRef` |
| `profile_avatar_upload` | Owner protected | Stream avatar bytes to a temporary file and convert the completed image to IPFS |
| `profile_avatar_abort` | Owner protected | Close an abandoned avatar upload handle |
| `drive_open` | Development protected | Resolve the deterministic File MiMei marked `lifeDrive` |
| `drive_list` | Development protected | List a committed folder with `path` and `recursive=false`; recursive listing remains available |
| `folder_create` | Development protected | Create a directory path in the drive's `cur` tree, flush it, and back it up |
| `upload_begin` | Protected | Validate a destination path, authorize the owner, and open a temporary upload file |
| `upload_write` | Protected | Write a negotiated binary chunk at an authoritative offset with `MFSetData` |
| `upload_complete` | Protected | Attach the verified file in the drive's `cur` tree, flush it, and back it up |
| `upload_abort` | Protected | Close an abandoned temporary upload |
| `file_get_info` | Development protected | Inspect a committed file by path |
| `file_read` | Development protected | Read a bounded file range from `last` with `MFGetData` |
| `object_move` | Development protected | Rename or move a committed file or directory by canonical path |
| `object_copy` | Development protected | Copy a committed file or directory to a new canonical path |
| `object_trash` | Development protected | Move an item into the hidden drive trash and commit the updated tree |
| `trash_list` | Development protected | List reversible top-level trash entries without a metadata catalog |
| `trash_restore` | Development protected | Restore a trash entry to its original or selected parent |
| `object_purge` | Development protected | Recursively remove one trash entry and commit the updated tree |

## Direct Android updates

The `direct` Android flavor follows Tweet Android's update architecture: it asks
the installed server release for upgrade metadata, resolves a published package
MiMei, and gives the transfer to Android `DownloadManager`. The `googlePlay`
flavor contains neither the updater implementation nor Android's package-install
permission.

The authoritative flag and package metadata live in the published
`lifedrive-release.json`:

```json
{
  "androidUpdate": {
    "enabled": true,
    "versionCode": 18,
    "versionName": "0.1.16",
    "size": 12345678,
    "sha256": "64-lowercase-hex-characters",
    "cid": "the-apk-ipfs-cid",
    "mission": "minor"
  }
}
```

For publication, put the signed APK at
`<Leither root>/lifeDrive.android-update.apk` on the application-publishing
node, import it with `./Leither ipfs add lifeDrive.android-update.apk`, and
require the returned CID to match the release manifest. Publish the server
release containing that exact size, SHA-256 and CID, then invoke
`android_update_publish` on that node. The entry takes no package argument: it
requires the fixed staging file's size and SHA-256 to match the release,
requires that same CID to exist in the node's content store, attaches it to the
deterministic package MiMei, and publishes that MiMei. The staging APK can be
removed afterward.

The official LifeDrive publisher's package MiMei is
`JddQDJa_hCrWIdWoO6tZ48oJ1Zd`. LifeDrive 0.7.47 advertises Android 0.1.22 (24)
there. The October 3 localization refresh retains Android 0.1.22 (24), with
CID `QmXcQs1bTZzZwRkNw4Yuv7UWC266mN32R7aq6m6nRigizP`, size
6,296,269 bytes, and SHA-256
`e147a4e669a7afb1d77dc890e2546bcfab84589d822f7949fb68140983611daa`.
This direct-package metadata refresh does not replace the immutable npm
0.7.47 installer or its source tag.
LifeDrive 0.7.54 advertises Android 0.1.23 (26), which carries the fix for a
video-playback deadlock (a request no longer waits for the main thread while
MediaPlayer holds it), under CID `QmTuVZ1VyxJJoRyPLDYBsfWGxF4VwXpVTUnEPwTAW9z7WU`,
size 6,296,269 bytes, and SHA-256
`e9226f0532589faa0f6169174cadf9916881e8aee7883b5397737f8eb19b8f5f`. The Play
flavor's build code is one above the direct one (27).
The October 6 refresh keeps Android 0.1.23 (26) but carries the later Android changes
(the `drive.lepan.org` node lookup and readable share-link errors) under CID
`QmXWofquFLWaxT8fWX1D1wHCLe84jgoRRTc8L8RATBQnJC`, size 6,296,269 bytes, and
SHA-256 `64b3d98c6fc33b197a837558373256e46db1d50bd86c41cd888b859c6135303e`. The
version code is unchanged, so devices already on 26 are not offered it; new installs
and reinstalls get the refreshed package.
The October 23 release advances the direct APK to Android **0.1.25 (28)**,
CID `QmPvEFac5zCk8EXkv2faJEc8vdGa4BXjP2eG6qmRiiC1Sy`, size
27,324,340 bytes, SHA-256
`f392a472974c9cde4b03ce871c2e61f6c5b73f65780d8e9da086fc525dadde24`.
It is an optimized, non-debuggable Release build signed with the existing direct
certificate so older direct installations can upgrade. Google Play uses build 32.
This APK metadata update does not replace the immutable npm installer release.
LifeDrive 0.7.43 had published Android 0.1.17 (19) under CID
`QmeQphu1BcPwrYfdn7Qdm7Ss8HRa75w1FVkD3VPXQFVB7J`.
`android_update_providers` orders public IPv4 providers before LAN providers,
then public IPv6 and finally overlay or other private routes. This keeps Android
`DownloadManager` from choosing an unreachable CGNAT or VPN address when a
direct public provider is available.

Clients only offer a greater Android `versionCode`. Before installation they
verify the completed download's byte count, SHA-256, Android package name and
version code. Android still enforces the signing identity. Set `enabled` to
`false` until the signed APK and final metadata are ready.

`access_check` derives the deterministic drive with the application author identity, then calls `MMOpen` with the browser caller's SID. Views require access to `last`; mutations and deletion require access to `cur`. The caller UID is obtained from that same SID. A missing, expired, or unauthorized session is denied without falling back to an application secret.

## File MiMei layout

The deterministic root is created or resolved with `MMCreate(authorSid, request.aid, "lifedrive.app-drive/v1", "lifeDrive", 1, 0x07276704)`. The application ID comes from the active Leither runtime request, so each publisher's `lifeDrive` application resolves its own household drive. `lifeDrive-owner.sh` creates a separate Ed25519 `sodiumv2` identity for each authorized device and grants its globally stable key UID rights to that MiMei.

The MiMei directory tree is the data model. A visible path such as `/Family photos/picnic.jpg` is the stored file path, and directory nesting is the parent-child relationship. There is no global catalog, per-object JSON, relationship JSON, or separate payload MiMei in the fundamental drive layer.

LifeDrive uses the node Files tree at `/appDrive` as its single mutable assembly surface. Folder creation, upload completion, move, copy, trash, restore, and purge mutate paths below that root, call `FilesFlush` once for the completed mutation, and pass the resulting root CID to `MFSetCid`.

`MFSetCid` is the whole commit: it backs the version up internally, returns the new version number, and `last` resolves to the flushed tree immediately. Verified on Leither V0.24.12 - the CID returned by `FilesFlush("/appDrive")` appears verbatim as the drive MiMei's newest version.

Addressing `mm://<drive-mid>:cur/<path>` directly was tried and reverted. Mutations do reach the drive's own tree that way, but `FilesFlush` on a mimei `cur` path fails ("OpenMM ver is empty") because `cur` is not a materialized version, so the commit can never complete. Do not mix the two: committing a `cur` mutation and a staged `MFSetCid` into one drive leaves a stale committed tree.

**Never add `MMBackup` to this path.** `MMBackup` snapshots the MiMei's own `cur` content, which overwrites the CID `MFSetCid` just committed and silently replaces the tree with an empty one. Every listing then returns zero objects while the staging tree still holds the data - a failure that looks like a read bug and is not.

`MMBackup` on the drive is also author-only. Verified on V0.24.12: a device holding the `0x07276704` grant receives `1101:Permission denied`, as does an ungranted device; only the author session commits. Drive mutations therefore run on the author session, and per-device grants cannot gate them - see `device_registry.go` for where that decision is made instead.

The household drive is private-local. LifeDrive never calls `MiMeiPublish`, `MiMeiProvide`, or provider advertisement for the drive MiMei or uploaded files. The separately published application AppID makes the web application reachable; it does not publish the owner's File MiMei.

The owner-only storage entries locate `ds/config` beside the running Leither executable, read only `Datastore.StorageMax`, and never expose the path or any other configuration value. This is a node-wide datastore limit for all Leither data, including LifeDrive, rather than a per-drive quota. A new whole-GB value is written by replacing only the JSON string in an atomic same-directory rename. The setting takes effect after the physical node owner restarts the Leither service through its existing service manager, or restarts the server. The MApp never attempts either action.

Upgrade note: a node that ran a `/appDrive` build keeps that directory in its node Files tree. The application no longer reads or writes it. Because the staged tree and the drive's `cur` tree were bound to the same directory object, `/appDrive` on such a node continues to reflect the drive's contents; it is a stale second name, not a second copy, and removing it is an operator decision rather than an application one. A node installed on this revision never creates it.

The web client sends file bytes through Leither's configured `/webapi/` endpoint. `upload_begin` opens a Leither temporary file, `upload_write` carries binary chunks in `RunMApp` arguments, and `upload_complete` validates the assembled size before referencing it in the drive's `cur` tree, flushing once, and backing the drive up. Ordinary lists and reads therefore never expose an unfinished upload. The MApp negotiates an adaptive upload range: the browser starts at 1 MiB, may grow successful fast transfers to 4 MiB, and reduces the next chunk after a slow request. The server rejects chunks above 4 MiB.

Trash is implemented without JSON metadata. Each trashed root is moved to `/.lifedrive-trash/<encoded-original-path>`. The encoded name makes the original path reversible, keeps trashed folder subtrees intact, and prevents the hidden trash directory from appearing in normal drive listings.

## Private development client

When served through a Leither-bound domain, the web client reads the application ID and provider addresses from the bootstrap page's `window.getParam()` block. The selected node and its configured Leither port are used for metadata, reads, mutations, and uploads through `/webapi/`.

The production browser build follows TweetWeb's proven Leither entry layout: top-level `index.html` with inline CSS and a top-level `lifedrive.js` browser object. LifeDrive uses `lifedrive.js` instead of TweetWeb's `index_entry.js` because Tahoe V0.24.05 derives the same entry short name, `index`, from `index.html`, `index_entry.js`, and `index.css`, then rejects the package. A Leither-bound domain supplies TweetWeb's provider-selecting `window.getParam()` bootstrap. Tahoe's direct `http://<node-ip>:<port>/entry?aid=<app-mid>&ver=last` response instead supplies `index.html` without that bootstrap or asset rebasing, so LifeDrive's small inline loader reads `aid` and `ver` from the URL and loads `/mm/<app-mid>:last/lifedrive.js` itself. No node-root route or `lifeDrive` URL prefix is required.

Local development falls back to the current gen8 private-network target:

```text
RPC endpoint: http://192.168.99.1:8002/webapi/
Application:  FKI2uZtAp6ZjUeecxQ4PvBq4bvK
Version:      last
RPC method:   RunMApp
```

Each MApp call has the form `RunMApp(entry, request, args)`. The request includes the application ID, `ver: "last"`, LifeDrive API version, request ID, and the SID returned by `LoginWithPPT`. The browser signs a 15-minute `CertFor=Self` PPT with its non-exportable device key, verifies that `GetVar(sid, "userid")` matches the expected key UID, and then uses Leither's one-hour SID. Upload chunks use the same call with a `Uint8Array` in `args` and an explicit offset in the request. WebCrypto Ed25519 and the `wss:` authentication endpoint require HTTPS (or localhost); `--skip-domain` deployments therefore need a trusted TLS proxy for browser login.

This private address is intentionally temporary. It is reachable only from a network that can route to gen8 and cannot be called by a normal public HTTPS page because of browser mixed-content and private-network restrictions.

## Leither API mapping

The capability entry recognizes the installed API families verified in the local Leither source:

- MiMei lifecycle: `MMCreate`, `MMOpen`, `MMClose`, `MMBackup`, `MMRelease`, `MMRestore`, `MMDelVers`.
- File sessions: `MMOpenUrl` for committed `mm://<mid>:last/...` reads. Uploads use `MFOpenTempFile`, `MFSetData`, `MFTemp2Files`, `FilesFlush`, and `MFSetCid` inside the MApp.
- File data: `MFSetData`, `MFGetData`, `MFGetSize`, `MFStat`, `MFGetMimeType`, and `MFReaddir`.
- Mutable file tree: current `Files*` names and legacy `FS*` names are detected separately so the adapter can be frozen against the installed runtime.
- Distribution: `MiMeiPublish`, `MiMeiProvide`, `MiMeiFindProvs`, `MiMeiSync`, `MiMeiIsProvider`, `MiMeiUnprovide`, and `MiMeiUnpublish` are probed independently. LifeDrive does not yet expose synchronization to clients. Any future synchronization entry must resolve the owner/provider first and skip `MiMeiSync` when the MiMei is owned by the same node; V0.24.02 can panic when self-sync has no other provider.

File-type MiMei uses the runtime data-type value `1`. This constant will be used only inside the future Leither adapter and will never be accepted from a client request.

## Deployment

The public npm launcher is the shortest installation path and may be run from any directory on the Leither server:

```bash
npx --yes @inoku/lepan
```

An existing key-auth installation can be upgraded with the same package. This path preserves authorized devices, application MID, registered address, and File MiMei data:

```bash
npx --yes @inoku/lepan@latest --upgrade
```

Fresh installation discovers and reuses a running Leither node. If none is running, it can start a selected existing node or download, verify, initialize, and start Leither from the official distribution. The default new-node directory is `~/.local/share/leither`. During fresh setup, the installer reports the selected filesystem's available space and asks for a node-wide `StorageMax` in whole decimal gigabytes, defaulting to 100 GB. `--storage-max-gb` and `LIFEDRIVE_STORAGE_MAX_GB` support unattended fresh setup. A value above current free space is rejected. Linux/macOS setup starts the new node to create its datastore, writes the selected limit, then restarts that newly provisioned managed node and verifies readiness. Existing nodes and upgrades are not changed. Upgrade and device-management operations still require a running node. Select another installation directory or choose among multiple running nodes explicitly:

Fresh Linux/macOS installations keep LePan application files in `<Leither root>/lepan` (by default `~/.local/share/leither/lepan`). This also applies to the macOS setup package. The folder contains `lifeDrive/` and `lifedrive-identity/`; compatibility links in the node root preserve the published app identity and service paths. Private node and household state stays in the node root. Existing installations retain their directories during upgrades.

```bash
npx --yes @inoku/lepan --leither-root /path/to/leither
```

The npm package includes its versioned installer, checksum, and LifeDrive bundle. The launcher validates those local assets and invokes the shared shell bootstrap, so LifeDrive does not require a second download from GitHub's release-asset host. A missing Leither runtime is downloaded separately using the [official distribution](http://vzhan.cn/#start.html) and its SHA-256 sidecar. A node without npm can invoke the same bootstrap directly (Node.js is still required):

```bash
curl -fLO https://github.com/cfa532/lifedrive-installer/releases/latest/download/lifedrive-install.sh
chmod +x lifedrive-install.sh
./lifedrive-install.sh
```

The private source repository publishes these assets and synchronizes the dependency-free npm launcher to the separate public `cfa532/lifedrive-installer` repository. The release workflow requires a `LIFEDRIVE_RELEASE_TOKEN` repository secret with permission to push source and workflow changes and create releases in that public repository; the source repository's default workflow token cannot publish across repositories.

The npm package is `@inoku/lepan`. The public repository's `publish-npm.yml` workflow publishes the package when a LifeDrive release is created. npm trusted publishing must authorize the public repository and that workflow; the workflow requests an OIDC identity and publishes with provenance. The npm scope and first package publication must be established once by the Inoku npm owner before automatic releases can continue.

Maintainers should follow the [LifeDrive npm Installer Release Runbook](../../docs/LIFEDRIVE_NPM_INSTALLER_RELEASE.md) for the complete versioning, packaging, tagging, trusted-publishing, verification, and manual-recovery procedure.

The installer requires Leither V0.24.11 or newer and uses the built-in AV1 endpoint `https://registry.lepan.org/v1/usernames/register`; ordinary users are never asked to supply an internal service URL, AV1 login, or developer-issued enrollment code. Fresh setup asks once for the public LifeDrive name, synchronizes the published application, creates a distinct `sodiumv2` key and certificate for the primary browser, grants that key UID native rights to the drive, and writes a mode-0600 identity bundle outside the application directory. The bundle is bound to the generated App MID. The owner imports that file once in the browser; the browser verifies the private/public key pair, retains only a non-exportable `CryptoKey`, and creates short-lived PPTs locally. `--add-device LABEL` issues a separate key and grant, `--list-devices` displays active key UIDs, and `--revoke-device UID` removes the native drive and owner-profile grants. The public name remains the `<username>.lepan.org` address and is not an authentication credential.

The deployed Leither application name is `lifeDrive`. On the current node, the Leither root is `/home/pi/demo`, the application source directory is `/home/pi/demo/lifeDrive`, and the operator script is `/home/pi/demo/lifeDrive.sh`.

Deployment follows this order:

1. Request the MiMei service required by the target node.
2. Upload the `lifeDrive` application directory with `lapp uploadapp`.
3. Back up the uploaded application with `lapp backup -a lifeDrive`.
4. Query `lapp showapp --json` with the same publisher identity and extract the authoritative `app_id`.
5. Publish that `app_id` with the same publisher identity using `mimei publish --mid <appId>`.

The application `appId` is determined by the publisher identity and application directory name and becomes publishable after backup. The value passed to `mimei publish --mid` must therefore be queried after the successful backup; it must not be hardcoded or copied from another publisher's application.

The included `lifeDrive.sh` implements this sequence, and it runs on one node: the one holding the publishing identity. It defaults to the node identity from `hostkey.cfg`; the publishing installation sets `LIFEDRIVE_PUBLISHER_KEY` or records the key path in the protected `lifeDrive.publisher-key` state file, which later runs reuse. If the selected identity's derived app MID disagrees with the saved app MID, the script exits 3 without uploading. That is the ordinary outcome everywhere else — a household node holds the application's MID without holding the identity that publishes it, so there is nothing for it to publish — and setup reports it as such rather than as a failure.

**A household node does not publish.** It synchronizes the published application MID with `mimei sync` and records it, and Leither tracks later versions from there, so publishing a new version reaches every synced node without anyone touching them. That also means no per-household application MID exists to bind a `<username>.lepan.org` address to, so fresh setup registers no public address: a household is reached by node id through the gateway, and the public name is a display name. Set `LIFEDRIVE_REGISTER_DOMAIN=1` to register anyway, which is only meaningful for a node running an application of its own. See `docs/LIFEDRIVE_UNIVERSAL_APP_AND_HTTPS.md`.

The application lifecycle is not complete merely because new files can be read from application `cur`. `lapp backup` must advance `last`, `lapp showapp` must return the expected App MID, and `mimei publish` must succeed. If upload or backup times out, setup reports publication failure and the prior `last` remains the active web and MApp version; retrying continues with the same application identity.

`@inoku/lepan` holds the shell and PowerShell installers, checksum, and matching LifeDrive bundle. The platform bootstrap reuses a running Leither node, or installs/starts one during fresh setup, checks V0.24.11 compatibility, verifies the bundled archive SHA-256, and installs LifeDrive below that node's root. `--leither-root` selects an existing node or a new empty directory; `--no-install-leither` retains the running-node requirement. Existing executables, node keys, and configuration are never replaced, and nonempty directories without Leither are left for operator recovery. New and stopped nodes use systemd (`lifedrive-leither.service`) on Linux, launchd (`uk.inoku.leither`) on macOS, or the `LifeDrive Leither` SYSTEM Scheduled Task on native x64 Windows. The managers start Leither at boot and recover from crashes. Windows fresh setup uses household pairing, registers the separate `LifeDrive Identity` task, and adds a program-scoped Windows Firewall rule for the configured Leither port; its identity control port stays on loopback. macOS setup registers the selected Leither executable with the Application Firewall, allows incoming connections, and verifies the rule without enabling or otherwise changing the global firewall mode. A macOS **Block all incoming connections** setting or managed policy can still override the rule. `--leither-service` configures only Leither startup and firewall access, without changing LifeDrive files. Already running unmanaged processes and different existing service definitions are left untouched; ordinary upgrades never restart Leither. Setup and recovery are terminal operations on the physically controlled node; there is no temporary web setup service. Router port forwarding remains a separate operator action on every platform.

Globally unique public-name checking, reservation, and domain binding execute on AV1 under AV1's retained program identity. The read-only check sends only the normalized name. The final self-service registration sends AV1 only that name and the published app MID. It never sends a device UID, private key, PPT, SID, publisher key, or node host key. AV1 rate-limits requests and serializes deterministic forward and reverse bindings so one name maps to one app MID and one app MID maps to one name. Those records are committed only to AV1's local MiMei state and are never published or provided; only the resulting domain resolution is public. Repeating the same pair is idempotent; a different pairing is rejected. The app MID and public name are not credentials; device-key login protects drive access.

`lifeDrive-owner.sh` does not assume that an interactive shell loaded NVM. It checks `LIFEDRIVE_NODE_PATH`, then the executable `node` on `PATH`, then installed NVM versions in the operating-system account's real home directory. It uses Leither's `genkey`, `gencert`, `signppt`, and `verifyppt` commands as the authoritative certificate encoder, extracts the verified PPT's opaque `SignerInfo`, and grants its `SignerID` with `MMSetRight`. Temporary key and certificate files are removed after the identity bundle is assembled. The bundle must be transferred securely, imported once, and retained offline for recovery; it is never copied into the application or public release.

This application-package backup is separate from the File-type MiMei backups used as commit boundaries for users' drive data.

A private key or passport used for deployment must remain outside the application directory and repository. The deployment script may refer to a configured key basename or path, but key and certificate material must never be copied into this directory or committed, regardless of filename.

## Current limitation

This revision implements native per-device key login, owner-managed Leither storage capacity, and direct folder creation, upload, list, read, rename, move, copy, trash, restore, and permanent deletion. Per-drive quotas, persisted resumable uploads, delegated sharing, anonymous upload links, and multi-server owner identity remain future work. Losing one browser key does not make data unreadable: another authorized device remains valid, and the physically owned node can issue a replacement device identity.
