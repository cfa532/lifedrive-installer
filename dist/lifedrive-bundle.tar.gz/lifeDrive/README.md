# LifeDriveServerApp

LifeDriveServerApp is the Leither-hosted backend for the Inoku foreground clients. It is one flat Go package named `lapp`. Leither compiles its source with the `ixgo` interpreter and calls the exported `RunMApp` dispatcher for every entry.

## Runtime contract

- Interpreted Go source only; this is not a native binary or a Leither server plugin.
- One flat `lapp` package with no subpackages, package initializers, downloaded modules, or third-party runtime dependencies.
- `RunMApp` dispatches entries to ordinary Go functions. Internal entry reuse stays inside the same invocation and does not recursively compile another MApp request.
- File-type MiMei only for authoritative persistence.
- No database-style `Get`, `Set`, hash, list, set, or sorted-set persistence.
- Normal storage reads use committed `last` or an explicit immutable version.
- Privileged operations pass through `access_check`, require an expiring native Leither SID, and fail closed unless that identity can open the drive with the required MiMei rights.
- A newly granted empty drive may verify the same MID's `cur` right when `last` does not exist; the web client then calls `drive_open` to create the first committed root before normal reads.
- Responses use the LifeDrive v1 envelope and never serialize raw exceptions or requests.

The ordinary Go compiler may be used for syntax and type checking. Leither remains the only deployed server dependency.

## Entries

| Entry | Exposure | Purpose |
|---|---|---|
| `health` | Public | Basic service liveness and architecture identity |
| `server_capabilities` | Public | Report the installed Go-MApp and `lapi` contract required by LifeDrive |
| `access_get_security_mode` | Public | Disclose the active native-security state |
| `access_check` | Internal | Central fail-closed authorization decision boundary |
| `drive_get_state` | Protected | Read MiMei information and version state after authorization |
| `storage_get` | Owner protected | Read the active Leither datastore limit and optional runtime usage without exposing the config path |
| `storage_set_limit` | Owner protected | Atomically update local `Datastore.StorageMax` in whole GB and report that the Leither service or server must restart |
| `profile_get` | Owner protected | Read the authenticated owner's JSON profile from its deterministic File-type MiMei |
| `profile_set` | Owner protected | Commit profile JSON and maintain the avatar CID reference with `MMAddRef`/`MMDelRef` |
| `profile_avatar_upload` | Owner protected | Stream avatar bytes to a temporary file and convert the completed image to IPFS |
| `profile_avatar_abort` | Owner protected | Close an abandoned avatar upload handle |
| `drive_open` | Development protected | Resolve the deterministic File MiMei marked `lifeDrive` |
| `drive_list` | Development protected | Walk the committed directory tree in `last` |
| `folder_create` | Development protected | Create a directory path in the drive's `cur` tree, flush it, and back it up |
| `upload_begin` | Protected | Validate a destination path, authorize the owner, and open a temporary upload file |
| `upload_write` | Protected | Write a negotiated binary chunk at an authoritative offset with `MFSetData` |
| `upload_complete` | Protected | Attach the verified file in the drive's `cur` tree, flush it, and back it up |
| `upload_abort` | Protected | Close an abandoned temporary upload |
| `file_get_info` | Development protected | Inspect a committed file by path |
| `file_read` | Development protected | Read a bounded file range from `last` with `MFGetData` |
| `object_move` | Development protected | Rename or move a committed file or directory by canonical path |
| `object_copy` | Development protected | Copy a committed file or directory to a new canonical path |
| `object_trash` | Development protected | Move an item into the hidden drive trash and commit the updated tree |
| `trash_list` | Development protected | List reversible top-level trash entries without a metadata catalog |
| `trash_restore` | Development protected | Restore a trash entry to its original or selected parent |
| `object_purge` | Development protected | Recursively remove one trash entry and commit the updated tree |

`access_check` derives the deterministic drive with the application author identity, then calls `MMOpen` with the browser caller's SID. Views require access to `last`; mutations and deletion require access to `cur`. The caller UID is obtained from that same SID. A missing, expired, or unauthorized session is denied without falling back to an application secret.

## File MiMei layout

The deterministic root is created or resolved with `MMCreate(authorSid, request.aid, "lifedrive.app-drive/v1", "lifeDrive", 1, 0x07276704)`. The application ID comes from the active Leither runtime request, so each publisher's `lifeDrive` application resolves its own household drive. `lifeDrive-owner.sh` creates a separate Ed25519 `sodiumv2` identity for each authorized device and grants its globally stable key UID rights to that MiMei.

The MiMei directory tree is the data model. A visible path such as `/Family photos/picnic.jpg` is the stored file path, and directory nesting is the parent-child relationship. There is no global catalog, per-object JSON, relationship JSON, or separate payload MiMei in the fundamental drive layer.

LifeDrive uses the node Files tree at `/appDrive` as its single mutable assembly surface. Folder creation, upload completion, move, copy, trash, restore, and purge mutate paths below that root, call `FilesFlush` once for the completed mutation, and pass the resulting root CID to `MFSetCid`.

`MFSetCid` is the whole commit: it backs the version up internally, returns the new version number, and `last` resolves to the flushed tree immediately. Verified on Leither V0.24.12 - the CID returned by `FilesFlush("/appDrive")` appears verbatim as the drive MiMei's newest version.

Addressing `mm://<drive-mid>:cur/<path>` directly was tried and reverted. Mutations do reach the drive's own tree that way, but `FilesFlush` on a mimei `cur` path fails ("OpenMM ver is empty") because `cur` is not a materialized version, so the commit can never complete. Do not mix the two: committing a `cur` mutation and a staged `MFSetCid` into one drive leaves a stale committed tree.

**Never add `MMBackup` to this path.** `MMBackup` snapshots the MiMei's own `cur` content, which overwrites the CID `MFSetCid` just committed and silently replaces the tree with an empty one. Every listing then returns zero objects while the staging tree still holds the data - a failure that looks like a read bug and is not.

`MMBackup` on the drive is also author-only. Verified on V0.24.12: a device holding the `0x07276704` grant receives `1101:Permission denied`, as does an ungranted device; only the author session commits. Drive mutations therefore run on the author session, and per-device grants cannot gate them - see `device_registry.go` for where that decision is made instead.

The household drive is private-local. LifeDrive never calls `MiMeiPublish`, `MiMeiProvide`, or provider advertisement for the drive MiMei or uploaded files. The separately published application AppID makes the web application reachable; it does not publish the owner's File MiMei.

The owner-only storage entries locate `ds/config` beside the running Leither executable, read only `Datastore.StorageMax`, and never expose the path or any other configuration value. This is a node-wide datastore limit for all Leither data, including LifeDrive, rather than a per-drive quota. A new whole-GB value is written by replacing only the JSON string in an atomic same-directory rename. The setting takes effect after the physical node owner restarts the Leither service through its existing service manager, or restarts the server. The MApp never attempts either action.

Upgrade note: a node that ran a `/appDrive` build keeps that directory in its node Files tree. The application no longer reads or writes it. Because the staged tree and the drive's `cur` tree were bound to the same directory object, `/appDrive` on such a node continues to reflect the drive's contents; it is a stale second name, not a second copy, and removing it is an operator decision rather than an application one. A node installed on this revision never creates it.

The web client sends file bytes through Leither's configured `/webapi/` endpoint. `upload_begin` opens a Leither temporary file, `upload_write` carries binary chunks in `RunMApp` arguments, and `upload_complete` validates the assembled size before referencing it in the drive's `cur` tree, flushing once, and backing the drive up. Ordinary lists and reads therefore never expose an unfinished upload. The MApp negotiates an adaptive upload range: the browser starts at 1 MiB, may grow successful fast transfers to 4 MiB, and reduces the next chunk after a slow request. The server rejects chunks above 4 MiB.

Trash is implemented without JSON metadata. Each trashed root is moved to `/.lifedrive-trash/<encoded-original-path>`. The encoded name makes the original path reversible, keeps trashed folder subtrees intact, and prevents the hidden trash directory from appearing in normal drive listings.

## Private development client

When served through a Leither-bound domain, the web client reads the application ID and provider addresses from the bootstrap page's `window.getParam()` block. The selected node and its configured Leither port are used for metadata, reads, mutations, and uploads through `/webapi/`.

The production browser build follows TweetWeb's proven Leither entry layout: top-level `index.html` with inline CSS and a top-level `lifedrive.js` browser object. LifeDrive uses `lifedrive.js` instead of TweetWeb's `index_entry.js` because Tahoe V0.24.05 derives the same entry short name, `index`, from `index.html`, `index_entry.js`, and `index.css`, then rejects the package. A Leither-bound domain supplies TweetWeb's provider-selecting `window.getParam()` bootstrap. Tahoe's direct `http://<node-ip>:<port>/entry?aid=<app-mid>&ver=last` response instead supplies `index.html` without that bootstrap or asset rebasing, so LifeDrive's small inline loader reads `aid` and `ver` from the URL and loads `/mm/<app-mid>:last/lifedrive.js` itself. No node-root route or `lifeDrive` URL prefix is required.

Local development falls back to the current gen8 private-network target:

```text
RPC endpoint: http://192.168.99.1:8002/webapi/
Application:  FKI2uZtAp6ZjUeecxQ4PvBq4bvK
Version:      last
RPC method:   RunMApp
```

Each MApp call has the form `RunMApp(entry, request, args)`. The request includes the application ID, `ver: "last"`, LifeDrive API version, request ID, and the SID returned by `LoginWithPPT`. The browser signs a 15-minute `CertFor=Self` PPT with its non-exportable device key, verifies that `GetVar(sid, "userid")` matches the expected key UID, and then uses Leither's one-hour SID. Upload chunks use the same call with a `Uint8Array` in `args` and an explicit offset in the request. WebCrypto Ed25519 and the `wss:` authentication endpoint require HTTPS (or localhost); `--skip-domain` deployments therefore need a trusted TLS proxy for browser login.

This private address is intentionally temporary. It is reachable only from a network that can route to gen8 and cannot be called by a normal public HTTPS page because of browser mixed-content and private-network restrictions.

## Leither API mapping

The capability entry recognizes the installed API families verified in the local Leither source:

- MiMei lifecycle: `MMCreate`, `MMOpen`, `MMClose`, `MMBackup`, `MMRelease`, `MMRestore`, `MMDelVers`.
- File sessions: `MMOpenUrl` for committed `mm://<mid>:last/...` reads. Uploads use `MFOpenTempFile`, `MFSetData`, `MFTemp2Files`, `FilesFlush`, and `MFSetCid` inside the MApp.
- File data: `MFSetData`, `MFGetData`, `MFGetSize`, `MFStat`, `MFGetMimeType`, and `MFReaddir`.
- Mutable file tree: current `Files*` names and legacy `FS*` names are detected separately so the adapter can be frozen against the installed runtime.
- Distribution: `MiMeiPublish`, `MiMeiProvide`, `MiMeiFindProvs`, `MiMeiSync`, `MiMeiIsProvider`, `MiMeiUnprovide`, and `MiMeiUnpublish` are probed independently. LifeDrive does not yet expose synchronization to clients. Any future synchronization entry must resolve the owner/provider first and skip `MiMeiSync` when the MiMei is owned by the same node; V0.24.02 can panic when self-sync has no other provider.

File-type MiMei uses the runtime data-type value `1`. This constant will be used only inside the future Leither adapter and will never be accepted from a client request.

## Deployment

The public npm launcher is the shortest installation path and may be run from any directory on the Leither server:

```bash
npx --yes @inoku/lifedrive
```

An existing key-auth installation can be upgraded with the same package. This path preserves authorized devices, application MID, registered address, and File MiMei data:

```bash
npx --yes @inoku/lifedrive@latest --upgrade
```

It first requires a running Leither service and discovers that process's executable directory automatically. If multiple Leither services intentionally run on one server, select the target explicitly:

```bash
npx --yes @inoku/lifedrive --leither-root /path/to/leither
```

The npm package includes its versioned installer, checksum, and LifeDrive bundle. The launcher checks for Leither before reading those local package assets, so setup does not require a second download from GitHub's release-asset host. A node without npm can invoke the GitHub bootstrap directly; the bootstrap performs the same running-service check and automatic root discovery:

```bash
curl -fLO https://github.com/cfa532/lifedrive-installer/releases/latest/download/lifedrive-install.sh
chmod +x lifedrive-install.sh
./lifedrive-install.sh
```

The private source repository publishes these assets and synchronizes the dependency-free npm launcher to the separate public `cfa532/lifedrive-installer` repository. The release workflow requires a `LIFEDRIVE_RELEASE_TOKEN` repository secret with permission to push source and workflow changes and create releases in that public repository; the source repository's default workflow token cannot publish across repositories.

The npm package is `@inoku/lifedrive`. The public repository's `publish-npm.yml` workflow publishes the package when a LifeDrive release is created. npm trusted publishing must authorize the public repository and that workflow; the workflow requests an OIDC identity and publishes with provenance. The npm scope and first package publication must be established once by the Inoku npm owner before automatic releases can continue.

Maintainers should follow the [LifeDrive npm Installer Release Runbook](../../docs/LIFEDRIVE_NPM_INSTALLER_RELEASE.md) for the complete versioning, packaging, tagging, trusted-publishing, verification, and manual-recovery procedure.

The installer requires Leither V0.24.11 or newer and uses the built-in AV1 endpoint `https://registry.inoku.uk/v1/usernames/register`; ordinary users are never asked to supply an internal service URL, AV1 login, or developer-issued enrollment code. Fresh setup asks once for the public LifeDrive name, checks it with AV1, publishes the app, creates a distinct `sodiumv2` key and certificate for the primary browser, grants that key UID native rights to the drive, and writes a mode-0600 identity bundle outside the application directory. The bundle is bound to the generated App MID. The owner imports that file once in the browser; the browser verifies the private/public key pair, retains only a non-exportable `CryptoKey`, and creates short-lived PPTs locally. `--add-device LABEL` issues a separate key and grant, `--list-devices` displays active key UIDs, and `--revoke-device UID` removes the native drive and owner-profile grants. The public name remains the `<username>.inoku.uk` address and is not an authentication credential.

The deployed Leither application name is `lifeDrive`. On the current node, the Leither root is `/home/pi/demo`, the application source directory is `/home/pi/demo/lifeDrive`, and the operator script is `/home/pi/demo/lifeDrive.sh`.

Deployment follows this order:

1. Request the MiMei service required by the target node.
2. Upload the `lifeDrive` application directory with `lapp uploadapp`.
3. Back up the uploaded application with `lapp backup -a lifeDrive`.
4. Query `lapp showapp --json` with the same publisher identity and extract the authoritative `app_id`.
5. Publish that `app_id` with the same publisher identity using `mimei publish --mid <appId>`.

The application `appId` is determined by the publisher identity and application directory name and becomes publishable after backup. The value passed to `mimei publish --mid` must therefore be queried after the successful backup; it must not be hardcoded or copied from another publisher's application.

The included `lifeDrive.sh` implements this sequence. It defaults to the node identity from `hostkey.cfg`; an existing installation created with a separate publisher key can set `LIFEDRIVE_PUBLISHER_KEY` and `LIFEDRIVE_PUBLISHER_CERT`. After a successful keyed publication, the script saves only the key path in the protected `lifeDrive.publisher-key` state file. Publication and owner recovery automatically reuse that path. If the selected identity's derived app MID disagrees with the saved app MID, publication stops before upload instead of creating an accidental second application.

The application lifecycle is not complete merely because new files can be read from application `cur`. `lapp backup` must advance `last`, `lapp showapp` must return the expected App MID, and `mimei publish` must succeed. If upload or backup times out, setup reports publication failure and the prior `last` remains the active web and MApp version; retrying continues with the same application identity.

`@inoku/lifedrive` is a small, self-contained Node.js launcher package holding `lifedrive-install.sh`, the checksum, and the matching release bundle. It requires a running Leither service, then executes the packaged bootstrap without contacting GitHub. The bootstrap independently confirms that service, derives the Leither root from its executable, verifies the bundled archive SHA-256, and installs the application beneath the detected root. `--leither-root` is only needed to disambiguate multiple running instances. `lifeDrive-setup.sh` coordinates the AV1 availability check, app publication, local owner creation, immediate AV1 reservation/domain binding, and removal of any retired 8011 companion. Setup and recovery are terminal operations on the physically controlled node; there is no temporary web setup service.

Globally unique public-name checking, reservation, and domain binding execute on AV1 under AV1's retained program identity. The read-only check sends only the normalized name. The final self-service registration sends AV1 only that name and the published app MID. It never sends a device UID, private key, PPT, SID, publisher key, or node host key. AV1 rate-limits requests and serializes deterministic forward and reverse bindings so one name maps to one app MID and one app MID maps to one name. Those records are committed only to AV1's local MiMei state and are never published or provided; only the resulting domain resolution is public. Repeating the same pair is idempotent; a different pairing is rejected. The app MID and public name are not credentials; device-key login protects drive access.

`lifeDrive-owner.sh` does not assume that an interactive shell loaded NVM. It checks `LIFEDRIVE_NODE_PATH`, then the executable `node` on `PATH`, then installed NVM versions in the operating-system account's real home directory. It uses Leither's `genkey`, `gencert`, `signppt`, and `verifyppt` commands as the authoritative certificate encoder, extracts the verified PPT's opaque `SignerInfo`, and grants its `SignerID` with `MMSetRight`. Temporary key and certificate files are removed after the identity bundle is assembled. The bundle must be transferred securely, imported once, and retained offline for recovery; it is never copied into the application or public release.

This application-package backup is separate from the File-type MiMei backups used as commit boundaries for users' drive data.

A private key or passport used for deployment must remain outside the application directory and repository. The deployment script may refer to a configured key basename or path, but key and certificate material must never be copied into this directory or committed, regardless of filename.

## Current limitation

This revision implements native per-device key login, owner-managed Leither storage capacity, and direct folder creation, upload, list, read, rename, move, copy, trash, restore, and permanent deletion. Per-drive quotas, persisted resumable uploads, delegated sharing, anonymous upload links, and multi-server owner identity remain future work. Losing one browser key does not make data unreadable: another authorized device remains valid, and the physically owned node can issue a replacement device identity.
