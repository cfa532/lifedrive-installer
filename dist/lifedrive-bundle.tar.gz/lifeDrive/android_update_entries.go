package lapp

import (
	"encoding/json"
	"fmt"
	"io"
	"os"
	"sort"
	"strings"

	"Leither/lapi"
)

const (
	androidPackageExt  = "lifedrive.android-package/v1"
	androidPackageMark = "LifeDrive Android direct update"
	androidPackageFile = "lifeDrive.android-update.apk"
	androidMaximumSize = int64(512 * 1024 * 1024)
)

type androidUpdateManifest struct {
	Enabled     bool   `json:"enabled"`
	VersionCode int64  `json:"versionCode"`
	VersionName string `json:"versionName"`
	Size        int64  `json:"size"`
	SHA256      string `json:"sha256"`
	CID         string `json:"cid"`
	Mission     string `json:"mission"`
}

type lifeDriveReleaseManifest struct {
	AndroidUpdate androidUpdateManifest `json:"androidUpdate"`
}

type androidProvider struct {
	address string
	score   int64
}

type mimeiPublisher interface {
	MiMeiPublish(sid, dhts, mid string) ([]lapi.DhtReply, error)
}

func installedAndroidUpdate(c *ctx) (*androidUpdateManifest, error) {
	raw, err := c.api.BEReadFile("lifedrive-release.json", "web")
	if err != nil {
		return nil, err
	}
	if len(raw) == 0 || len(raw) > 16*1024 {
		return nil, fmt.Errorf("invalid LifeDrive release manifest size")
	}
	var release lifeDriveReleaseManifest
	if json.Unmarshal(raw, &release) != nil {
		return nil, fmt.Errorf("invalid LifeDrive release manifest")
	}
	update := release.AndroidUpdate
	if !update.Enabled {
		return &update, nil
	}
	update.SHA256 = strings.ToLower(update.SHA256)
	if update.VersionCode < 1 || update.VersionCode > 2147483647 || !validUpdateName(update.VersionName) ||
		update.Size < 1 || update.Size > androidMaximumSize || !validSHA256(update.SHA256) || !validSharedCID(update.CID) ||
		(update.Mission != "minor" && update.Mission != "major" && update.Mission != "critical") {
		return nil, fmt.Errorf("invalid enabled Android update metadata")
	}
	return &update, nil
}

func validUpdateName(value string) bool {
	if value == "" || len(value) > 64 || strings.TrimSpace(value) != value {
		return false
	}
	for i := 0; i < len(value); i++ {
		if value[i] < 0x20 || value[i] > 0x7e {
			return false
		}
	}
	return true
}

func validSHA256(value string) bool {
	if len(value) != 64 {
		return false
	}
	for i := 0; i < len(value); i++ {
		if !((value[i] >= '0' && value[i] <= '9') || (value[i] >= 'a' && value[i] <= 'f')) {
			return false
		}
	}
	return true
}

func androidPackageID(c *ctx) (string, string, error) {
	sid, err := authSID(c)
	if err != nil {
		return "", "", err
	}
	mid, err := c.api.MMCreate(sid, c.str("aid"), androidPackageExt, androidPackageMark, fileType, driveRight)
	if err != nil {
		return "", "", err
	}
	return sid, mid, nil
}

// android_update_info mirrors Tweet's check_upgrade contract while retaining
// an explicit release flag and verification metadata for the direct APK.
func entryAndroidUpdateInfo(c *ctx) (any, error) {
	update, err := installedAndroidUpdate(c)
	if err != nil {
		return nil, err
	}
	if !update.Enabled {
		return ok(c, map[string]any{"enabled": false}), nil
	}
	_, mid, err := androidPackageID(c)
	if err != nil {
		return nil, err
	}
	return ok(c, map[string]any{
		"enabled": true, "version_code": update.VersionCode, "version_name": update.VersionName,
		"package_id": mid, "size": update.Size, "sha256": update.SHA256, "mission": update.Mission,
	}), nil
}

// android_update_publish is deliberately argument-free. It can only attach
// and publish the immutable CID embedded in this installed server release, so
// a remote caller cannot redirect the well-known package MiMei.
func entryAndroidUpdatePublish(c *ctx) (any, error) {
	update, err := installedAndroidUpdate(c)
	if err != nil {
		return nil, err
	}
	if !update.Enabled {
		return nil, fmt.Errorf("Android update is disabled")
	}
	sid, mid, err := androidPackageID(c)
	if err != nil {
		return nil, err
	}
	root, err := leitherRootDirectory()
	if err != nil {
		return nil, err
	}
	path := joinUnixPath(root, androidPackageFile)
	info, err := os.Stat(path)
	if err != nil || !info.Mode().IsRegular() || info.Size() != update.Size {
		return nil, fmt.Errorf("staged Android package does not match release metadata")
	}
	digest, err := androidFileSHA256(path)
	if err != nil || digest != update.SHA256 {
		return nil, fmt.Errorf("staged Android package does not match release checksum")
	}
	stored, err := c.api.FilesStat(sid, "ipfs/"+update.CID)
	if err != nil || stored.Hash != update.CID || int64(stored.Size) != update.Size {
		return nil, fmt.Errorf("staged Android package is not imported under the release CID")
	}
	if _, err = c.api.MFSetCid(sid, mid, update.CID); err != nil {
		return nil, err
	}
	publisher, supported := c.api.(mimeiPublisher)
	if !supported {
		return nil, fmt.Errorf("MiMeiPublish is unavailable")
	}
	if _, err = publisher.MiMeiPublish(sid, "", mid); err != nil {
		return nil, err
	}
	return ok(c, map[string]any{"published": true, "package_id": mid}), nil
}

func androidFileSHA256(path string) (string, error) {
	file, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer file.Close()
	digest := newAndroidSHA256()
	buffer := make([]byte, 64*1024)
	for {
		count, readErr := file.Read(buffer)
		if count > 0 {
			digest.write(buffer[:count])
		}
		if readErr == io.EOF {
			break
		}
		if readErr != nil {
			return "", readErr
		}
	}
	return digest.sumHex(), nil
}

// Leither's ixgo interpreter intentionally exposes a smaller standard-library
// set than ordinary Go and does not include crypto/sha256. Keep this compact
// streaming implementation local to the release verifier instead of weakening
// the signed APK check or loading a 512 MiB maximum package into memory.
type androidSHA256 struct {
	state [8]uint32
	block [64]byte
	used  int
	size  uint64
}

var androidSHA256Constants = [64]uint32{
	0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
	0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
	0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
	0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
	0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
	0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
	0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
	0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
}

func newAndroidSHA256() *androidSHA256 {
	return &androidSHA256{state: [8]uint32{
		0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
		0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19,
	}}
}

func (digest *androidSHA256) write(data []byte) {
	digest.size += uint64(len(data))
	for len(data) > 0 {
		count := copy(digest.block[digest.used:], data)
		digest.used += count
		data = data[count:]
		if digest.used == len(digest.block) {
			digest.process(digest.block[:])
			digest.used = 0
		}
	}
}

func (digest *androidSHA256) sumHex() string {
	final := *digest
	bitSize := final.size * 8
	padding := [128]byte{0x80}
	paddingSize := 56 - final.used
	if paddingSize <= 0 {
		paddingSize += 64
	}
	final.write(padding[:paddingSize])
	length := [8]byte{}
	for i := 0; i < len(length); i++ {
		length[len(length)-1-i] = byte(bitSize >> (8 * i))
	}
	final.write(length[:])
	result := ""
	for _, value := range final.state {
		result += fmt.Sprintf("%08x", value)
	}
	return result
}

func (digest *androidSHA256) process(block []byte) {
	words := [64]uint32{}
	for i := 0; i < 16; i++ {
		offset := i * 4
		words[i] = uint32(block[offset])<<24 | uint32(block[offset+1])<<16 | uint32(block[offset+2])<<8 | uint32(block[offset+3])
	}
	for i := 16; i < len(words); i++ {
		left := words[i-15]
		right := words[i-2]
		small0 := androidRotateRight(left, 7) ^ androidRotateRight(left, 18) ^ left>>3
		small1 := androidRotateRight(right, 17) ^ androidRotateRight(right, 19) ^ right>>10
		words[i] = words[i-16] + small0 + words[i-7] + small1
	}
	a, b, c, d := digest.state[0], digest.state[1], digest.state[2], digest.state[3]
	e, f, g, h := digest.state[4], digest.state[5], digest.state[6], digest.state[7]
	for i := 0; i < len(words); i++ {
		large1 := androidRotateRight(e, 6) ^ androidRotateRight(e, 11) ^ androidRotateRight(e, 25)
		choice := (e & f) ^ (^e & g)
		temporary1 := h + large1 + choice + androidSHA256Constants[i] + words[i]
		large0 := androidRotateRight(a, 2) ^ androidRotateRight(a, 13) ^ androidRotateRight(a, 22)
		majority := (a & b) ^ (a & c) ^ (b & c)
		temporary2 := large0 + majority
		h, g, f, e, d, c, b, a = g, f, e, d+temporary1, c, b, a, temporary1+temporary2
	}
	digest.state[0] += a
	digest.state[1] += b
	digest.state[2] += c
	digest.state[3] += d
	digest.state[4] += e
	digest.state[5] += f
	digest.state[6] += g
	digest.state[7] += h
}

func androidRotateRight(value uint32, bits uint32) uint32 {
	return value>>bits | value<<(32-bits)
}

// android_update_providers is Tweet's provider-resolution step scoped to the
// one deterministic package ID advertised by this application.
func entryAndroidUpdateProviders(c *ctx) (any, error) {
	update, err := installedAndroidUpdate(c)
	if err != nil {
		return nil, err
	}
	if !update.Enabled {
		return ok(c, map[string]any{"providers": []string{}}), nil
	}
	_, mid, err := androidPackageID(c)
	if err != nil {
		return nil, err
	}
	if c.str("package_id") != mid {
		return nil, fmt.Errorf("unknown Android update package")
	}
	providers, err := androidPackageProviders(c, mid)
	if err != nil {
		return nil, err
	}
	addresses := make([]string, 0, len(providers))
	for _, provider := range providers {
		addresses = append(addresses, provider.address)
	}
	return ok(c, map[string]any{"providers": addresses}), nil
}

func androidPackageProviders(c *ctx, mid string) ([]androidProvider, error) {
	raw, err := c.api.GetVar("", "mmprovsips", mid)
	if err != nil {
		return nil, err
	}
	text, _ := raw.(string)
	if text == "" {
		return []androidProvider{}, nil
	}
	var decoded any
	if json.Unmarshal([]byte(text), &decoded) != nil {
		return nil, fmt.Errorf("invalid Android package provider data")
	}
	if inner, ok := decoded.(string); ok {
		if json.Unmarshal([]byte(inner), &decoded) != nil {
			return nil, fmt.Errorf("invalid nested Android package provider data")
		}
	}
	groups, ok := decoded.([]any)
	if !ok {
		return nil, fmt.Errorf("invalid Android package provider groups")
	}
	providers := []androidProvider{}
	seen := map[string]bool{}
	for _, groupValue := range groups {
		group, ok := groupValue.([]any)
		if !ok {
			return nil, fmt.Errorf("invalid Android package provider group")
		}
		for _, pairValue := range group {
			pair, ok := pairValue.([]any)
			if !ok || len(pair) < 2 {
				return nil, fmt.Errorf("invalid Android package provider")
			}
			address, _ := pair[0].(string)
			score, _ := pair[1].(float64)
			if address == "" || len(address) > 256 || strings.ContainsAny(address, "\x00\r\n\t ") {
				return nil, fmt.Errorf("invalid Android package provider address")
			}
			if !seen[address] {
				seen[address] = true
				providers = append(providers, androidProvider{address: address, score: int64(score)})
			}
		}
	}
	sort.SliceStable(providers, func(i, j int) bool {
		left, right := androidProviderPriority(providers[i].address), androidProviderPriority(providers[j].address)
		if left != right {
			return left < right
		}
		return providers[i].score < providers[j].score
	})
	return providers, nil
}

// Public IPv4 providers work both on and away from the publishing node's LAN.
// Prefer them before score: an overlay address can have an excellent local DHT
// score while being unroutable from an Android client that is not on that
// overlay. LAN addresses remain useful fallbacks for home clients.
func androidProviderPriority(address string) int {
	host := address
	if strings.HasPrefix(host, "[") {
		if end := strings.Index(host, "]"); end > 1 {
			host = host[1:end]
		}
		if host == "::1" || strings.HasPrefix(host, "fe80:") || strings.HasPrefix(host, "fc") || strings.HasPrefix(host, "fd") {
			return 4
		}
		return 2
	}
	if separator := strings.LastIndex(host, ":"); separator >= 0 {
		host = host[:separator]
	}
	if strings.HasPrefix(host, "192.168.") || androidProviderRange(host, "172.", 16, 31) {
		return 1
	}
	if strings.HasPrefix(host, "10.") || strings.HasPrefix(host, "127.") || strings.HasPrefix(host, "169.254.") ||
		androidProviderRange(host, "100.", 64, 127) {
		return 3
	}
	return 0
}

func androidProviderRange(host, prefix string, first, last int) bool {
	for value := first; value <= last; value++ {
		if strings.HasPrefix(host, fmt.Sprintf("%s%d.", prefix, value)) {
			return true
		}
	}
	return false
}
