#!/usr/bin/env bash
set -euo pipefail

LEITHER_WORKDIR="${LIFEDRIVE_WORKDIR:-/home/pi/demo}"
APP_NAME="${LIFEDRIVE_APP_NAME:-lifeDrive}"
STATE_FILE="${LIFEDRIVE_PUBLICATION_STATE:-$LEITHER_WORKDIR/$APP_NAME.appid}"
USERNAME_STATE_FILE="${LIFEDRIVE_USERNAME_STATE:-$LEITHER_WORKDIR/$APP_NAME.username}"
DOMAIN_STATE_FILE="${LIFEDRIVE_DOMAIN_STATE:-$LEITHER_WORKDIR/$APP_NAME.domain}"
REGISTRY_URL="${LIFEDRIVE_REGISTRY_URL:-}"
NODE_BIN="${LIFEDRIVE_NODE_PATH:-}"
CHECK_ONLY=0
if [[ "${1:-}" == "--check" ]]; then
  CHECK_ONLY=1
  shift
fi

if [[ -z "$NODE_BIN" ]]; then
  NODE_BIN=$(command -v node 2>/dev/null || true)
fi
if [[ -z "$NODE_BIN" ]]; then
  USER_HOME_DIR=""
  if command -v getent >/dev/null 2>&1; then
    USER_HOME_DIR=$(getent passwd "$(id -u)" 2>/dev/null | cut -d: -f6 || true)
  elif command -v dscl >/dev/null 2>&1; then
    USER_HOME_DIR=$(dscl . -read "/Users/$(id -un)" NFSHomeDirectory 2>/dev/null | awk '{print $2}' || true)
  fi
  USER_HOME_DIR="${USER_HOME_DIR:-${HOME:-}}"
  for candidate in "$USER_HOME_DIR"/.nvm/versions/node/*/bin/node /opt/homebrew/bin/node /usr/local/bin/node; do
    if [[ -x "$candidate" ]]; then
      NODE_BIN="$candidate"
      break
    fi
  done
fi
if [[ -z "$NODE_BIN" || ! -x "$NODE_BIN" ]]; then
  echo "Public-address registration stopped: Node.js was not found." >&2
  exit 1
fi
if [[ -z "$REGISTRY_URL" ]]; then
  echo "Public-address registration is not configured." >&2
  echo "Set LIFEDRIVE_REGISTRY_URL to the AV1 registration endpoint and rerun setup." >&2
  exit 1
fi
username="${1:-${LIFEDRIVE_PUBLIC_USERNAME:-}}"
if [[ -z "$username" && -s "$USERNAME_STATE_FILE" ]]; then
  username=$(tr -d '\r\n' < "$USERNAME_STATE_FILE")
fi
if [[ -z "$username" ]]; then
  read -r -p "Public LifeDrive name (<name>.inoku.uk): " username
fi
username=$(printf '%s' "$username" | tr '[:upper:]' '[:lower:]')
if (( ${#username} < 1 || ${#username} > 63 )) || [[ ! "$username" =~ ^[a-z0-9]([a-z0-9-]*[a-z0-9])?$ ]]; then
  echo "Use 1-63 lowercase letters, numbers, or interior hyphens." >&2
  exit 1
fi

if (( CHECK_ONLY )); then
  check_url="${LIFEDRIVE_REGISTRY_CHECK_URL:-}"
  if [[ -z "$check_url" ]]; then
    if [[ "$REGISTRY_URL" == */register ]]; then
      check_url="${REGISTRY_URL%/register}/check"
    else
      check_url="${REGISTRY_URL%/}/check"
    fi
  fi
  set +e
  check_output=$(LIFEDRIVE_REGISTRY_CHECK_URL_VALUE="$check_url" \
    LIFEDRIVE_REGISTRY_USERNAME="$username" \
    "$NODE_BIN" -e '
      const controller=new AbortController();
      const timer=setTimeout(()=>controller.abort(),120000);
      (async()=>{
        const response=await fetch(process.env.LIFEDRIVE_REGISTRY_CHECK_URL_VALUE,{
          method:"POST",
          headers:{"Content-Type":"application/json","Accept":"application/json"},
          body:JSON.stringify({username:process.env.LIFEDRIVE_REGISTRY_USERNAME}),
          signal:controller.signal
        });
        const reply=await response.json().catch(()=>null);
        if(!response.ok||!reply||reply.success!==true||reply?.data?.available!==true){
          console.error(reply?.error?.code||`registry_http_${response.status}`);
          process.exit(1);
        }
        process.stdout.write(reply.data.domain||`${process.env.LIFEDRIVE_REGISTRY_USERNAME}.inoku.uk`);
      })().catch(error=>{console.error(error?.name==="AbortError"?"registry_timeout":"registry_unavailable");process.exit(1)}).finally(()=>clearTimeout(timer));' 2>&1)
  check_status=$?
  set -e
  if (( check_status != 0 )); then
    echo "Username availability check stopped: $check_output" >&2
    exit "$check_status"
  fi
  echo "Username available: $check_output"
  exit 0
fi

if [[ ! -s "$STATE_FILE" ]]; then
  echo "Public-address registration stopped: publish LifeDrive first." >&2
  exit 1
fi

app_mid=$(tr -d '[:space:]' < "$STATE_FILE")
if (( ${#app_mid} < 8 || ${#app_mid} > 256 )) || [[ ! "$app_mid" =~ ^[A-Za-z0-9_-]+$ ]]; then
  echo "Public-address registration stopped: the saved app MID is invalid." >&2
  exit 1
fi

enrollment_code="${LIFEDRIVE_REGISTRATION_CODE:-}"
if [[ -z "$enrollment_code" ]]; then
  read -r -s -p "AV1 enrollment code: " enrollment_code
  echo
fi

set +e
registration_output=$(LIFEDRIVE_REGISTRY_URL_VALUE="$REGISTRY_URL" \
  LIFEDRIVE_REGISTRY_USERNAME="$username" \
  LIFEDRIVE_REGISTRY_APP_MID="$app_mid" \
  LIFEDRIVE_REGISTRY_CODE="$enrollment_code" \
  "$NODE_BIN" -e '
    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),120000);
    (async()=>{
      const response=await fetch(process.env.LIFEDRIVE_REGISTRY_URL_VALUE,{
        method:"POST",
        headers:{"Content-Type":"application/json","Accept":"application/json"},
        body:JSON.stringify({
          username:process.env.LIFEDRIVE_REGISTRY_USERNAME,
          app_mid:process.env.LIFEDRIVE_REGISTRY_APP_MID,
          enrollment_code:process.env.LIFEDRIVE_REGISTRY_CODE
        }),
        signal:controller.signal
      });
      const reply=await response.json().catch(()=>null);
      if(!response.ok||!reply||reply.success!==true){
        console.error(reply?.error?.code||`registry_http_${response.status}`);
        process.exit(1);
      }
      const domain=reply?.data?.domain;
      if(typeof domain!=="string"||!domain){console.error("registry_invalid_response");process.exit(1)}
      process.stdout.write(JSON.stringify({username:reply.data.username,domain}));
    })().catch(error=>{console.error(error?.name==="AbortError"?"registry_timeout":"registry_unavailable");process.exit(1)}).finally(()=>clearTimeout(timer));' 2>&1)
registration_status=$?
set -e
unset enrollment_code LIFEDRIVE_REGISTRATION_CODE

if (( registration_status != 0 )); then
  echo "Public-address registration stopped: $registration_output" >&2
  echo "The local owner and drive remain ready; rerun setup when AV1 is available." >&2
  exit "$registration_status"
fi

domain=$(LIFEDRIVE_REGISTRATION_OUTPUT="$registration_output" "$NODE_BIN" -e '
  const value=JSON.parse(process.env.LIFEDRIVE_REGISTRATION_OUTPUT);
  process.stdout.write(value.domain);')

umask 077
printf '%s\n' "$username" > "$USERNAME_STATE_FILE"
printf '%s\n' "$domain" > "$DOMAIN_STATE_FILE"

echo "Public address registered: http://$domain/"
