#!/usr/bin/env bash
set -euo pipefail

# LifeDrive uploads now pass through Leither's own RunMApp endpoint. Disable an
# older 8011 companion if this node previously installed one. Its files are
# intentionally left in place so an operator can inspect or remove them later.
SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
default_root=$(cd "$SCRIPT_DIR/.." && pwd)
if [[ "$(basename "$default_root")" == lepan && -f "$default_root/.installer-layout-v1" ]]; then
  default_root=$(cd "$default_root/.." && pwd)
fi
LEITHER_WORKDIR="${LIFEDRIVE_WORKDIR:-$default_root}"

case "$(uname -s)" in
  Linux)
    if command -v systemctl >/dev/null 2>&1; then
      systemctl --user disable --now lifedrive-stream.service >/dev/null 2>&1 || true
      unit_file="${XDG_CONFIG_HOME:-${HOME:-}/.config}/systemd/user/lifedrive-stream.service"
      if [[ -f "$unit_file" ]]; then rm -f -- "$unit_file"; fi
      systemctl --user daemon-reload >/dev/null 2>&1 || true
    fi
    ;;
  Darwin)
    label="uk.inoku.lifedrive-stream"
    launch_domain="gui/$(id -u)"
    if ! launchctl print "$launch_domain" >/dev/null 2>&1; then launch_domain="user/$(id -u)"; fi
    launchctl bootout "$launch_domain/$label" >/dev/null 2>&1 || true
    plist_file="${HOME:-}/Library/LaunchAgents/$label.plist"
    if [[ -f "$plist_file" ]]; then rm -f -- "$plist_file"; fi
    ;;
esac

env_file="$LEITHER_WORKDIR/lifedrive-stream.env"
if [[ -f "$env_file" ]]; then rm -f -- "$env_file"; fi
echo "LePan uploads will use the configured Leither server port."
