#!/usr/bin/env bash
set -euo pipefail

# Installed files, the published application, and the running identity service
# are separate states. A household upgrade must advance all three.
SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
default_root=$(cd "$SCRIPT_DIR/.." && pwd)
if [[ "$(basename "$default_root")" == lepan && -f "$default_root/.installer-layout-v1" ]]; then
  default_root=$(cd "$default_root/.." && pwd)
fi
root=$(cd "${LIFEDRIVE_WORKDIR:-$default_root}" && pwd -P)
pairing_launcher="${LIFEDRIVE_PAIRING_COMMAND:-npx --yes @inoku/lepan@latest}"
leither="${LIFEDRIVE_LEITHER_PATH:-$root/Leither}"
app_mid=$(tr -d '[:space:]' < "$root/lifeDrive.appid")
[[ "$app_mid" =~ ^[A-Za-z0-9_-]{20,64}$ ]] || { echo "Invalid saved LePan application identity." >&2; exit 1; }
expected_version=$(sed -n 's/.*"version"[[:space:]]*:[[:space:]]*"\([0-9][0-9.]*\)".*/\1/p' "$root/lifeDrive/lifedrive-release.json" | head -1)
[[ -n "$expected_version" ]] || { echo "The installed LePan release version is missing." >&2; exit 1; }
cd "$root"

# Only the existing publisher node may publish. Its helper validates the MID
# and uses its retained authority; neither helper nor key ships in the bundle.
if [[ -s "$root/lifeDrive.publisher-key" ]]; then
  [[ -x "$root/lifeDrive.sh" ]] || { echo "The publisher's existing lifeDrive.sh helper is missing; activation is incomplete." >&2; exit 1; }
  publication_status=0
  "$root/lifeDrive.sh" || publication_status=$?
  case "$publication_status" in
    0) ;;
    3) "$leither" mimei sync --mid "$app_mid" ;;
    *) echo "LePan publication failed; the upgrade is incomplete." >&2; exit 1 ;;
  esac
else
  echo "Synchronizing the published LePan application..."
  "$leither" mimei sync --mid "$app_mid"
fi
[[ "$(tr -d '[:space:]' < "$root/lifeDrive.appid")" == "$app_mid" ]] || { echo "The application identity changed unexpectedly." >&2; exit 1; }

vars="$root/SystemVars.json"
[[ -f "$vars" ]] || vars="$root/systemvars.json"
port=""
if [[ -f "$vars" ]]; then
  port=$(sed -n 's/.*"ServicePort"[[:space:]]*:[[:space:]]*\([0-9][0-9]*\).*/\1/p' "$vars" | head -1)
fi
if [[ ! "$port" =~ ^[0-9]+$ ]] || (( port < 1 || port > 65535 )); then port=4800; fi
active_version=""
for attempt in {1..15}; do
  manifest=$(curl --noproxy '*' -fsS --max-time 3 "http://127.0.0.1:$port/mm/$app_mid:last/lifedrive-release.json" 2>/dev/null || true)
  active_version=$(sed -n 's/.*"version"[[:space:]]*:[[:space:]]*"\([0-9][0-9.]*\)".*/\1/p' <<< "$manifest" | head -1)
  [[ "$active_version" == "$expected_version" ]] && break
  sleep 2
done
if [[ "$active_version" != "$expected_version" ]]; then
  echo "LePan $expected_version files are installed, but the published app is ${active_version:-unavailable}." >&2
  echo "Activation is incomplete. The publisher must publish this release before household nodes can receive it." >&2
  exit 1
fi

run_service_command() {
  if [[ $(id -u) == 0 ]]; then "$@"; else sudo "$@"; fi
}
case "$(uname -m)" in x86_64|amd64) arch=amd64 ;; aarch64|arm64) arch=arm64 ;; *) echo "Unsupported identity-service architecture." >&2; exit 1 ;; esac
case "$(uname -s)" in
  Linux)
    binary="$root/lifedrive-identity/lifedrive-identity-linux-$arch"
    service_root=$(systemctl show lifedrive-identity.service --property=WorkingDirectory --value)
    service_command=$(systemctl show lifedrive-identity.service --property=ExecStart --value)
    if [[ "$service_root" != "$root" || "$service_command" != *"path=$binary ;"* ]]; then
      echo "The identity service does not match this installation. Restart its service manually; activation is incomplete." >&2
      exit 1
    fi
    if ! run_service_command systemctl restart lifedrive-identity.service; then
      echo "Activation is incomplete. Run: sudo systemctl restart lifedrive-identity.service" >&2
      exit 1
    fi
    ;;
  Darwin)
    binary="$root/lifedrive-identity/lifedrive-identity-darwin-$arch"
    plist=/Library/LaunchDaemons/uk.inoku.lifedrive-identity.plist
    saved_binary=$(/usr/libexec/PlistBuddy -c 'Print :ProgramArguments:0' "$plist")
    saved_config=$(/usr/libexec/PlistBuddy -c 'Print :ProgramArguments:2' "$plist")
    if [[ "$saved_binary" != "$binary" || "$saved_config" != "$root/"* ]]; then
      echo "The identity daemon does not match this installation. Restart its service manually; activation is incomplete." >&2
      exit 1
    fi
    if ! run_service_command launchctl kickstart -k system/uk.inoku.lifedrive-identity; then
      echo "Activation is incomplete. Run: sudo launchctl kickstart -k system/uk.inoku.lifedrive-identity" >&2
      exit 1
    fi
    ;;
  *) echo "Restart the LePan identity service for this platform; activation is incomplete." >&2; exit 1 ;;
esac
identity_process_ready() {
  local pid
  if [[ "$(uname -s)" == Linux ]]; then
    systemctl is-active --quiet lifedrive-identity.service || return 1
    pid=$(systemctl show lifedrive-identity.service --property=MainPID --value)
    [[ "$pid" =~ ^[1-9][0-9]*$ ]] && cmp -s "$binary" "/proc/$pid/exe"
  else
    pid=$(launchctl print system/uk.inoku.lifedrive-identity 2>/dev/null | awk '/^[[:space:]]*pid = / {print $3; exit}') || return 1
    [[ "$pid" =~ ^[1-9][0-9]*$ ]] && lsof -nP -a -p "$pid" -iTCP:4811 -sTCP:LISTEN -t >/dev/null 2>&1
  fi
}
for attempt in {1..15}; do
  health=$(curl --noproxy '*' -fsS --max-time 2 http://127.0.0.1:4811/health 2>/dev/null || true)
  if identity_process_ready && [[ "$health" =~ \"service\"[[:space:]]*:[[:space:]]*\"lifedrive-identity\" ]]; then
    echo "LePan $expected_version is active. Existing users and device keys were preserved."
    echo
    echo "Saved pairing files, if retained: $root/lepan-pairing-*.json (with matching .png images)."
    printf '\nHelp:\n  %s --help\n' "$pairing_launcher"
    exit 0
  fi
  sleep 1
done
echo "The identity service did not become ready; activation is incomplete. Check its service log." >&2
exit 1
