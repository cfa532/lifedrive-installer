#!/usr/bin/env bash
set -euo pipefail

# Installed files, the published application, and the running identity service
# are separate states. A household upgrade must advance all three.
preflight_only=0
if [[ $# == 1 && "${1:-}" == --preflight ]]; then
  preflight_only=1
elif (( $# )); then
  echo "Use lifeDrive-upgrade-household.sh [--preflight]." >&2
  exit 2
fi
SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
default_root=$(cd "$SCRIPT_DIR/.." && pwd)
if [[ "$(basename "$default_root")" == lepan && -f "$default_root/.installer-layout-v1" ]]; then
  default_root=$(cd "$default_root/.." && pwd)
fi
root=$(cd "${LIFEDRIVE_WORKDIR:-$default_root}" && pwd -P)
pairing_launcher="${LIFEDRIVE_PAIRING_COMMAND:-npx --yes @inoku/lepan@latest}"
leither="${LIFEDRIVE_LEITHER_PATH:-$root/Leither}"
app_mid=$(tr -d '[:space:]' < "$root/lifeDrive.appid")
[[ "$app_mid" =~ ^[A-Za-z0-9_-]{20,64}$ ]] || { echo "Invalid saved LePan application identity." >&2; exit 1; }
expected_version=$(sed -n 's/.*"version"[[:space:]]*:[[:space:]]*"\([0-9][0-9.]*\)".*/\1/p' "$SCRIPT_DIR/lifedrive-release.json" | head -1)
[[ -n "$expected_version" ]] || { echo "The installed LePan release version is missing." >&2; exit 1; }
cd "$root"

# Publication is a release prerequisite, including on a node that retains a
# publishing identity. The installer must never publish its bundled manifest
# over a newer Android update or make a household user complete a release.
sync_log=$(umask 077; mktemp "${TMPDIR:-/tmp}/lepan-upgrade-sync.XXXXXX")
cleanup_sync_log() {
  if command -v shred >/dev/null 2>&1; then
    shred -u "$sync_log" || rm -f -- "$sync_log"
  else
    rm -f -- "$sync_log"
  fi
}
trap cleanup_sync_log EXIT
echo "Synchronizing the published LePan application..."
if ! "$leither" mimei sync --mid "$app_mid" > "$sync_log" 2>&1; then
  echo "The update could not be prepared on this node. Try again when the node is connected." >&2
  exit 1
fi
[[ "$(tr -d '[:space:]' < "$root/lifeDrive.appid")" == "$app_mid" ]] || { echo "The application identity changed unexpectedly." >&2; exit 1; }

vars="$root/SystemVars.json"
[[ -f "$vars" ]] || vars="$root/systemvars.json"
port=""
if [[ -f "$vars" ]]; then
  port=$(sed -n 's/.*"ServicePort"[[:space:]]*:[[:space:]]*\([0-9][0-9]*\).*/\1/p' "$vars" | head -1)
fi
if [[ ! "$port" =~ ^[0-9]+$ ]] || (( port < 1 || port > 65535 )); then port=4800; fi
active_version=""
active_server_version=""
for attempt in {1..15}; do
  manifest=$(curl -q --noproxy '*' -fsS --max-time 3 "http://127.0.0.1:$port/mm/$app_mid:last/lifedrive-release.json" 2>/dev/null || true)
  active_version=$(sed -n 's/.*"version"[[:space:]]*:[[:space:]]*"\([0-9][0-9.]*\)".*/\1/p' <<< "$manifest" | head -1)
  health=$(curl -q --noproxy '*' -fsS --max-time 3 "http://127.0.0.1:$port/entry?aid=$app_mid&ver=last&entry=health" 2>/dev/null || true)
  active_server_version=$(sed -n 's/.*"server_version"[[:space:]]*:[[:space:]]*"\([0-9][0-9.]*\)".*/\1/p' <<< "$health" | head -1)
  if [[ "$active_version" == "$expected_version" && "$active_server_version" == "$expected_version" && "$health" =~ \"success\"[[:space:]]*:[[:space:]]*true ]]; then break; fi
  sleep 2
done
if [[ "$active_version" != "$expected_version" || "$active_server_version" != "$expected_version" || ! "$health" =~ \"success\"[[:space:]]*:[[:space:]]*true ]]; then
  echo "LePan $expected_version is not ready on this node. Please try again later." >&2
  exit 1
fi
if (( preflight_only )); then
  echo "LePan $expected_version is ready. Continuing the update."
  exit 0
fi
if ! "$leither" mimei provide --mid "$app_mid" >> "$sync_log" 2>&1; then
  echo "The updated application could not be advertised. Please try the update again." >&2
  exit 1
fi

run_service_command() {
  if [[ $(id -u) == 0 ]]; then "$@"; else sudo "$@"; fi
}
case "$(uname -m)" in x86_64|amd64) arch=amd64 ;; aarch64|arm64) arch=arm64 ;; *) echo "Unsupported identity-service architecture." >&2; exit 1 ;; esac
case "$(uname -s)" in
  Linux)
    binary="$root/lifedrive-identity/lifedrive-identity-linux-$arch"
    service_root=$(systemctl show lifedrive-identity.service --property=WorkingDirectory --value)
    service_command=$(systemctl show lifedrive-identity.service --property=ExecStart --value)
    service_binary=$(sed -n 's/.*path=\([^ ;]*\) ;.*/\1/p' <<< "$service_command" | head -1)
    # Compare real paths: a unit may name the same directory through a symlink
    # (gen8's runs from /home/pi/demo, a link to /mnt/6T2/demo).
    if [[ -z "$service_root" || -z "$service_binary" ||
          "$(readlink -f -- "$service_root")" != "$(readlink -f -- "$root")" ||
          "$(readlink -f -- "$service_binary")" != "$(readlink -f -- "$binary")" ]]; then
      echo "The identity service does not match this installation. Restart its service manually; activation is incomplete." >&2
      exit 1
    fi
    if ! run_service_command systemctl restart lifedrive-identity.service; then
      echo "Activation is incomplete. Run: sudo systemctl restart lifedrive-identity.service" >&2
      exit 1
    fi
    ;;
  Darwin)
    binary="$root/lifedrive-identity/lifedrive-identity-darwin-$arch"
    plist=/Library/LaunchDaemons/uk.inoku.lifedrive-identity.plist
    saved_binary=$(/usr/libexec/PlistBuddy -c 'Print :ProgramArguments:0' "$plist")
    saved_config=$(/usr/libexec/PlistBuddy -c 'Print :ProgramArguments:2' "$plist")
    if [[ "$saved_binary" != "$binary" || "$saved_config" != "$root/"* ]]; then
      echo "The identity daemon does not match this installation. Restart its service manually; activation is incomplete." >&2
      exit 1
    fi
    if ! run_service_command launchctl kickstart -k system/uk.inoku.lifedrive-identity; then
      echo "Activation is incomplete. Run: sudo launchctl kickstart -k system/uk.inoku.lifedrive-identity" >&2
      exit 1
    fi
    ;;
  *) echo "Restart the LePan identity service for this platform; activation is incomplete." >&2; exit 1 ;;
esac
identity_process_ready() {
  local pid
  if [[ "$(uname -s)" == Linux ]]; then
    systemctl is-active --quiet lifedrive-identity.service || return 1
    pid=$(systemctl show lifedrive-identity.service --property=MainPID --value)
    [[ "$pid" =~ ^[1-9][0-9]*$ ]] && cmp -s "$binary" "/proc/$pid/exe"
  else
    pid=$(launchctl print system/uk.inoku.lifedrive-identity 2>/dev/null | awk '/^[[:space:]]*pid = / {print $3; exit}') || return 1
    [[ "$pid" =~ ^[1-9][0-9]*$ ]] && lsof -nP -a -p "$pid" -iTCP:4811 -sTCP:LISTEN -t >/dev/null 2>&1
  fi
}
# Startup verifies the shared app and advertises it through Leither before
# opening the health endpoint. Those network operations can outlast 15 seconds.
# Bound elapsed time, including each health request, rather than probe count.
echo "Waiting for the account service to start..."
identity_ready_deadline=$((SECONDS + 180))
while (( SECONDS < identity_ready_deadline )); do
  health=$(curl -q --noproxy '*' -fsS --max-time 2 http://127.0.0.1:4811/health 2>/dev/null || true)
  if identity_process_ready && [[ "$health" =~ \"service\"[[:space:]]*:[[:space:]]*\"lifedrive-identity\" ]]; then
    node_name=$(hostname -s 2>/dev/null || hostname 2>/dev/null || printf 'unknown')
    echo
    echo "------------------------------------------------------------"
    echo "LePan $expected_version is active. Existing users and device keys were preserved."
    echo "Node: $node_name"
    echo
    echo "Saved pairing files, if retained: $root/lepan-pairing-*.json (with matching .png images)."
    printf '\nHelp:\n  %s --help\n' "$pairing_launcher"
    exit 0
  fi
  sleep 1
done
echo "The identity service was not ready within 180 seconds; activation could not be verified. Check its service log." >&2
exit 1
