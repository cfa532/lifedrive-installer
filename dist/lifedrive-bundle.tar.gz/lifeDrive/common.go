package lapp

import (
	"fmt"
	"strconv"
	"strings"
	"time"

	"Leither/lapi"
)

const (
	apiVersion    = "v1"
	serverVersion = "0.7.0"
	driveID       = "lifeDrive"
	driveExt      = "lifedrive.app-drive/v1"
	driveWorkRoot = "/appDrive"
	trashRoot     = "/.lifedrive-trash"
	driveRight    = uint64(0x07276704)
	fileType      = byte(1)
	maxItems      = 10000
	maxReadChunk  = 524288
	// Upload requests start small to keep HTTP memory and retry costs bounded.
	// The client may grow successful transfers up to the server-enforced limit.
	uploadMinChunkSize     = 256 * 1024
	uploadInitialChunkSize = 1 * 1024 * 1024
	uploadMaxChunkSize     = 4 * 1024 * 1024
)

func (c *ctx) str(name string) string { return c.req[name] }

func requestID(c *ctx) string {
	if value := c.str("request_id"); value != "" && len(value) <= 128 {
		return value
	}
	return "req_" + strconv.FormatInt(time.Now().UnixNano(), 10)
}

func serverTime() string { return time.Now().UTC().Format(time.RFC3339Nano) }

func response(success bool, id string, data any, appError map[string]any) map[string]any {
	result := map[string]any{
		"success":     success,
		"api_version": apiVersion,
		"request_id":  id,
		"server_time": serverTime(),
	}
	if success {
		result["data"] = data
	} else {
		result["error"] = appError
	}
	return result
}

func ok(c *ctx, data any) map[string]any { return response(true, requestID(c), data, nil) }

func fail(c *ctx, code, message string, retryable bool) map[string]any {
	return failDetails(c, code, message, retryable, nil)
}

func failDetails(c *ctx, code, message string, retryable bool, details map[string]any) map[string]any {
	appError := map[string]any{"code": code, "message_key": message, "retryable": retryable}
	if details != nil {
		appError["details"] = details
	}
	return response(false, requestID(c), nil, appError)
}

func versionFailure(c *ctx) map[string]any {
	requested := c.str("api_version")
	if requested == "" {
		requested = c.str("version")
	}
	if requested == "" || requested == apiVersion {
		return nil
	}
	return failDetails(c, "lifedrive.api.unsupported_version", "error.api.unsupported_version", false,
		map[string]any{"supported_versions": []string{apiVersion}})
}

func logError(c *ctx, format string, values ...any) {
	c.api.Error("LifeDrive Go "+c.entry+": "+format, values...)
}

func authSID(c *ctx) (string, error) {
	sid, err := c.api.BELoginAsAuthor()
	if err != nil {
		return "", err
	}
	if sid == "" {
		return "", fmt.Errorf("author session unavailable")
	}
	return sid, nil
}

func closeHandle(c *ctx, handle string) {
	if handle != "" {
		_ = c.api.MMClose(handle)
	}
}

func mimeiURL(mid, version, path string) string {
	if !strings.HasPrefix(path, "/") {
		path = "/" + path
	}
	return "mm://" + mid + ":" + version + path
}

func workPath(path string) string { return driveWorkRoot + path }

func splitCleanPath(value string) ([]string, error) {
	if strings.Contains(value, "\x00") || strings.Contains(value, "\\") {
		return nil, fmt.Errorf("invalid path")
	}
	raw := strings.Split(value, "/")
	parts := make([]string, 0, len(raw))
	for _, part := range raw {
		if part == "" {
			continue
		}
		if part == "." || part == ".." {
			return nil, fmt.Errorf("invalid path")
		}
		parts = append(parts, part)
	}
	return parts, nil
}

func normalizeDirectory(value string) (string, error) {
	if value == "" || value == "root" || value == "/" {
		return "/", nil
	}
	parts, err := splitCleanPath(value)
	if err != nil || len(parts) == 0 || parts[0] == ".lifedrive-trash" {
		return "", fmt.Errorf("invalid directory")
	}
	return "/" + strings.Join(parts, "/"), nil
}

func normalizeObjectPath(value string) (string, error) {
	parts, err := splitCleanPath(value)
	if err != nil || len(parts) == 0 || parts[0] == ".lifedrive-trash" {
		return "", fmt.Errorf("invalid path")
	}
	return "/" + strings.Join(parts, "/"), nil
}

func cleanName(value string) string {
	value = strings.TrimSpace(value)
	if len(value) > 255 {
		value = value[:255]
	}
	if value == "" || value == "." || value == ".." || value == ".lifedrive-trash" ||
		strings.Contains(value, "/") || strings.Contains(value, "\\") || strings.Contains(value, "\x00") {
		return ""
	}
	return value
}

func joinPath(parent, name string) string {
	if parent == "/" {
		return "/" + name
	}
	return parent + "/" + name
}

func parentPath(path string) string {
	index := strings.LastIndex(path, "/")
	if index <= 0 {
		return "/"
	}
	return path[:index]
}

func parentID(path string) string {
	parent := parentPath(path)
	if parent == "/" {
		return "root"
	}
	return parent
}

func baseName(path string) string {
	index := strings.LastIndex(path, "/")
	if index < 0 {
		return path
	}
	return path[index+1:]
}

func extension(name string) string {
	name = strings.ToLower(name)
	index := strings.LastIndex(name, ".")
	if index < 0 || index == len(name)-1 {
		return ""
	}
	return name[index+1:]
}

func contains(values []string, value string) bool {
	for _, candidate := range values {
		if candidate == value {
			return true
		}
	}
	return false
}

func kindOf(name string, directory bool, requested string) string {
	if directory {
		return "folder"
	}
	if contains([]string{"image", "video", "audio", "pdf", "file"}, requested) {
		return requested
	}
	ext := extension(name)
	if contains([]string{"jpg", "jpeg", "png", "gif", "webp", "heic", "heif", "avif", "bmp", "tif", "tiff"}, ext) {
		return "image"
	}
	if contains([]string{"mp4", "mov", "m4v", "webm", "mkv", "avi"}, ext) {
		return "video"
	}
	if contains([]string{"mp3", "m4a", "aac", "wav", "flac", "ogg", "opus"}, ext) {
		return "audio"
	}
	if ext == "pdf" {
		return "pdf"
	}
	return "file"
}

func mediaTypeOf(name, kind string) string {
	if kind == "folder" {
		return "inode/directory"
	}
	known := map[string]string{
		"jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png", "gif": "image/gif", "webp": "image/webp",
		"heic": "image/heic", "heif": "image/heif", "avif": "image/avif", "mp4": "video/mp4", "mov": "video/quicktime",
		"m4v": "video/x-m4v", "webm": "video/webm", "mp3": "audio/mpeg", "m4a": "audio/mp4", "aac": "audio/aac",
		"wav": "audio/wav", "flac": "audio/flac", "ogg": "audio/ogg", "opus": "audio/opus", "pdf": "application/pdf",
		"txt": "text/plain", "json": "application/json",
	}
	if value := known[extension(name)]; value != "" {
		return value
	}
	return "application/octet-stream"
}

func objectFromLink(path string, link lapi.LsLink) map[string]any {
	directory := link.Type == 1 || link.Type == 5
	kind := kindOf(link.Name, directory, "")
	size := uint64(0)
	if !directory {
		size = link.Size
	}
	return map[string]any{
		"object_id": path, "path": path, "kind": kind, "display_name": link.Name,
		"parent_id": parentID(path), "parent_path": parentID(path), "media_type": mediaTypeOf(link.Name, kind),
		"plaintext_size": size, "content_id": link.Hash, "created_at": nil, "modified_at": nil,
	}
}

func ensureDirectory(c *ctx, auth, path string) ([]string, error) {
	parts, err := splitCleanPath(path)
	if err != nil {
		return nil, err
	}
	created := []string{}
	current := ""
	for _, part := range parts {
		current += "/" + part
		if _, err := c.api.FilesStat(auth, current); err == nil {
			continue
		}
		if err := c.api.FilesMkdir(auth, current, false); err != nil {
			if _, statErr := c.api.FilesStat(auth, current); statErr != nil {
				return created, err
			}
			continue
		}
		created = append(created, current)
	}
	return created, nil
}

func ensureDriveRoot(c *ctx, auth, mid string) (bool, error) {
	if _, err := c.api.FilesStat(auth, mimeiURL(mid, "last", "/")); err == nil {
		return false, nil
	}
	if _, err := c.api.FilesStat(auth, driveWorkRoot); err != nil {
		if err := c.api.FilesMkdir(auth, driveWorkRoot, false); err != nil {
			return false, err
		}
	}
	cid, err := c.api.FilesFlush(auth, driveWorkRoot)
	if err != nil {
		return false, err
	}
	if _, err := c.api.MFSetCid(auth, mid, cid); err != nil {
		return false, err
	}
	_, err = c.api.FilesStat(auth, mimeiURL(mid, "last", "/"))
	return true, err
}

func parseInt64(value string, fallback int64) int64 {
	if value == "" {
		return fallback
	}
	parsed, err := strconv.ParseInt(value, 10, 64)
	if err != nil {
		return fallback
	}
	return parsed
}

func chunkArg(args []any) ([]byte, error) {
	if len(args) == 0 {
		return nil, fmt.Errorf("missing chunk")
	}
	switch value := args[0].(type) {
	case []byte:
		return value, nil
	case string:
		return []byte(value), nil
	case []any:
		result := make([]byte, 0, len(value))
		for _, item := range value {
			switch number := item.(type) {
			case int:
				result = append(result, byte(number))
			case int64:
				result = append(result, byte(number))
			case uint8:
				result = append(result, number)
			case float64:
				result = append(result, byte(number))
			default:
				return nil, fmt.Errorf("invalid chunk item %T", item)
			}
		}
		return result, nil
	default:
		return nil, fmt.Errorf("invalid chunk type %T", args[0])
	}
}

func percentEncode(value string) string {
	const hex = "0123456789ABCDEF"
	var builder strings.Builder
	for index := 0; index < len(value); index++ {
		char := value[index]
		if (char >= 'a' && char <= 'z') || (char >= 'A' && char <= 'Z') || (char >= '0' && char <= '9') ||
			strings.ContainsRune("-_.!~*'()", rune(char)) {
			builder.WriteByte(char)
		} else {
			builder.WriteByte('%')
			builder.WriteByte(hex[char>>4])
			builder.WriteByte(hex[char&15])
		}
	}
	return builder.String()
}

func hexValue(char byte) (byte, bool) {
	if char >= '0' && char <= '9' {
		return char - '0', true
	}
	if char >= 'a' && char <= 'f' {
		return char - 'a' + 10, true
	}
	if char >= 'A' && char <= 'F' {
		return char - 'A' + 10, true
	}
	return 0, false
}

func percentDecode(value string) (string, error) {
	result := make([]byte, 0, len(value))
	for index := 0; index < len(value); index++ {
		if value[index] != '%' {
			result = append(result, value[index])
			continue
		}
		if index+2 >= len(value) {
			return "", fmt.Errorf("invalid escape")
		}
		high, okHigh := hexValue(value[index+1])
		low, okLow := hexValue(value[index+2])
		if !okHigh || !okLow {
			return "", fmt.Errorf("invalid escape")
		}
		result = append(result, high<<4|low)
		index += 2
	}
	return string(result), nil
}
