package lapp

import (
	"encoding/json"
	"fmt"
	"strings"
)

const (
	profileSchemaVersion = 3
	profileExt           = "lifedrive.user-profile/v1"
	profileMarkPrefix    = "user-profile:"
	maxDisplayNameRunes  = 80
	maxProfileBioRunes   = 500
	maxAvatarBytes       = 1500000
	maxProfileBytes      = 65536
)

type ownerProfile struct {
	Version         int    `json:"version"`
	MID             string `json:"mid"`
	DisplayName     string `json:"display_name"`
	Bio             string `json:"bio"`
	AvatarCID       string `json:"avatar_cid,omitempty"`
	AvatarMediaType string `json:"avatar_media_type,omitempty"`
	UpdatedAt       string `json:"updated_at"`
}

func profileResponse(profile ownerProfile) map[string]any {
	return map[string]any{
		"version": profile.Version, "mid": profile.MID,
		"display_name": profile.DisplayName, "bio": profile.Bio,
		"avatar_cid": profile.AvatarCID, "avatar_media_type": profile.AvatarMediaType,
		"updated_at": profile.UpdatedAt,
	}
}

func profileMID(c *ctx, access *driveAccess) (string, error) {
	mid, err := c.api.MMCreate(
		access.authorSID,
		c.str("aid"),
		profileExt,
		profileMarkPrefix+access.userID,
		fileType,
		driveRight,
	)
	if err != nil {
		return "", fmt.Errorf("create profile MiMei: %w", err)
	}
	if err := c.api.MMSetRight(access.authorSID, mid, access.userID, driveRight); err != nil {
		return "", fmt.Errorf("grant profile MiMei: %w", err)
	}
	return mid, nil
}

func profileData(c *ctx, access *driveAccess, mid string) (ownerProfile, bool, error) {
	profile := ownerProfile{Version: profileSchemaVersion, MID: mid}
	handle, err := c.api.MMOpen(access.authorSID, mid, "last")
	if err != nil {
		return profile, false, nil
	}
	return profileDataFromHandle(c, access, mid, handle)
}

func profileDataFromHandle(c *ctx, access *driveAccess, mid, handle string) (ownerProfile, bool, error) {
	profile := ownerProfile{Version: profileSchemaVersion, MID: mid}
	defer closeHandle(c, handle)
	size, err := c.api.MFGetSize(handle)
	if err != nil {
		return profile, false, err
	}
	if size == 0 {
		return profile, false, nil
	}
	if size < 0 || size > maxProfileBytes {
		return profile, false, fmt.Errorf("invalid profile size")
	}
	data, err := c.api.MFGetData(handle, 0, int(size))
	if err != nil {
		return profile, false, err
	}
	if err := json.Unmarshal(data, &profile); err != nil {
		return ownerProfile{Version: profileSchemaVersion, MID: mid}, false, fmt.Errorf("invalid profile record")
	}
	// Schema 2 used the native Leither UID as the profile identifier. Accept it
	// for one read so the next save can rewrite the object with its own MiMei MID.
	if profile.Version == 2 && profile.MID == "" {
		var legacy struct {
			UID string `json:"uid"`
		}
		if json.Unmarshal(data, &legacy) == nil && legacy.UID == access.userID {
			profile.Version = profileSchemaVersion
			profile.MID = mid
		}
	}
	if profile.Version != profileSchemaVersion || profile.MID != mid ||
		!validAvatarCID(profile.AvatarCID) || !validAvatarMediaType(profile.AvatarMediaType) ||
		(profile.AvatarCID == "") != (profile.AvatarMediaType == "") {
		return ownerProfile{Version: profileSchemaVersion, MID: mid}, false, fmt.Errorf("invalid profile record")
	}
	return profile, true, nil
}

func entryProfileGet(c *ctx) (any, error) {
	access, err := requireAccess(c, "view", "drive")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	mid, err := profileMID(c, access)
	if err != nil {
		logError(c, "profile MiMei resolution failed: %v", err)
		return fail(c, "lifedrive.profile.read_failed", "error.profile.read_failed", true), nil
	}
	profile, exists, err := profileData(c, access, mid)
	if err != nil {
		logError(c, "profile read failed: %v", err)
		return fail(c, "lifedrive.profile.read_failed", "error.profile.read_failed", true), nil
	}
	return ok(c, map[string]any{
		"drive_mid": access.driveMID, "profile_mid": mid, "exists": exists, "profile": profileResponse(profile),
	}), nil
}

func validAvatarCID(value string) bool {
	if value == "" {
		return true
	}
	if len(value) < 32 || len(value) > 256 {
		return false
	}
	for index := 0; index < len(value); index++ {
		character := value[index]
		if !((character >= 'A' && character <= 'Z') ||
			(character >= 'a' && character <= 'z') ||
			(character >= '0' && character <= '9')) {
			return false
		}
	}
	return true
}

func validAvatarMediaType(value string) bool {
	return value == "" || contains([]string{
		"image/jpeg", "image/png", "image/webp", "image/gif", "image/avif",
	}, value)
}

func profileRuneCount(value string) int {
	count := 0
	for range value {
		count++
	}
	return count
}

func profilesMatch(left, right ownerProfile) bool {
	return left.Version == right.Version && left.MID == right.MID &&
		left.DisplayName == right.DisplayName && left.Bio == right.Bio &&
		left.AvatarCID == right.AvatarCID && left.AvatarMediaType == right.AvatarMediaType &&
		left.UpdatedAt == right.UpdatedAt
}

func saveOwnerProfile(c *ctx, access *driveAccess, displayName, bio, avatarAction, replacementCID, replacementMediaType string) (ownerProfile, string, error) {
	mid, err := profileMID(c, access)
	if err != nil {
		return ownerProfile{}, "", fmt.Errorf("resolve profile MiMei: %w", err)
	}
	current, _, err := profileData(c, access, mid)
	if err != nil {
		return ownerProfile{}, "", fmt.Errorf("read current profile: %w", err)
	}
	avatarCID := current.AvatarCID
	avatarMediaType := current.AvatarMediaType
	switch avatarAction {
	case "replace":
		avatarCID = replacementCID
		avatarMediaType = replacementMediaType
	case "remove":
		avatarCID = ""
		avatarMediaType = ""
	}
	profile := ownerProfile{
		Version: profileSchemaVersion, MID: mid, DisplayName: displayName, Bio: bio,
		AvatarCID: avatarCID, AvatarMediaType: avatarMediaType, UpdatedAt: serverTime(),
	}
	payload, err := json.Marshal(profile)
	if err != nil || len(payload) > maxProfileBytes {
		return ownerProfile{}, "", fmt.Errorf("encode profile")
	}
	currentHandle, err := c.api.MMOpen(access.authorSID, mid, "cur")
	if err != nil {
		return ownerProfile{}, "", fmt.Errorf("open current profile: %w", err)
	}
	defer closeHandle(c, currentHandle)
	written, err := c.api.MFSetData(currentHandle, payload, 0)
	if err != nil || written != len(payload) || c.api.MFTruncate(currentHandle, int64(len(payload))) != nil {
		return ownerProfile{}, "", fmt.Errorf("write profile record")
	}
	if current.AvatarCID != "" && current.AvatarCID != avatarCID {
		if _, err := c.api.MMDelRef(access.authorSID, mid, current.AvatarCID); err != nil {
			return ownerProfile{}, "", fmt.Errorf("remove previous avatar reference: %w", err)
		}
	}
	if avatarCID != "" && avatarCID != current.AvatarCID {
		if _, err := c.api.MMAddRef(access.authorSID, mid, avatarCID); err != nil {
			return ownerProfile{}, "", fmt.Errorf("attach avatar reference: %w", err)
		}
	}
	version, err := c.api.MMBackup(access.authorSID, mid, "profile update", "delref=false")
	if err != nil {
		return ownerProfile{}, "", fmt.Errorf("back up profile: %w", err)
	}
	committed, exists, err := profileData(c, access, mid)
	if err != nil {
		return ownerProfile{}, "", fmt.Errorf("read committed profile: %w", err)
	}
	if !exists {
		return ownerProfile{}, "", fmt.Errorf("committed profile is missing")
	}
	if !profilesMatch(profile, committed) {
		return ownerProfile{}, "", fmt.Errorf("committed profile does not match current write")
	}
	return committed, version, nil
}

func entryProfileSet(c *ctx) (any, error) {
	displayName := strings.TrimSpace(c.str("display_name"))
	bio := strings.TrimSpace(c.str("bio"))
	avatarAction := c.str("avatar_action")
	if avatarAction == "" {
		avatarAction = "keep"
	}
	// Avatar replacement is committed by profile_avatar_upload after the server
	// validates the temporary file. This endpoint never trusts a client-supplied CID.
	if displayName == "" || profileRuneCount(displayName) > maxDisplayNameRunes ||
		profileRuneCount(bio) > maxProfileBioRunes ||
		!contains([]string{"keep", "remove"}, avatarAction) {
		return fail(c, "lifedrive.request.invalid_profile", "error.request.invalid_profile", false), nil
	}
	access, err := requireAccess(c, "modify", "drive")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	profile, version, err := saveOwnerProfile(c, access, displayName, bio, avatarAction, "", "")
	if err != nil {
		logError(c, "profile save failed: %v", err)
		return fail(c, "lifedrive.profile.save_failed", "error.profile.save_failed", true), nil
	}
	return ok(c, map[string]any{
		"drive_mid": access.driveMID, "profile_mid": profile.MID, "version": version, "profile": profileResponse(profile),
	}), nil
}

// entryProfileAvatarUpload follows TweetWeb's proven upload_ipfs sequence:
// write bounded chunks into a Leither temporary file, then convert it to IPFS
// and commit the already-validated image with the user's profile in one request.
func entryProfileAvatarUpload(c *ctx) (any, error) {
	access, err := requireAccess(c, "modify", "drive")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	handle := c.str("upload_id")
	if c.str("finished") == "true" {
		displayName := strings.TrimSpace(c.str("display_name"))
		bio := strings.TrimSpace(c.str("bio"))
		mediaType := c.str("mime_type")
		if handle == "" || displayName == "" || profileRuneCount(displayName) > maxDisplayNameRunes ||
			profileRuneCount(bio) > maxProfileBioRunes || !validAvatarMediaType(mediaType) || mediaType == "" {
			return fail(c, "lifedrive.request.invalid_avatar", "error.request.invalid_avatar", false), nil
		}
		defer closeHandle(c, handle)
		size, sizeErr := c.api.MFGetSize(handle)
		if sizeErr != nil || size <= 0 || size > maxAvatarBytes || size != parseInt64(c.str("size"), -1) {
			return fail(c, "lifedrive.request.invalid_avatar", "error.request.invalid_avatar", false), nil
		}
		cid, convertErr := c.api.MFTemp2Ipfs(handle, "")
		if convertErr != nil || !validAvatarCID(cid) {
			logError(c, "avatar IPFS conversion failed: %v", convertErr)
			return fail(c, "lifedrive.profile.avatar_upload_failed", "error.profile.avatar_upload_failed", true), nil
		}
		profile, version, saveErr := saveOwnerProfile(c, access, displayName, bio, "replace", cid, mediaType)
		if saveErr != nil {
			logError(c, "profile save after avatar upload failed: %v", saveErr)
			return fail(c, "lifedrive.profile.save_failed", "error.profile.save_failed", true), nil
		}
		return ok(c, map[string]any{
			"cid": cid, "size": size, "media_type": mediaType,
			"drive_mid": access.driveMID, "profile_mid": profile.MID, "version": version, "profile": profileResponse(profile),
		}), nil
	}
	offset := parseInt64(c.str("offset"), -1)
	chunk, chunkErr := chunkArg(c.args)
	if offset < 0 || chunkErr != nil || len(chunk) == 0 || len(chunk) > uploadMaxChunkSize || offset+int64(len(chunk)) > maxAvatarBytes {
		return fail(c, "lifedrive.request.invalid_chunk", "error.request.invalid_chunk", false), nil
	}
	if handle == "" {
		handle, err = c.api.MFOpenTempFile(access.authorSID)
		if err != nil || handle == "" {
			return fail(c, "lifedrive.profile.avatar_upload_failed", "error.profile.avatar_upload_failed", true), nil
		}
	}
	written, err := c.api.MFSetData(handle, chunk, offset)
	if err != nil || written != len(chunk) {
		return fail(c, "lifedrive.profile.avatar_upload_failed", "error.profile.avatar_upload_failed", true), nil
	}
	return ok(c, map[string]any{
		"upload_id": handle, "offset": offset, "received": written, "next_offset": offset + int64(written),
	}), nil
}

func entryProfileAvatarAbort(c *ctx) (any, error) {
	if _, err := requireAccess(c, "modify", "drive"); err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	handle := c.str("upload_id")
	closeHandle(c, handle)
	return ok(c, map[string]any{"upload_id": handle, "state": "aborted"}), nil
}
