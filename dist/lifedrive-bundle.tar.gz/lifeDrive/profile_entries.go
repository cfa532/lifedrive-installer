package lapp

import (
	"encoding/json"
	"fmt"
	"regexp"
	"strings"
	"unicode/utf8"
)

const (
	profileSchemaVersion = 3
	profileExt           = "lifedrive.user-profile/v1"
	profileMarkPrefix    = "user-profile:"
	maxDisplayNameRunes  = 80
	maxProfileBioRunes   = 500
	maxAvatarBytes       = 1500000
	maxProfileBytes      = 65536
)

var ipfsCIDPattern = regexp.MustCompile(`^[A-Za-z0-9]+$`)

type ownerProfile struct {
	Version         int    `json:"version"`
	MID             string `json:"mid"`
	DisplayName     string `json:"display_name"`
	Bio             string `json:"bio"`
	AvatarCID       string `json:"avatar_cid,omitempty"`
	AvatarMediaType string `json:"avatar_media_type,omitempty"`
	UpdatedAt       string `json:"updated_at"`
}

func profileMID(c *ctx, access *driveAccess) (string, error) {
	mid, err := c.api.MMCreate(
		access.authorSID,
		c.str("aid"),
		profileExt,
		profileMarkPrefix+access.userID,
		fileType,
		driveRight,
	)
	if err != nil {
		return "", fmt.Errorf("create profile MiMei: %w", err)
	}
	if err := c.api.MMSetRight(access.authorSID, mid, access.userID, driveRight); err != nil {
		return "", fmt.Errorf("grant profile MiMei: %w", err)
	}
	return mid, nil
}

func profileData(c *ctx, access *driveAccess, mid string) (ownerProfile, bool, error) {
	profile := ownerProfile{Version: profileSchemaVersion, MID: mid}
	handle, err := c.api.MMOpen(access.authorSID, mid, "last")
	if err != nil {
		return profile, false, nil
	}
	defer closeHandle(c, handle)
	size, err := c.api.MFGetSize(handle)
	if err != nil {
		return profile, false, err
	}
	if size == 0 {
		return profile, false, nil
	}
	if size < 0 || size > maxProfileBytes {
		return profile, false, fmt.Errorf("invalid profile size")
	}
	data, err := c.api.MFGetData(handle, 0, int(size))
	if err != nil {
		return profile, false, err
	}
	if err := json.Unmarshal(data, &profile); err != nil {
		return ownerProfile{Version: profileSchemaVersion, MID: mid}, false, fmt.Errorf("invalid profile record")
	}
	// Schema 2 used the native Leither UID as the profile identifier. Accept it
	// for one read so the next save can rewrite the object with its own MiMei MID.
	if profile.Version == 2 && profile.MID == "" {
		var legacy struct {
			UID string `json:"uid"`
		}
		if json.Unmarshal(data, &legacy) == nil && legacy.UID == access.userID {
			profile.Version = profileSchemaVersion
			profile.MID = mid
		}
	}
	if profile.Version != profileSchemaVersion || profile.MID != mid ||
		!validAvatarCID(profile.AvatarCID) || !validAvatarMediaType(profile.AvatarMediaType) ||
		(profile.AvatarCID == "") != (profile.AvatarMediaType == "") {
		return ownerProfile{Version: profileSchemaVersion, MID: mid}, false, fmt.Errorf("invalid profile record")
	}
	return profile, true, nil
}

func entryProfileGet(c *ctx) (any, error) {
	access, err := requireAccess(c, "view", "drive")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	mid, err := profileMID(c, access)
	if err != nil {
		logError(c, "profile MiMei resolution failed: %v", err)
		return fail(c, "lifedrive.profile.read_failed", "error.profile.read_failed", true), nil
	}
	profile, exists, err := profileData(c, access, mid)
	if err != nil {
		logError(c, "profile read failed: %v", err)
		return fail(c, "lifedrive.profile.read_failed", "error.profile.read_failed", true), nil
	}
	return ok(c, map[string]any{
		"drive_mid": access.driveMID, "profile_mid": mid, "exists": exists, "profile": profile,
	}), nil
}

func validAvatarCID(value string) bool {
	return value == "" || (len(value) >= 32 && len(value) <= 256 && ipfsCIDPattern.MatchString(value))
}

func validAvatarMediaType(value string) bool {
	return value == "" || contains([]string{
		"image/jpeg", "image/png", "image/webp", "image/gif", "image/avif",
	}, value)
}

func verifyAvatar(c *ctx, access *driveAccess, cid string) error {
	handle, err := c.api.MFOpenMacFile(access.authorSID, "", cid)
	if err != nil {
		return fmt.Errorf("open avatar IPFS object: %w", err)
	}
	defer closeHandle(c, handle)
	size, err := c.api.MFGetSize(handle)
	if err != nil {
		return fmt.Errorf("read avatar IPFS size: %w", err)
	}
	if size <= 0 || size > maxAvatarBytes {
		return fmt.Errorf("invalid avatar IPFS size")
	}
	return nil
}

func entryProfileSet(c *ctx) (any, error) {
	displayName := strings.TrimSpace(c.str("display_name"))
	bio := strings.TrimSpace(c.str("bio"))
	avatarAction := c.str("avatar_action")
	if avatarAction == "" {
		avatarAction = "keep"
	}
	if displayName == "" || utf8.RuneCountInString(displayName) > maxDisplayNameRunes ||
		utf8.RuneCountInString(bio) > maxProfileBioRunes ||
		!contains([]string{"keep", "replace", "remove"}, avatarAction) {
		return fail(c, "lifedrive.request.invalid_profile", "error.request.invalid_profile", false), nil
	}
	access, err := requireAccess(c, "modify", "drive")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	mid, err := profileMID(c, access)
	if err != nil {
		logError(c, "profile MiMei resolution failed: %v", err)
		return fail(c, "lifedrive.profile.save_failed", "error.profile.save_failed", true), nil
	}
	current, _, err := profileData(c, access, mid)
	if err != nil {
		return fail(c, "lifedrive.profile.save_failed", "error.profile.save_failed", true), nil
	}
	avatarCID := current.AvatarCID
	avatarMediaType := current.AvatarMediaType
	switch avatarAction {
	case "replace":
		avatarCID = c.str("avatar_cid")
		avatarMediaType = c.str("avatar_media_type")
		if !validAvatarCID(avatarCID) || avatarCID == "" || !validAvatarMediaType(avatarMediaType) || avatarMediaType == "" ||
			verifyAvatar(c, access, avatarCID) != nil {
			return fail(c, "lifedrive.request.invalid_avatar", "error.request.invalid_avatar", false), nil
		}
	case "remove":
		avatarCID = ""
		avatarMediaType = ""
	}
	profile := ownerProfile{
		Version: profileSchemaVersion, MID: mid, DisplayName: displayName, Bio: bio,
		AvatarCID: avatarCID, AvatarMediaType: avatarMediaType, UpdatedAt: serverTime(),
	}
	payload, err := json.Marshal(profile)
	if err != nil || len(payload) > maxProfileBytes {
		return fail(c, "lifedrive.request.invalid_profile", "error.request.invalid_profile", false), nil
	}
	handle, err := c.api.MMOpen(access.authorSID, mid, "cur")
	if err != nil {
		return fail(c, "lifedrive.profile.save_failed", "error.profile.save_failed", true), nil
	}
	defer closeHandle(c, handle)
	written, err := c.api.MFSetData(handle, payload, 0)
	if err != nil || written != len(payload) || c.api.MFTruncate(handle, int64(len(payload))) != nil {
		return fail(c, "lifedrive.profile.save_failed", "error.profile.save_failed", true), nil
	}
	if current.AvatarCID != "" && current.AvatarCID != avatarCID {
		if _, err := c.api.MMDelRef(handle, mid, current.AvatarCID); err != nil {
			return fail(c, "lifedrive.profile.save_failed", "error.profile.save_failed", true), nil
		}
	}
	if avatarCID != "" && avatarCID != current.AvatarCID {
		if _, err := c.api.MMAddRef(handle, mid, avatarCID); err != nil {
			return fail(c, "lifedrive.profile.save_failed", "error.profile.save_failed", true), nil
		}
	}
	version, err := c.api.MMBackup(handle, mid, "profile update", "delref=false")
	if err != nil {
		logError(c, "profile commit failed: %v", err)
		return fail(c, "lifedrive.profile.save_failed", "error.profile.save_failed", true), nil
	}
	return ok(c, map[string]any{
		"drive_mid": access.driveMID, "profile_mid": mid, "version": version, "profile": profile,
	}), nil
}

// entryProfileAvatarUpload follows TweetWeb's proven upload_ipfs sequence:
// write bounded chunks into a Leither temporary file, then convert it to IPFS.
// profile_set attaches the returned CID to the user's profile MiMei with MMAddRef.
func entryProfileAvatarUpload(c *ctx) (any, error) {
	access, err := requireAccess(c, "modify", "drive")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	handle := c.str("upload_id")
	if c.str("finished") == "true" {
		if handle == "" || !validAvatarMediaType(c.str("mime_type")) || c.str("mime_type") == "" {
			return fail(c, "lifedrive.request.invalid_avatar", "error.request.invalid_avatar", false), nil
		}
		defer closeHandle(c, handle)
		size, sizeErr := c.api.MFGetSize(handle)
		if sizeErr != nil || size <= 0 || size > maxAvatarBytes || size != parseInt64(c.str("size"), -1) {
			return fail(c, "lifedrive.request.invalid_avatar", "error.request.invalid_avatar", false), nil
		}
		cid, convertErr := c.api.MFTemp2Ipfs(handle, "")
		if convertErr != nil || !validAvatarCID(cid) {
			logError(c, "avatar IPFS conversion failed: %v", convertErr)
			return fail(c, "lifedrive.profile.avatar_upload_failed", "error.profile.avatar_upload_failed", true), nil
		}
		return ok(c, map[string]any{"cid": cid, "size": size, "media_type": c.str("mime_type")}), nil
	}
	offset := parseInt64(c.str("offset"), -1)
	chunk, chunkErr := chunkArg(c.args)
	if offset < 0 || chunkErr != nil || len(chunk) == 0 || len(chunk) > uploadMaxChunkSize || offset+int64(len(chunk)) > maxAvatarBytes {
		return fail(c, "lifedrive.request.invalid_chunk", "error.request.invalid_chunk", false), nil
	}
	if handle == "" {
		handle, err = c.api.MFOpenTempFile(access.authorSID)
		if err != nil || handle == "" {
			return fail(c, "lifedrive.profile.avatar_upload_failed", "error.profile.avatar_upload_failed", true), nil
		}
	}
	written, err := c.api.MFSetData(handle, chunk, offset)
	if err != nil || written != len(chunk) {
		return fail(c, "lifedrive.profile.avatar_upload_failed", "error.profile.avatar_upload_failed", true), nil
	}
	return ok(c, map[string]any{
		"upload_id": handle, "offset": offset, "received": written, "next_offset": offset + int64(written),
	}), nil
}

func entryProfileAvatarAbort(c *ctx) (any, error) {
	if _, err := requireAccess(c, "modify", "drive"); err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	handle := c.str("upload_id")
	closeHandle(c, handle)
	return ok(c, map[string]any{"upload_id": handle, "state": "aborted"}), nil
}
