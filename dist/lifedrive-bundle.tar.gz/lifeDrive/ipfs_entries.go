package lapp

import "strings"

// The native client pins first using its own Leither session, then registers
// this immutable reference so the existing Files menu can download it later.
// Files calls take "ipfs/<cid>"; "/ipfs/<cid>" names a path in the node's own
// Files tree and does not exist (verified on V0.24.23).
func entryIPFSImport(c *ctx) (any, error) {
	cid, name := c.str("cid"), cleanName(c.str("name"))
	if !validSharedCID(cid) || name == "" {
		return fail(c, "lifedrive.ipfs.invalid_file", "error.ipfs.invalid_file", false), nil
	}
	path, err := normalizeObjectPath("/" + name)
	if err != nil {
		return fail(c, "lifedrive.ipfs.invalid_file", "error.ipfs.invalid_file", false), nil
	}
	access, err := requireAccess(c, "modify", "file")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	source, err := c.api.FilesStat(access.sid, "ipfs/"+cid)
	if err != nil || source.Hash == "" {
		return fail(c, "lifedrive.ipfs.import_failed", "error.ipfs.import_failed", true), nil
	}
	contentHash := source.Hash
	if existing, err := c.api.FilesStat(access.sid, mimeiURL(access.driveMID, "last", path)); err == nil {
		if existing.Hash == contentHash {
			return ok(c, map[string]any{"cid": cid, "path": path}), nil
		}
		return fail(c, "lifedrive.file.already_exists", "error.file.already_exists", false), nil
	}
	staged := c.workPath(path)
	if existing, err := c.api.FilesStat(access.sid, staged); err == nil {
		if existing.Hash != contentHash {
			return fail(c, "lifedrive.file.already_exists", "error.file.already_exists", false), nil
		}
	} else if err := c.api.FilesCopy(access.sid, "ipfs/"+cid, staged, false); err != nil {
		return fail(c, "lifedrive.ipfs.import_failed", "error.ipfs.import_failed", true), nil
	}
	if _, err := commitDrive(c, access); err != nil {
		return fail(c, "lifedrive.ipfs.import_failed", "error.ipfs.import_failed", true), nil
	}
	stored, err := c.api.FilesStat(access.sid, mimeiURL(access.driveMID, "last", path))
	if err != nil || stored.Hash != contentHash {
		return fail(c, "lifedrive.ipfs.import_failed", "error.ipfs.import_failed", true), nil
	}
	return ok(c, map[string]any{"cid": cid, "path": path}), nil
}

func validSharedCID(cid string) bool {
	base58 := "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
	alphabet, body := "", ""
	if strings.HasPrefix(cid, "Qm") && len(cid) == 46 {
		alphabet, body = base58, cid
	} else if len(cid) >= 10 && len(cid) <= 128 {
		if cid[0] == 'b' {
			alphabet, body = "abcdefghijklmnopqrstuvwxyz234567", cid[1:]
		}
		if cid[0] == 'z' {
			alphabet, body = base58, cid[1:]
		}
	}
	if body == "" {
		return false
	}
	for _, character := range body {
		if !strings.ContainsRune(alphabet, character) {
			return false
		}
	}
	return true
}
