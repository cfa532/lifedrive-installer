package lapp

import (
	"encoding/json"
	"fmt"
)

// A node reachable from the internet gets a lepan.org name and certificate
// (docs/LEPAN_NODE_DOMAINS.md). LePan's registrar on AV1 publishes the
// certificate's DNS-01 values, and must get them from the node that owns the
// name, not from whoever asks. It calls node_dns_fetch on AV1's own Leither,
// which runs node_dns_challenge on the named node through Leither's node-to-node
// transport (a cross-node RunMApp, as Tweet's peer calls are made). Both entries
// are public: the values are published in DNS anyway.

// On the node itself: the values of an issuance in progress, held by the
// identity service.
func entryNodeDNSChallenge(c *ctx) (any, error) {
	rpc := householdClient()
	defer rpc.HouseholdClose()
	raw, err := rpc.HouseholdNodeDomain()
	value, err := householdResponse(raw, err)
	if err != nil {
		return fail(c, "lifedrive.domain.unavailable", "error.domain.unavailable", true), nil
	}
	return ok(c, value), nil
}

type crossNodeRunner interface {
	RunMApp(entry string, req map[string]string, args []any, opts ...string) (any, error)
}

// On the registrar's node: node_dns_challenge run on the node named by "node".
// Leither refuses an anonymous /entry?nid= ("GetMApp want System user!"); the
// call needs this node's system session.
func entryNodeDNSFetch(c *ctx) (any, error) {
	nodeID := c.str("node")
	if !validMID(nodeID) {
		return fail(c, "lifedrive.request.invalid_node_id", "error.request.invalid_node_id", false), nil
	}
	runner, isRunner := c.api.(crossNodeRunner)
	if !isRunner {
		return fail(c, "lifedrive.domain.unavailable", "error.domain.unavailable", false), nil
	}
	// RunMApp needs a login session; a BEOpenAppDataNode handle opens the node's
	// own data area and is refused here ("mmsid is a data-area session, not a
	// login identity", V0.24.74), so the call carries the
	// application's author login, as Tweet's Go callRemote does.
	sid, err := authSID(c)
	if err != nil {
		return failDetails(c, "lifedrive.domain.unavailable", "error.domain.unavailable", true, map[string]any{"reason": fmt.Sprintf("author session: %v", err)}), nil
	}
	request := map[string]string{"aid": c.str("aid"), "ver": "last", "sid": sid, "nid": nodeID}
	result, err := runner.RunMApp("node_dns_challenge", request, nil, "nid="+nodeID)
	if err != nil {
		// Leither's reason goes back to the registrar, which logs it; it holds no secret.
		return failDetails(c, "lifedrive.domain.unreachable", "error.domain.unreachable", true, map[string]any{"reason": err.Error()}), nil
	}
	// Passed on as JSON text: the registrar reads the remote envelope's data.values.
	reply, isText := result.(string)
	if !isText {
		encoded, err := json.Marshal(plainJSON(result))
		if err != nil {
			return failDetails(c, "lifedrive.domain.unreachable", "error.domain.unreachable", true, map[string]any{"reason": fmt.Sprintf("reply %T: %v", result, err), "reply": fmt.Sprintf("%v", result)}), nil
		}
		reply = string(encoded)
	}
	return ok(c, map[string]any{"node": nodeID, "reply": reply}), nil
}

// A cross-node reply arrives decoded with interface{} map keys, which
// encoding/json refuses; this turns it into string-keyed maps.
func plainJSON(value any) any {
	switch v := value.(type) {
	case map[interface{}]interface{}:
		out := make(map[string]any, len(v))
		for key, item := range v {
			out[fmt.Sprint(key)] = plainJSON(item)
		}
		return out
	case map[string]any:
		out := make(map[string]any, len(v))
		for key, item := range v {
			out[key] = plainJSON(item)
		}
		return out
	case []any:
		out := make([]any, len(v))
		for i, item := range v {
			out[i] = plainJSON(item)
		}
		return out
	}
	return value
}
