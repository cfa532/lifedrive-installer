//#region \0rolldown/runtime.js
var e = Object.create, t = Object.defineProperty, n = Object.getOwnPropertyDescriptor, r = Object.getOwnPropertyNames, i = Object.getPrototypeOf, a = Object.prototype.hasOwnProperty, o = (e, t) => () => (t || (e((t = { exports: {} }).exports, t), e = null), t.exports), s = (e, i, o, s) => {
	if (i && typeof i == "object" || typeof i == "function") for (var c = r(i), l = 0, u = c.length, d; l < u; l++) d = c[l], !a.call(e, d) && d !== o && t(e, d, {
		get: ((e) => i[e]).bind(null, d),
		enumerable: !(s = n(i, d)) || s.enumerable
	});
	return e;
}, c = (n, r, a) => (a = n == null ? {} : e(i(n)), s(r || !n || !n.__esModule ? t(a, "default", {
	value: n,
	enumerable: !0
}) : a, n));
//#endregion
//#region node_modules/@vue/shared/dist/shared.esm-bundler.js
/* @__NO_SIDE_EFFECTS__ */
function l(e) {
	let t = /* @__PURE__ */ Object.create(null);
	for (let n of e.split(",")) t[n] = 1;
	return (e) => e in t;
}
var u = {}, d = [], f = () => {}, p = () => !1, m = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && (e.charCodeAt(2) > 122 || e.charCodeAt(2) < 97), h = (e) => e.startsWith("onUpdate:"), g = Object.assign, _ = (e, t) => {
	let n = e.indexOf(t);
	n > -1 && e.splice(n, 1);
}, v = Object.prototype.hasOwnProperty, y = (e, t) => v.call(e, t), b = Array.isArray, x = (e) => ne(e) === "[object Map]", S = (e) => ne(e) === "[object Set]", C = (e) => ne(e) === "[object Date]", w = (e) => typeof e == "function", T = (e) => typeof e == "string", E = (e) => typeof e == "symbol", D = (e) => typeof e == "object" && !!e, ee = (e) => (D(e) || w(e)) && w(e.then) && w(e.catch), te = Object.prototype.toString, ne = (e) => te.call(e), re = (e) => ne(e).slice(8, -1), ie = (e) => ne(e) === "[object Object]", ae = (e) => T(e) && e !== "NaN" && e[0] !== "-" && "" + parseInt(e, 10) === e, oe = /* @__PURE__ */ l(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"), O = (e) => {
	let t = /* @__PURE__ */ Object.create(null);
	return ((n) => t[n] || (t[n] = e(n)));
}, se = /-\w/g, k = O((e) => e.replace(se, (e) => e.slice(1).toUpperCase())), ce = /\B([A-Z])/g, A = O((e) => e.replace(ce, "-$1").toLowerCase()), j = O((e) => e.charAt(0).toUpperCase() + e.slice(1)), le = O((e) => e ? `on${j(e)}` : ""), M = (e, t) => !Object.is(e, t), N = (e, ...t) => {
	for (let n = 0; n < e.length; n++) e[n](...t);
}, ue = (e, t, n, r = !1) => {
	Object.defineProperty(e, t, {
		configurable: !0,
		enumerable: !1,
		writable: r,
		value: n
	});
}, P = (e) => {
	let t = parseFloat(e);
	return isNaN(t) ? e : t;
}, de = (e) => {
	let t = T(e) ? Number(e) : NaN;
	return isNaN(t) ? e : t;
}, fe, pe = () => fe ||= typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {};
function me(e) {
	if (b(e)) {
		let t = {};
		for (let n = 0; n < e.length; n++) {
			let r = e[n], i = T(r) ? _e(r) : me(r);
			if (i) for (let e in i) t[e] = i[e];
		}
		return t;
	} else if (T(e) || D(e)) return e;
}
var F = /;(?![^(]*\))/g, he = /:([^]+)/, ge = /\/\*[^]*?\*\//g;
function _e(e) {
	let t = {};
	return e.replace(ge, "").split(F).forEach((e) => {
		if (e) {
			let n = e.split(he);
			n.length > 1 && (t[n[0].trim()] = n[1].trim());
		}
	}), t;
}
function I(e) {
	let t = "";
	if (T(e)) t = e;
	else if (b(e)) for (let n = 0; n < e.length; n++) {
		let r = I(e[n]);
		r && (t += r + " ");
	}
	else if (D(e)) for (let n in e) e[n] && (t += n + " ");
	return t.trim();
}
var ve = "itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly", ye = /* @__PURE__ */ l(ve);
ve + "";
function be(e) {
	return !!e || e === "";
}
function xe(e, t) {
	if (e.length !== t.length) return !1;
	let n = !0;
	for (let r = 0; n && r < e.length; r++) n = Se(e[r], t[r]);
	return n;
}
function Se(e, t) {
	if (e === t) return !0;
	let n = C(e), r = C(t);
	if (n || r) return n && r ? e.getTime() === t.getTime() : !1;
	if (n = E(e), r = E(t), n || r) return e === t;
	if (n = b(e), r = b(t), n || r) return n && r ? xe(e, t) : !1;
	if (n = D(e), r = D(t), n || r) {
		if (!n || !r || Object.keys(e).length !== Object.keys(t).length) return !1;
		for (let n in e) {
			let r = e.hasOwnProperty(n), i = t.hasOwnProperty(n);
			if (r && !i || !r && i || !Se(e[n], t[n])) return !1;
		}
	}
	return String(e) === String(t);
}
function Ce(e, t) {
	return e.findIndex((e) => Se(e, t));
}
var we = (e) => !!(e && e.__v_isRef === !0), L = (e) => T(e) ? e : e == null ? "" : b(e) || D(e) && (e.toString === te || !w(e.toString)) ? we(e) ? L(e.value) : JSON.stringify(e, Te, 2) : String(e), Te = (e, t) => we(t) ? Te(e, t.value) : x(t) ? { [`Map(${t.size})`]: [...t.entries()].reduce((e, [t, n], r) => (e[Ee(t, r) + " =>"] = n, e), {}) } : S(t) ? { [`Set(${t.size})`]: [...t.values()].map((e) => Ee(e)) } : E(t) ? Ee(t) : D(t) && !b(t) && !ie(t) ? String(t) : t, Ee = (e, t = "") => E(e) ? `Symbol(${e.description ?? t})` : e, R, De = class {
	constructor(e = !1) {
		this.detached = e, this._active = !0, this._on = 0, this.effects = [], this.cleanups = [], this._isPaused = !1, this._warnOnRun = !0, this.__v_skip = !0, !e && R && (R.active ? (this.parent = R, this.index = (R.scopes ||= []).push(this) - 1) : (this._active = !1, this._warnOnRun = !1));
	}
	get active() {
		return this._active;
	}
	pause() {
		if (this._active) {
			this._isPaused = !0;
			let e, t;
			if (this.scopes) {
				let n = this.scopes.slice();
				for (e = 0, t = n.length; e < t; e++) n[e].pause();
			}
			for (e = 0, t = this.effects.length; e < t; e++) this.effects[e].pause();
		}
	}
	resume() {
		if (this._active && this._isPaused) {
			this._isPaused = !1;
			let e, t;
			if (this.scopes) {
				let n = this.scopes.slice();
				for (e = 0, t = n.length; e < t; e++) n[e].resume();
			}
			let n = this.effects.slice();
			for (e = 0, t = n.length; e < t; e++) n[e].resume();
		}
	}
	run(e) {
		if (this._active) {
			let t = R;
			try {
				return R = this, e();
			} finally {
				R = t;
			}
		}
	}
	on() {
		++this._on === 1 && (this.prevScope = R, R = this);
	}
	off() {
		if (this._on > 0 && --this._on === 0) {
			if (R === this) R = this.prevScope;
			else {
				let e = R;
				for (; e;) {
					if (e.prevScope === this) {
						e.prevScope = this.prevScope;
						break;
					}
					e = e.prevScope;
				}
			}
			this.prevScope = void 0;
		}
	}
	stop(e) {
		if (this._active) {
			this._active = !1;
			let t, n;
			for (t = 0, n = this.effects.length; t < n; t++) this.effects[t].stop();
			for (this.effects.length = 0, t = 0, n = this.cleanups.length; t < n; t++) this.cleanups[t]();
			if (this.cleanups.length = 0, this.scopes) {
				let e = this.scopes.slice();
				for (t = 0, n = e.length; t < n; t++) e[t].stop(!0);
				this.scopes.length = 0;
			}
			if (!this.detached && this.parent && !e) {
				let e = this.parent.scopes.pop();
				e && e !== this && (this.parent.scopes[this.index] = e, e.index = this.index);
			}
			this.parent = void 0;
		}
	}
};
function Oe() {
	return R;
}
var z, ke = /* @__PURE__ */ new WeakSet(), Ae = class {
	constructor(e) {
		this.fn = e, this.deps = void 0, this.depsTail = void 0, this.flags = 5, this.next = void 0, this.cleanup = void 0, this.scheduler = void 0, R && (R.active ? R.effects.push(this) : this.flags &= -2);
	}
	pause() {
		this.flags |= 64;
	}
	resume() {
		this.flags & 64 && (this.flags &= -65, ke.has(this) && (ke.delete(this), this.trigger()));
	}
	notify() {
		this.flags & 2 && !(this.flags & 32) || this.flags & 8 || Pe(this);
	}
	run() {
		if (!(this.flags & 1)) return this.fn();
		this.flags |= 2, qe(this), Le(this);
		let e = z, t = Ue;
		z = this, Ue = !0;
		try {
			return this.fn();
		} finally {
			Re(this), z = e, Ue = t, this.flags &= -3;
		}
	}
	stop() {
		if (this.flags & 1) {
			for (let e = this.deps; e; e = e.nextDep) Ve(e);
			this.deps = this.depsTail = void 0, qe(this), this.onStop && this.onStop(), this.flags &= -2;
		}
	}
	trigger() {
		this.flags & 64 ? ke.add(this) : this.scheduler ? this.scheduler() : this.runIfDirty();
	}
	runIfDirty() {
		ze(this) && this.run();
	}
	get dirty() {
		return ze(this);
	}
}, je = 0, Me, Ne;
function Pe(e, t = !1) {
	if (e.flags |= 8, t) {
		e.next = Ne, Ne = e;
		return;
	}
	e.next = Me, Me = e;
}
function Fe() {
	je++;
}
function Ie() {
	if (--je > 0) return;
	if (Ne) {
		let e = Ne;
		for (Ne = void 0; e;) {
			let t = e.next;
			e.next = void 0, e.flags &= -9, e = t;
		}
	}
	let e;
	for (; Me;) {
		let t = Me;
		for (Me = void 0; t;) {
			let n = t.next;
			if (t.next = void 0, t.flags &= -9, t.flags & 1) try {
				t.trigger();
			} catch (t) {
				e ||= t;
			}
			t = n;
		}
	}
	if (e) throw e;
}
function Le(e) {
	for (let t = e.deps; t; t = t.nextDep) t.version = -1, t.prevActiveLink = t.dep.activeLink, t.dep.activeLink = t;
}
function Re(e) {
	let t, n = e.depsTail, r = n;
	for (; r;) {
		let e = r.prevDep;
		r.version === -1 ? (r === n && (n = e), Ve(r), He(r)) : t = r, r.dep.activeLink = r.prevActiveLink, r.prevActiveLink = void 0, r = e;
	}
	e.deps = t, e.depsTail = n;
}
function ze(e) {
	for (let t = e.deps; t; t = t.nextDep) if (t.dep.version !== t.version || t.dep.computed && (Be(t.dep.computed) || t.dep.version !== t.version)) return !0;
	return !!e._dirty;
}
function Be(e) {
	if (e.flags & 4 && !(e.flags & 16) || (e.flags &= -17, e.globalVersion === Je) || (e.globalVersion = Je, !e.isSSR && e.flags & 128 && (!e.deps && !e._dirty || !ze(e)))) return;
	e.flags |= 2;
	let t = e.dep, n = z, r = Ue;
	z = e, Ue = !0;
	try {
		Le(e);
		let n = e.fn(e._value);
		(t.version === 0 || M(n, e._value)) && (e.flags |= 128, e._value = n, t.version++);
	} catch (e) {
		throw t.version++, e;
	} finally {
		z = n, Ue = r, Re(e), e.flags &= -3;
	}
}
function Ve(e, t = !1) {
	let { dep: n, prevSub: r, nextSub: i } = e;
	if (r && (r.nextSub = i, e.prevSub = void 0), i && (i.prevSub = r, e.nextSub = void 0), n.subs === e && (n.subs = r, !r && n.computed)) {
		n.computed.flags &= -5;
		for (let e = n.computed.deps; e; e = e.nextDep) Ve(e, !0);
	}
	!t && !--n.sc && n.map && n.map.delete(n.key);
}
function He(e) {
	let { prevDep: t, nextDep: n } = e;
	t && (t.nextDep = n, e.prevDep = void 0), n && (n.prevDep = t, e.nextDep = void 0);
}
var Ue = !0, We = [];
function Ge() {
	We.push(Ue), Ue = !1;
}
function Ke() {
	let e = We.pop();
	Ue = e === void 0 ? !0 : e;
}
function qe(e) {
	let { cleanup: t } = e;
	if (e.cleanup = void 0, t) {
		let e = z;
		z = void 0;
		try {
			t();
		} finally {
			z = e;
		}
	}
}
var Je = 0, Ye = class {
	constructor(e, t) {
		this.sub = e, this.dep = t, this.version = t.version, this.nextDep = this.prevDep = this.nextSub = this.prevSub = this.prevActiveLink = void 0;
	}
}, Xe = class {
	constructor(e) {
		this.computed = e, this.version = 0, this.activeLink = void 0, this.subs = void 0, this.map = void 0, this.key = void 0, this.sc = 0, this.__v_skip = !0;
	}
	track(e) {
		if (!z || !Ue || z === this.computed) return;
		let t = this.activeLink;
		if (t === void 0 || t.sub !== z) t = this.activeLink = new Ye(z, this), z.deps ? (t.prevDep = z.depsTail, z.depsTail.nextDep = t, z.depsTail = t) : z.deps = z.depsTail = t, Ze(t);
		else if (t.version === -1 && (t.version = this.version, t.nextDep)) {
			let e = t.nextDep;
			e.prevDep = t.prevDep, t.prevDep && (t.prevDep.nextDep = e), t.prevDep = z.depsTail, t.nextDep = void 0, z.depsTail.nextDep = t, z.depsTail = t, z.deps === t && (z.deps = e);
		}
		return t;
	}
	trigger(e) {
		this.version++, Je++, this.notify(e);
	}
	notify(e) {
		Fe();
		try {
			for (let e = this.subs; e; e = e.prevSub) e.sub.notify() && e.sub.dep.notify();
		} finally {
			Ie();
		}
	}
};
function Ze(e) {
	if (e.dep.sc++, e.sub.flags & 4) {
		let t = e.dep.computed;
		if (t && !e.dep.subs) {
			t.flags |= 20;
			for (let e = t.deps; e; e = e.nextDep) Ze(e);
		}
		let n = e.dep.subs;
		n !== e && (e.prevSub = n, n && (n.nextSub = e)), e.dep.subs = e;
	}
}
var Qe = /* @__PURE__ */ new WeakMap(), B = /* @__PURE__ */ Symbol(""), $e = /* @__PURE__ */ Symbol(""), et = /* @__PURE__ */ Symbol("");
function tt(e, t, n) {
	if (Ue && z) {
		let t = Qe.get(e);
		t || Qe.set(e, t = /* @__PURE__ */ new Map());
		let r = t.get(n);
		r || (t.set(n, r = new Xe()), r.map = t, r.key = n), r.track();
	}
}
function nt(e, t, n, r, i, a) {
	let o = Qe.get(e);
	if (!o) {
		Je++;
		return;
	}
	let s = (e) => {
		e && e.trigger();
	};
	if (Fe(), t === "clear") o.forEach(s);
	else {
		let i = b(e), a = i && ae(n);
		if (i && n === "length") {
			let e = Number(r);
			o.forEach((t, n) => {
				(n === "length" || n === et || !E(n) && n >= e) && s(t);
			});
		} else switch ((n !== void 0 || o.has(void 0)) && s(o.get(n)), a && s(o.get(et)), t) {
			case "add":
				i ? a && s(o.get("length")) : (s(o.get(B)), x(e) && s(o.get($e)));
				break;
			case "delete":
				i || (s(o.get(B)), x(e) && s(o.get($e)));
				break;
			case "set":
				x(e) && s(o.get(B));
				break;
		}
	}
	Ie();
}
function rt(e) {
	let t = /* @__PURE__ */ H(e);
	return t === e ? t : (tt(t, "iterate", et), /* @__PURE__ */ Vt(e) ? t : t.map(Wt));
}
function it(e) {
	return tt(e = /* @__PURE__ */ H(e), "iterate", et), e;
}
function at(e, t) {
	return /* @__PURE__ */ Bt(e) ? Gt(/* @__PURE__ */ zt(e) ? Wt(t) : t) : Wt(t);
}
var ot = {
	__proto__: null,
	[Symbol.iterator]() {
		return st(this, Symbol.iterator, (e) => at(this, e));
	},
	concat(...e) {
		return rt(this).concat(...e.map((e) => b(e) ? rt(e) : e));
	},
	entries() {
		return st(this, "entries", (e) => (e[1] = at(this, e[1]), e));
	},
	every(e, t) {
		return lt(this, "every", e, t, void 0, arguments);
	},
	filter(e, t) {
		return lt(this, "filter", e, t, (e) => e.map((e) => at(this, e)), arguments);
	},
	find(e, t) {
		return lt(this, "find", e, t, (e) => at(this, e), arguments);
	},
	findIndex(e, t) {
		return lt(this, "findIndex", e, t, void 0, arguments);
	},
	findLast(e, t) {
		return lt(this, "findLast", e, t, (e) => at(this, e), arguments);
	},
	findLastIndex(e, t) {
		return lt(this, "findLastIndex", e, t, void 0, arguments);
	},
	forEach(e, t) {
		return lt(this, "forEach", e, t, void 0, arguments);
	},
	includes(...e) {
		return dt(this, "includes", e);
	},
	indexOf(...e) {
		return dt(this, "indexOf", e);
	},
	join(e) {
		return rt(this).join(e);
	},
	lastIndexOf(...e) {
		return dt(this, "lastIndexOf", e);
	},
	map(e, t) {
		return lt(this, "map", e, t, void 0, arguments);
	},
	pop() {
		return ft(this, "pop");
	},
	push(...e) {
		return ft(this, "push", e);
	},
	reduce(e, ...t) {
		return ut(this, "reduce", e, t);
	},
	reduceRight(e, ...t) {
		return ut(this, "reduceRight", e, t);
	},
	shift() {
		return ft(this, "shift");
	},
	some(e, t) {
		return lt(this, "some", e, t, void 0, arguments);
	},
	splice(...e) {
		return ft(this, "splice", e);
	},
	toReversed() {
		return rt(this).toReversed();
	},
	toSorted(e) {
		return rt(this).toSorted(e);
	},
	toSpliced(...e) {
		return rt(this).toSpliced(...e);
	},
	unshift(...e) {
		return ft(this, "unshift", e);
	},
	values() {
		return st(this, "values", (e) => at(this, e));
	}
};
function st(e, t, n) {
	let r = it(e), i = r[t]();
	return r !== e && !/* @__PURE__ */ Vt(e) && (i._next = i.next, i.next = () => {
		let e = i._next();
		return e.done || (e.value = n(e.value)), e;
	}), i;
}
var ct = Array.prototype;
function lt(e, t, n, r, i, a) {
	let o = it(e), s = o !== e && !/* @__PURE__ */ Vt(e), c = o[t];
	if (c !== ct[t]) {
		let t = c.apply(e, a);
		return s ? Wt(t) : t;
	}
	let l = n;
	o !== e && (s ? l = function(t, r) {
		return n.call(this, at(e, t), r, e);
	} : n.length > 2 && (l = function(t, r) {
		return n.call(this, t, r, e);
	}));
	let u = c.call(o, l, r);
	return s && i ? i(u) : u;
}
function ut(e, t, n, r) {
	let i = it(e), a = i !== e && !/* @__PURE__ */ Vt(e), o = n, s = !1;
	i !== e && (a ? (s = r.length === 0, o = function(t, r, i) {
		return s && (s = !1, t = at(e, t)), n.call(this, t, at(e, r), i, e);
	}) : n.length > 3 && (o = function(t, r, i) {
		return n.call(this, t, r, i, e);
	}));
	let c = i[t](o, ...r);
	return s ? at(e, c) : c;
}
function dt(e, t, n) {
	let r = /* @__PURE__ */ H(e);
	tt(r, "iterate", et);
	let i = r[t](...n);
	return (i === -1 || i === !1) && /* @__PURE__ */ Ht(n[0]) ? (n[0] = /* @__PURE__ */ H(n[0]), r[t](...n)) : i;
}
function ft(e, t, n = []) {
	Ge(), Fe();
	let r = (/* @__PURE__ */ H(e))[t].apply(e, n);
	return Ie(), Ke(), r;
}
var pt = /* @__PURE__ */ l("__proto__,__v_isRef,__isVue"), mt = new Set(/* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((e) => e !== "arguments" && e !== "caller").map((e) => Symbol[e]).filter(E));
function ht(e) {
	E(e) || (e = String(e));
	let t = /* @__PURE__ */ H(this);
	return tt(t, "has", e), t.hasOwnProperty(e);
}
var gt = class {
	constructor(e = !1, t = !1) {
		this._isReadonly = e, this._isShallow = t;
	}
	get(e, t, n) {
		if (t === "__v_skip") return e.__v_skip;
		let r = this._isReadonly, i = this._isShallow;
		if (t === "__v_isReactive") return !r;
		if (t === "__v_isReadonly") return r;
		if (t === "__v_isShallow") return i;
		if (t === "__v_raw") return n === (r ? i ? Nt : Mt : i ? jt : At).get(e) || Object.getPrototypeOf(e) === Object.getPrototypeOf(n) ? e : void 0;
		let a = b(e);
		if (!r) {
			let e;
			if (a && (e = ot[t])) return e;
			if (t === "hasOwnProperty") return ht;
		}
		let o = Reflect.get(e, t, /* @__PURE__ */ Kt(e) ? e : n);
		if ((E(t) ? mt.has(t) : pt(t)) || (r || tt(e, "get", t), i)) return o;
		if (/* @__PURE__ */ Kt(o)) {
			let e = a && ae(t) ? o : o.value;
			return r && D(e) ? /* @__PURE__ */ Lt(e) : e;
		}
		return D(o) ? r ? /* @__PURE__ */ Lt(o) : /* @__PURE__ */ Ft(o) : o;
	}
}, _t = class extends gt {
	constructor(e = !1) {
		super(!1, e);
	}
	set(e, t, n, r) {
		let i = e[t], a = b(e) && ae(t);
		if (!this._isShallow) {
			let e = /* @__PURE__ */ Bt(i);
			if (!/* @__PURE__ */ Vt(n) && !/* @__PURE__ */ Bt(n) && (i = /* @__PURE__ */ H(i), n = /* @__PURE__ */ H(n)), !a && /* @__PURE__ */ Kt(i) && !/* @__PURE__ */ Kt(n)) return e || (i.value = n), !0;
		}
		let o = a ? Number(t) < e.length : y(e, t), s = Reflect.set(e, t, n, /* @__PURE__ */ Kt(e) ? e : r);
		return e === /* @__PURE__ */ H(r) && s && (o ? M(n, i) && nt(e, "set", t, n, i) : nt(e, "add", t, n)), s;
	}
	deleteProperty(e, t) {
		let n = y(e, t), r = e[t], i = Reflect.deleteProperty(e, t);
		return i && n && nt(e, "delete", t, void 0, r), i;
	}
	has(e, t) {
		let n = Reflect.has(e, t);
		return (!E(t) || !mt.has(t)) && tt(e, "has", t), n;
	}
	ownKeys(e) {
		return tt(e, "iterate", b(e) ? "length" : B), Reflect.ownKeys(e);
	}
}, vt = class extends gt {
	constructor(e = !1) {
		super(!0, e);
	}
	set(e, t) {
		return !0;
	}
	deleteProperty(e, t) {
		return !0;
	}
}, yt = /* @__PURE__ */ new _t(), bt = /* @__PURE__ */ new vt(), xt = /* @__PURE__ */ new _t(!0), St = (e) => e, Ct = (e) => Reflect.getPrototypeOf(e);
function wt(e, t, n) {
	return function(...r) {
		let i = this.__v_raw, a = /* @__PURE__ */ H(i), o = x(a), s = e === "entries" || e === Symbol.iterator && o, c = e === "keys" && o, l = i[e](...r), u = n ? St : t ? Gt : Wt;
		return !t && tt(a, "iterate", c ? $e : B), g(Object.create(l), { next() {
			let { value: e, done: t } = l.next();
			return t ? {
				value: e,
				done: t
			} : {
				value: s ? [u(e[0]), u(e[1])] : u(e),
				done: t
			};
		} });
	};
}
function Tt(e) {
	return function(...t) {
		return e === "delete" ? !1 : e === "clear" ? void 0 : this;
	};
}
function Et(e, t) {
	let n = {
		get(n) {
			let r = this.__v_raw, i = /* @__PURE__ */ H(r), a = /* @__PURE__ */ H(n);
			e || (M(n, a) && tt(i, "get", n), tt(i, "get", a));
			let { has: o } = Ct(i), s = t ? St : e ? Gt : Wt;
			if (o.call(i, n)) return s(r.get(n));
			if (o.call(i, a)) return s(r.get(a));
			r !== i && r.get(n);
		},
		get size() {
			let t = this.__v_raw;
			return !e && tt(/* @__PURE__ */ H(t), "iterate", B), t.size;
		},
		has(t) {
			let n = this.__v_raw, r = /* @__PURE__ */ H(n), i = /* @__PURE__ */ H(t);
			return e || (M(t, i) && tt(r, "has", t), tt(r, "has", i)), t === i ? n.has(t) : n.has(t) || n.has(i);
		},
		forEach(n, r) {
			let i = this, a = i.__v_raw, o = /* @__PURE__ */ H(a), s = t ? St : e ? Gt : Wt;
			return !e && tt(o, "iterate", B), a.forEach((e, t) => n.call(r, s(e), s(t), i));
		}
	};
	return g(n, e ? {
		add: Tt("add"),
		set: Tt("set"),
		delete: Tt("delete"),
		clear: Tt("clear")
	} : {
		add(e) {
			let n = /* @__PURE__ */ H(this), r = Ct(n), i = /* @__PURE__ */ H(e), a = !t && !/* @__PURE__ */ Vt(e) && !/* @__PURE__ */ Bt(e) ? i : e;
			return r.has.call(n, a) || M(e, a) && r.has.call(n, e) || M(i, a) && r.has.call(n, i) || (n.add(a), nt(n, "add", a, a)), this;
		},
		set(e, n) {
			!t && !/* @__PURE__ */ Vt(n) && !/* @__PURE__ */ Bt(n) && (n = /* @__PURE__ */ H(n));
			let r = /* @__PURE__ */ H(this), { has: i, get: a } = Ct(r), o = i.call(r, e);
			o ||= (e = /* @__PURE__ */ H(e), i.call(r, e));
			let s = a.call(r, e);
			return r.set(e, n), o ? M(n, s) && nt(r, "set", e, n, s) : nt(r, "add", e, n), this;
		},
		delete(e) {
			let t = /* @__PURE__ */ H(this), { has: n, get: r } = Ct(t), i = n.call(t, e);
			i ||= (e = /* @__PURE__ */ H(e), n.call(t, e));
			let a = r ? r.call(t, e) : void 0, o = t.delete(e);
			return i && nt(t, "delete", e, void 0, a), o;
		},
		clear() {
			let e = /* @__PURE__ */ H(this), t = e.size !== 0, n = e.clear();
			return t && nt(e, "clear", void 0, void 0, void 0), n;
		}
	}), [
		"keys",
		"values",
		"entries",
		Symbol.iterator
	].forEach((r) => {
		n[r] = wt(r, e, t);
	}), n;
}
function Dt(e, t) {
	let n = Et(e, t);
	return (t, r, i) => r === "__v_isReactive" ? !e : r === "__v_isReadonly" ? e : r === "__v_raw" ? t : Reflect.get(y(n, r) && r in t ? n : t, r, i);
}
var V = { get: /* @__PURE__ */ Dt(!1, !1) }, Ot = { get: /* @__PURE__ */ Dt(!1, !0) }, kt = { get: /* @__PURE__ */ Dt(!0, !1) }, At = /* @__PURE__ */ new WeakMap(), jt = /* @__PURE__ */ new WeakMap(), Mt = /* @__PURE__ */ new WeakMap(), Nt = /* @__PURE__ */ new WeakMap();
function Pt(e) {
	switch (e) {
		case "Object":
		case "Array": return 1;
		case "Map":
		case "Set":
		case "WeakMap":
		case "WeakSet": return 2;
		default: return 0;
	}
}
/* @__NO_SIDE_EFFECTS__ */
function Ft(e) {
	return /* @__PURE__ */ Bt(e) ? e : Rt(e, !1, yt, V, At);
}
/* @__NO_SIDE_EFFECTS__ */
function It(e) {
	return Rt(e, !1, xt, Ot, jt);
}
/* @__NO_SIDE_EFFECTS__ */
function Lt(e) {
	return Rt(e, !0, bt, kt, Mt);
}
function Rt(e, t, n, r, i) {
	if (!D(e) || e.__v_raw && !(t && e.__v_isReactive) || e.__v_skip || !Object.isExtensible(e)) return e;
	let a = i.get(e);
	if (a) return a;
	let o = Pt(re(e));
	if (o === 0) return e;
	let s = new Proxy(e, o === 2 ? r : n);
	return i.set(e, s), s;
}
/* @__NO_SIDE_EFFECTS__ */
function zt(e) {
	return /* @__PURE__ */ Bt(e) ? /* @__PURE__ */ zt(e.__v_raw) : !!(e && e.__v_isReactive);
}
/* @__NO_SIDE_EFFECTS__ */
function Bt(e) {
	return !!(e && e.__v_isReadonly);
}
/* @__NO_SIDE_EFFECTS__ */
function Vt(e) {
	return !!(e && e.__v_isShallow);
}
/* @__NO_SIDE_EFFECTS__ */
function Ht(e) {
	return e ? !!e.__v_raw : !1;
}
/* @__NO_SIDE_EFFECTS__ */
function H(e) {
	let t = e && e.__v_raw;
	return t ? /* @__PURE__ */ H(t) : e;
}
function Ut(e) {
	return !y(e, "__v_skip") && Object.isExtensible(e) && ue(e, "__v_skip", !0), e;
}
var Wt = (e) => D(e) ? /* @__PURE__ */ Ft(e) : e, Gt = (e) => D(e) ? /* @__PURE__ */ Lt(e) : e;
/* @__NO_SIDE_EFFECTS__ */
function Kt(e) {
	return e ? e.__v_isRef === !0 : !1;
}
/* @__NO_SIDE_EFFECTS__ */
function U(e) {
	return qt(e, !1);
}
function qt(e, t) {
	return /* @__PURE__ */ Kt(e) ? e : new Jt(e, t);
}
var Jt = class {
	constructor(e, t) {
		this.dep = new Xe(), this.__v_isRef = !0, this.__v_isShallow = !1, this._rawValue = t ? e : /* @__PURE__ */ H(e), this._value = t ? e : Wt(e), this.__v_isShallow = t;
	}
	get value() {
		return this.dep.track(), this._value;
	}
	set value(e) {
		let t = this._rawValue, n = this.__v_isShallow || /* @__PURE__ */ Vt(e) || /* @__PURE__ */ Bt(e);
		e = n ? e : /* @__PURE__ */ H(e), M(e, t) && (this._rawValue = e, this._value = n ? e : Wt(e), this.dep.trigger());
	}
};
function W(e) {
	return /* @__PURE__ */ Kt(e) ? e.value : e;
}
var Yt = {
	get: (e, t, n) => t === "__v_raw" ? e : W(Reflect.get(e, t, n)),
	set: (e, t, n, r) => {
		let i = e[t];
		return /* @__PURE__ */ Kt(i) && !/* @__PURE__ */ Kt(n) ? (i.value = n, !0) : Reflect.set(e, t, n, r);
	}
};
function Xt(e) {
	return /* @__PURE__ */ zt(e) ? e : new Proxy(e, Yt);
}
var Zt = class {
	constructor(e, t, n) {
		this.fn = e, this.setter = t, this._value = void 0, this.dep = new Xe(this), this.__v_isRef = !0, this.deps = void 0, this.depsTail = void 0, this.flags = 16, this.globalVersion = Je - 1, this.next = void 0, this.effect = this, this.__v_isReadonly = !t, this.isSSR = n;
	}
	notify() {
		if (this.flags |= 16, !(this.flags & 8) && z !== this) return Pe(this, !0), !0;
	}
	get value() {
		let e = this.dep.track();
		return Be(this), e && (e.version = this.dep.version), this._value;
	}
	set value(e) {
		this.setter && this.setter(e);
	}
};
/* @__NO_SIDE_EFFECTS__ */
function Qt(e, t, n = !1) {
	let r, i;
	return w(e) ? r = e : (r = e.get, i = e.set), new Zt(r, i, n);
}
var $t = {}, en = /* @__PURE__ */ new WeakMap(), tn = void 0;
function nn(e, t = !1, n = tn) {
	if (n) {
		let t = en.get(n);
		t || en.set(n, t = []), t.push(e);
	}
}
function rn(e, t, n = u) {
	let { immediate: r, deep: i, once: a, scheduler: o, augmentJob: s, call: c } = n, l = (e) => i ? e : /* @__PURE__ */ Vt(e) || i === !1 || i === 0 ? an(e, 1) : an(e), d, p, m, h, g = !1, v = !1;
	if (/* @__PURE__ */ Kt(e) ? (p = () => e.value, g = /* @__PURE__ */ Vt(e)) : /* @__PURE__ */ zt(e) ? (p = () => l(e), g = !0) : b(e) ? (v = !0, g = e.some((e) => /* @__PURE__ */ zt(e) || /* @__PURE__ */ Vt(e)), p = () => e.map((e) => {
		if (/* @__PURE__ */ Kt(e)) return e.value;
		if (/* @__PURE__ */ zt(e)) return l(e);
		if (w(e)) return c ? c(e, 2) : e();
	})) : p = w(e) ? t ? c ? () => c(e, 2) : e : () => {
		if (m) {
			Ge();
			try {
				m();
			} finally {
				Ke();
			}
		}
		let t = tn;
		tn = d;
		try {
			return c ? c(e, 3, [h]) : e(h);
		} finally {
			tn = t;
		}
	} : f, t && i) {
		let e = p, t = i === !0 ? Infinity : i;
		p = () => an(e(), t);
	}
	let y = Oe(), x = () => {
		d.stop(), y && y.active && _(y.effects, d);
	};
	if (a && t) {
		let e = t;
		t = (...t) => {
			let n = e(...t);
			return x(), n;
		};
	}
	let S = v ? Array(e.length).fill($t) : $t, C = (e) => {
		if (!(!(d.flags & 1) || !d.dirty && !e)) if (t) {
			let n = d.run();
			if (e || i || g || (v ? n.some((e, t) => M(e, S[t])) : M(n, S))) {
				m && m();
				let e = tn;
				tn = d;
				try {
					let e = [
						n,
						S === $t ? void 0 : v && S[0] === $t ? [] : S,
						h
					];
					S = n, c ? c(t, 3, e) : t(...e);
				} finally {
					tn = e;
				}
			}
		} else d.run();
	};
	return s && s(C), d = new Ae(p), d.scheduler = o ? () => o(C, !1) : C, h = (e) => nn(e, !1, d), m = d.onStop = () => {
		let e = en.get(d);
		if (e) {
			if (c) c(e, 4);
			else for (let t of e) t();
			en.delete(d);
		}
	}, t ? r ? C(!0) : S = d.run() : o ? o(C.bind(null, !0), !0) : d.run(), x.pause = d.pause.bind(d), x.resume = d.resume.bind(d), x.stop = x, x;
}
function an(e, t = Infinity, n) {
	if (t <= 0 || !D(e) || e.__v_skip || (n ||= /* @__PURE__ */ new Map(), (n.get(e) || 0) >= t)) return e;
	if (n.set(e, t), t--, /* @__PURE__ */ Kt(e)) an(e.value, t, n);
	else if (b(e)) for (let r = 0; r < e.length; r++) an(e[r], t, n);
	else if (S(e) || x(e)) e.forEach((e) => {
		an(e, t, n);
	});
	else if (ie(e)) {
		for (let r in e) an(e[r], t, n);
		for (let r of Object.getOwnPropertySymbols(e)) Object.prototype.propertyIsEnumerable.call(e, r) && an(e[r], t, n);
	}
	return e;
}
//#endregion
//#region node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js
function on(e, t, n, r) {
	try {
		return r ? e(...r) : e();
	} catch (e) {
		cn(e, t, n);
	}
}
function sn(e, t, n, r) {
	if (w(e)) {
		let i = on(e, t, n, r);
		return i && ee(i) && i.catch((e) => {
			cn(e, t, n);
		}), i;
	}
	if (b(e)) {
		let i = [];
		for (let a = 0; a < e.length; a++) i.push(sn(e[a], t, n, r));
		return i;
	}
}
function cn(e, t, n, r = !0) {
	let i = t ? t.vnode : null, { errorHandler: a, throwUnhandledErrorInProduction: o } = t && t.appContext.config || u;
	if (t) {
		let r = t.parent, i = t.proxy, o = `https://vuejs.org/error-reference/#runtime-${n}`;
		for (; r;) {
			let t = r.ec;
			if (t) {
				for (let n = 0; n < t.length; n++) if (t[n](e, i, o) === !1) return;
			}
			r = r.parent;
		}
		if (a) {
			Ge(), on(a, null, 10, [
				e,
				i,
				o
			]), Ke();
			return;
		}
	}
	ln(e, n, i, r, o);
}
function ln(e, t, n, r = !0, i = !1) {
	if (i) throw e;
	console.error(e);
}
var un = [], dn = -1, fn = [], pn = null, mn = 0, hn = /* @__PURE__ */ Promise.resolve(), gn = null;
function _n(e) {
	let t = gn || hn;
	return e ? t.then(this ? e.bind(this) : e) : t;
}
function vn(e) {
	let t = dn + 1, n = un.length;
	for (; t < n;) {
		let r = t + n >>> 1, i = un[r], a = wn(i);
		a < e || a === e && i.flags & 2 ? t = r + 1 : n = r;
	}
	return t;
}
function yn(e) {
	if (!(e.flags & 1)) {
		let t = wn(e), n = un[un.length - 1];
		!n || !(e.flags & 2) && t >= wn(n) ? un.push(e) : un.splice(vn(t), 0, e), e.flags |= 1, bn();
	}
}
function bn() {
	gn ||= hn.then(Tn);
}
function xn(e) {
	if (!b(e)) pn && e.id === -1 ? pn.splice(mn + 1, 0, e) : e.flags & 1 || (fn.push(e), e.flags |= 1);
	else for (let t = 0; t < e.length; t++) fn.push(e[t]);
	bn();
}
function Sn(e, t, n = dn + 1) {
	for (; n < un.length; n++) {
		let t = un[n];
		if (t && t.flags & 2) {
			if (e && t.id !== e.uid) continue;
			un.splice(n, 1), n--, t.flags & 4 && (t.flags &= -2), t(), t.flags & 4 || (t.flags &= -2);
		}
	}
}
function Cn(e) {
	if (fn.length) {
		let e = [...new Set(fn)].sort((e, t) => wn(e) - wn(t));
		if (fn.length = 0, pn) {
			for (let t = 0; t < e.length; t++) pn.push(e[t]);
			return;
		}
		for (pn = e, mn = 0; mn < pn.length; mn++) {
			let e = pn[mn];
			e.flags & 4 && (e.flags &= -2), e.flags & 8 || e(), e.flags &= -2;
		}
		pn = null, mn = 0;
	}
}
var wn = (e) => e.id == null ? e.flags & 2 ? -1 : Infinity : e.id;
function Tn(e) {
	try {
		for (dn = 0; dn < un.length; dn++) {
			let e = un[dn];
			e && !(e.flags & 8) && (e.flags & 4 && (e.flags &= -2), on(e, e.i, e.i ? 15 : 14), e.flags & 4 || (e.flags &= -2));
		}
	} finally {
		for (; dn < un.length; dn++) {
			let e = un[dn];
			e && (e.flags &= -2);
		}
		dn = -1, un.length = 0, Cn(e), gn = null, (un.length || fn.length) && Tn(e);
	}
}
var En = null, Dn = null;
function On(e) {
	let t = En;
	return En = e, Dn = e && e.type.__scopeId || null, t;
}
function kn(e, t = En, n) {
	if (!t || e._n) return e;
	let r = (...n) => {
		r._d && $i(-1);
		let i = On(t), a = Yi.length, o;
		try {
			o = e(...n);
		} finally {
			for (let e = Yi.length; e > a; e--) Zi();
			On(i), r._d && $i(1);
		}
		return o;
	};
	return r._n = !0, r._c = !0, r._d = !0, r;
}
function An(e, t) {
	if (En === null) return e;
	let n = Pa(En), r = e.dirs ||= [];
	for (let e = 0; e < t.length; e++) {
		let [i, a, o, s = u] = t[e];
		i && (w(i) && (i = {
			mounted: i,
			updated: i
		}), i.deep && an(a), r.push({
			dir: i,
			instance: n,
			value: a,
			oldValue: void 0,
			arg: o,
			modifiers: s
		}));
	}
	return e;
}
function jn(e, t, n, r) {
	let i = e.dirs, a = t && t.dirs;
	for (let o = 0; o < i.length; o++) {
		let s = i[o];
		a && (s.oldValue = a[o].value);
		let c = s.dir[r];
		c && (Ge(), sn(c, n, 8, [
			e.el,
			s,
			e,
			t
		]), Ke());
	}
}
function Mn(e, t) {
	if (va) {
		let n = va.provides, r = va.parent && va.parent.provides;
		r === n && (n = va.provides = Object.create(r)), n[e] = t;
	}
}
function Nn(e, t, n = !1) {
	let r = ya();
	if (r || ni) {
		let i = ni ? ni._context.provides : r ? r.parent == null || r.ce ? r.vnode.appContext && r.vnode.appContext.provides : r.parent.provides : void 0;
		if (i && e in i) return i[e];
		if (arguments.length > 1) return n && w(t) ? t.call(r && r.proxy) : t;
	}
}
var Pn = /* @__PURE__ */ Symbol.for("v-scx"), Fn = () => Nn(Pn);
function In(e, t, n) {
	return Ln(e, t, n);
}
function Ln(e, t, n = u) {
	let { immediate: r, deep: i, flush: a, once: o } = n, s = g({}, n), c = t && r || !t && a !== "post", l;
	if (Ta) {
		if (a === "sync") {
			let e = Fn();
			l = e.__watcherHandles ||= [];
		} else if (!c) {
			let e = () => {};
			return e.stop = f, e.resume = f, e.pause = f, e;
		}
	}
	let d = va;
	s.call = (e, t, n) => sn(e, d, t, n);
	let p = !1;
	a === "post" ? s.scheduler = (e) => {
		Ni(e, d && d.suspense);
	} : a !== "sync" && (p = !0, s.scheduler = (e, t) => {
		t ? e() : yn(e);
	}), s.augmentJob = (e) => {
		t && (e.flags |= 4), p && (e.flags |= 2, d && (e.id = d.uid, e.i = d));
	};
	let m = rn(e, t, s);
	return Ta && (l ? l.push(m) : c && m()), m;
}
function Rn(e, t, n) {
	let r = this.proxy, i = T(e) ? e.includes(".") ? zn(r, e) : () => r[e] : e.bind(r, r), a;
	w(t) ? a = t : (a = t.handler, n = t);
	let o = Sa(this), s = Ln(i, a.bind(r), n);
	return o(), s;
}
function zn(e, t) {
	let n = t.split(".");
	return () => {
		let t = e;
		for (let e = 0; e < n.length && t; e++) t = t[n[e]];
		return t;
	};
}
var Bn = /* @__PURE__ */ Symbol("_vte"), Vn = (e) => e.__isTeleport, Hn = /* @__PURE__ */ Symbol("_leaveCb"), Un = /* @__PURE__ */ Symbol("_enterCb");
function Wn() {
	let e = {
		isMounted: !1,
		isLeaving: !1,
		isUnmounting: !1,
		leavingVNodes: /* @__PURE__ */ new Map()
	};
	return vr(() => {
		e.isMounted = !0;
	}), xr(() => {
		e.isUnmounting = !0;
	}), e;
}
var Gn = [Function, Array], Kn = {
	mode: String,
	appear: Boolean,
	persisted: Boolean,
	onBeforeEnter: Gn,
	onEnter: Gn,
	onAfterEnter: Gn,
	onEnterCancelled: Gn,
	onBeforeLeave: Gn,
	onLeave: Gn,
	onAfterLeave: Gn,
	onLeaveCancelled: Gn,
	onBeforeAppear: Gn,
	onAppear: Gn,
	onAfterAppear: Gn,
	onAppearCancelled: Gn
}, qn = (e) => {
	let t = e.subTree;
	return t.component ? qn(t.component) : t;
}, Jn = {
	name: "BaseTransition",
	props: Kn,
	setup(e, { slots: t }) {
		let n = ya(), r = Wn();
		return () => {
			let i = t.default && nr(t.default(), !0), a = i && i.length ? Yn(i) : n.subTree ? Z() : void 0;
			if (!a) return;
			let o = /* @__PURE__ */ H(e), { mode: s } = o;
			if (r.isLeaving) return $n(a);
			let c = er(a);
			if (!c) return $n(a);
			let l = Qn(c, o, r, n, (e) => l = e);
			c.type !== qi && tr(c, l);
			let u = n.subTree && er(n.subTree);
			if (u && u.type !== qi && !ra(u, c) && qn(n).type !== qi) {
				let e = Qn(u, o, r, n);
				if (tr(u, e), s === "out-in" && c.type !== qi) return r.isLeaving = !0, e.afterLeave = () => {
					r.isLeaving = !1, n.job.flags & 8 || n.update(), delete e.afterLeave, u = void 0;
				}, $n(a);
				s === "in-out" && c.type !== qi ? e.delayLeave = (e, t, n) => {
					let i = Zn(r, u);
					i[String(u.key)] = u, e[Hn] = () => {
						t(), e[Hn] = void 0, delete l.delayedLeave, u = void 0;
					}, l.delayedLeave = () => {
						n(), delete l.delayedLeave, u = void 0;
					};
				} : u = void 0;
			} else u &&= void 0;
			return a;
		};
	}
};
function Yn(e) {
	let t = e[0];
	if (e.length > 1) {
		for (let n of e) if (n.type !== qi) {
			t = n;
			break;
		}
	}
	return t;
}
var Xn = Jn;
function Zn(e, t) {
	let { leavingVNodes: n } = e, r = n.get(t.type);
	return r || (r = /* @__PURE__ */ Object.create(null), n.set(t.type, r)), r;
}
function Qn(e, t, n, r, i) {
	let { appear: a, mode: o, persisted: s = !1, onBeforeEnter: c, onEnter: l, onAfterEnter: u, onEnterCancelled: d, onBeforeLeave: f, onLeave: p, onAfterLeave: m, onLeaveCancelled: h, onBeforeAppear: g, onAppear: _, onAfterAppear: v, onAppearCancelled: y } = t, x = String(e.key), S = Zn(n, e), C = (e, t) => {
		e && sn(e, r, 9, t);
	}, w = (e, t) => {
		let n = t[1];
		C(e, t), b(e) ? e.every((e) => e.length <= 1) && n() : e.length <= 1 && n();
	}, T = {
		mode: o,
		persisted: s,
		beforeEnter(t) {
			let r = c;
			if (!n.isMounted) if (a) r = g || c;
			else return;
			t[Hn] && t[Hn](!0);
			let i = S[x];
			i && ra(e, i) && i.el[Hn] && i.el[Hn](), C(r, [t]);
		},
		enter(t) {
			if (S[x] === e) return;
			let r = l, i = u, o = d;
			if (!n.isMounted) if (a) r = _ || l, i = v || u, o = y || d;
			else return;
			let s = !1;
			t[Un] = (e) => {
				s || (s = !0, C(e ? o : i, [t]), T.delayedLeave && T.delayedLeave(), t[Un] = void 0);
			};
			let c = t[Un].bind(null, !1);
			r ? w(r, [t, c]) : c();
		},
		leave(t, r) {
			let i = String(e.key);
			if (t[Un] && t[Un](!0), n.isUnmounting) return r();
			C(f, [t]);
			let a = !1;
			t[Hn] = (n) => {
				a || (a = !0, r(), C(n ? h : m, [t]), t[Hn] = void 0, S[i] === e && delete S[i]);
			};
			let o = t[Hn].bind(null, !1);
			S[i] = e, p ? w(p, [t, o]) : o();
		},
		clone(e) {
			let a = Qn(e, t, n, r, i);
			return i && i(a), a;
		}
	};
	return T;
}
function $n(e) {
	if (ur(e)) return e = ca(e), e.children = null, e;
}
function er(e) {
	if (!ur(e)) return Vn(e.type) && e.children ? Yn(e.children) : e;
	if (e.component) return e.component.subTree;
	let { shapeFlag: t, children: n } = e;
	if (n) {
		if (t & 16) return n[0];
		if (t & 32 && w(n.default)) return n.default();
	}
}
function tr(e, t) {
	if (e.shapeFlag & 6 && e.component) {
		e.transition = t;
		let n = e.component.subTree;
		tr(Vn(n.type) && er(n) || n, t);
	} else e.shapeFlag & 128 ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t;
}
function nr(e, t = !1, n) {
	let r = [], i = 0;
	for (let a = 0; a < e.length; a++) {
		let o = e[a], s = n == null ? o.key : String(n) + String(o.key == null ? a : o.key);
		o.type === G ? (o.patchFlag & 128 && i++, r = r.concat(nr(o.children, t, s))) : (t || o.type !== qi) && r.push(s == null ? o : ca(o, { key: s }));
	}
	if (i > 1) for (let e = 0; e < r.length; e++) r[e].patchFlag = -2;
	return r;
}
/* @__NO_SIDE_EFFECTS__ */
function rr(e, t) {
	return w(e) ? g({ name: e.name }, t, { setup: e }) : e;
}
function ir(e) {
	e.ids = [
		e.ids[0] + e.ids[2]++ + "-",
		0,
		0
	];
}
function ar(e, t) {
	let n;
	return !!((n = Object.getOwnPropertyDescriptor(e, t)) && !n.configurable);
}
var or = /* @__PURE__ */ new WeakMap();
function sr(e, t, n, r, i = !1) {
	if (b(e)) {
		e.forEach((e, a) => sr(e, t && (b(t) ? t[a] : t), n, r, i));
		return;
	}
	if (lr(r) && !i) {
		r.shapeFlag & 512 && r.type.__asyncResolved && r.component.subTree.component && sr(e, t, n, r.component.subTree);
		return;
	}
	let a = r.shapeFlag & 4 ? Pa(r.component) : r.el, o = i ? null : a, { i: s, r: c } = e, l = t && t.r, d = s.refs === u ? s.refs = {} : s.refs, f = s.setupState, m = /* @__PURE__ */ H(f), h = f === u ? p : (e) => ar(d, e) ? !1 : y(m, e), g = (e, t) => !(t && ar(d, t));
	if (l != null && l !== c) {
		if (cr(t), T(l)) d[l] = null, h(l) && (f[l] = null);
		else if (/* @__PURE__ */ Kt(l)) {
			let e = t;
			g(l, e.k) && (l.value = null), e.k && (d[e.k] = null);
		}
	}
	if (w(c)) on(c, s, 12, [o, d]);
	else {
		let t = T(c), r = /* @__PURE__ */ Kt(c);
		if (t || r) {
			let s = () => {
				if (e.f) {
					let n = t ? h(c) ? f[c] : d[c] : g(c) || !e.k ? c.value : d[e.k];
					if (i) b(n) && _(n, a);
					else if (b(n)) n.includes(a) || n.push(a);
					else if (t) d[c] = [a], h(c) && (f[c] = d[c]);
					else {
						let t = [a];
						g(c, e.k) && (c.value = t), e.k && (d[e.k] = t);
					}
				} else t ? (d[c] = o, h(c) && (f[c] = o)) : r && (g(c, e.k) && (c.value = o), e.k && (d[e.k] = o));
			};
			if (o) {
				let t = () => {
					s(), or.delete(e);
				};
				t.id = -1, or.set(e, t), Ni(t, n);
			} else cr(e), s();
		}
	}
}
function cr(e) {
	let t = or.get(e);
	t && (t.flags |= 8, or.delete(e));
}
pe().requestIdleCallback, pe().cancelIdleCallback;
var lr = (e) => !!e.type.__asyncLoader, ur = (e) => e.type.__isKeepAlive;
function dr(e, t) {
	pr(e, "a", t);
}
function fr(e, t) {
	pr(e, "da", t);
}
function pr(e, t, n = va) {
	let r = e.__wdc ||= () => {
		let t = n;
		for (; t;) {
			if (t.isDeactivated) return;
			t = t.parent;
		}
		return e();
	};
	if (hr(t, r, n), n) {
		let e = n.parent;
		for (; e && e.parent;) ur(e.parent.vnode) && mr(r, t, n, e), e = e.parent;
	}
}
function mr(e, t, n, r) {
	let i = hr(t, e, r, !0);
	Sr(() => {
		_(r[t], i);
	}, n);
}
function hr(e, t, n = va, r = !1) {
	if (n) {
		let i = n[e] || (n[e] = []), a = t.__weh ||= (...r) => {
			Ge();
			let i = Sa(n), a = sn(t, n, e, r);
			return i(), Ke(), a;
		};
		return r ? i.unshift(a) : i.push(a), a;
	}
}
var gr = (e) => (t, n = va) => {
	(!Ta || e === "sp") && hr(e, (...e) => t(...e), n);
}, _r = gr("bm"), vr = gr("m"), yr = gr("bu"), br = gr("u"), xr = gr("bum"), Sr = gr("um"), Cr = gr("sp"), wr = gr("rtg"), Tr = gr("rtc");
function Er(e, t = va) {
	hr("ec", e, t);
}
var Dr = "components", Or = /* @__PURE__ */ Symbol.for("v-ndc");
function kr(e) {
	return T(e) ? Ar(Dr, e, !1) || e : e || Or;
}
function Ar(e, t, n = !0, r = !1) {
	let i = En || va;
	if (i) {
		let n = i.type;
		if (e === Dr) {
			let e = Fa(n, !1);
			if (e && (e === t || e === k(t) || e === j(k(t)))) return n;
		}
		let a = jr(i[e] || n[e], t) || jr(i.appContext[e], t);
		return !a && r ? n : a;
	}
}
function jr(e, t) {
	return e && (e[t] || e[k(t)] || e[j(k(t))]);
}
function Mr(e, t, n, r) {
	let i, a = n && n[r], o = b(e);
	if (o || T(e)) {
		let n = o && /* @__PURE__ */ zt(e), r = !1, s = !1;
		n && (r = !/* @__PURE__ */ Vt(e), s = /* @__PURE__ */ Bt(e), e = it(e)), i = Array(e.length);
		for (let n = 0, o = e.length; n < o; n++) i[n] = t(r ? s ? Gt(Wt(e[n])) : Wt(e[n]) : e[n], n, void 0, a && a[n]);
	} else if (typeof e == "number") {
		i = Array(e);
		for (let n = 0; n < e; n++) i[n] = t(n + 1, n, void 0, a && a[n]);
	} else if (D(e)) if (e[Symbol.iterator]) i = Array.from(e, (e, n) => t(e, n, void 0, a && a[n]));
	else {
		let n = Object.keys(e);
		i = Array(n.length);
		for (let r = 0, o = n.length; r < o; r++) {
			let o = n[r];
			i[r] = t(e[o], o, r, a && a[r]);
		}
	}
	else i = [];
	return n && (n[r] = i), i;
}
var Nr = (e) => e ? wa(e) ? Pa(e) : Nr(e.parent) : null, Pr = /* @__PURE__ */ g(/* @__PURE__ */ Object.create(null), {
	$: (e) => e,
	$el: (e) => e.vnode.el,
	$data: (e) => e.data,
	$props: (e) => e.props,
	$attrs: (e) => e.attrs,
	$slots: (e) => e.slots,
	$refs: (e) => e.refs,
	$parent: (e) => Nr(e.parent),
	$root: (e) => Nr(e.root),
	$host: (e) => e.ce,
	$emit: (e) => e.emit,
	$options: (e) => Ur(e),
	$forceUpdate: (e) => e.f ||= () => {
		yn(e.update);
	},
	$nextTick: (e) => e.n ||= _n.bind(e.proxy),
	$watch: (e) => Rn.bind(e)
}), Fr = (e, t) => e !== u && !e.__isScriptSetup && y(e, t), Ir = {
	get({ _: e }, t) {
		if (t === "__v_skip") return !0;
		let { ctx: n, setupState: r, data: i, props: a, accessCache: o, type: s, appContext: c } = e;
		if (t[0] !== "$") {
			let e = o[t];
			if (e !== void 0) switch (e) {
				case 1: return r[t];
				case 2: return i[t];
				case 4: return n[t];
				case 3: return a[t];
			}
			else if (Fr(r, t)) return o[t] = 1, r[t];
			else if (i !== u && y(i, t)) return o[t] = 2, i[t];
			else if (y(a, t)) return o[t] = 3, a[t];
			else if (n !== u && y(n, t)) return o[t] = 4, n[t];
			else Rr && (o[t] = 0);
		}
		let l = Pr[t], d, f;
		if (l) return t === "$attrs" && tt(e.attrs, "get", ""), l(e);
		if ((d = s.__cssModules) && (d = d[t])) return d;
		if (n !== u && y(n, t)) return o[t] = 4, n[t];
		if (f = c.config.globalProperties, y(f, t)) return f[t];
	},
	set({ _: e }, t, n) {
		let { data: r, setupState: i, ctx: a } = e;
		return Fr(i, t) ? (i[t] = n, !0) : r !== u && y(r, t) ? (r[t] = n, !0) : y(e.props, t) || t[0] === "$" && t.slice(1) in e ? !1 : (a[t] = n, !0);
	},
	has({ _: { data: e, setupState: t, accessCache: n, ctx: r, appContext: i, props: a, type: o } }, s) {
		let c;
		return !!(n[s] || e !== u && s[0] !== "$" && y(e, s) || Fr(t, s) || y(a, s) || y(r, s) || y(Pr, s) || y(i.config.globalProperties, s) || (c = o.__cssModules) && c[s]);
	},
	defineProperty(e, t, n) {
		return n.get == null ? y(n, "value") && this.set(e, t, n.value, null) : e._.accessCache[t] = 0, Reflect.defineProperty(e, t, n);
	}
};
function Lr(e) {
	return b(e) ? e.reduce((e, t) => (e[t] = null, e), {}) : e;
}
var Rr = !0;
function zr(e) {
	let t = Ur(e), n = e.proxy, r = e.ctx;
	Rr = !1, t.beforeCreate && Vr(t.beforeCreate, e, "bc");
	let { data: i, computed: a, methods: o, watch: s, provide: c, inject: l, created: u, beforeMount: d, mounted: p, beforeUpdate: m, updated: h, activated: g, deactivated: _, beforeDestroy: v, beforeUnmount: y, destroyed: x, unmounted: S, render: C, renderTracked: T, renderTriggered: E, errorCaptured: ee, serverPrefetch: te, expose: ne, inheritAttrs: re, components: ie, directives: ae, filters: oe } = t;
	if (l && Br(l, r, null), o) for (let e in o) {
		let t = o[e];
		w(t) && (r[e] = t.bind(n));
	}
	if (i) {
		let t = i.call(n, n);
		D(t) && (e.data = /* @__PURE__ */ Ft(t));
	}
	if (Rr = !0, a) for (let e in a) {
		let t = a[e], i = Q({
			get: w(t) ? t.bind(n, n) : w(t.get) ? t.get.bind(n, n) : f,
			set: !w(t) && w(t.set) ? t.set.bind(n) : f
		});
		Object.defineProperty(r, e, {
			enumerable: !0,
			configurable: !0,
			get: () => i.value,
			set: (e) => i.value = e
		});
	}
	if (s) for (let e in s) Hr(s[e], r, n, e);
	if (c) {
		let e = w(c) ? c.call(n) : c;
		Reflect.ownKeys(e).forEach((t) => {
			Mn(t, e[t]);
		});
	}
	u && Vr(u, e, "c");
	function O(e, t) {
		b(t) ? t.forEach((t) => e(t.bind(n))) : t && e(t.bind(n));
	}
	if (O(_r, d), O(vr, p), O(yr, m), O(br, h), O(dr, g), O(fr, _), O(Er, ee), O(Tr, T), O(wr, E), O(xr, y), O(Sr, S), O(Cr, te), b(ne)) if (ne.length) {
		let t = e.exposed ||= {};
		ne.forEach((e) => {
			Object.defineProperty(t, e, {
				get: () => n[e],
				set: (t) => n[e] = t,
				enumerable: !0
			});
		});
	} else e.exposed ||= {};
	C && e.render === f && (e.render = C), re != null && (e.inheritAttrs = re), ie && (e.components = ie), ae && (e.directives = ae), te && ir(e);
}
function Br(e, t, n = f) {
	b(e) && (e = Jr(e));
	for (let n in e) {
		let r = e[n], i;
		i = D(r) ? "default" in r ? Nn(r.from || n, r.default, !0) : Nn(r.from || n) : Nn(r), /* @__PURE__ */ Kt(i) ? Object.defineProperty(t, n, {
			enumerable: !0,
			configurable: !0,
			get: () => i.value,
			set: (e) => i.value = e
		}) : t[n] = i;
	}
}
function Vr(e, t, n) {
	sn(b(e) ? e.map((e) => e.bind(t.proxy)) : e.bind(t.proxy), t, n);
}
function Hr(e, t, n, r) {
	let i = r.includes(".") ? zn(n, r) : () => n[r];
	if (T(e)) {
		let n = t[e];
		w(n) && In(i, n);
	} else if (w(e)) In(i, e.bind(n));
	else if (D(e)) if (b(e)) e.forEach((e) => Hr(e, t, n, r));
	else {
		let r = w(e.handler) ? e.handler.bind(n) : t[e.handler];
		w(r) && In(i, r, e);
	}
}
function Ur(e) {
	let t = e.type, { mixins: n, extends: r } = t, { mixins: i, optionsCache: a, config: { optionMergeStrategies: o } } = e.appContext, s = a.get(t), c;
	return s ? c = s : !i.length && !n && !r ? c = t : (c = {}, i.length && i.forEach((e) => Wr(c, e, o, !0)), Wr(c, t, o)), D(t) && a.set(t, c), c;
}
function Wr(e, t, n, r = !1) {
	let { mixins: i, extends: a } = t;
	a && Wr(e, a, n, !0), i && i.forEach((t) => Wr(e, t, n, !0));
	for (let i in t) if (!(r && i === "expose")) {
		let r = Gr[i] || n && n[i];
		e[i] = r ? r(e[i], t[i]) : t[i];
	}
	return e;
}
var Gr = {
	data: Kr,
	props: Zr,
	emits: Zr,
	methods: Xr,
	computed: Xr,
	beforeCreate: Yr,
	created: Yr,
	beforeMount: Yr,
	mounted: Yr,
	beforeUpdate: Yr,
	updated: Yr,
	beforeDestroy: Yr,
	beforeUnmount: Yr,
	destroyed: Yr,
	unmounted: Yr,
	activated: Yr,
	deactivated: Yr,
	errorCaptured: Yr,
	serverPrefetch: Yr,
	components: Xr,
	directives: Xr,
	watch: Qr,
	provide: Kr,
	inject: qr
};
function Kr(e, t) {
	return t ? e ? function() {
		return g(w(e) ? e.call(this, this) : e, w(t) ? t.call(this, this) : t);
	} : t : e;
}
function qr(e, t) {
	return Xr(Jr(e), Jr(t));
}
function Jr(e) {
	if (b(e)) {
		let t = {};
		for (let n = 0; n < e.length; n++) t[e[n]] = e[n];
		return t;
	}
	return e;
}
function Yr(e, t) {
	return e ? [...new Set([].concat(e, t))] : t;
}
function Xr(e, t) {
	return e ? g(/* @__PURE__ */ Object.create(null), e, t) : t;
}
function Zr(e, t) {
	return e ? b(e) && b(t) ? [.../* @__PURE__ */ new Set([...e, ...t])] : g(/* @__PURE__ */ Object.create(null), Lr(e), Lr(t ?? {})) : t;
}
function Qr(e, t) {
	if (!e) return t;
	if (!t) return e;
	let n = g(/* @__PURE__ */ Object.create(null), e);
	for (let r in t) n[r] = Yr(e[r], t[r]);
	return n;
}
function $r() {
	return {
		app: null,
		config: {
			isNativeTag: p,
			performance: !1,
			globalProperties: {},
			optionMergeStrategies: {},
			errorHandler: void 0,
			warnHandler: void 0,
			compilerOptions: {}
		},
		mixins: [],
		components: {},
		directives: {},
		provides: /* @__PURE__ */ Object.create(null),
		optionsCache: /* @__PURE__ */ new WeakMap(),
		propsCache: /* @__PURE__ */ new WeakMap(),
		emitsCache: /* @__PURE__ */ new WeakMap()
	};
}
var ei = 0;
function ti(e, t) {
	return function(n, r = null) {
		w(n) || (n = g({}, n)), r != null && !D(r) && (r = null);
		let i = $r(), a = /* @__PURE__ */ new WeakSet(), o = [], s = !1, c = i.app = {
			_uid: ei++,
			_component: n,
			_props: r,
			_container: null,
			_context: i,
			_instance: null,
			version: Ra,
			get config() {
				return i.config;
			},
			set config(e) {},
			use(e, ...t) {
				return a.has(e) || (e && w(e.install) ? (a.add(e), e.install(c, ...t)) : w(e) && (a.add(e), e(c, ...t))), c;
			},
			mixin(e) {
				return i.mixins.includes(e) || i.mixins.push(e), c;
			},
			component(e, t) {
				return t ? (i.components[e] = t, c) : i.components[e];
			},
			directive(e, t) {
				return t ? (i.directives[e] = t, c) : i.directives[e];
			},
			mount(a, o, l) {
				if (!s) {
					let u = c._ceVNode || Y(n, r);
					return u.appContext = i, l === !0 ? l = "svg" : l === !1 && (l = void 0), o && t ? t(u, a) : e(u, a, l), s = !0, c._container = a, a.__vue_app__ = c, Pa(u.component);
				}
			},
			onUnmount(e) {
				o.push(e);
			},
			unmount() {
				s && (sn(o, c._instance, 16), e(null, c._container), delete c._container.__vue_app__);
			},
			provide(e, t) {
				return i.provides[e] = t, c;
			},
			runWithContext(e) {
				let t = ni;
				ni = c;
				try {
					return e();
				} finally {
					ni = t;
				}
			}
		};
		return c;
	};
}
var ni = null, ri = (e, t) => t === "modelValue" || t === "model-value" ? e.modelModifiers : e[`${t}Modifiers`] || e[`${k(t)}Modifiers`] || e[`${A(t)}Modifiers`];
function ii(e, t, ...n) {
	if (e.isUnmounted) return;
	let r = e.vnode.props || u, i = n, a = t.startsWith("update:"), o = a && ri(r, t.slice(7));
	o && (o.trim && (i = n.map((e) => T(e) ? e.trim() : e)), o.number && (i = n.map(P)));
	let s, c = r[s = le(t)] || r[s = le(k(t))];
	!c && a && (c = r[s = le(A(t))]), c && sn(c, e, 6, i);
	let l = r[s + "Once"];
	if (l) {
		if (!e.emitted) e.emitted = {};
		else if (e.emitted[s]) return;
		e.emitted[s] = !0, sn(l, e, 6, i);
	}
}
var ai = /* @__PURE__ */ new WeakMap();
function oi(e, t, n = !1) {
	let r = n ? ai : t.emitsCache, i = r.get(e);
	if (i !== void 0) return i;
	let a = e.emits, o = {}, s = !1;
	if (!w(e)) {
		let r = (e) => {
			let n = oi(e, t, !0);
			n && (s = !0, g(o, n));
		};
		!n && t.mixins.length && t.mixins.forEach(r), e.extends && r(e.extends), e.mixins && e.mixins.forEach(r);
	}
	return !a && !s ? (D(e) && r.set(e, null), null) : (b(a) ? a.forEach((e) => o[e] = null) : g(o, a), D(e) && r.set(e, o), o);
}
function si(e, t) {
	return !e || !m(t) ? !1 : (t = t.slice(2), t = t === "Once" ? t : t.replace(/Once$/, ""), y(e, t[0].toLowerCase() + t.slice(1)) || y(e, A(t)) || y(e, t));
}
function ci(e) {
	let { type: t, vnode: n, proxy: r, withProxy: i, propsOptions: [a], slots: o, attrs: s, emit: c, render: l, renderCache: u, props: d, data: f, setupState: p, ctx: m, inheritAttrs: g } = e, _ = On(e), v, y;
	try {
		if (n.shapeFlag & 4) {
			let e = i || r, t = e;
			v = ua(l.call(t, e, u, d, p, f, m)), y = s;
		} else {
			let e = t;
			v = ua(e.length > 1 ? e(d, {
				attrs: s,
				slots: o,
				emit: c
			}) : e(d, null)), y = t.props ? s : li(s);
		}
	} catch (t) {
		Yi.length = 0, cn(t, e, 1), v = Y(qi);
	}
	let b = v;
	if (y && g !== !1) {
		let e = Object.keys(y), { shapeFlag: t } = b;
		e.length && t & 7 && (a && e.some(h) && (y = ui(y, a)), b = ca(b, y, !1, !0));
	}
	return n.dirs && (b = ca(b, null, !1, !0), b.dirs = b.dirs ? b.dirs.concat(n.dirs) : n.dirs), n.transition && tr(Vn(b.type) && er(b) || b, n.transition), v = b, On(_), v;
}
var li = (e) => {
	let t;
	for (let n in e) (n === "class" || n === "style" || m(n)) && ((t ||= {})[n] = e[n]);
	return t;
}, ui = (e, t) => {
	let n = {};
	for (let r in e) (!h(r) || !(r.slice(9) in t)) && (n[r] = e[r]);
	return n;
};
function di(e, t, n) {
	let { props: r, children: i, component: a } = e, { props: o, children: s, patchFlag: c } = t, l = a.emitsOptions;
	if (t.dirs || t.transition) return !0;
	if (n && c >= 0) {
		if (c & 1024) return !0;
		if (c & 16) return r ? fi(r, o, l) : !!o;
		if (c & 8) {
			let e = t.dynamicProps;
			for (let t = 0; t < e.length; t++) {
				let n = e[t];
				if (pi(o, r, n) && !si(l, n)) return !0;
			}
		}
	} else return (i || s) && (!s || !s.$stable) ? !0 : r === o ? !1 : r ? o ? fi(r, o, l) : !0 : !!o;
	return !1;
}
function fi(e, t, n) {
	let r = Object.keys(t);
	if (r.length !== Object.keys(e).length) return !0;
	for (let i = 0; i < r.length; i++) {
		let a = r[i];
		if (pi(t, e, a) && !si(n, a)) return !0;
	}
	return !1;
}
function pi(e, t, n) {
	let r = e[n], i = t[n];
	return n === "style" && D(r) && D(i) ? !Se(r, i) : r !== i;
}
function mi({ vnode: e, parent: t, suspense: n }, r) {
	for (; t;) {
		let n = t.subTree;
		if (n.suspense && n.suspense.activeBranch === e && (n.suspense.vnode.el = n.el = r, e = n), n === e) (e = t.vnode).el = r, t = t.parent;
		else break;
	}
	n && n.activeBranch === e && (n.vnode.el = r);
}
var hi = {}, gi = () => Object.create(hi), _i = (e) => Object.getPrototypeOf(e) === hi;
function vi(e, t, n, r = !1) {
	let i = {}, a = gi();
	e.propsDefaults = /* @__PURE__ */ Object.create(null), bi(e, t, i, a);
	for (let t in e.propsOptions[0]) t in i || (i[t] = void 0);
	n ? e.props = r ? i : /* @__PURE__ */ It(i) : e.type.props ? e.props = i : e.props = a, e.attrs = a;
}
function yi(e, t, n, r) {
	let { props: i, attrs: a, vnode: { patchFlag: o } } = e, s = /* @__PURE__ */ H(i), [c] = e.propsOptions, l = !1;
	if ((r || o > 0) && !(o & 16)) {
		if (o & 8) {
			let n = e.vnode.dynamicProps;
			for (let r = 0; r < n.length; r++) {
				let o = n[r];
				if (si(e.emitsOptions, o)) continue;
				let u = t[o];
				if (c) if (y(a, o)) u !== a[o] && (a[o] = u, l = !0);
				else {
					let t = k(o);
					i[t] = xi(c, s, t, u, e, !1);
				}
				else u !== a[o] && (a[o] = u, l = !0);
			}
		}
	} else {
		bi(e, t, i, a) && (l = !0);
		let r;
		for (let a in s) (!t || !y(t, a) && ((r = A(a)) === a || !y(t, r))) && (c ? n && (n[a] !== void 0 || n[r] !== void 0) && (i[a] = xi(c, s, a, void 0, e, !0)) : delete i[a]);
		if (a !== s) for (let e in a) (!t || !y(t, e)) && (delete a[e], l = !0);
	}
	l && nt(e.attrs, "set", "");
}
function bi(e, t, n, r) {
	let [i, a] = e.propsOptions, o = !1, s;
	if (t) for (let c in t) {
		if (oe(c)) continue;
		let l = t[c], u;
		i && y(i, u = k(c)) ? !a || !a.includes(u) ? n[u] = l : (s ||= {})[u] = l : si(e.emitsOptions, c) || (!(c in r) || l !== r[c]) && (r[c] = l, o = !0);
	}
	if (a) {
		let t = /* @__PURE__ */ H(n), r = s || u;
		for (let o = 0; o < a.length; o++) {
			let s = a[o];
			n[s] = xi(i, t, s, r[s], e, !y(r, s));
		}
	}
	return o;
}
function xi(e, t, n, r, i, a) {
	let o = e[n];
	if (o != null) {
		let e = y(o, "default");
		if (e && r === void 0) {
			let e = o.default;
			if (o.type !== Function && !o.skipFactory && w(e)) {
				let { propsDefaults: a } = i;
				if (n in a) r = a[n];
				else {
					let o = Sa(i);
					r = a[n] = e.call(null, t), o();
				}
			} else r = e;
			i.ce && i.ce._setProp(n, r);
		}
		o[0] && (a && !e ? r = !1 : o[1] && (r === "" || r === A(n)) && (r = !0));
	}
	return r;
}
var Si = /* @__PURE__ */ new WeakMap();
function Ci(e, t, n = !1) {
	let r = n ? Si : t.propsCache, i = r.get(e);
	if (i) return i;
	let a = e.props, o = {}, s = [], c = !1;
	if (!w(e)) {
		let r = (e) => {
			c = !0;
			let [n, r] = Ci(e, t, !0);
			g(o, n), r && s.push(...r);
		};
		!n && t.mixins.length && t.mixins.forEach(r), e.extends && r(e.extends), e.mixins && e.mixins.forEach(r);
	}
	if (!a && !c) return D(e) && r.set(e, d), d;
	if (b(a)) for (let e = 0; e < a.length; e++) {
		let t = k(a[e]);
		wi(t) && (o[t] = u);
	}
	else if (a) for (let e in a) {
		let t = k(e);
		if (wi(t)) {
			let n = a[e], r = o[t] = b(n) || w(n) ? { type: n } : g({}, n), i = r.type, c = !1, l = !0;
			if (b(i)) for (let e = 0; e < i.length; ++e) {
				let t = i[e], n = w(t) && t.name;
				if (n === "Boolean") {
					c = !0;
					break;
				} else n === "String" && (l = !1);
			}
			else c = w(i) && i.name === "Boolean";
			r[0] = c, r[1] = l, (c || y(r, "default")) && s.push(t);
		}
	}
	let l = [o, s];
	return D(e) && r.set(e, l), l;
}
function wi(e) {
	return e[0] !== "$" && !oe(e);
}
var Ti = (e) => e === "_" || e === "_ctx" || e === "$stable", Ei = (e) => b(e) ? e.map(ua) : [ua(e)], Di = (e, t, n) => {
	if (t._n) return t;
	let r = kn((...e) => Ei(t(...e)), n);
	return r._c = !1, r;
}, Oi = (e, t, n) => {
	let r = e._ctx;
	for (let n in e) {
		if (Ti(n)) continue;
		let i = e[n];
		if (w(i)) t[n] = Di(n, i, r);
		else if (i != null) {
			let e = Ei(i);
			t[n] = () => e;
		}
	}
}, ki = (e, t) => {
	let n = Ei(t);
	e.slots.default = () => n;
}, Ai = (e, t, n) => {
	for (let r in t) (n || !Ti(r)) && (e[r] = t[r]);
}, ji = (e, t, n) => {
	let r = e.slots = gi();
	if (e.vnode.shapeFlag & 32) {
		let e = t._;
		e ? (Ai(r, t, n), n && ue(r, "_", e, !0)) : Oi(t, r);
	} else t && ki(e, t);
}, Mi = (e, t, n) => {
	let { vnode: r, slots: i } = e, a = !0, o = u;
	if (r.shapeFlag & 32) {
		let e = t._;
		e ? n && e === 1 ? a = !1 : Ai(i, t, n) : (a = !t.$stable, Oi(t, i)), o = t;
	} else t && (ki(e, t), o = { default: 1 });
	if (a) for (let e in i) !Ti(e) && o[e] == null && delete i[e];
}, Ni = Gi;
function Pi(e) {
	return Fi(e);
}
function Fi(e, t) {
	let n = pe();
	n.__VUE__ = !0;
	let { insert: r, remove: i, patchProp: a, createElement: o, createText: s, createComment: c, setText: l, setElementText: p, parentNode: m, nextSibling: h, setScopeId: g = f, insertStaticContent: _ } = e, v = (e, t, n, r = null, i = null, a = null, o = void 0, s = null, c = !!t.dynamicChildren) => {
		if (e === t) return;
		e && !ra(e, t) && (r = me(e), M(e, i, a, !0), e = null), t.patchFlag === -2 && (c = !1, t.dynamicChildren = null);
		let { type: l, ref: u, shapeFlag: d } = t;
		switch (l) {
			case Ki:
				y(e, t, n, r);
				break;
			case qi:
				b(e, t, n, r);
				break;
			case Ji:
				e ?? x(t, n, r, o);
				break;
			case G:
				re(e, t, n, r, i, a, o, s, c);
				break;
			default: d & 1 ? w(e, t, n, r, i, a, o, s, c) : d & 6 ? ie(e, t, n, r, i, a, o, s, c) : (d & 64 || d & 128) && l.process(e, t, n, r, i, a, o, s, c, ge);
		}
		u != null && i ? sr(u, e && e.ref, a, t || e, !t) : u == null && e && e.ref != null && sr(e.ref, null, a, e, !0);
	}, y = (e, t, n, i) => {
		if (e == null) r(t.el = s(t.children), n, i);
		else {
			let n = t.el = e.el;
			t.children !== e.children && l(n, t.children);
		}
	}, b = (e, t, n, i) => {
		e == null ? r(t.el = c(t.children || ""), n, i) : t.el = e.el;
	}, x = (e, t, n, r) => {
		[e.el, e.anchor] = _(e.children, t, n, r, e.el, e.anchor);
	}, S = ({ el: e, anchor: t }, n, i) => {
		let a;
		for (; e && e !== t;) a = h(e), r(e, n, i), e = a;
		r(t, n, i);
	}, C = ({ el: e, anchor: t }) => {
		let n;
		for (; e && e !== t;) n = h(e), i(e), e = n;
		i(t);
	}, w = (e, t, n, r, i, a, o, s, c) => {
		if (t.type === "svg" ? o = "svg" : t.type === "math" && (o = "mathml"), e == null) T(t, n, r, i, a, o, s, c);
		else {
			let n = e.el && e.el._isVueCE ? e.el : null;
			try {
				n && n._beginPatch(), ee(e, t, i, a, o, s, c);
			} finally {
				n && n._endPatch();
			}
		}
	}, T = (e, t, n, i, s, c, l, u) => {
		let d, f, { props: m, shapeFlag: h, transition: g, dirs: _ } = e;
		if (d = e.el = o(e.type, c, m && m.is, m), h & 8 ? p(d, e.children) : h & 16 && D(e.children, d, null, i, s, Ii(e, c), l, u), _ && jn(e, null, i, "created"), E(d, e, e.scopeId, l, i), m) {
			for (let e in m) e !== "value" && !oe(e) && a(d, e, null, m[e], c, i);
			"value" in m && a(d, "value", null, m.value, c), (f = m.onVnodeBeforeMount) && ma(f, i, e);
		}
		_ && jn(e, null, i, "beforeMount");
		let v = Ri(s, g);
		v && g.beforeEnter(d), r(d, t, n), ((f = m && m.onVnodeMounted) || v || _) && Ni(() => {
			try {
				f && ma(f, i, e), v && g.enter(d), _ && jn(e, null, i, "mounted");
			} finally {}
		}, s);
	}, E = (e, t, n, r, i) => {
		if (n && g(e, n), r) for (let t = 0; t < r.length; t++) g(e, r[t]);
		if (i) {
			let n = i.subTree;
			if (t === n || Wi(n.type) && (n.ssContent === t || n.ssFallback === t)) {
				let t = i.vnode;
				E(e, t, t.scopeId, t.slotScopeIds, i.parent);
			}
		}
	}, D = (e, t, n, r, i, a, o, s, c = 0) => {
		for (let l = c; l < e.length; l++) v(null, e[l] = s ? da(e[l]) : ua(e[l]), t, n, r, i, a, o, s);
	}, ee = (e, t, n, r, i, o, s) => {
		let c = t.el = e.el, { patchFlag: l, dynamicChildren: d, dirs: f } = t;
		l |= e.patchFlag & 16;
		let m = e.props || u, h = t.props || u, g;
		if (n && Li(n, !1), (g = h.onVnodeBeforeUpdate) && ma(g, n, t, e), f && jn(t, e, n, "beforeUpdate"), n && Li(n, !0), d && (!e.dynamicChildren || e.dynamicChildren.length !== d.length) && (l = 0, s = !1, d = null), (m.innerHTML && h.innerHTML == null || m.textContent && h.textContent == null) && p(c, ""), d ? te(e.dynamicChildren, d, c, n, r, Ii(t, i), o) : s || ce(e, t, c, null, n, r, Ii(t, i), o, !1), l > 0) {
			if (l & 16) ne(c, m, h, n, i);
			else if (l & 2 && m.class !== h.class && a(c, "class", null, h.class, i), l & 4 && a(c, "style", m.style, h.style, i), l & 8) {
				let e = t.dynamicProps;
				for (let t = 0; t < e.length; t++) {
					let r = e[t], o = m[r], s = h[r];
					(s !== o || r === "value") && a(c, r, o, s, i, n);
				}
			}
			l & 1 && e.children !== t.children && p(c, t.children);
		} else !s && d == null && ne(c, m, h, n, i);
		((g = h.onVnodeUpdated) || f) && Ni(() => {
			g && ma(g, n, t, e), f && jn(t, e, n, "updated");
		}, r);
	}, te = (e, t, n, r, i, a, o) => {
		for (let s = 0; s < t.length; s++) {
			let c = e[s], l = t[s];
			v(c, l, c.el && (c.type === G || !ra(c, l) || c.shapeFlag & 198) ? m(c.el) : n, null, r, i, a, o, !0);
		}
	}, ne = (e, t, n, r, i) => {
		if (t !== n) {
			if (t !== u) for (let o in t) !oe(o) && !(o in n) && a(e, o, t[o], null, i, r);
			for (let o in n) {
				if (oe(o)) continue;
				let s = n[o], c = t[o];
				s !== c && o !== "value" && a(e, o, c, s, i, r);
			}
			"value" in n && a(e, "value", t.value, n.value, i);
		}
	}, re = (e, t, n, i, a, o, c, l, u) => {
		let d = t.el = e ? e.el : s(""), f = t.anchor = e ? e.anchor : s(""), { patchFlag: p, dynamicChildren: m, slotScopeIds: h } = t;
		h && (l = l ? l.concat(h) : h), e == null ? (r(d, n, i), r(f, n, i), D(t.children || [], n, f, a, o, c, l, u)) : p > 0 && p & 64 && m && e.dynamicChildren && e.dynamicChildren.length === m.length ? (te(e.dynamicChildren, m, n, a, o, c, l), (t.key != null || a && t === a.subTree) && zi(e, t, !0)) : ce(e, t, n, f, a, o, c, l, u);
	}, ie = (e, t, n, r, i, a, o, s, c) => {
		t.slotScopeIds = s, e == null ? t.shapeFlag & 512 ? i.ctx.activate(t, n, r, o, c) : ae(t, n, r, i, a, o, c) : O(e, t, c);
	}, ae = (e, t, n, r, i, a, o) => {
		let s = e.component = _a(e, r, i);
		if (ur(e) && (s.ctx.renderer = ge), Ea(s, !1, o), s.asyncDep) {
			if (i && i.registerDep(s, se, o), !e.el) {
				let r = s.subTree = Y(qi);
				b(null, r, t, n), e.placeholder = r.el;
			}
		} else se(s, e, t, n, i, a, o);
	}, O = (e, t, n) => {
		let r = t.component = e.component;
		if (di(e, t, n)) if (r.asyncDep && !r.asyncResolved) {
			k(r, t, n);
			return;
		} else r.next = t, r.update();
		else t.el = e.el, r.vnode = t;
	}, se = (e, t, n, r, i, a, o) => {
		let s = () => {
			if (e.isMounted) {
				let { next: t, bu: n, u: r, parent: s, vnode: c } = e;
				{
					let n = Vi(e);
					if (n) {
						t && (t.el = c.el, k(e, t, o)), n.asyncDep.then(() => {
							Ni(() => {
								e.isUnmounted || l();
							}, i);
						});
						return;
					}
				}
				let u = t, d;
				Li(e, !1), t ? (t.el = c.el, k(e, t, o)) : t = c, n && N(n), (d = t.props && t.props.onVnodeBeforeUpdate) && ma(d, s, t, c), Li(e, !0);
				let f = ci(e), p = e.subTree;
				e.subTree = f, v(p, f, m(p.el), me(p), e, i, a), t.el = f.el, u === null && mi(e, f.el), r && Ni(r, i), (d = t.props && t.props.onVnodeUpdated) && Ni(() => ma(d, s, t, c), i);
			} else {
				let o, { el: s, props: c } = t, { bm: l, m: u, parent: d, root: f, type: p } = e, m = lr(t);
				if (Li(e, !1), l && N(l), !m && (o = c && c.onVnodeBeforeMount) && ma(o, d, t), Li(e, !0), s && I) {
					let t = () => {
						e.subTree = ci(e), I(s, e.subTree, e, i, null);
					};
					m && p.__asyncHydrate ? p.__asyncHydrate(s, e, t) : t();
				} else {
					f.ce && f.ce._hasShadowRoot() && f.ce._injectChildStyle(p, e.parent ? e.parent.type : void 0);
					let o = e.subTree = ci(e);
					v(null, o, n, r, e, i, a), t.el = o.el;
				}
				if (u && Ni(u, i), !m && (o = c && c.onVnodeMounted)) {
					let e = t;
					Ni(() => ma(o, d, e), i);
				}
				(t.shapeFlag & 256 || d && lr(d.vnode) && d.vnode.shapeFlag & 256) && e.a && Ni(e.a, i), e.isMounted = !0, t = n = r = null;
			}
		};
		e.scope.on();
		let c = e.effect = new Ae(s);
		e.scope.off();
		let l = e.update = c.run.bind(c), u = e.job = c.runIfDirty.bind(c);
		u.i = e, u.id = e.uid, c.scheduler = () => yn(u), Li(e, !0), l();
	}, k = (e, t, n) => {
		t.component = e;
		let r = e.vnode.props;
		e.vnode = t, e.next = null, yi(e, t.props, r, n), Mi(e, t.children, n), Ge(), Sn(e), Ke();
	}, ce = (e, t, n, r, i, a, o, s, c = !1) => {
		let l = e && e.children, u = e ? e.shapeFlag : 0, d = t.children, { patchFlag: f, shapeFlag: m } = t;
		if (f > 0) {
			if (f & 128) {
				j(l, d, n, r, i, a, o, s, c);
				return;
			} else if (f & 256) {
				A(l, d, n, r, i, a, o, s, c);
				return;
			}
		}
		m & 8 ? (u & 16 && fe(l, i, a), d !== l && p(n, d)) : u & 16 ? m & 16 ? j(l, d, n, r, i, a, o, s, c) : fe(l, i, a, !0) : (u & 8 && p(n, ""), m & 16 && D(d, n, r, i, a, o, s, c));
	}, A = (e, t, n, r, i, a, o, s, c) => {
		e ||= d, t ||= d;
		let l = e.length, u = t.length, f = Math.min(l, u), p;
		for (p = 0; p < f; p++) {
			let r = t[p] = c ? da(t[p]) : ua(t[p]);
			v(e[p], r, n, null, i, a, o, s, c);
		}
		l > u ? fe(e, i, a, !0, !1, f) : D(t, n, r, i, a, o, s, c, f);
	}, j = (e, t, n, r, i, a, o, s, c) => {
		let l = 0, u = t.length, f = e.length - 1, p = u - 1;
		for (; l <= f && l <= p;) {
			let r = e[l], u = t[l] = c ? da(t[l]) : ua(t[l]);
			if (ra(r, u)) v(r, u, n, null, i, a, o, s, c);
			else break;
			l++;
		}
		for (; l <= f && l <= p;) {
			let r = e[f], l = t[p] = c ? da(t[p]) : ua(t[p]);
			if (ra(r, l)) v(r, l, n, null, i, a, o, s, c);
			else break;
			f--, p--;
		}
		if (l > f) {
			if (l <= p) {
				let e = p + 1, d = e < u ? t[e].el : r;
				for (; l <= p;) v(null, t[l] = c ? da(t[l]) : ua(t[l]), n, d, i, a, o, s, c), l++;
			}
		} else if (l > p) for (; l <= f;) M(e[l], i, a, !0), l++;
		else {
			let m = l, h = l, g = /* @__PURE__ */ new Map();
			for (l = h; l <= p; l++) {
				let e = t[l] = c ? da(t[l]) : ua(t[l]);
				e.key != null && g.set(e.key, l);
			}
			let _, y = 0, b = p - h + 1, x = !1, S = 0, C = Array(b);
			for (l = 0; l < b; l++) C[l] = 0;
			for (l = m; l <= f; l++) {
				let r = e[l];
				if (y >= b) {
					M(r, i, a, !0);
					continue;
				}
				let u;
				if (r.key != null) u = g.get(r.key);
				else for (_ = h; _ <= p; _++) if (C[_ - h] === 0 && ra(r, t[_])) {
					u = _;
					break;
				}
				u === void 0 ? M(r, i, a, !0) : (C[u - h] = l + 1, u >= S ? S = u : x = !0, v(r, t[u], n, null, i, a, o, s, c), y++);
			}
			let w = x ? Bi(C) : d;
			for (_ = w.length - 1, l = b - 1; l >= 0; l--) {
				let e = h + l, d = t[e], f = t[e + 1], p = e + 1 < u ? f.el || Ui(f) : r;
				C[l] === 0 ? v(null, d, n, p, i, a, o, s, c) : x && (_ < 0 || l !== w[_] ? le(d, n, p, 2) : _--);
			}
		}
	}, le = (e, t, n, a, o = null) => {
		let { el: s, type: c, transition: l, children: u, shapeFlag: d } = e;
		if (d & 6) {
			le(e.component.subTree, t, n, a);
			return;
		}
		if (d & 128) {
			e.suspense.move(t, n, a);
			return;
		}
		if (d & 64) {
			c.move(e, t, n, ge);
			return;
		}
		if (c === G) {
			r(s, t, n);
			for (let e = 0; e < u.length; e++) le(u[e], t, n, a);
			r(e.anchor, t, n);
			return;
		}
		if (c === Ji) {
			S(e, t, n);
			return;
		}
		if (a !== 2 && d & 1 && l) if (a === 0) l.persisted && !s[Hn] ? r(s, t, n) : (l.beforeEnter(s), r(s, t, n), Ni(() => l.enter(s), o));
		else {
			let { leave: a, delayLeave: o, afterLeave: c } = l, u = () => {
				e.ctx.isUnmounted ? i(s) : r(s, t, n);
			}, d = () => {
				let e = s._isLeaving || !!s[Hn];
				s._isLeaving && s[Hn](!0), l.persisted && !e ? u() : a(s, () => {
					u(), c && c();
				});
			};
			o ? o(s, u, d) : d();
		}
		else r(s, t, n);
	}, M = (e, t, n, r = !1, i = !1) => {
		let { type: a, props: o, ref: s, children: c, dynamicChildren: l, shapeFlag: u, patchFlag: d, dirs: f, cacheIndex: p, memo: m } = e;
		if (d === -2 && (i = !1), s != null && (Ge(), sr(s, null, n, e, !0), Ke()), p != null && (t.renderCache[p] = void 0), u & 256) {
			t.ctx.deactivate(e);
			return;
		}
		let h = u & 1 && f, g = !lr(e), _;
		if (g && (_ = o && o.onVnodeBeforeUnmount) && ma(_, t, e), u & 6) de(e.component, n, r);
		else {
			if (u & 128) {
				e.suspense.unmount(n, r);
				return;
			}
			h && jn(e, null, t, "beforeUnmount"), u & 64 ? e.type.remove(e, t, n, ge, r) : l && !l.hasOnce && (a !== G || d > 0 && d & 64) ? fe(l, t, n, !1, !0) : (a === G && d & 384 || !i && u & 16) && fe(c, t, n), r && ue(e);
		}
		let v = m != null && p == null;
		(g && (_ = o && o.onVnodeUnmounted) || h || v) && Ni(() => {
			_ && ma(_, t, e), h && jn(e, null, t, "unmounted"), v && (e.el = null);
		}, n);
	}, ue = (e) => {
		let { type: t, el: n, anchor: r, transition: a } = e;
		if (t === G) {
			P(n, r);
			return;
		}
		if (t === Ji) {
			C(e);
			return;
		}
		let o = () => {
			i(n), a && !a.persisted && a.afterLeave && a.afterLeave();
		};
		if (e.shapeFlag & 1 && a && !a.persisted) {
			let { leave: t, delayLeave: r } = a, i = () => t(n, o);
			r ? r(e.el, o, i) : i();
		} else o();
	}, P = (e, t) => {
		let n;
		for (; e !== t;) n = h(e), i(e), e = n;
		i(t);
	}, de = (e, t, n) => {
		let { bum: r, scope: i, job: a, subTree: o, um: s, m: c, a: l } = e;
		Hi(c), Hi(l), r && N(r), i.stop(), a && (a.flags |= 8, M(o, e, t, n)), s && Ni(s, t), Ni(() => {
			e.isUnmounted = !0;
		}, t);
	}, fe = (e, t, n, r = !1, i = !1, a = 0) => {
		for (let o = a; o < e.length; o++) M(e[o], t, n, r, i);
	}, me = (e) => {
		if (e.shapeFlag & 6) return me(e.component.subTree);
		if (e.shapeFlag & 128) return e.suspense.next();
		let t = h(e.anchor || e.el), n = t && t[Bn];
		return n ? h(n) : t;
	}, F = !1, he = (e, t, n) => {
		let r;
		e == null ? t._vnode && (M(t._vnode, null, null, !0), r = t._vnode.component) : v(t._vnode || null, e, t, null, null, null, n), t._vnode = e, F ||= (F = !0, Sn(r), Cn(), !1);
	}, ge = {
		p: v,
		um: M,
		m: le,
		r: ue,
		mt: ae,
		mc: D,
		pc: ce,
		pbc: te,
		n: me,
		o: e
	}, _e, I;
	return t && ([_e, I] = t(ge)), {
		render: he,
		hydrate: _e,
		createApp: ti(he, _e)
	};
}
function Ii({ type: e, props: t }, n) {
	return n === "svg" && e === "foreignObject" || n === "mathml" && e === "annotation-xml" && t && t.encoding && t.encoding.includes("html") ? void 0 : n;
}
function Li({ effect: e, job: t }, n) {
	n ? (e.flags |= 32, t.flags |= 4) : (e.flags &= -33, t.flags &= -5);
}
function Ri(e, t) {
	return (!e || e && !e.pendingBranch) && t && !t.persisted;
}
function zi(e, t, n = !1) {
	let r = e.children, i = t.children;
	if (b(r) && b(i)) for (let e = 0; e < r.length; e++) {
		let t = r[e], a = i[e];
		a.shapeFlag & 1 && !a.dynamicChildren && ((a.patchFlag <= 0 || a.patchFlag === 32) && (a = i[e] = da(i[e]), a.el = t.el), !n && a.patchFlag !== -2 && zi(t, a)), a.type === Ki && (a.patchFlag === -1 && (a = i[e] = da(a)), a.el = t.el), a.type === qi && !a.el && (a.el = t.el);
	}
}
function Bi(e) {
	let t = e.slice(), n = [0], r, i, a, o, s, c = e.length;
	for (r = 0; r < c; r++) {
		let c = e[r];
		if (c !== 0) {
			if (i = n[n.length - 1], e[i] < c) {
				t[r] = i, n.push(r);
				continue;
			}
			for (a = 0, o = n.length - 1; a < o;) s = a + o >> 1, e[n[s]] < c ? a = s + 1 : o = s;
			c < e[n[a]] && (a > 0 && (t[r] = n[a - 1]), n[a] = r);
		}
	}
	for (a = n.length, o = n[a - 1]; a-- > 0;) n[a] = o, o = t[o];
	return n;
}
function Vi(e) {
	let t = e.subTree.component;
	if (t) return t.asyncDep && !t.asyncResolved ? t : Vi(t);
}
function Hi(e) {
	if (e) for (let t = 0; t < e.length; t++) e[t].flags |= 8;
}
function Ui(e) {
	if (e.placeholder) return e.placeholder;
	let t = e.component;
	return t ? Ui(t.subTree) : null;
}
var Wi = (e) => e.__isSuspense;
function Gi(e, t) {
	t && t.pendingBranch ? b(e) ? t.effects.push(...e) : t.effects.push(e) : xn(e);
}
var G = /* @__PURE__ */ Symbol.for("v-fgt"), Ki = /* @__PURE__ */ Symbol.for("v-txt"), qi = /* @__PURE__ */ Symbol.for("v-cmt"), Ji = /* @__PURE__ */ Symbol.for("v-stc"), Yi = [], Xi = null;
function K(e = !1) {
	Yi.push(Xi = e ? null : []);
}
function Zi() {
	Yi.pop(), Xi = Yi[Yi.length - 1] || null;
}
var Qi = 1;
function $i(e, t = !1) {
	Qi += e, e < 0 && Xi && t && (Xi.hasOnce = !0);
}
function ea(e) {
	return e.dynamicChildren = Qi > 0 ? Xi || d : null, Zi(), Qi > 0 && Xi && Xi.push(e), e;
}
function q(e, t, n, r, i, a) {
	return ea(J(e, t, n, r, i, a, !0));
}
function ta(e, t, n, r, i) {
	return ea(Y(e, t, n, r, i, !0));
}
function na(e) {
	return e ? e.__v_isVNode === !0 : !1;
}
function ra(e, t) {
	return e.type === t.type && e.key === t.key;
}
var ia = ({ key: e }) => e ?? null, aa = ({ ref: e, ref_key: t, ref_for: n }) => (typeof e == "number" && (e = "" + e), e == null ? null : T(e) || /* @__PURE__ */ Kt(e) || w(e) ? {
	i: En,
	r: e,
	k: t,
	f: !!n
} : e);
function J(e, t = null, n = null, r = 0, i = null, a = e === G ? 0 : 1, o = !1, s = !1) {
	let c = {
		__v_isVNode: !0,
		__v_skip: !0,
		type: e,
		props: t,
		key: t && ia(t),
		ref: t && aa(t),
		scopeId: Dn,
		slotScopeIds: null,
		children: n,
		component: null,
		suspense: null,
		ssContent: null,
		ssFallback: null,
		dirs: null,
		transition: null,
		el: null,
		anchor: null,
		target: null,
		targetStart: null,
		targetAnchor: null,
		staticCount: 0,
		shapeFlag: a,
		patchFlag: r,
		dynamicProps: i,
		dynamicChildren: null,
		appContext: null,
		ctx: En
	};
	return s ? (fa(c, n), a & 128 && e.normalize(c)) : n && (c.shapeFlag |= T(n) ? 8 : 16), Qi > 0 && !o && Xi && (c.patchFlag > 0 || a & 6) && c.patchFlag !== 32 && Xi.push(c), c;
}
var Y = oa;
function oa(e, t = null, n = null, r = 0, i = null, a = !1) {
	if ((!e || e === Or) && (e = qi), na(e)) {
		let r = ca(e, t, !0);
		return n && fa(r, n), Qi > 0 && !a && Xi && (r.shapeFlag & 6 ? Xi[Xi.indexOf(e)] = r : Xi.push(r)), r.patchFlag = -2, r;
	}
	if (Ia(e) && (e = e.__vccOpts), t) {
		t = sa(t);
		let { class: e, style: n } = t;
		e && !T(e) && (t.class = I(e)), D(n) && (/* @__PURE__ */ Ht(n) && !b(n) && (n = g({}, n)), t.style = me(n));
	}
	let o = T(e) ? 1 : Wi(e) ? 128 : Vn(e) ? 64 : D(e) ? 4 : w(e) ? 2 : 0;
	return J(e, t, n, r, i, o, a, !0);
}
function sa(e) {
	return e ? /* @__PURE__ */ Ht(e) || _i(e) ? g({}, e) : e : null;
}
function ca(e, t, n = !1, r = !1) {
	let { props: i, ref: a, patchFlag: o, children: s, transition: c } = e, l = t ? pa(i || {}, t) : i, u = {
		__v_isVNode: !0,
		__v_skip: !0,
		type: e.type,
		props: l,
		key: l && ia(l),
		ref: t && t.ref ? n && a ? b(a) ? a.concat(aa(t)) : [a, aa(t)] : aa(t) : a,
		scopeId: e.scopeId,
		slotScopeIds: e.slotScopeIds,
		children: s,
		target: e.target,
		targetStart: e.targetStart,
		targetAnchor: e.targetAnchor,
		staticCount: e.staticCount,
		shapeFlag: e.shapeFlag,
		patchFlag: t && e.type !== G ? o === -1 ? 16 : o | 16 : o,
		dynamicProps: e.dynamicProps,
		dynamicChildren: e.dynamicChildren,
		appContext: e.appContext,
		dirs: e.dirs,
		transition: c,
		component: e.component,
		suspense: e.suspense,
		ssContent: e.ssContent && ca(e.ssContent),
		ssFallback: e.ssFallback && ca(e.ssFallback),
		placeholder: e.placeholder,
		el: e.el,
		anchor: e.anchor,
		ctx: e.ctx,
		ce: e.ce
	};
	return c && r && tr(u, c.clone(u)), u;
}
function X(e = " ", t = 0) {
	return Y(Ki, null, e, t);
}
function la(e, t) {
	let n = Y(Ji, null, e);
	return n.staticCount = t, n;
}
function Z(e = "", t = !1) {
	return t ? (K(), ta(qi, null, e)) : Y(qi, null, e);
}
function ua(e) {
	return e == null || typeof e == "boolean" ? Y(qi) : b(e) ? Y(G, null, e.slice()) : na(e) ? da(e) : Y(Ki, null, String(e));
}
function da(e) {
	return e.el === null && e.patchFlag !== -1 || e.memo ? e : ca(e);
}
function fa(e, t) {
	let n = 0, { shapeFlag: r } = e;
	if (t == null) t = null;
	else if (b(t)) n = 16;
	else if (typeof t == "object") if (r & 65) {
		let n = t.default;
		n && (n._c && (n._d = !1), fa(e, n()), n._c && (n._d = !0));
		return;
	} else {
		n = 32;
		let r = t._;
		!r && !_i(t) ? t._ctx = En : r === 3 && En && (En.slots._ === 1 ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024));
	}
	else if (w(t)) {
		if (r & 65) {
			fa(e, { default: t });
			return;
		}
		t = {
			default: t,
			_ctx: En
		}, n = 32;
	} else t = String(t), r & 64 ? (n = 16, t = [X(t)]) : n = 8;
	e.children = t, e.shapeFlag |= n;
}
function pa(...e) {
	let t = {};
	for (let n = 0; n < e.length; n++) {
		let r = e[n];
		for (let e in r) if (e === "class") t.class !== r.class && (t.class = I([t.class, r.class]));
		else if (e === "style") t.style = me([t.style, r.style]);
		else if (m(e)) {
			let n = t[e], i = r[e];
			i && n !== i && !(b(n) && n.includes(i)) ? t[e] = n ? [].concat(n, i) : i : i == null && n == null && !h(e) && (t[e] = i);
		} else e !== "" && (t[e] = r[e]);
	}
	return t;
}
function ma(e, t, n, r = null) {
	sn(e, t, 7, [n, r]);
}
var ha = $r(), ga = 0;
function _a(e, t, n) {
	let r = e.type, i = (t ? t.appContext : e.appContext) || ha, a = {
		uid: ga++,
		vnode: e,
		type: r,
		parent: t,
		appContext: i,
		root: null,
		next: null,
		subTree: null,
		effect: null,
		update: null,
		job: null,
		scope: new De(!0),
		render: null,
		proxy: null,
		exposed: null,
		exposeProxy: null,
		withProxy: null,
		provides: t ? t.provides : Object.create(i.provides),
		ids: t ? t.ids : [
			"",
			0,
			0
		],
		accessCache: null,
		renderCache: [],
		components: null,
		directives: null,
		propsOptions: Ci(r, i),
		emitsOptions: oi(r, i),
		emit: null,
		emitted: null,
		propsDefaults: u,
		inheritAttrs: r.inheritAttrs,
		ctx: u,
		data: u,
		props: u,
		attrs: u,
		slots: u,
		refs: u,
		setupState: u,
		setupContext: null,
		suspense: n,
		suspenseId: n ? n.pendingId : 0,
		asyncDep: null,
		asyncResolved: !1,
		isMounted: !1,
		isUnmounted: !1,
		isDeactivated: !1,
		bc: null,
		c: null,
		bm: null,
		m: null,
		bu: null,
		u: null,
		um: null,
		bum: null,
		da: null,
		a: null,
		rtg: null,
		rtc: null,
		ec: null,
		sp: null
	};
	return a.ctx = { _: a }, a.root = t ? t.root : a, a.emit = ii.bind(null, a), e.ce && e.ce(a), a;
}
var va = null, ya = () => va || En, ba, xa;
{
	let e = pe(), t = (t, n) => {
		let r;
		return (r = e[t]) || (r = e[t] = []), r.push(n), (e) => {
			r.length > 1 ? r.forEach((t) => t(e)) : r[0](e);
		};
	};
	ba = t("__VUE_INSTANCE_SETTERS__", (e) => va = e), xa = t("__VUE_SSR_SETTERS__", (e) => Ta = e);
}
var Sa = (e) => {
	let t = va;
	return ba(e), e.scope.on(), () => {
		e.scope.off(), ba(t);
	};
}, Ca = () => {
	va && va.scope.off(), ba(null);
};
function wa(e) {
	return e.vnode.shapeFlag & 4;
}
var Ta = !1;
function Ea(e, t = !1, n = !1) {
	t && xa(t);
	let { props: r, children: i } = e.vnode, a = wa(e);
	vi(e, r, a, t), ji(e, i, n || t);
	let o = a ? Da(e, t) : void 0;
	return t && xa(!1), o;
}
function Da(e, t) {
	let n = e.type;
	e.accessCache = /* @__PURE__ */ Object.create(null), e.proxy = new Proxy(e.ctx, Ir);
	let { setup: r } = n;
	if (r) {
		Ge();
		let n = e.setupContext = r.length > 1 ? Na(e) : null, i = Sa(e), a = on(r, e, 0, [e.props, n]), o = ee(a);
		if (Ke(), i(), (o || e.sp) && !lr(e) && ir(e), o) {
			if (a.then(Ca, Ca), t) return a.then((n) => {
				xa(!0);
				try {
					Oa(e, n, t);
				} finally {
					xa(!1);
				}
			}).catch((t) => {
				cn(t, e, 0);
			});
			e.asyncDep = a;
		} else Oa(e, a, t);
	} else ja(e, t);
}
function Oa(e, t, n) {
	w(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : D(t) && (e.setupState = Xt(t)), ja(e, n);
}
var ka, Aa;
function ja(e, t, n) {
	let r = e.type;
	if (!e.render) {
		if (!t && ka && !r.render) {
			let t = r.template || Ur(e).template;
			if (t) {
				let { isCustomElement: n, compilerOptions: i } = e.appContext.config, { delimiters: a, compilerOptions: o } = r;
				r.render = ka(t, g(g({
					isCustomElement: n,
					delimiters: a
				}, i), o));
			}
		}
		e.render = r.render || f, Aa && Aa(e);
	}
	{
		let t = Sa(e);
		Ge();
		try {
			zr(e);
		} finally {
			Ke(), t();
		}
	}
}
var Ma = { get(e, t) {
	return tt(e, "get", ""), e[t];
} };
function Na(e) {
	return {
		attrs: new Proxy(e.attrs, Ma),
		slots: e.slots,
		emit: e.emit,
		expose: (t) => {
			e.exposed = t || {};
		}
	};
}
function Pa(e) {
	return e.exposed ? e.exposeProxy ||= new Proxy(Xt(Ut(e.exposed)), {
		get(t, n) {
			if (n in t) return t[n];
			if (n in Pr) return Pr[n](e);
		},
		has(e, t) {
			return t in e || t in Pr;
		}
	}) : e.proxy;
}
function Fa(e, t = !0) {
	return w(e) ? e.displayName || e.name : e.name || t && e.__name;
}
function Ia(e) {
	return w(e) && "__vccOpts" in e;
}
var Q = (e, t) => /* @__PURE__ */ Qt(e, t, Ta);
function La(e, t, n) {
	try {
		$i(-1);
		let r = arguments.length;
		return r === 2 ? D(t) && !b(t) ? na(t) ? Y(e, null, [t]) : Y(e, t) : Y(e, null, t) : (r > 3 ? n = Array.prototype.slice.call(arguments, 2) : r === 3 && na(n) && (n = [n]), Y(e, t, n));
	} finally {
		$i(1);
	}
}
var Ra = "3.5.41", za = void 0, Ba = typeof window < "u" && window.trustedTypes;
if (Ba) try {
	za = /* @__PURE__ */ Ba.createPolicy("vue", { createHTML: (e) => e });
} catch {}
var Va = za ? (e) => za.createHTML(e) : (e) => e, Ha = "http://www.w3.org/2000/svg", Ua = "http://www.w3.org/1998/Math/MathML", Wa = typeof document < "u" ? document : null, Ga = Wa && /* @__PURE__ */ Wa.createElement("template"), Ka = {
	insert: (e, t, n) => {
		t.insertBefore(e, n || null);
	},
	remove: (e) => {
		let t = e.parentNode;
		t && t.removeChild(e);
	},
	createElement: (e, t, n, r) => {
		let i = t === "svg" ? Wa.createElementNS(Ha, e) : t === "mathml" ? Wa.createElementNS(Ua, e) : n ? Wa.createElement(e, { is: n }) : Wa.createElement(e);
		return e === "select" && r && r.multiple != null && i.setAttribute("multiple", r.multiple), i;
	},
	createText: (e) => Wa.createTextNode(e),
	createComment: (e) => Wa.createComment(e),
	setText: (e, t) => {
		e.nodeValue = t;
	},
	setElementText: (e, t) => {
		e.textContent = t;
	},
	parentNode: (e) => e.parentNode,
	nextSibling: (e) => e.nextSibling,
	querySelector: (e) => Wa.querySelector(e),
	setScopeId(e, t) {
		e.setAttribute(t, "");
	},
	insertStaticContent(e, t, n, r, i, a) {
		let o = n ? n.previousSibling : t.lastChild;
		if (i && (i === a || i.nextSibling)) for (; t.insertBefore(i.cloneNode(!0), n), !(i === a || !(i = i.nextSibling)););
		else {
			Ga.innerHTML = Va(r === "svg" ? `<svg>${e}</svg>` : r === "mathml" ? `<math>${e}</math>` : e);
			let i = Ga.content;
			if (r === "svg" || r === "mathml") {
				let e = i.firstChild;
				for (; e.firstChild;) i.appendChild(e.firstChild);
				i.removeChild(e);
			}
			t.insertBefore(i, n);
		}
		return [o ? o.nextSibling : t.firstChild, n ? n.previousSibling : t.lastChild];
	}
}, qa = "transition", Ja = "animation", Ya = /* @__PURE__ */ Symbol("_vtc"), Xa = {
	name: String,
	type: String,
	css: {
		type: Boolean,
		default: !0
	},
	duration: [
		String,
		Number,
		Object
	],
	enterFromClass: String,
	enterActiveClass: String,
	enterToClass: String,
	appearFromClass: String,
	appearActiveClass: String,
	appearToClass: String,
	leaveFromClass: String,
	leaveActiveClass: String,
	leaveToClass: String
}, Za = /* @__PURE__ */ g({}, Kn, Xa), Qa = /* @__PURE__ */ ((e) => (e.displayName = "Transition", e.props = Za, e))((e, { slots: t }) => La(Xn, to(e), t)), $a = (e, t = []) => {
	b(e) ? e.forEach((e) => e(...t)) : e && e(...t);
}, eo = (e) => e ? b(e) ? e.some((e) => e.length > 1) : e.length > 1 : !1;
function to(e) {
	let t = {};
	for (let n in e) n in Xa || (t[n] = e[n]);
	if (e.css === !1) return t;
	let { name: n = "v", type: r, duration: i, enterFromClass: a = `${n}-enter-from`, enterActiveClass: o = `${n}-enter-active`, enterToClass: s = `${n}-enter-to`, appearFromClass: c = a, appearActiveClass: l = o, appearToClass: u = s, leaveFromClass: d = `${n}-leave-from`, leaveActiveClass: f = `${n}-leave-active`, leaveToClass: p = `${n}-leave-to` } = e, m = no(i), h = m && m[0], _ = m && m[1], { onBeforeEnter: v, onEnter: y, onEnterCancelled: b, onLeave: x, onLeaveCancelled: S, onBeforeAppear: C = v, onAppear: w = y, onAppearCancelled: T = b } = t, E = (e, t, n, r) => {
		e._enterCancelled = r, ao(e, t ? u : s), ao(e, t ? l : o), n && n();
	}, D = (e, t) => {
		e._isLeaving = !1, ao(e, d), ao(e, p), ao(e, f), t && t();
	}, ee = (e) => (t, n) => {
		let i = e ? w : y, o = () => E(t, e, n);
		$a(i, [t, o]), oo(() => {
			ao(t, e ? c : a), io(t, e ? u : s), eo(i) || co(t, r, h, o);
		});
	};
	return g(t, {
		onBeforeEnter(e) {
			$a(v, [e]), io(e, a), io(e, o);
		},
		onBeforeAppear(e) {
			$a(C, [e]), io(e, c), io(e, l);
		},
		onEnter: ee(!1),
		onAppear: ee(!0),
		onLeave(e, t) {
			e._isLeaving = !0;
			let n = () => D(e, t);
			io(e, d), e._enterCancelled ? (io(e, f), po(e)) : (po(e), io(e, f)), oo(() => {
				e._isLeaving && (ao(e, d), io(e, p), eo(x) || co(e, r, _, n));
			}), $a(x, [e, n]);
		},
		onEnterCancelled(e) {
			E(e, !1, void 0, !0), $a(b, [e]);
		},
		onAppearCancelled(e) {
			E(e, !0, void 0, !0), $a(T, [e]);
		},
		onLeaveCancelled(e) {
			D(e), $a(S, [e]);
		}
	});
}
function no(e) {
	if (e == null) return null;
	if (D(e)) return [ro(e.enter), ro(e.leave)];
	{
		let t = ro(e);
		return [t, t];
	}
}
function ro(e) {
	return de(e);
}
function io(e, t) {
	t.split(/\s+/).forEach((t) => t && e.classList.add(t)), (e[Ya] || (e[Ya] = /* @__PURE__ */ new Set())).add(t);
}
function ao(e, t) {
	t.split(/\s+/).forEach((t) => t && e.classList.remove(t));
	let n = e[Ya];
	n && (n.delete(t), n.size || (e[Ya] = void 0));
}
function oo(e) {
	requestAnimationFrame(() => {
		requestAnimationFrame(e);
	});
}
var so = 0;
function co(e, t, n, r) {
	let i = e._endId = ++so, a = () => {
		i === e._endId && r();
	};
	if (n != null) return setTimeout(a, n);
	let { type: o, timeout: s, propCount: c } = lo(e, t);
	if (!o) return r();
	let l = o + "end", u = 0, d = () => {
		e.removeEventListener(l, f), a();
	}, f = (t) => {
		t.target === e && ++u >= c && d();
	};
	setTimeout(() => {
		u < c && d();
	}, s + 1), e.addEventListener(l, f);
}
function lo(e, t) {
	let n = window.getComputedStyle(e), r = (e) => (n[e] || "").split(", "), i = r(`${qa}Delay`), a = r(`${qa}Duration`), o = uo(i, a), s = r(`${Ja}Delay`), c = r(`${Ja}Duration`), l = uo(s, c), u = null, d = 0, f = 0;
	t === qa ? o > 0 && (u = qa, d = o, f = a.length) : t === Ja ? l > 0 && (u = Ja, d = l, f = c.length) : (d = Math.max(o, l), u = d > 0 ? o > l ? qa : Ja : null, f = u ? u === qa ? a.length : c.length : 0);
	let p = u === qa && /\b(?:transform|all)(?:,|$)/.test(r(`${qa}Property`).toString());
	return {
		type: u,
		timeout: d,
		propCount: f,
		hasTransform: p
	};
}
function uo(e, t) {
	for (; e.length < t.length;) e = e.concat(e);
	return Math.max(...t.map((t, n) => fo(t) + fo(e[n])));
}
function fo(e) {
	return e === "auto" ? 0 : Number(e.slice(0, -1).replace(",", ".")) * 1e3;
}
function po(e) {
	return (e ? e.ownerDocument : document).body.offsetHeight;
}
function mo(e, t, n) {
	let r = e[Ya];
	r && (t = (t ? [t, ...r] : [...r]).join(" ")), t == null ? e.removeAttribute("class") : n ? e.setAttribute("class", t) : e.className = t;
}
var ho = /* @__PURE__ */ Symbol("_vod"), go = /* @__PURE__ */ Symbol("_vsh"), _o = /* @__PURE__ */ Symbol(""), vo = /(?:^|;)\s*display\s*:/;
function yo(e, t, n) {
	let r = e.style, i = T(n), a = !1;
	if (n && !i) {
		if (t) if (T(t)) for (let e of t.split(";")) {
			let t = e.slice(0, e.indexOf(":")).trim();
			n[t] ?? xo(r, t, "");
		}
		else for (let e in t) n[e] ?? xo(r, e, "");
		for (let i in n) {
			i === "display" && (a = !0);
			let o = n[i];
			o == null ? xo(r, i, "") : To(e, i, !T(t) && t ? t[i] : void 0, o) || xo(r, i, o);
		}
	} else if (i) {
		if (t !== n) {
			let e = r[_o];
			e && (n += ";" + e), r.cssText = n, a = vo.test(n);
		}
	} else t && e.removeAttribute("style");
	ho in e && (e[ho] = a ? r.display : "", e[go] && (r.display = "none"));
}
var bo = /\s*!important$/;
function xo(e, t, n) {
	if (b(n)) n.forEach((n) => xo(e, t, n));
	else if (n ??= "", t.startsWith("--")) e.setProperty(t, n);
	else {
		let r = wo(e, t);
		bo.test(n) ? e.setProperty(A(r), n.replace(bo, ""), "important") : e[r] = n;
	}
}
var So = [
	"Webkit",
	"Moz",
	"ms"
], Co = {};
function wo(e, t) {
	let n = Co[t];
	if (n) return n;
	let r = k(t);
	if (r !== "filter" && r in e) return Co[t] = r;
	r = j(r);
	for (let n = 0; n < So.length; n++) {
		let i = So[n] + r;
		if (i in e) return Co[t] = i;
	}
	return t;
}
function To(e, t, n, r) {
	return e.tagName === "TEXTAREA" && (t === "width" || t === "height") && T(r) && n === r;
}
var Eo = "http://www.w3.org/1999/xlink";
function Do(e, t, n, r, i, a = ye(t)) {
	r && t.startsWith("xlink:") ? n == null ? e.removeAttributeNS(Eo, t.slice(6, t.length)) : e.setAttributeNS(Eo, t, n) : n == null || a && !be(n) ? e.removeAttribute(t) : e.setAttribute(t, a ? "" : E(n) ? String(n) : n);
}
function Oo(e, t, n, r, i) {
	if (t === "innerHTML" || t === "textContent") {
		n != null && (e[t] = t === "innerHTML" ? Va(n) : n);
		return;
	}
	let a = e.tagName;
	if (t === "value" && a !== "PROGRESS" && !a.includes("-")) {
		let r = a === "OPTION" ? e.getAttribute("value") || "" : e.value, i = n == null ? e.type === "checkbox" ? "on" : "" : String(n);
		(r !== i || !("_value" in e)) && (e.value = i), n ?? e.removeAttribute(t), e._value = n;
		return;
	}
	let o = !1;
	if (n === "" || n == null) {
		let r = typeof e[t];
		r === "boolean" ? n = be(n) : n == null && r === "string" ? (n = "", o = !0) : r === "number" && (n = 0, o = !0);
	}
	try {
		e[t] = n;
	} catch {}
	o && e.removeAttribute(i || t);
}
function ko(e, t, n, r) {
	e.addEventListener(t, n, r);
}
function Ao(e, t, n, r) {
	e.removeEventListener(t, n, r);
}
var jo = /* @__PURE__ */ Symbol("_vei");
function Mo(e, t, n, r, i = null) {
	let a = e[jo] || (e[jo] = {}), o = a[t];
	if (r && o) o.value = r;
	else {
		let [n, s] = Fo(t);
		r ? ko(e, n, a[t] = zo(r, i), s) : o && (Ao(e, n, o, s), a[t] = void 0);
	}
}
var No = /(Once|Passive|Capture)$/, Po = /^on:?(?:Once|Passive|Capture)$/;
function Fo(e) {
	let t, n;
	for (; (n = e.match(No)) && !Po.test(e);) t ||= {}, e = e.slice(0, e.length - n[1].length), t[n[1].toLowerCase()] = !0;
	return [e[2] === ":" ? e.slice(3) : A(e.slice(2)), t];
}
var Io = 0, Lo = /* @__PURE__ */ Promise.resolve(), Ro = () => Io ||= (Lo.then(() => Io = 0), Date.now());
function zo(e, t) {
	let n = (e) => {
		if (!e._vts) e._vts = Date.now();
		else if (e._vts <= n.attached) return;
		let r = n.value;
		if (b(r)) {
			let n = e.stopImmediatePropagation;
			e.stopImmediatePropagation = () => {
				n.call(e), e._stopped = !0;
			};
			let i = r.slice(), a = [e];
			for (let n = 0; n < i.length && !e._stopped; n++) {
				let e = i[n];
				e && sn(e, t, 5, a);
			}
		} else sn(r, t, 5, [e]);
	};
	return n.value = e, n.attached = Ro(), n;
}
var Bo = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && e.charCodeAt(2) > 96 && e.charCodeAt(2) < 123, Vo = (e, t, n, r, i, a) => {
	let o = i === "svg";
	t === "class" ? mo(e, r, o) : t === "style" ? yo(e, n, r) : m(t) ? h(t) || Mo(e, t, n, r, a) : (t[0] === "." ? (t = t.slice(1), !0) : t[0] === "^" ? (t = t.slice(1), !1) : Ho(e, t, r, o)) ? (Oo(e, t, r), !e.tagName.includes("-") && (t === "value" || t === "checked" || t === "selected") && Do(e, t, r, o, a, t !== "value")) : e._isVueCE && (Uo(e, t) || e._def.__asyncLoader && (/[A-Z]/.test(t) || !T(r))) ? Oo(e, k(t), r, a, t) : (t === "true-value" ? e._trueValue = r : t === "false-value" && (e._falseValue = r), Do(e, t, r, o));
};
function Ho(e, t, n, r) {
	if (r) return !!(t === "innerHTML" || t === "textContent" || t in e && Bo(t) && w(n));
	if (t === "spellcheck" || t === "draggable" || t === "translate" || t === "autocorrect" || t === "sandbox" && e.tagName === "IFRAME" || t === "form" || t === "list" && e.tagName === "INPUT" || t === "type" && e.tagName === "TEXTAREA") return !1;
	if (t === "width" || t === "height") {
		let t = e.tagName;
		if (t === "IMG" || t === "VIDEO" || t === "CANVAS" || t === "SOURCE") return !1;
	}
	return Bo(t) && T(n) ? !1 : t in e;
}
function Uo(e, t) {
	let n = e._def.props;
	if (!n) return !1;
	let r = k(t);
	return Array.isArray(n) ? n.some((e) => k(e) === r) : Object.keys(n).some((e) => k(e) === r);
}
var Wo = (e) => {
	let t = e.props["onUpdate:modelValue"] || !1;
	return b(t) ? (e) => N(t, e) : t;
};
function Go(e) {
	e.target.composing = !0;
}
function Ko(e) {
	let t = e.target;
	t.composing && (t.composing = !1, t.dispatchEvent(new Event("input")));
}
var qo = /* @__PURE__ */ Symbol("_assign"), Jo = /* @__PURE__ */ Symbol("_initialValue");
function Yo(e, t, n) {
	return t && (e = e.trim()), n && (e = P(e)), e;
}
var Xo = {
	created(e, { modifiers: { lazy: t, trim: n, number: r } }, i) {
		e.parentNode && (e.type === "text" ? e[Jo] = e.defaultValue.replace(/[\r\n]/g, "") : e.type === "textarea" && (e[Jo] = e.defaultValue.replace(/\r\n?/g, "\n"))), e[qo] = Wo(i);
		let a = r || i.props && i.props.type === "number";
		ko(e, t ? "change" : "input", (t) => {
			t.target.composing || e[qo](Yo(e.value, n, a));
		}), (n || a) && ko(e, "change", () => {
			e.value = Yo(e.value, n, a);
		}), t || (ko(e, "compositionstart", Go), ko(e, "compositionend", Ko), ko(e, "change", Ko));
	},
	mounted(e, { value: t, modifiers: { trim: n, number: r } }) {
		let i = t ?? "", a = e[Jo];
		delete e[Jo], a !== void 0 && (e.type === "text" || e.type === "textarea") && e.value !== a ? e[qo](Yo(e.value, n, r)) : e.value = i;
	},
	beforeUpdate(e, { value: t, oldValue: n, modifiers: { lazy: r, trim: i, number: a } }, o) {
		if (e[qo] = Wo(o), e.composing) return;
		let s = (a || e.type === "number") && !/^0\d/.test(e.value) ? P(e.value) : e.value, c = t ?? "";
		if (s === c) return;
		let l = e.getRootNode();
		(l instanceof Document || l instanceof ShadowRoot) && l.activeElement === e && e.type !== "range" && (r && t === n || i && e.value.trim() === c) || (e.value = c);
	}
}, Zo = {
	deep: !0,
	created(e, { value: t, modifiers: { number: n } }, r) {
		e._modelValue = t, ko(e, "change", () => {
			let t = Array.prototype.filter.call(e.options, (e) => e.selected).map((e) => n ? P($o(e)) : $o(e));
			e[qo](e.multiple ? S(e._modelValue) ? new Set(t) : t : t[0]), e._assigning = !0, _n(() => {
				e._assigning = !1;
			});
		}), e[qo] = Wo(r);
	},
	mounted(e, { value: t }) {
		Qo(e, t);
	},
	beforeUpdate(e, { value: t }, n) {
		e._modelValue = t, e[qo] = Wo(n);
	},
	updated(e, { value: t }) {
		e._assigning || Qo(e, t);
	}
};
function Qo(e, t) {
	let n = e.multiple, r = b(t);
	if (!(n && !r && !S(t))) {
		for (let i = 0, a = e.options.length; i < a; i++) {
			let a = e.options[i], o = $o(a);
			if (n) if (r) {
				let e = typeof o;
				e === "string" || e === "number" ? a.selected = t.some((e) => String(e) === String(o)) : a.selected = Ce(t, o) > -1;
			} else a.selected = t.has(o);
			else if (Se($o(a), t)) {
				e.selectedIndex !== i && (e.selectedIndex = i);
				return;
			}
		}
		!n && e.selectedIndex !== -1 && (e.selectedIndex = -1);
	}
}
function $o(e) {
	return "_value" in e ? e._value : e.value;
}
var es = [
	"ctrl",
	"shift",
	"alt",
	"meta"
], ts = {
	stop: (e) => e.stopPropagation(),
	prevent: (e) => e.preventDefault(),
	self: (e) => e.target !== e.currentTarget,
	ctrl: (e) => !e.ctrlKey,
	shift: (e) => !e.shiftKey,
	alt: (e) => !e.altKey,
	meta: (e) => !e.metaKey,
	left: (e) => "button" in e && e.button !== 0,
	middle: (e) => "button" in e && e.button !== 1,
	right: (e) => "button" in e && e.button !== 2,
	exact: (e, t) => es.some((n) => e[`${n}Key`] && !t.includes(n))
}, ns = (e, t) => {
	if (!e) return e;
	let n = e._withMods ||= {}, r = t.join(".");
	return n[r] || (n[r] = ((n, ...r) => {
		for (let e = 0; e < t.length; e++) {
			let r = ts[t[e]];
			if (r && r(n, t)) return;
		}
		return e(n, ...r);
	}));
}, rs = {
	esc: "escape",
	space: " ",
	up: "arrow-up",
	left: "arrow-left",
	right: "arrow-right",
	down: "arrow-down",
	delete: "backspace"
}, is = (e, t) => {
	let n = e._withKeys ||= {}, r = t.join(".");
	return n[r] || (n[r] = ((n) => {
		if (!("key" in n)) return;
		let r = A(n.key);
		if (t.some((e) => e === r || rs[e] === r)) return e(n);
	}));
}, as = /* @__PURE__ */ g({ patchProp: Vo }, Ka), os;
function ss() {
	return os ||= Pi(as);
}
var cs = ((...e) => {
	let t = ss().createApp(...e), { mount: n } = t;
	return t.mount = (e) => {
		let r = us(e);
		if (!r) return;
		let i = t._component;
		!w(i) && !i.render && !i.template && (i.template = r.innerHTML), r.nodeType === 1 && (r.textContent = "");
		let a = n(r, !1, ls(r));
		return r instanceof Element && (r.removeAttribute("v-cloak"), r.setAttribute("data-v-app", "")), a;
	}, t;
});
function ls(e) {
	if (e instanceof SVGElement) return "svg";
	if (typeof MathMLElement == "function" && e instanceof MathMLElement) return "mathml";
}
function us(e) {
	return T(e) ? document.querySelector(e) : e;
}
//#endregion
//#region node_modules/lucide-vue-next/dist/esm/shared/src/utils.js
var ds = (e) => e.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase(), fs = {
	xmlns: "http://www.w3.org/2000/svg",
	width: 24,
	height: 24,
	viewBox: "0 0 24 24",
	fill: "none",
	stroke: "currentColor",
	"stroke-width": 2,
	"stroke-linecap": "round",
	"stroke-linejoin": "round"
}, ps = ({ size: e, strokeWidth: t = 2, absoluteStrokeWidth: n, color: r, iconNode: i, name: a, class: o, ...s }, { slots: c }) => La("svg", {
	...fs,
	width: e || fs.width,
	height: e || fs.height,
	stroke: r || fs.stroke,
	"stroke-width": n ? Number(t) * 24 / Number(e) : t,
	class: ["lucide", `lucide-${ds(a ?? "icon")}`],
	...s
}, [...i.map((e) => La(...e)), ...c.default ? [c.default()] : []]), $ = (e, t) => (n, { slots: r }) => La(ps, {
	...n,
	iconNode: t,
	name: e
}, r), ms = $("ArchiveRestoreIcon", [
	["rect", {
		width: "20",
		height: "5",
		x: "2",
		y: "3",
		rx: "1",
		key: "1wp1u1"
	}],
	["path", {
		d: "M4 8v11a2 2 0 0 0 2 2h2",
		key: "tvwodi"
	}],
	["path", {
		d: "M20 8v11a2 2 0 0 1-2 2h-2",
		key: "1gkqxj"
	}],
	["path", {
		d: "m9 15 3-3 3 3",
		key: "1pd0qc"
	}],
	["path", {
		d: "M12 12v9",
		key: "192myk"
	}]
]), hs = $("ArrowLeftIcon", [["path", {
	d: "m12 19-7-7 7-7",
	key: "1l729n"
}], ["path", {
	d: "M19 12H5",
	key: "x3x0zl"
}]]), gs = $("ArrowRightIcon", [["path", {
	d: "M5 12h14",
	key: "1ays0h"
}], ["path", {
	d: "m12 5 7 7-7 7",
	key: "xquz4c"
}]]), _s = $("ArrowUpFromLineIcon", [
	["path", {
		d: "m18 9-6-6-6 6",
		key: "kcunyi"
	}],
	["path", {
		d: "M12 3v14",
		key: "7cf3v8"
	}],
	["path", {
		d: "M5 21h14",
		key: "11awu3"
	}]
]), vs = $("CameraIcon", [["path", {
	d: "M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z",
	key: "1tc9qg"
}], ["circle", {
	cx: "12",
	cy: "13",
	r: "3",
	key: "1vg3eu"
}]]), ys = $("CheckIcon", [["path", {
	d: "M20 6 9 17l-5-5",
	key: "1gmf2c"
}]]), bs = $("ChevronDownIcon", [["path", {
	d: "m6 9 6 6 6-6",
	key: "qrunsl"
}]]), xs = $("ChevronRightIcon", [["path", {
	d: "m9 18 6-6-6-6",
	key: "mthhwq"
}]]), Ss = $("CircleHelpIcon", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "10",
		key: "1mglay"
	}],
	["path", {
		d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3",
		key: "1u773s"
	}],
	["path", {
		d: "M12 17h.01",
		key: "p32p05"
	}]
]), Cs = $("CloudIcon", [["path", {
	d: "M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z",
	key: "p7xjir"
}]]), ws = $("CopyIcon", [["rect", {
	width: "14",
	height: "14",
	x: "8",
	y: "8",
	rx: "2",
	ry: "2",
	key: "17jyea"
}], ["path", {
	d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",
	key: "zix9uf"
}]]), Ts = $("DownloadIcon", [
	["path", {
		d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
		key: "ih7n3h"
	}],
	["polyline", {
		points: "7 10 12 15 17 10",
		key: "2ggqvy"
	}],
	["line", {
		x1: "12",
		x2: "12",
		y1: "15",
		y2: "3",
		key: "1vk2je"
	}]
]), Es = $("EllipsisIcon", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "1",
		key: "41hilf"
	}],
	["circle", {
		cx: "19",
		cy: "12",
		r: "1",
		key: "1wjl8i"
	}],
	["circle", {
		cx: "5",
		cy: "12",
		r: "1",
		key: "1pcz8c"
	}]
]), Ds = $("FileArchiveIcon", [
	["path", {
		d: "M10 12v-1",
		key: "v7bkov"
	}],
	["path", {
		d: "M10 18v-2",
		key: "1cjy8d"
	}],
	["path", {
		d: "M10 7V6",
		key: "dljcrl"
	}],
	["path", {
		d: "M14 2v4a2 2 0 0 0 2 2h4",
		key: "tnqrlb"
	}],
	["path", {
		d: "M15.5 22H18a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v16a2 2 0 0 0 .274 1.01",
		key: "gkbcor"
	}],
	["circle", {
		cx: "10",
		cy: "20",
		r: "2",
		key: "1xzdoj"
	}]
]), Os = $("FileAudioIcon", [
	["path", {
		d: "M17.5 22h.5a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v3",
		key: "rslqgf"
	}],
	["path", {
		d: "M14 2v4a2 2 0 0 0 2 2h4",
		key: "tnqrlb"
	}],
	["path", {
		d: "M2 19a2 2 0 1 1 4 0v1a2 2 0 1 1-4 0v-4a6 6 0 0 1 12 0v4a2 2 0 1 1-4 0v-1a2 2 0 1 1 4 0",
		key: "9f7x3i"
	}]
]), ks = $("FileCode2Icon", [
	["path", {
		d: "M4 22h14a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v4",
		key: "1pf5j1"
	}],
	["path", {
		d: "M14 2v4a2 2 0 0 0 2 2h4",
		key: "tnqrlb"
	}],
	["path", {
		d: "m5 12-3 3 3 3",
		key: "oke12k"
	}],
	["path", {
		d: "m9 18 3-3-3-3",
		key: "112psh"
	}]
]), As = $("FileImageIcon", [
	["path", {
		d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",
		key: "1rqfz7"
	}],
	["path", {
		d: "M14 2v4a2 2 0 0 0 2 2h4",
		key: "tnqrlb"
	}],
	["circle", {
		cx: "10",
		cy: "12",
		r: "2",
		key: "737tya"
	}],
	["path", {
		d: "m20 17-1.296-1.296a2.41 2.41 0 0 0-3.408 0L9 22",
		key: "wt3hpn"
	}]
]), js = $("FileSpreadsheetIcon", [
	["path", {
		d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",
		key: "1rqfz7"
	}],
	["path", {
		d: "M14 2v4a2 2 0 0 0 2 2h4",
		key: "tnqrlb"
	}],
	["path", {
		d: "M8 13h2",
		key: "yr2amv"
	}],
	["path", {
		d: "M14 13h2",
		key: "un5t4a"
	}],
	["path", {
		d: "M8 17h2",
		key: "2yhykz"
	}],
	["path", {
		d: "M14 17h2",
		key: "10kma7"
	}]
]), Ms = $("FileTextIcon", [
	["path", {
		d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",
		key: "1rqfz7"
	}],
	["path", {
		d: "M14 2v4a2 2 0 0 0 2 2h4",
		key: "tnqrlb"
	}],
	["path", {
		d: "M10 9H8",
		key: "b1mrlr"
	}],
	["path", {
		d: "M16 13H8",
		key: "t4e002"
	}],
	["path", {
		d: "M16 17H8",
		key: "z1uh3a"
	}]
]), Ns = $("FileType2Icon", [
	["path", {
		d: "M4 22h14a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v4",
		key: "1pf5j1"
	}],
	["path", {
		d: "M14 2v4a2 2 0 0 0 2 2h4",
		key: "tnqrlb"
	}],
	["path", {
		d: "M2 13v-1h6v1",
		key: "1dh9dg"
	}],
	["path", {
		d: "M5 12v6",
		key: "150t9c"
	}],
	["path", {
		d: "M4 18h2",
		key: "1xrofg"
	}]
]), Ps = $("FileVideoIcon", [
	["path", {
		d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",
		key: "1rqfz7"
	}],
	["path", {
		d: "M14 2v4a2 2 0 0 0 2 2h4",
		key: "tnqrlb"
	}],
	["path", {
		d: "m10 11 5 3-5 3v-6Z",
		key: "7ntvm4"
	}]
]), Fs = $("FileIcon", [["path", {
	d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",
	key: "1rqfz7"
}], ["path", {
	d: "M14 2v4a2 2 0 0 0 2 2h4",
	key: "tnqrlb"
}]]), Is = $("FilesIcon", [
	["path", {
		d: "M20 7h-3a2 2 0 0 1-2-2V2",
		key: "x099mo"
	}],
	["path", {
		d: "M9 18a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h7l4 4v10a2 2 0 0 1-2 2Z",
		key: "18t6ie"
	}],
	["path", {
		d: "M3 7.6v12.8A1.6 1.6 0 0 0 4.6 22h9.8",
		key: "1nja0z"
	}]
]), Ls = $("FolderOpenIcon", [["path", {
	d: "m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2",
	key: "usdka0"
}]]), Rs = $("FolderIcon", [["path", {
	d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
	key: "1kt360"
}]]), zs = $("Grid2x2Icon", [
	["path", {
		d: "M12 3v18",
		key: "108xh3"
	}],
	["path", {
		d: "M3 12h18",
		key: "1i2n21"
	}],
	["rect", {
		x: "3",
		y: "3",
		width: "18",
		height: "18",
		rx: "2",
		key: "h1oib"
	}]
]), Bs = $("HardDriveIcon", [
	["line", {
		x1: "22",
		x2: "2",
		y1: "12",
		y2: "12",
		key: "1y58io"
	}],
	["path", {
		d: "M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z",
		key: "oot6mr"
	}],
	["line", {
		x1: "6",
		x2: "6.01",
		y1: "16",
		y2: "16",
		key: "sgf278"
	}],
	["line", {
		x1: "10",
		x2: "10.01",
		y1: "16",
		y2: "16",
		key: "1l4acy"
	}]
]), Vs = $("InfoIcon", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "10",
		key: "1mglay"
	}],
	["path", {
		d: "M12 16v-4",
		key: "1dtifu"
	}],
	["path", {
		d: "M12 8h.01",
		key: "e9boi3"
	}]
]), Hs = $("LayoutListIcon", [
	["rect", {
		width: "7",
		height: "7",
		x: "3",
		y: "3",
		rx: "1",
		key: "1g98yp"
	}],
	["rect", {
		width: "7",
		height: "7",
		x: "3",
		y: "14",
		rx: "1",
		key: "1bb6yr"
	}],
	["path", {
		d: "M14 4h7",
		key: "3xa0d5"
	}],
	["path", {
		d: "M14 9h7",
		key: "1icrd9"
	}],
	["path", {
		d: "M14 15h7",
		key: "1mj8o2"
	}],
	["path", {
		d: "M14 20h7",
		key: "11slyb"
	}]
]), Us = $("Link2Icon", [
	["path", {
		d: "M9 17H7A5 5 0 0 1 7 7h2",
		key: "8i5ue5"
	}],
	["path", {
		d: "M15 7h2a5 5 0 1 1 0 10h-2",
		key: "1b9ql8"
	}],
	["line", {
		x1: "8",
		x2: "16",
		y1: "12",
		y2: "12",
		key: "1jonct"
	}]
]), Ws = $("LockKeyholeIcon", [
	["circle", {
		cx: "12",
		cy: "16",
		r: "1",
		key: "1au0dj"
	}],
	["rect", {
		x: "3",
		y: "10",
		width: "18",
		height: "12",
		rx: "2",
		key: "6s8ecr"
	}],
	["path", {
		d: "M7 10V7a5 5 0 0 1 10 0v3",
		key: "1pqi11"
	}]
]), Gs = $("MenuIcon", [
	["line", {
		x1: "4",
		x2: "20",
		y1: "12",
		y2: "12",
		key: "1e0a9i"
	}],
	["line", {
		x1: "4",
		x2: "20",
		y1: "6",
		y2: "6",
		key: "1owob3"
	}],
	["line", {
		x1: "4",
		x2: "20",
		y1: "18",
		y2: "18",
		key: "yk5zj1"
	}]
]), Ks = $("MoveIcon", [
	["path", {
		d: "M12 2v20",
		key: "t6zp3m"
	}],
	["path", {
		d: "m15 19-3 3-3-3",
		key: "11eu04"
	}],
	["path", {
		d: "m19 9 3 3-3 3",
		key: "1mg7y2"
	}],
	["path", {
		d: "M2 12h20",
		key: "9i4pu4"
	}],
	["path", {
		d: "m5 9-3 3 3 3",
		key: "j64kie"
	}],
	["path", {
		d: "m9 5 3-3 3 3",
		key: "l8vdw6"
	}]
]), qs = $("PlayIcon", [["polygon", {
	points: "6 3 20 12 6 21 6 3",
	key: "1oa8hb"
}]]), Js = $("PlusIcon", [["path", {
	d: "M5 12h14",
	key: "1ays0h"
}], ["path", {
	d: "M12 5v14",
	key: "s699le"
}]]), Ys = $("PresentationIcon", [
	["path", {
		d: "M2 3h20",
		key: "91anmk"
	}],
	["path", {
		d: "M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3",
		key: "2k9sn8"
	}],
	["path", {
		d: "m7 21 5-5 5 5",
		key: "bip4we"
	}]
]), Xs = $("RefreshCwIcon", [
	["path", {
		d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",
		key: "v9h5vc"
	}],
	["path", {
		d: "M21 3v5h-5",
		key: "1q7to0"
	}],
	["path", {
		d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",
		key: "3uifl3"
	}],
	["path", {
		d: "M8 16H3v5",
		key: "1cv678"
	}]
]), Zs = $("SearchIcon", [["circle", {
	cx: "11",
	cy: "11",
	r: "8",
	key: "4ej97u"
}], ["path", {
	d: "m21 21-4.3-4.3",
	key: "1qie3q"
}]]), Qs = $("SettingsIcon", [["path", {
	d: "M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",
	key: "1qme2f"
}], ["circle", {
	cx: "12",
	cy: "12",
	r: "3",
	key: "1v7zrd"
}]]), $s = $("ShieldCheckIcon", [["path", {
	d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
	key: "oel41y"
}], ["path", {
	d: "m9 12 2 2 4-4",
	key: "dzmm74"
}]]), ec = $("SlidersHorizontalIcon", [
	["line", {
		x1: "21",
		x2: "14",
		y1: "4",
		y2: "4",
		key: "obuewd"
	}],
	["line", {
		x1: "10",
		x2: "3",
		y1: "4",
		y2: "4",
		key: "1q6298"
	}],
	["line", {
		x1: "21",
		x2: "12",
		y1: "12",
		y2: "12",
		key: "1iu8h1"
	}],
	["line", {
		x1: "8",
		x2: "3",
		y1: "12",
		y2: "12",
		key: "ntss68"
	}],
	["line", {
		x1: "21",
		x2: "16",
		y1: "20",
		y2: "20",
		key: "14d8ph"
	}],
	["line", {
		x1: "12",
		x2: "3",
		y1: "20",
		y2: "20",
		key: "m0wm8r"
	}],
	["line", {
		x1: "14",
		x2: "14",
		y1: "2",
		y2: "6",
		key: "14e1ph"
	}],
	["line", {
		x1: "8",
		x2: "8",
		y1: "10",
		y2: "14",
		key: "1i6ji0"
	}],
	["line", {
		x1: "16",
		x2: "16",
		y1: "18",
		y2: "22",
		key: "1lctlv"
	}]
]), tc = $("Trash2Icon", [
	["path", {
		d: "M3 6h18",
		key: "d0wm0j"
	}],
	["path", {
		d: "M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",
		key: "4alrt4"
	}],
	["path", {
		d: "M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",
		key: "v07s0e"
	}],
	["line", {
		x1: "10",
		x2: "10",
		y1: "11",
		y2: "17",
		key: "1uufr5"
	}],
	["line", {
		x1: "14",
		x2: "14",
		y1: "11",
		y2: "17",
		key: "xtxkd"
	}]
]), nc = $("UploadIcon", [
	["path", {
		d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
		key: "ih7n3h"
	}],
	["polyline", {
		points: "17 8 12 3 7 8",
		key: "t8dd8p"
	}],
	["line", {
		x1: "12",
		x2: "12",
		y1: "3",
		y2: "15",
		key: "widbto"
	}]
]), rc = $("XIcon", [["path", {
	d: "M18 6 6 18",
	key: "1bl5f8"
}], ["path", {
	d: "m6 6 12 12",
	key: "d8bk6v"
}]]);
//#endregion
//#region src/leitherRuntime.ts
function ic(e) {
	return typeof e == "string" ? e.trim() : "";
}
function ac() {
	try {
		return typeof window.getParam == "function" ? window.getParam() : null;
	} catch {
		return null;
	}
}
function oc(e) {
	let t = ic(e);
	if (!t) return "";
	let n = /^https?:\/\//i.test(t) ? t : `http://${t}`;
	try {
		return new URL(n).origin;
	} catch {
		return "";
	}
}
function sc() {
	let e = new URLSearchParams(window.location.search);
	return e.get("aid") || e.get("mid") || window.location.pathname.match(/\/mm\/([^/:]+)(?::[^/]+)?\//)?.[1] || "";
}
function cc(e) {
	if (e && Array.isArray(e.ips)) {
		let t = typeof e.CurNode == "number" ? e.CurNode : 0, n = oc(e.ips[t]);
		if (n) return n;
		for (let t of e.ips) {
			let e = oc(t);
			if (e) return e;
		}
	}
	return /^https?:$/.test(window.location.protocol) && window.location.port ? window.location.origin : "";
}
var lc = ac(), uc = ic(lc?.aid) || ic(lc?.mid) || sc(), dc = cc(lc), fc = uc || "", pc = dc || "";
function mc() {
	if (!fc || !pc) throw Error("lifedrive.bootstrap.unavailable");
}
//#endregion
//#region src/driveStorage.ts
var hc = "inoku.lifedrive.web.v1", gc = "inoku-lifedrive", _c = 1, vc = "file-blobs";
function yc() {
	try {
		let e = window.localStorage.getItem(hc);
		return e ? JSON.parse(e) : null;
	} catch {
		return null;
	}
}
function bc(e) {
	window.localStorage.setItem(hc, JSON.stringify(e));
}
function xc() {
	return new Promise((e, t) => {
		let n = window.indexedDB.open(gc, _c);
		n.onupgradeneeded = () => {
			let e = n.result;
			e.objectStoreNames.contains(vc) || e.createObjectStore(vc);
		}, n.onsuccess = () => e(n.result), n.onerror = () => t(n.error ?? /* @__PURE__ */ Error("Unable to open local file storage."));
	});
}
async function Sc(e, t) {
	let n = await xc();
	await new Promise((r, i) => {
		let a = n.transaction(vc, "readwrite");
		a.objectStore(vc).put(t, e), a.oncomplete = () => r(), a.onerror = () => i(a.error ?? /* @__PURE__ */ Error("Unable to save the file."));
	}), n.close();
}
async function Cc(e) {
	let t = await xc(), n = await new Promise((n, r) => {
		let i = t.transaction(vc, "readonly").objectStore(vc).get(e);
		i.onsuccess = () => n(i.result ?? null), i.onerror = () => r(i.error ?? /* @__PURE__ */ Error("Unable to read the file."));
	});
	return t.close(), n;
}
async function wc(e) {
	let t = await xc();
	await new Promise((n, r) => {
		let i = t.transaction(vc, "readwrite");
		i.objectStore(vc).delete(e), i.oncomplete = () => n(), i.onerror = () => r(i.error ?? /* @__PURE__ */ Error("Unable to remove the file."));
	}), t.close();
}
//#endregion
//#region src/ownerAuth.ts
var Tc = /* @__PURE__ */ c((/* @__PURE__ */ o(((e, t) => {
	var n = Object.create(null);
	n.global = typeof global == "object" ? global : typeof window == "object" ? window : typeof self == "object" ? self : e, (function(e, t) {
		function n(e) {
			if (typeof e != "function") throw TypeError(e + " is not a function");
			return function(t) {
				return e.apply(t, Array.prototype.slice.call(arguments, 1));
			};
		}
		var r = !0;
		try {
			String.fromCharCode.apply(String, new Uint8Array([1]));
		} catch {
			r = !1;
		}
		function i(e) {
			for (var t = e.length, n = Array(t), r = 0; r < t; ++r) n[r] = e[r];
			return n;
		}
		var a = r ? function(e) {
			return e;
		} : i;
		function o(e) {
			e instanceof ArrayBuffer && (e = new Uint8Array(e));
			var t = e.length;
			if (t < 65535) return String.fromCharCode.apply(String, a(e));
			for (var n = t & 32767, r = t >> 15, i = Array(n ? r + 1 : r), o = 0; o < r; ++o) i[o] = String.fromCharCode.apply(String, a(e.subarray(o << 15, o + 1 << 15)));
			return n && (i[r] = String.fromCharCode.apply(String, a(e.subarray(r << 15, t)))), i.join("");
		}
		function s(e) {
			for (var t = e.length, n = new Uint8Array(t), r = 0; r < t; r++) n[r] = e.charCodeAt(r) & 255;
			return n;
		}
		e.generic = n, e.toBinaryString = o, e.toUint8Array = s, e.toArray = i, e.parseuri = function(e) {
			var t = /* @__PURE__ */ RegExp("^(([^:/?#]+):)?(//([^/?#]*))?([^?#]*)(\\?([^#]*))?(#(.*))?"), n = e.match(t), r = n[4].split(":", 2);
			return {
				protocol: n[1],
				host: n[4],
				hostname: r[0],
				port: parseInt(r[1], 10) || 0,
				path: n[5],
				query: n[7],
				fragment: n[9]
			};
		}, e.isObjectEmpty = function(e) {
			if (e) for (var t in e) return !1;
			return !0;
		};
	})(n), (function(e, t) {
		Function.prototype.bind || Object.defineProperty(Function.prototype, "bind", { value: function(e) {
			if (typeof this != "function") throw TypeError("Function.prototype.bind - what is trying to be bound is not callable");
			var t = Array.prototype.slice.call(arguments, 1), n = this, r = function() {}, i = function() {
				return n.apply(this instanceof r ? this : e, t.concat(Array.prototype.slice.call(arguments)));
			};
			return this.prototype && (r.prototype = this.prototype), i.prototype = new r(), i;
		} }), Array.prototype.includes || Object.defineProperty(Array.prototype, "includes", { value: function(e) {
			var t = Object(this), n = parseInt(t.length, 10) || 0;
			if (n === 0) return !1;
			var r = parseInt(arguments[1], 10) || 0, i;
			r >= 0 ? i = r : (i = n + r, i < 0 && (i = 0));
			for (var a; i < n;) {
				if (a = t[i], e === a || e !== e && a !== a) return !0;
				i++;
			}
			return !1;
		} }), Array.prototype.find || Object.defineProperty(Array.prototype, "find", { value: function(e) {
			if (this === null || this === t) throw TypeError("Array.prototype.find called on null or undefined");
			if (typeof e != "function") throw TypeError("predicate must be a function");
			for (var n = Object(this), r = n.length >>> 0, i = arguments[1], a, o = 0; o < r; o++) if (a = n[o], e.call(i, a, o, n)) return a;
			return t;
		} }), Array.prototype.findIndex || Object.defineProperty(Array.prototype, "findIndex", { value: function(e) {
			if (this === null || this === t) throw TypeError("Array.prototype.findIndex called on null or undefined");
			if (typeof e != "function") throw TypeError("predicate must be a function");
			for (var n = Object(this), r = n.length >>> 0, i = arguments[1], a, o = 0; o < r; o++) if (a = n[o], e.call(i, a, o, n)) return o;
			return -1;
		} }), Array.prototype.fill || Object.defineProperty(Array.prototype, "fill", { value: function(e) {
			if (this === null || this === t) throw TypeError("this is null or not defined");
			for (var n = Object(this), r = n.length >>> 0, i = arguments[1] >> 0, a = i < 0 ? Math.max(r + i, 0) : Math.min(i, r), o = arguments[2], s = o === t ? r : o >> 0, c = s < 0 ? Math.max(r + s, 0) : Math.min(s, r); a < c;) n[a] = e, a++;
			return n;
		} }), Array.prototype.copyWithin || Object.defineProperty(Array.prototype, "copyWithin", { value: function(e, n) {
			if (this === null || this === t) throw TypeError("this is null or not defined");
			var r = Object(this), i = r.length >>> 0, a = e >> 0, o = a < 0 ? Math.max(i + a, 0) : Math.min(a, i), s = n >> 0, c = s < 0 ? Math.max(i + s, 0) : Math.min(s, i), l = arguments[2], u = l === t ? i : l >> 0, d = u < 0 ? Math.max(i + u, 0) : Math.min(u, i), f = Math.min(d - c, i - o), p = 1;
			for (c < o && o < c + f && (p = -1, c += f - 1, o += f - 1); f > 0;) c in r ? r[o] = r[c] : delete r[o], c += p, o += p, f--;
			return r;
		} }), Array.from || Object.defineProperty(Array, "from", { value: function() {
			var e = Object.prototype.toString, n = function(t) {
				return typeof t == "function" || e.call(t) === "[object Function]";
			}, r = function(e) {
				var t = Number(e);
				return isNaN(t) ? 0 : t === 0 || !isFinite(t) ? t : (t > 0 ? 1 : -1) * Math.floor(Math.abs(t));
			}, i = 2 ** 53 - 1, a = function(e) {
				var t = r(e);
				return Math.min(Math.max(t, 0), i);
			};
			return function(e) {
				var r = this, i = Object(e);
				if (e === null || e === t) throw TypeError("Array.from requires an array-like object - not null or undefined");
				var o = arguments.length > 1 ? arguments[1] : void 0, s;
				if (o !== void 0) {
					if (!n(o)) throw TypeError("Array.from: when provided, the second argument must be a function");
					arguments.length > 2 && (s = arguments[2]);
				}
				for (var c = a(i.length), l = n(r) ? Object(new r(c)) : Array(c), u = 0, d; u < c;) d = i[u], o ? l[u] = s === void 0 ? o(d, u) : o.call(s, d, u) : l[u] = d, u += 1;
				return l.length = c, l;
			};
		}() }), Array.of || Object.defineProperty(Array, "of", { value: function() {
			return Array.prototype.slice.call(arguments);
		} }), String.prototype.startsWith || Object.defineProperty(String.prototype, "startsWith", { value: function(e, t) {
			return t ||= 0, this.substr(t, e.length) === e;
		} }), String.prototype.endsWith || Object.defineProperty(String.prototype, "endsWith", { value: function(e, t) {
			var n = this.toString();
			(typeof t != "number" || !isFinite(t) || Math.floor(t) !== t || t > n.length) && (t = n.length), t -= e.length;
			var r = n.indexOf(e, t);
			return r !== -1 && r === t;
		} }), String.prototype.includes || Object.defineProperty(String.prototype, "includes", { value: function() {
			return typeof arguments[1] == "number" ? this.length < arguments[0].length + arguments[1].length ? !1 : this.substr(arguments[1], arguments[0].length) === arguments[0] : String.prototype.indexOf.apply(this, arguments) !== -1;
		} }), String.prototype.repeat || Object.defineProperty(String.prototype, "repeat", { value: function(e) {
			var t = this.toString();
			if (e = +e, e !== e && (e = 0), e < 0) throw RangeError("repeat count must be non-negative");
			if (e === Infinity) throw RangeError("repeat count must be less than infinity");
			if (e = Math.floor(e), t.length === 0 || e === 0) return "";
			if (t.length * e >= 1 << 28) throw RangeError("repeat count must not overflow maximum string size");
			for (var n = ""; (e & 1) == 1 && (n += t), e >>>= 1, e !== 0;) t += t;
			return n;
		} }), String.prototype.trim || Object.defineProperty(String.prototype, "trim", { value: function() {
			return this.toString().replace(/^[\s\xa0]+|[\s\xa0]+$/g, "");
		} }), String.prototype.trimLeft || Object.defineProperty(String.prototype, "trimLeft", { value: function() {
			return this.toString().replace(/^[\s\xa0]+/, "");
		} }), String.prototype.trimRight || Object.defineProperty(String.prototype, "trimRight", { value: function() {
			return this.toString().replace(/[\s\xa0]+$/, "");
		} }), Object.keys || Object.defineProperty(Object, "keys", { value: (function() {
			var e = Object.prototype.hasOwnProperty, t = !{ toString: null }.propertyIsEnumerable("toString"), n = [
				"toString",
				"toLocaleString",
				"valueOf",
				"hasOwnProperty",
				"isPrototypeOf",
				"propertyIsEnumerable",
				"constructor"
			], r = n.length;
			return function(i) {
				if (typeof i != "object" && typeof i != "function" || i === null) throw TypeError("Object.keys called on non-object");
				var a = [];
				for (var o in i) e.call(i, o) && a.push(o);
				if (t) for (var s = 0; s < r; s++) e.call(i, n[s]) && a.push(n[s]);
				return a;
			};
		})() });
		function n(t, n) {
			for (var r = t.prototype, i = 0, a = n.length; i < a; i++) {
				var o = n[i], s = r[o];
				typeof s == "function" && t[o] === void 0 && Object.defineProperty(t, o, { value: e(s) });
			}
		}
		n(Array, [
			"pop",
			"push",
			"reverse",
			"shift",
			"sort",
			"splice",
			"unshift",
			"concat",
			"join",
			"slice",
			"indexOf",
			"lastIndexOf",
			"filter",
			"forEach",
			"every",
			"map",
			"some",
			"reduce",
			"reduceRight",
			"includes",
			"find",
			"findIndex"
		]), n(String, [
			"quote",
			"substring",
			"toLowerCase",
			"toUpperCase",
			"charAt",
			"charCodeAt",
			"indexOf",
			"lastIndexOf",
			"include",
			"startsWith",
			"endsWith",
			"repeat",
			"trim",
			"trimLeft",
			"trimRight",
			"toLocaleLowerCase",
			"toLocaleUpperCase",
			"match",
			"search",
			"replace",
			"split",
			"substr",
			"concat",
			"slice"
		]);
	})(n.generic), (function(e) {
		var t = "WeakMap" in e, n = "Map" in e, r = !0;
		if (n && (r = "forEach" in new e.Map()), !(t && n && r)) {
			var i = Object.create(null), a = 0, o = function(e) {
				var t = Object.create(null), n = e.valueOf;
				Object.defineProperty(e, "valueOf", {
					value: function(r, a) {
						return this === e && a in i && i[a] === r ? (a in t || (t[a] = Object.create(null)), t[a]) : n.apply(this, arguments);
					},
					writable: !0,
					configurable: !0,
					enumerable: !1
				});
			};
			if (t || (e.WeakMap = function e() {
				var t = Object.create(null), n = a++;
				i[n] = t;
				var r = function(e) {
					if (e !== Object(e)) throw Error("value is not a non-null object");
					var r = e.valueOf(t, n);
					return r === e.valueOf() ? (o(e), e.valueOf(t, n)) : r;
				}, s = Object.create(e.prototype, {
					get: { value: function(e) {
						return r(e).value;
					} },
					set: { value: function(e, t) {
						r(e).value = t;
					} },
					has: { value: function(e) {
						return "value" in r(e);
					} },
					delete: { value: function(e) {
						return delete r(e).value;
					} },
					clear: { value: function() {
						delete i[n], n = a++, i[n] = t;
					} }
				});
				if (arguments.length > 0 && Array.isArray(arguments[0])) for (var c = arguments[0], l = 0, u = c.length; l < u; l++) s.set(c[l][0], c[l][1]);
				return s;
			}), !n) {
				var s = function() {
					var e = Object.create(null), t = a++, n = Object.create(null);
					i[t] = e;
					var r = function(r) {
						if (r === null) return n;
						var i = r.valueOf(e, t);
						return i === r.valueOf() ? (o(r), r.valueOf(e, t)) : i;
					};
					return {
						get: function(e) {
							return r(e).value;
						},
						set: function(e, t) {
							r(e).value = t;
						},
						has: function(e) {
							return "value" in r(e);
						},
						delete: function(e) {
							return delete r(e).value;
						},
						clear: function() {
							delete i[t], t = a++, i[t] = e;
						}
					};
				}, c = function() {
					var e = Object.create(null);
					return {
						get: function() {
							return e.value;
						},
						set: function(t, n) {
							e.value = n;
						},
						has: function() {
							return "value" in e;
						},
						delete: function() {
							return delete e.value;
						},
						clear: function() {
							e = Object.create(null);
						}
					};
				}, l = function() {
					var e = Object.create(null);
					return {
						get: function(t) {
							return e[t];
						},
						set: function(t, n) {
							e[t] = n;
						},
						has: function(t) {
							return t in e;
						},
						delete: function(t) {
							return delete e[t];
						},
						clear: function() {
							e = Object.create(null);
						}
					};
				};
				e.Map = function e() {
					var t = {
						number: l(),
						string: l(),
						boolean: l(),
						object: s(),
						function: s(),
						unknown: s(),
						undefined: c(),
						null: c()
					}, n = 0, r = [], i = Object.create(e.prototype, {
						size: { get: function() {
							return n;
						} },
						get: { value: function(e) {
							return t[typeof e].get(e);
						} },
						set: { value: function(e, i) {
							this.has(e) || (r.push(e), n++), t[typeof e].set(e, i);
						} },
						has: { value: function(e) {
							return t[typeof e].has(e);
						} },
						delete: { value: function(e) {
							return this.has(e) ? (n--, r.splice(r.indexOf(e), 1), t[typeof e].delete(e)) : !1;
						} },
						clear: { value: function() {
							for (var e in r.length = 0, t) t[e].clear();
							n = 0;
						} },
						forEach: { value: function(e, t) {
							for (var n = 0, i = r.length; n < i; n++) e.call(t, this.get(r[n]), r[n], this);
						} }
					});
					if (arguments.length > 0 && Array.isArray(arguments[0])) for (var a = arguments[0], o = 0, u = a.length; o < u; o++) i.set(a[o][0], a[o][1]);
					return i;
				};
			}
			if (!r) {
				var u = e.Map;
				e.Map = function e() {
					var t = new u(), n = 0, r = [], i = Object.create(e.prototype, {
						size: { get: function() {
							return n;
						} },
						get: { value: function(e) {
							return t.get(e);
						} },
						set: { value: function(e, i) {
							t.has(e) || (r.push(e), n++), t.set(e, i);
						} },
						has: { value: function(e) {
							return t.has(e);
						} },
						delete: { value: function(e) {
							return t.has(e) ? (n--, r.splice(r.indexOf(e), 1), t.delete(e)) : !1;
						} },
						clear: { value: function() {
							if ("clear" in t) t.clear();
							else for (var e = 0, i = r.length; e < i; e++) t.delete(r[e]);
							r.length = 0, n = 0;
						} },
						forEach: { value: function(e, t) {
							for (var n = 0, i = r.length; n < i; n++) e.call(t, this.get(r[n]), r[n], this);
						} }
					});
					if (arguments.length > 0 && Array.isArray(arguments[0])) for (var a = arguments[0], o = 0, s = a.length; o < s; o++) i.set(a[o][0], a[o][1]);
					return i;
				};
			}
		}
	})(n.global), (function(e) {
		function t(e) {
			Error.call(this), this.message = e, this.name = t.name, typeof Error.captureStackTrace == "function" && Error.captureStackTrace(this, t);
		}
		t.prototype = Object.create(Error.prototype), t.prototype.constructor = t, e.TimeoutError = t;
	})(n.global), (function(e, t) {
		if (e.setImmediate) return;
		var n = e.document, r = e.MutationObserver || e.WebKitMutationObserver || e.MozMutationOvserver, i = {}, a = 1, o = {};
		function s(e) {
			var n = Array.prototype.slice.call(arguments, 1);
			return function() {
				e.apply(t, n);
			};
		}
		function c(e) {
			delete o[e];
		}
		function l(e) {
			var t = o[e];
			if (t) try {
				t();
			} finally {
				c(e);
			}
		}
		function u(e) {
			return o[a] = s.apply(t, e), a++;
		}
		i.mutationObserver = function() {
			var e = [], t = n.createTextNode("");
			return new r(function() {
				for (; e.length > 0;) l(e.shift());
			}).observe(t, { characterData: !0 }), function() {
				var n = u(arguments);
				return e.push(n), t.data = n & 1, n;
			};
		}, i.messageChannel = function() {
			var t = new e.MessageChannel();
			return t.port1.onmessage = function(e) {
				l(Number(e.data));
			}, function() {
				var e = u(arguments);
				return t.port2.postMessage(e), e;
			};
		}, i.nextTick = function() {
			return function() {
				var t = u(arguments);
				return e.process.nextTick(s(l, t)), t;
			};
		}, i.postMessage = function() {
			var e = n.createElement("iframe");
			e.style.display = "none", n.documentElement.appendChild(e);
			var t = e.contentWindow;
			t.document.write("<script>window.onmessage=function(){parent.postMessage(1, \"*\");};<\/script>"), t.document.close();
			var r = [];
			return window.addEventListener("message", function() {
				for (; r.length > 0;) l(r.shift());
			}), function() {
				var e = u(arguments);
				return r.push(e), t.postMessage(1, "*"), e;
			};
		}, i.readyStateChange = function() {
			var e = n.documentElement;
			return function() {
				var t = u(arguments), r = n.createElement("script");
				return r.onreadystatechange = function() {
					l(t), r.onreadystatechange = null, e.removeChild(r), r = null;
				}, e.appendChild(r), t;
			};
		};
		var d = Object.getPrototypeOf && Object.getPrototypeOf(e);
		d = d && d.setTimeout ? d : e, i.setTimeout = function() {
			return function() {
				var e = u(arguments);
				return d.setTimeout(s(l, e), 0), e;
			};
		}, e.process !== void 0 && Object.prototype.toString.call(e.process) === "[object process]" && !e.process.browser ? d.setImmediate = i.nextTick() : n && "onreadystatechange" in n.createElement("script") ? d.setImmediate = i.readyStateChange() : n && r ? d.setImmediate = i.mutationObserver() : e.MessageChannel ? d.setImmediate = i.messageChannel() : n && "postMessage" in e && "addEventListener" in e ? d.setImmediate = i.postMessage() : d.setImmediate = i.setTimeout(), d.clearImmediate = c;
	})(n.global), (function(e, t, n) {
		var r = 0, i = 1, a = 2, o = "Promise" in t, s = t.setImmediate, c = t.setTimeout, l = t.clearTimeout, u = t.TimeoutError, d = Array.prototype.forEach, f = Array.prototype.slice;
		function p(e) {
			var t = this;
			Object.defineProperties(this, {
				_subscribers: { value: [] },
				resolve: { value: this.resolve.bind(this) },
				reject: { value: this.reject.bind(this) }
			}), typeof e == "function" && s(function() {
				try {
					t.resolve(e());
				} catch (e) {
					t.reject(e);
				}
			});
		}
		function m(e) {
			return e instanceof p;
		}
		function h(e) {
			return m(e) ? e : y(e);
		}
		function g(e) {
			return typeof e.then == "function";
		}
		function _(e, t) {
			var n = typeof t == "function" ? t : function() {
				return t;
			}, r = new p();
			return c(function() {
				try {
					r.resolve(n());
				} catch (e) {
					r.reject(e);
				}
			}, e), r;
		}
		function v(e) {
			var t = new p();
			return t.reject(e), t;
		}
		function y(e) {
			var t = new p();
			return t.resolve(e), t;
		}
		function b(e) {
			try {
				return y(e());
			} catch (e) {
				return v(e);
			}
		}
		function x(e) {
			var t = new p();
			return e(t.resolve, t.reject), t;
		}
		function S(e) {
			var t = 0;
			return d.call(e, function() {
				++t;
			}), t;
		}
		function C(e) {
			return h(e).then(function(e) {
				var t = e.length, n = S(e), r = Array(t);
				if (n === 0) return r;
				var i = new p();
				return d.call(e, function(e, t) {
					h(e).then(function(e) {
						r[t] = e, --n === 0 && i.resolve(r);
					}, i.reject);
				}), i;
			});
		}
		function w() {
			return C(arguments);
		}
		function T(e) {
			return h(e).then(function(e) {
				var t = new p();
				return d.call(e, function(e) {
					h(e).fill(t);
				}), t;
			});
		}
		function E(e) {
			return h(e).then(function(e) {
				var t = e.length, n = S(e);
				if (n === 0) throw RangeError("any(): array must not be empty");
				var r = Array(t), i = new p();
				return d.call(e, function(e, t) {
					h(e).then(i.resolve, function(e) {
						r[t] = e, --n === 0 && i.reject(r);
					});
				}), i;
			});
		}
		function D(e) {
			return h(e).then(function(e) {
				var t = e.length, n = S(e), r = Array(t);
				if (n === 0) return r;
				var i = new p();
				return d.call(e, function(e, t) {
					var a = h(e);
					a.complete(function() {
						r[t] = a.inspect(), --n === 0 && i.resolve(r);
					});
				}), i;
			});
		}
		function ee(e) {
			var t = (function() {
				return this;
			})();
			return C(f.call(arguments, 1)).then(function(n) {
				return e.apply(t, n);
			});
		}
		function te(e, t) {
			return C(f.call(arguments, 2)).then(function(n) {
				return e.apply(t, n);
			});
		}
		function ne(e) {
			return e ? typeof e.next == "function" && typeof e.throw == "function" : !1;
		}
		function re(e) {
			if (!e) return !1;
			var t = e.constructor;
			return t ? t.name === "GeneratorFunction" || t.displayName === "GeneratorFunction" ? !0 : ne(t.prototype) : !1;
		}
		function ie(e) {
			return function(t, r) {
				if (t instanceof Error) return e.reject(t);
				if (arguments.length < 2) return e.resolve(t);
				r = t === null || t === n ? f.call(arguments, 1) : f.call(arguments, 0), r.length == 1 ? e.resolve(r[0]) : e.resolve(r);
			};
		}
		function ae(e) {
			if (re(e) || ne(e)) return k(e);
			var t = (function() {
				return this;
			})(), n = new p();
			return e.call(t, ie(n)), n;
		}
		function oe(e) {
			return function() {
				var t = f.call(arguments, 0), n = this, r = new p();
				t.push(function() {
					n = this, r.resolve(arguments);
				});
				try {
					e.apply(this, t);
				} catch (e) {
					r.resolve([e]);
				}
				return function(e) {
					r.then(function(t) {
						e.apply(n, t);
					});
				};
			};
		}
		function O(e) {
			return function() {
				var t = f.call(arguments, 0), n = new p();
				t.push(ie(n));
				try {
					e.apply(this, t);
				} catch (e) {
					n.reject(e);
				}
				return n;
			};
		}
		function se(e) {
			return re(e) || ne(e) ? k(e) : h(e);
		}
		function k(e) {
			var t = (function() {
				return this;
			})();
			if (typeof e == "function") {
				var n = f.call(arguments, 1);
				e = e.apply(t, n);
			}
			if (!e || typeof e.next != "function") return h(e);
			var r = new p();
			function i(t) {
				try {
					o(e.next(t));
				} catch (e) {
					r.reject(e);
				}
			}
			function a(t) {
				try {
					o(e.throw(t));
				} catch (e) {
					r.reject(e);
				}
			}
			function o(e) {
				e.done ? r.resolve(e.value) : (typeof e.value == "function" ? ae(e.value) : se(e.value)).then(i, a);
			}
			return i(), r;
		}
		function ce(e, t) {
			return function() {
				return t ||= this, C(arguments).then(function(n) {
					var r = e.apply(t, n);
					return re(r) || ne(r) ? k.call(t, r) : r;
				});
			};
		}
		k.wrap = ce;
		function A(e, t, n) {
			return n ||= (function() {
				return this;
			})(), C(e).then(function(e) {
				return e.forEach(t, n);
			});
		}
		function j(e, t, n) {
			return n ||= (function() {
				return this;
			})(), C(e).then(function(e) {
				return e.every(t, n);
			});
		}
		function le(e, t, n) {
			return n ||= (function() {
				return this;
			})(), C(e).then(function(e) {
				return e.some(t, n);
			});
		}
		function M(e, t, n) {
			return n ||= (function() {
				return this;
			})(), C(e).then(function(e) {
				return e.filter(t, n);
			});
		}
		function N(e, t, n) {
			return n ||= (function() {
				return this;
			})(), C(e).then(function(e) {
				return e.map(t, n);
			});
		}
		function ue(e, t, n) {
			return arguments.length > 2 ? C(e).then(function(e) {
				return h(n).then(function(n) {
					return e.reduce(t, n);
				});
			}) : C(e).then(function(e) {
				return e.reduce(t);
			});
		}
		function P(e, t, n) {
			return arguments.length > 2 ? C(e).then(function(e) {
				return h(n).then(function(n) {
					return e.reduceRight(t, n);
				});
			}) : C(e).then(function(e) {
				return e.reduceRight(t);
			});
		}
		function de(e, t, n) {
			return C(e).then(function(e) {
				return h(t).then(function(t) {
					return e.indexOf(t, n);
				});
			});
		}
		function fe(e, t, r) {
			return C(e).then(function(e) {
				return h(t).then(function(t) {
					return r === n && (r = e.length - 1), e.lastIndexOf(t, r);
				});
			});
		}
		function pe(e, t, n) {
			return C(e).then(function(e) {
				return h(t).then(function(t) {
					return e.includes(t, n);
				});
			});
		}
		function me(e, t, n) {
			return n ||= (function() {
				return this;
			})(), C(e).then(function(e) {
				return e.find(t, n);
			});
		}
		function F(e, t, n) {
			return n ||= (function() {
				return this;
			})(), C(e).then(function(e) {
				return e.findIndex(t, n);
			});
		}
		Object.defineProperties(p, {
			delayed: { value: _ },
			error: { value: v },
			sync: { value: b },
			value: { value: y },
			all: { value: C },
			race: { value: T },
			resolve: { value: y },
			reject: { value: v },
			promise: { value: x },
			isFuture: { value: m },
			toFuture: { value: h },
			isPromise: { value: g },
			toPromise: { value: se },
			join: { value: w },
			any: { value: E },
			settle: { value: D },
			attempt: { value: ee },
			run: { value: te },
			thunkify: { value: oe },
			promisify: { value: O },
			co: { value: k },
			wrap: { value: ce },
			forEach: { value: A },
			every: { value: j },
			some: { value: le },
			filter: { value: M },
			map: { value: N },
			reduce: { value: ue },
			reduceRight: { value: P },
			indexOf: { value: de },
			lastIndexOf: { value: fe },
			includes: { value: pe },
			find: { value: me },
			findIndex: { value: F }
		});
		function he(e, t, n) {
			s(function() {
				try {
					var r = e(n);
					t.resolve(r);
				} catch (e) {
					t.reject(e);
				}
			});
		}
		function ge(e, t, n) {
			e ? he(e, t, n) : t.resolve(n);
		}
		function _e(e, t, n) {
			e ? he(e, t, n) : t.reject(n);
		}
		Object.defineProperties(p.prototype, {
			_value: { writable: !0 },
			_reason: { writable: !0 },
			_state: {
				value: r,
				writable: !0
			},
			resolve: { value: function(e) {
				if (e === this) {
					this.reject(/* @__PURE__ */ TypeError("Self resolution"));
					return;
				}
				if (m(e)) {
					e.fill(this);
					return;
				}
				if (typeof e == "object" && e || typeof e == "function") {
					var t;
					try {
						t = e.then;
					} catch (e) {
						this.reject(e);
						return;
					}
					if (typeof t == "function") {
						var n = !0;
						try {
							var a = this;
							t.call(e, function(e) {
								n && (n = !1, a.resolve(e));
							}, function(e) {
								n && (n = !1, a.reject(e));
							});
							return;
						} catch (e) {
							n && (n = !1, this.reject(e));
						}
						return;
					}
				}
				if (this._state === r) {
					this._state = i, this._value = e;
					for (var o = this._subscribers; o.length > 0;) {
						var s = o.shift();
						ge(s.onfulfill, s.next, e);
					}
				}
			} },
			reject: { value: function(e) {
				if (this._state === r) {
					this._state = a, this._reason = e;
					for (var t = this._subscribers; t.length > 0;) {
						var n = t.shift();
						_e(n.onreject, n.next, e);
					}
				}
			} },
			then: { value: function(e, t) {
				typeof e != "function" && (e = null), typeof t != "function" && (t = null);
				var n = new p();
				return this._state === i ? ge(e, n, this._value) : this._state === a ? _e(t, n, this._reason) : this._subscribers.push({
					onfulfill: e,
					onreject: t,
					next: n
				}), n;
			} },
			done: { value: function(e, t) {
				this.then(e, t).then(null, function(e) {
					s(function() {
						throw e;
					});
				});
			} },
			inspect: { value: function() {
				switch (this._state) {
					case r: return { state: "pending" };
					case i: return {
						state: "fulfilled",
						value: this._value
					};
					case a: return {
						state: "rejected",
						reason: this._reason
					};
				}
			} },
			catchError: { value: function(e, t) {
				if (typeof t == "function") {
					var n = this;
					return this.catch(function(r) {
						if (t(r)) return n.catch(e);
						throw r;
					});
				}
				return this.catch(e);
			} },
			catch: { value: function(e) {
				return this.then(null, e);
			} },
			fail: { value: function(e) {
				this.done(null, e);
			} },
			whenComplete: { value: function(e) {
				return this.then(function(t) {
					return e(), t;
				}, function(t) {
					throw e(), t;
				});
			} },
			complete: { value: function(e) {
				return e ||= function(e) {
					return e;
				}, this.then(e, e);
			} },
			always: { value: function(e) {
				this.done(e, e);
			} },
			fill: { value: function(e) {
				this.then(e.resolve, e.reject);
			} },
			timeout: { value: function(e, t) {
				var n = new p(), r = c(function() {
					n.reject(t || new u("timeout"));
				}, e);
				return this.whenComplete(function() {
					l(r);
				}).fill(n), n;
			} },
			delay: { value: function(e) {
				var t = new p();
				return this.then(function(n) {
					c(function() {
						t.resolve(n);
					}, e);
				}, t.reject), t;
			} },
			tap: { value: function(e, t) {
				return this.then(function(n) {
					return e.call(t, n), n;
				});
			} },
			spread: { value: function(e, t) {
				return this.then(function(n) {
					return e.apply(t, n);
				});
			} },
			get: { value: function(e) {
				return this.then(function(t) {
					return t[e];
				});
			} },
			set: { value: function(e, t) {
				return this.then(function(n) {
					return n[e] = t, n;
				});
			} },
			apply: { value: function(e, t) {
				return t ||= [], this.then(function(n) {
					return C(t).then(function(t) {
						return n[e].apply(n, t);
					});
				});
			} },
			call: { value: function(e) {
				var t = f.call(arguments, 1);
				return this.then(function(n) {
					return C(t).then(function(t) {
						return n[e].apply(n, t);
					});
				});
			} },
			bind: { value: function(e) {
				var t = f.call(arguments);
				if (Array.isArray(e)) {
					for (var n = 0, r = e.length; n < r; ++n) t[0] = e[n], this.bind.apply(this, t);
					return;
				}
				t.shift();
				var i = this;
				return Object.defineProperty(this, e, { value: function() {
					var n = f.call(arguments);
					return i.then(function(r) {
						return C(t.concat(n)).then(function(t) {
							return r[e].apply(r, t);
						});
					});
				} }), this;
			} },
			forEach: { value: function(e, t) {
				return A(this, e, t);
			} },
			every: { value: function(e, t) {
				return j(this, e, t);
			} },
			some: { value: function(e, t) {
				return le(this, e, t);
			} },
			filter: { value: function(e, t) {
				return M(this, e, t);
			} },
			map: { value: function(e, t) {
				return N(this, e, t);
			} },
			reduce: { value: function(e, t) {
				return arguments.length > 1 ? ue(this, e, t) : ue(this, e);
			} },
			reduceRight: { value: function(e, t) {
				return arguments.length > 1 ? P(this, e, t) : P(this, e);
			} },
			indexOf: { value: function(e, t) {
				return de(this, e, t);
			} },
			lastIndexOf: { value: function(e, t) {
				return fe(this, e, t);
			} },
			includes: { value: function(e, t) {
				return pe(this, e, t);
			} },
			find: { value: function(e, t) {
				return me(this, e, t);
			} },
			findIndex: { value: function(e, t) {
				return F(this, e, t);
			} }
		}), e.Future = p, e.thunkify = oe, e.promisify = O, e.co = k, e.co.wrap = e.wrap = ce;
		function I() {
			var e = new p();
			Object.defineProperties(this, {
				future: { value: e },
				complete: { value: e.resolve },
				completeError: { value: e.reject },
				isCompleted: { get: function() {
					return e._state !== r;
				} }
			});
		}
		if (e.Completer = I, e.resolved = y, e.rejected = v, e.deferred = function() {
			var e = new p();
			return Object.create(null, {
				promise: { value: e },
				resolve: { value: e.resolve },
				reject: { value: e.reject }
			});
		}, o) return;
		function ve(e) {
			p.call(this), e(this.resolve, this.reject);
		}
		ve.prototype = Object.create(p.prototype), ve.prototype.constructor = p, Object.defineProperties(ve, {
			all: { value: C },
			race: { value: T },
			resolve: { value: y },
			reject: { value: v }
		}), t.Promise = ve;
	})(n, n.global), (function(e, t) {
		var n = e.toBinaryString, r = new Uint8Array(), i = 1024;
		function a(e, t, n) {
			return e[t++] = n >>> 24 & 255, e[t++] = n >>> 16 & 255, e[t++] = n >>> 8 & 255, e[t++] = n & 255, t;
		}
		function o(e, t, n) {
			return e[t++] = n & 255, e[t++] = n >>> 8 & 255, e[t++] = n >>> 16 & 255, e[t++] = n >>> 24 & 255, t;
		}
		function s(e, t, n) {
			for (var r = n.length, i = 0; i < r; ++i) {
				var a = n.charCodeAt(i);
				if (a < 128) e[t++] = a;
				else if (a < 2048) e[t++] = 192 | a >> 6, e[t++] = 128 | a & 63;
				else if (a < 55296 || a > 57343) e[t++] = 224 | a >> 12, e[t++] = 128 | a >> 6 & 63, e[t++] = 128 | a & 63;
				else {
					if (i + 1 < r) {
						var o = n.charCodeAt(i + 1);
						if (a < 56320 && 56320 <= o && o <= 57343) {
							var s = ((a & 1023) << 10 | o & 1023) + 65536;
							e[t++] = 240 | s >> 18, e[t++] = 128 | s >> 12 & 63, e[t++] = 128 | s >> 6 & 63, e[t++] = 128 | s & 63, ++i;
							continue;
						}
					}
					throw Error("Malformed string");
				}
			}
			return t;
		}
		function c(e, t) {
			for (var n = Array(t), r = 0, i = 0, a = e.length; r < t && i < a; r++) {
				var o = e[i++];
				switch (o >> 4) {
					case 0:
					case 1:
					case 2:
					case 3:
					case 4:
					case 5:
					case 6:
					case 7:
						n[r] = o;
						break;
					case 12:
					case 13:
						if (i < a) {
							n[r] = (o & 31) << 6 | e[i++] & 63;
							break;
						}
						throw Error("Unfinished UTF-8 octet sequence");
					case 14:
						if (i + 1 < a) {
							n[r] = (o & 15) << 12 | (e[i++] & 63) << 6 | e[i++] & 63;
							break;
						}
						throw Error("Unfinished UTF-8 octet sequence");
					case 15:
						if (i + 2 < a) {
							var s = ((o & 7) << 18 | (e[i++] & 63) << 12 | (e[i++] & 63) << 6 | e[i++] & 63) - 65536;
							if (0 <= s && s <= 1048575) {
								n[r++] = s >> 10 & 1023 | 55296, n[r] = s & 1023 | 56320;
								break;
							}
							throw Error("Character outside valid Unicode range: 0x" + s.toString(16));
						}
						throw Error("Unfinished UTF-8 octet sequence");
					default: throw Error("Bad UTF-8 encoding 0x" + o.toString(16));
				}
			}
			return r < t && (n.length = r), [String.fromCharCode.apply(String, n), i];
		}
		function l(e, t) {
			for (var n = [], r = Array(32768), i = 0, a = 0, o = e.length; i < t && a < o; i++) {
				var s = e[a++];
				switch (s >> 4) {
					case 0:
					case 1:
					case 2:
					case 3:
					case 4:
					case 5:
					case 6:
					case 7:
						r[i] = s;
						break;
					case 12:
					case 13:
						if (a < o) {
							r[i] = (s & 31) << 6 | e[a++] & 63;
							break;
						}
						throw Error("Unfinished UTF-8 octet sequence");
					case 14:
						if (a + 1 < o) {
							r[i] = (s & 15) << 12 | (e[a++] & 63) << 6 | e[a++] & 63;
							break;
						}
						throw Error("Unfinished UTF-8 octet sequence");
					case 15:
						if (a + 2 < o) {
							var c = ((s & 7) << 18 | (e[a++] & 63) << 12 | (e[a++] & 63) << 6 | e[a++] & 63) - 65536;
							if (0 <= c && c <= 1048575) {
								r[i++] = c >> 10 & 1023 | 55296, r[i] = c & 1023 | 56320;
								break;
							}
							throw Error("Character outside valid Unicode range: 0x" + c.toString(16));
						}
						throw Error("Unfinished UTF-8 octet sequence");
					default: throw Error("Bad UTF-8 encoding 0x" + s.toString(16));
				}
				if (i >= 32766) {
					var l = i + 1;
					r.length = l, n.push(String.fromCharCode.apply(String, r)), t -= l, i = -1;
				}
			}
			return i > 0 && (r.length = i, n.push(String.fromCharCode.apply(String, r))), [n.join(""), a];
		}
		function u(e, n) {
			return (n === t || n === null || n < 0) && (n = e.length), n === 0 ? ["", 0] : n < 65535 ? c(e, n) : l(e, n);
		}
		function d(e, n) {
			if (n === t && (n = e.length), n === 0) return [r, 0];
			for (var i = 0, a = 0, o = e.length; i < n && a < o; i++) {
				var s = e[a++];
				switch (s >> 4) {
					case 0:
					case 1:
					case 2:
					case 3:
					case 4:
					case 5:
					case 6:
					case 7: break;
					case 12:
					case 13:
						if (a < o) {
							a++;
							break;
						}
						throw Error("Unfinished UTF-8 octet sequence");
					case 14:
						if (a + 1 < o) {
							a += 2;
							break;
						}
						throw Error("Unfinished UTF-8 octet sequence");
					case 15:
						if (a + 2 < o) {
							var c = ((s & 7) << 18 | (e[a++] & 63) << 12 | (e[a++] & 63) << 6 | e[a++] & 63) - 65536;
							if (0 <= c && c <= 1048575) {
								i++;
								break;
							}
							throw Error("Character outside valid Unicode range: 0x" + c.toString(16));
						}
						throw Error("Unfinished UTF-8 octet sequence");
					default: throw Error("Bad UTF-8 encoding 0x" + s.toString(16));
				}
			}
			return [e.subarray(0, a), a];
		}
		function f(e) {
			return --e, e |= e >> 1, e |= e >> 2, e |= e >> 4, e |= e >> 8, e |= e >> 16, e + 1;
		}
		function p() {
			var e = arguments;
			switch (e.length) {
				case 1:
					switch (e[0].constructor) {
						case Uint8Array:
							this._bytes = e[0], this._length = e[0].length;
							break;
						case p:
							this._bytes = e[0].toBytes(), this._length = e[0].length;
							break;
						case String:
							this.writeString(e[0]);
							break;
						case Number:
							this._bytes = new Uint8Array(e[0]);
							break;
						default:
							this._bytes = new Uint8Array(e[0]), this._length = this._bytes.length;
							break;
					}
					break;
				case 2:
					this._bytes = new Uint8Array(e[0], e[1]), this._length = e[1];
					break;
				case 3:
					this._bytes = new Uint8Array(e[0], e[1], e[2]), this._length = e[2];
					break;
			}
			this.mark();
		}
		Object.defineProperties(p.prototype, {
			_bytes: {
				value: null,
				writable: !0
			},
			_length: {
				value: 0,
				writable: !0
			},
			_wmark: {
				value: 0,
				writable: !0
			},
			_off: {
				value: 0,
				writable: !0
			},
			_rmark: {
				value: 0,
				writable: !0
			},
			_grow: { value: function(e) {
				var t = this._bytes, n = f(this._length + e);
				if (t) {
					if (n *= 2, n > t.length) {
						var r = new Uint8Array(n);
						r.set(t), this._bytes = r;
					}
				} else n = Math.max(n, i), this._bytes = new Uint8Array(n);
			} },
			length: { get: function() {
				return this._length;
			} },
			capacity: { get: function() {
				return this._bytes ? this._bytes.length : 0;
			} },
			position: { get: function() {
				return this._off;
			} },
			bytes: { get: function() {
				return this._bytes === null ? r : this._bytes.subarray(0, this._length);
			} },
			buffer: { get: function() {
				if (this._bytes === null) return r.buffer;
				if (this._bytes.buffer.slice) return this._bytes.buffer.slice(0, this._length);
				var e = new Uint8Array(this._length);
				return e.set(this._bytes.subarray(0, this._length)), e.buffer;
			} },
			mark: { value: function() {
				this._wmark = this._length, this._rmark = this._off;
			} },
			reset: { value: function() {
				this._length = this._wmark, this._off = this._rmark;
			} },
			clear: { value: function() {
				this._bytes = null, this._length = 0, this._wmark = 0, this._off = 0, this._rmark = 0;
			} },
			writeByte: { value: function(e) {
				this._grow(1), this._bytes[this._length++] = e;
			} },
			writeInt32BE: { value: function(e) {
				if (e === (e | 0) && e <= 2147483647) {
					this._grow(4), this._length = a(this._bytes, this._length, e);
					return;
				}
				throw TypeError("value is out of bounds");
			} },
			writeUInt32BE: { value: function(e) {
				if ((e & 2147483647) + 2147483648 === e && e >= 0) {
					this._grow(4), this._length = a(this._bytes, this._length, e | 0);
					return;
				}
				throw TypeError("value is out of bounds");
			} },
			writeInt32LE: { value: function(e) {
				if (e === (e | 0) && e <= 2147483647) {
					this._grow(4), this._length = o(this._bytes, this._length, e);
					return;
				}
				throw TypeError("value is out of bounds");
			} },
			writeUInt32LE: { value: function(e) {
				if ((e & 2147483647) + 2147483648 === e && e >= 0) {
					this._grow(4), this._length = o(this._bytes, this._length, e | 0);
					return;
				}
				throw TypeError("value is out of bounds");
			} },
			write: { value: function(e) {
				var t = e.byteLength || e.length;
				if (t !== 0) {
					this._grow(t);
					var n = this._bytes, r = this._length;
					switch (e.constructor) {
						case ArrayBuffer:
							n.set(new Uint8Array(e), r);
							break;
						case Uint8Array:
							n.set(e, r);
							break;
						case p:
							n.set(e.bytes, r);
							break;
						default:
							for (var i = 0; i < t; i++) n[r + i] = e[i];
							break;
					}
					this._length += t;
				}
			} },
			writeAsciiString: { value: function(e) {
				var t = e.length;
				if (t !== 0) {
					this._grow(t);
					for (var n = this._bytes, r = this._length, i = 0; i < t; ++i, ++r) n[r] = e.charCodeAt(i);
					this._length = r;
				}
			} },
			writeString: { value: function(e) {
				var t = e.length;
				t !== 0 && (this._grow(t * 3), this._length = s(this._bytes, this._length, e));
			} },
			readByte: { value: function() {
				return this._off < this._length ? this._bytes[this._off++] : -1;
			} },
			readInt32BE: { value: function() {
				var e = this._bytes, t = this._off;
				if (t + 3 < this._length) {
					var n = e[t++] << 24 | e[t++] << 16 | e[t++] << 8 | e[t++];
					return this._off = t, n;
				}
				throw Error("EOF");
			} },
			readUInt32BE: { value: function() {
				var e = this.readInt32BE();
				return e < 0 ? (e & 2147483647) + 2147483648 : e;
			} },
			readInt32LE: { value: function() {
				var e = this._bytes, t = this._off;
				if (t + 3 < this._length) {
					var n = e[t++] | e[t++] << 8 | e[t++] << 16 | e[t++] << 24;
					return this._off = t, n;
				}
				throw Error("EOF");
			} },
			readUInt32LE: { value: function() {
				var e = this.readInt32LE();
				return e < 0 ? (e & 2147483647) + 2147483648 : e;
			} },
			read: { value: function(e) {
				return this._off + e > this._length && (e = this._length - this._off), e === 0 ? r : this._bytes.subarray(this._off, this._off += e);
			} },
			skip: { value: function(e) {
				return this._off + e > this._length ? (e = this._length - this._off, this._off = this._length) : this._off += e, e;
			} },
			readBytes: { value: function(e) {
				var t = Array.indexOf(this._bytes, e, this._off), n;
				return t === -1 ? (n = this._bytes.subarray(this._off, this._length), this._off = this._length) : (n = this._bytes.subarray(this._off, t + 1), this._off = t + 1), n;
			} },
			readUntil: { value: function(e) {
				var t = Array.indexOf(this._bytes, e, this._off), n = "";
				return t === this._off ? this._off++ : t === -1 ? (n = u(this._bytes.subarray(this._off, this._length))[0], this._off = this._length) : (n = u(this._bytes.subarray(this._off, t))[0], this._off = t + 1), n;
			} },
			readAsciiString: { value: function(e) {
				return this._off + e > this._length && (e = this._length - this._off), e === 0 ? "" : n(this._bytes.subarray(this._off, this._off += e));
			} },
			readStringAsBytes: { value: function(e) {
				var t = d(this._bytes.subarray(this._off, this._length), e);
				return this._off += t[1], t[0];
			} },
			readString: { value: function(e) {
				var t = u(this._bytes.subarray(this._off, this._length), e);
				return this._off += t[1], t[0];
			} },
			takeBytes: { value: function() {
				var e = this.bytes;
				return this.clear(), e;
			} },
			toBytes: { value: function() {
				return new Uint8Array(this.bytes);
			} },
			toString: { value: function() {
				return u(this.bytes, this._length)[0];
			} },
			clone: { value: function() {
				return new p(this.toBytes());
			} },
			trunc: { value: function() {
				this._bytes = this._bytes.subarray(this._off, this._length), this._length = this._bytes.length, this._off = 0, this._wmark = 0, this._rmark = 0;
			} }
		});
		function m(e) {
			if (e.length === 0) return "";
			switch (e.constructor) {
				case String: return e;
				case p: e = e.bytes;
				case ArrayBuffer: e = new Uint8Array(e);
				case Uint8Array: return u(e, e.length)[0];
				default: return String.fromCharCode.apply(String, e);
			}
		}
		Object.defineProperty(p, "toString", { value: m }), e.BytesIO = p;
	})(n), (function(e) {
		e.Tags = {
			TagInteger: 105,
			TagLong: 108,
			TagDouble: 100,
			TagNull: 110,
			TagEmpty: 101,
			TagTrue: 116,
			TagFalse: 102,
			TagNaN: 78,
			TagInfinity: 73,
			TagDate: 68,
			TagTime: 84,
			TagUTC: 90,
			TagBytes: 98,
			TagUTF8Char: 117,
			TagString: 115,
			TagGuid: 103,
			TagList: 97,
			TagMap: 109,
			TagClass: 99,
			TagObject: 111,
			TagRef: 114,
			TagPos: 43,
			TagNeg: 45,
			TagSemicolon: 59,
			TagOpenbrace: 123,
			TagClosebrace: 125,
			TagQuote: 34,
			TagPoint: 46,
			TagFunctions: 70,
			TagCall: 67,
			TagResult: 82,
			TagArgument: 65,
			TagError: 69,
			TagEnd: 122
		};
	})(n), (function(e, t) {
		var n = t.WeakMap, r = Object.create(null), i = new n();
		function a(e, t) {
			i.set(e, t), r[t] = e;
		}
		function o(e) {
			return i.get(e);
		}
		function s(e) {
			return r[e];
		}
		e.ClassManager = Object.create(null, {
			register: { value: a },
			getClassAlias: { value: o },
			getClass: { value: s }
		}), e.register = a, a(Object, "Object");
	})(n, n.global), (function(e, t, n) {
		var r = t.Map, i = e.BytesIO, a = e.Tags, o = e.ClassManager;
		function s(e) {
			var t = e.constructor;
			if (!t) return "Object";
			var n = o.getClassAlias(t);
			if (n) return n;
			if (t.name) n = t.name;
			else {
				var r = t.toString();
				if (n = r.substr(0, r.indexOf("(")).replace(/(^\s*function\s*)|(\s*$)/gi, ""), n === "" || n === "Object") return typeof e.getClassName == "function" ? e.getClassName() : "Object";
			}
			return n !== "Object" && o.register(t, n), n;
		}
		var c = Object.create(null, {
			set: { value: function() {} },
			write: { value: function() {
				return !1;
			} },
			reset: { value: function() {} }
		});
		function l(e) {
			Object.defineProperties(this, {
				_stream: { value: e },
				_ref: {
					value: new r(),
					writable: !0
				}
			});
		}
		Object.defineProperties(l.prototype, {
			_refcount: {
				value: 0,
				writable: !0
			},
			set: { value: function(e) {
				this._ref.set(e, this._refcount++);
			} },
			write: { value: function(e) {
				var t = this._ref.get(e);
				return t === n ? !1 : (this._stream.writeByte(a.TagRef), this._stream.writeString("" + t), this._stream.writeByte(a.TagSemicolon), !0);
			} },
			reset: { value: function() {
				this._ref = new r(), this._refcount = 0;
			} }
		});
		function u(e) {
			return new l(e);
		}
		function d(e, t) {
			Object.defineProperties(this, {
				stream: { value: e },
				_classref: {
					value: Object.create(null),
					writable: !0
				},
				_fieldsref: {
					value: [],
					writable: !0
				},
				_refer: { value: t ? c : u(e) }
			});
		}
		function f(e, t) {
			var o = e.stream;
			if (t === n || t === null) {
				o.writeByte(a.TagNull);
				return;
			}
			switch (t.constructor) {
				case Function:
					o.writeByte(a.TagNull);
					return;
				case Number:
					p(e, t);
					return;
				case Boolean:
					g(e, t);
					return;
				case String:
					switch (t.length) {
						case 0:
							o.writeByte(a.TagEmpty);
							return;
						case 1:
							o.writeByte(a.TagUTF8Char), o.writeString(t);
							return;
					}
					e.writeStringWithRef(t);
					return;
				case Date:
					e.writeDateWithRef(t);
					return;
				case r:
					e.writeMapWithRef(t);
					return;
				case ArrayBuffer:
				case Uint8Array:
				case i:
					e.writeBytesWithRef(t);
					return;
				case Int8Array:
				case Int16Array:
				case Int32Array:
				case Uint16Array:
				case Uint32Array:
					C(e, t);
					return;
				case Float32Array:
				case Float64Array:
					w(e, t);
					return;
				default:
					Array.isArray(t) ? e.writeListWithRef(t) : s(t) === "Object" ? e.writeMapWithRef(t) : e.writeObjectWithRef(t);
					break;
			}
		}
		function p(e, t) {
			var n = e.stream;
			t = t.valueOf(), t === (t | 0) ? 0 <= t && t <= 9 ? n.writeByte(t + 48) : (n.writeByte(a.TagInteger), n.writeAsciiString("" + t), n.writeByte(a.TagSemicolon)) : isNaN(t) ? n.writeByte(a.TagNaN) : isFinite(t) ? (n.writeByte(a.TagDouble), n.writeAsciiString("" + t), n.writeByte(a.TagSemicolon)) : (n.writeByte(a.TagInfinity), n.writeByte(t > 0 ? a.TagPos : a.TagNeg));
		}
		function m(e, t) {
			var n = e.stream;
			0 <= t && t <= 9 ? n.writeByte(t + 48) : (t < -2147483648 || t > 2147483647 ? n.writeByte(a.TagLong) : n.writeByte(a.TagInteger), n.writeAsciiString("" + t), n.writeByte(a.TagSemicolon));
		}
		function h(e, t) {
			var n = e.stream;
			isNaN(t) ? n.writeByte(a.TagNaN) : isFinite(t) ? (n.writeByte(a.TagDouble), n.writeAsciiString("" + t), n.writeByte(a.TagSemicolon)) : (n.writeByte(a.TagInfinity), n.writeByte(t > 0 ? a.TagPos : a.TagNeg));
		}
		function g(e, t) {
			e.stream.writeByte(t.valueOf() ? a.TagTrue : a.TagFalse);
		}
		function _(e, t) {
			e._refer.set(t);
			var n = e.stream, r = ("0000" + t.getUTCFullYear()).slice(-4), i = ("00" + (t.getUTCMonth() + 1)).slice(-2), o = ("00" + t.getUTCDate()).slice(-2), s = ("00" + t.getUTCHours()).slice(-2), c = ("00" + t.getUTCMinutes()).slice(-2), l = ("00" + t.getUTCSeconds()).slice(-2), u = ("000" + t.getUTCMilliseconds()).slice(-3);
			n.writeByte(a.TagDate), n.writeAsciiString(r + i + o), n.writeByte(a.TagTime), n.writeAsciiString(s + c + l), u !== "000" && (n.writeByte(a.TagPoint), n.writeAsciiString(u)), n.writeByte(a.TagUTC);
		}
		function v(e, t) {
			e._refer.set(t);
			var n = e.stream, r = ("0000" + t.getFullYear()).slice(-4), i = ("00" + (t.getMonth() + 1)).slice(-2), o = ("00" + t.getDate()).slice(-2), s = ("00" + t.getHours()).slice(-2), c = ("00" + t.getMinutes()).slice(-2), l = ("00" + t.getSeconds()).slice(-2), u = ("000" + t.getMilliseconds()).slice(-3);
			s === "00" && c === "00" && l === "00" && u === "000" ? (n.writeByte(a.TagDate), n.writeAsciiString(r + i + o)) : r === "1970" && i === "01" && o === "01" ? (n.writeByte(a.TagTime), n.writeAsciiString(s + c + l), u !== "000" && (n.writeByte(a.TagPoint), n.writeAsciiString(u))) : (n.writeByte(a.TagDate), n.writeAsciiString(r + i + o), n.writeByte(a.TagTime), n.writeAsciiString(s + c + l), u !== "000" && (n.writeByte(a.TagPoint), n.writeAsciiString(u))), n.writeByte(a.TagSemicolon);
		}
		function y(e, t) {
			e._refer.set(t);
			var n = e.stream, r = ("00" + t.getHours()).slice(-2), i = ("00" + t.getMinutes()).slice(-2), o = ("00" + t.getSeconds()).slice(-2), s = ("000" + t.getMilliseconds()).slice(-3);
			n.writeByte(a.TagTime), n.writeAsciiString(r + i + o), s !== "000" && (n.writeByte(a.TagPoint), n.writeAsciiString(s)), n.writeByte(a.TagSemicolon);
		}
		function b(e, t) {
			e._refer.set(t);
			var n = e.stream;
			n.writeByte(a.TagBytes);
			var r = t.byteLength || t.length;
			r > 0 ? (n.writeAsciiString("" + r), n.writeByte(a.TagQuote), n.write(t)) : n.writeByte(a.TagQuote), n.writeByte(a.TagQuote);
		}
		function x(e, t) {
			e._refer.set(t);
			var n = e.stream, r = t.length;
			n.writeByte(a.TagString), r > 0 ? (n.writeAsciiString("" + r), n.writeByte(a.TagQuote), n.writeString(t)) : n.writeByte(a.TagQuote), n.writeByte(a.TagQuote);
		}
		function S(e, t, n) {
			e._refer.set(t);
			var r = e.stream, i = t.length;
			if (r.writeByte(a.TagList), i > 0) {
				r.writeAsciiString("" + i), r.writeByte(a.TagOpenbrace);
				for (var o = 0; o < i; o++) n(e, t[o]);
			} else r.writeByte(a.TagOpenbrace);
			r.writeByte(a.TagClosebrace);
		}
		function C(e, t) {
			e._refer.write(t) || S(e, t, m);
		}
		function w(e, t) {
			e._refer.write(t) || S(e, t, h);
		}
		function T(e, t) {
			e._refer.set(t);
			var n = e.stream, r = [];
			for (var i in t) t.hasOwnProperty(i) && typeof t[i] != "function" && (r[r.length] = i);
			var o = r.length;
			if (n.writeByte(a.TagMap), o > 0) {
				n.writeAsciiString("" + o), n.writeByte(a.TagOpenbrace);
				for (var s = 0; s < o; s++) f(e, r[s]), f(e, t[r[s]]);
			} else n.writeByte(a.TagOpenbrace);
			n.writeByte(a.TagClosebrace);
		}
		function E(e, t) {
			e._refer.set(t);
			var n = e.stream, r = t.size;
			n.writeByte(a.TagMap), r > 0 ? (n.writeAsciiString("" + r), n.writeByte(a.TagOpenbrace), t.forEach(function(t, n) {
				f(e, n), f(e, t);
			})) : n.writeByte(a.TagOpenbrace), n.writeByte(a.TagClosebrace);
		}
		function D(e, t) {
			var n = e.stream, r = s(t), i, o;
			if (r in e._classref) o = e._classref[r], i = e._fieldsref[o];
			else {
				for (var c in i = [], t) t.hasOwnProperty(c) && typeof t[c] != "function" && (i[i.length] = c.toString());
				o = ee(e, r, i);
			}
			n.writeByte(a.TagObject), n.writeAsciiString("" + o), n.writeByte(a.TagOpenbrace), e._refer.set(t);
			for (var l = i.length, u = 0; u < l; u++) f(e, t[i[u]]);
			n.writeByte(a.TagClosebrace);
		}
		function ee(e, t, n) {
			var r = e.stream, i = n.length;
			if (r.writeByte(a.TagClass), r.writeAsciiString("" + t.length), r.writeByte(a.TagQuote), r.writeString(t), r.writeByte(a.TagQuote), i > 0) {
				r.writeAsciiString("" + i), r.writeByte(a.TagOpenbrace);
				for (var o = 0; o < i; o++) x(e, n[o]);
			} else r.writeByte(a.TagOpenbrace);
			r.writeByte(a.TagClosebrace);
			var s = e._fieldsref.length;
			return e._classref[t] = s, e._fieldsref[s] = n, s;
		}
		Object.defineProperties(d.prototype, {
			serialize: { value: function(e) {
				f(this, e);
			} },
			writeInteger: { value: function(e) {
				m(this, e);
			} },
			writeDouble: { value: function(e) {
				h(this, e);
			} },
			writeBoolean: { value: function(e) {
				g(this, e);
			} },
			writeUTCDate: { value: function(e) {
				_(this, e);
			} },
			writeUTCDateWithRef: { value: function(e) {
				this._refer.write(e) || _(this, e);
			} },
			writeDate: { value: function(e) {
				v(this, e);
			} },
			writeDateWithRef: { value: function(e) {
				this._refer.write(e) || v(this, e);
			} },
			writeTime: { value: function(e) {
				y(this, e);
			} },
			writeTimeWithRef: { value: function(e) {
				this._refer.write(e) || y(this, e);
			} },
			writeBytes: { value: function(e) {
				b(this, e);
			} },
			writeBytesWithRef: { value: function(e) {
				this._refer.write(e) || b(this, e);
			} },
			writeString: { value: function(e) {
				x(this, e);
			} },
			writeStringWithRef: { value: function(e) {
				this._refer.write(e) || x(this, e);
			} },
			writeList: { value: function(e) {
				S(this, e, f);
			} },
			writeListWithRef: { value: function(e) {
				this._refer.write(e) || S(this, e, f);
			} },
			writeMap: { value: function(e) {
				e instanceof r ? E(this, e) : T(this, e);
			} },
			writeMapWithRef: { value: function(e) {
				this._refer.write(e) || (e instanceof r ? E(this, e) : T(this, e));
			} },
			writeObject: { value: function(e) {
				D(this, e);
			} },
			writeObjectWithRef: { value: function(e) {
				this._refer.write(e) || D(this, e);
			} },
			reset: { value: function() {
				this._classref = Object.create(null), this._fieldsref.length = 0, this._refer.reset();
			} }
		}), e.Writer = d;
	})(n, n.global), (function(e, t, n) {
		var r = t.Map, i = e.BytesIO, a = e.Tags, o = e.ClassManager;
		function s(e, t) {
			if (e && t) {
				var n = "";
				throw n = typeof t == "number" ? String.fromCharCode(t) : String.fromCharCode.apply(String, t), Error("Tag \"" + n + "\" expected, but \"" + String.fromCharCode(e) + "\" found in stream");
			} else if (e) throw Error("Unexpected serialize tag \"" + String.fromCharCode(e) + "\" in stream");
			else throw Error("No byte found in stream");
		}
		function c(e) {
			var t = new i();
			return l(e, t), t.bytes;
		}
		function l(e, t) {
			u(e, t, e.readByte());
		}
		function u(e, t, n) {
			switch (t.writeByte(n), n) {
				case 48:
				case 49:
				case 50:
				case 51:
				case 52:
				case 53:
				case 54:
				case 55:
				case 56:
				case 57:
				case a.TagNull:
				case a.TagEmpty:
				case a.TagTrue:
				case a.TagFalse:
				case a.TagNaN: break;
				case a.TagInfinity:
					t.writeByte(e.readByte());
					break;
				case a.TagInteger:
				case a.TagLong:
				case a.TagDouble:
				case a.TagRef:
					d(e, t);
					break;
				case a.TagDate:
				case a.TagTime:
					f(e, t);
					break;
				case a.TagUTF8Char:
					p(e, t);
					break;
				case a.TagBytes:
					m(e, t);
					break;
				case a.TagString:
					h(e, t);
					break;
				case a.TagGuid:
					g(e, t);
					break;
				case a.TagList:
				case a.TagMap:
				case a.TagObject:
					_(e, t);
					break;
				case a.TagClass:
					_(e, t), l(e, t);
					break;
				case a.TagError:
					l(e, t);
					break;
				default: s(n);
			}
		}
		function d(e, t) {
			var n;
			do
				n = e.readByte(), t.writeByte(n);
			while (n !== a.TagSemicolon);
		}
		function f(e, t) {
			var n;
			do
				n = e.readByte(), t.writeByte(n);
			while (n !== a.TagSemicolon && n !== a.TagUTC);
		}
		function p(e, t) {
			t.writeString(e.readString(1));
		}
		function m(e, t) {
			var n = 0, r = 48;
			do
				n *= 10, n += r - 48, r = e.readByte(), t.writeByte(r);
			while (r !== a.TagQuote);
			t.write(e.read(n + 1));
		}
		function h(e, t) {
			var n = 0, r = 48;
			do
				n *= 10, n += r - 48, r = e.readByte(), t.writeByte(r);
			while (r !== a.TagQuote);
			t.write(e.readStringAsBytes(n + 1));
		}
		function g(e, t) {
			t.write(e.read(38));
		}
		function _(e, t) {
			var n;
			do
				n = e.readByte(), t.writeByte(n);
			while (n !== a.TagOpenbrace);
			for (; (n = e.readByte()) !== a.TagClosebrace;) u(e, t, n);
			t.writeByte(n);
		}
		function v(e) {
			Object.defineProperties(this, {
				stream: { value: e },
				readRaw: { value: function() {
					return c(e);
				} }
			});
		}
		e.RawReader = v;
		var y = Object.create(null, {
			set: { value: function() {} },
			read: { value: function() {
				s(a.TagRef);
			} },
			reset: { value: function() {} }
		});
		function b() {
			Object.defineProperties(this, { ref: { value: [] } });
		}
		Object.defineProperties(b.prototype, {
			set: { value: function(e) {
				this.ref.push(e);
			} },
			read: { value: function(e) {
				return this.ref[e];
			} },
			reset: { value: function() {
				this.ref.length = 0;
			} }
		});
		function x() {
			return new b();
		}
		function S(e) {
			var r = t, i = e.split("."), a;
			for (a = 0; a < i.length; a++) if (r = r[i[a]], r === n) return null;
			return r;
		}
		function C(e, t, n, r) {
			if (n < t.length) {
				var i = t[n];
				e[i] = r;
				var a = C(e, t, n + 1, ".");
				return n + 1 < t.length && a === null && (a = C(e, t, n + 1, "_")), a;
			}
			var o = e.join("");
			try {
				var s = S(o);
				return typeof s == "function" ? s : null;
			} catch {
				return null;
			}
		}
		function w(e) {
			var t = o.getClass(e);
			if (t) return t;
			if (t = S(e), typeof t == "function") return o.register(t, e), t;
			for (var n = [], r = e.indexOf("_"); r >= 0;) n[n.length] = r, r = e.indexOf("_", r + 1);
			if (n.length > 0) {
				var i = e.split("");
				if (t = C(i, n, 0, "."), t === null && (t = C(i, n, 0, "_")), typeof t == "function") return o.register(t, e), t;
			}
			return t = function() {}, Object.defineProperty(t.prototype, "getClassName", { value: function() {
				return e;
			} }), o.register(t, e), t;
		}
		function T(e, t) {
			var n = e.readUntil(t);
			return n.length === 0 ? 0 : parseInt(n, 10);
		}
		function E(e) {
			var t = e.stream, n = t.readByte();
			switch (n) {
				case 48:
				case 49:
				case 50:
				case 51:
				case 52:
				case 53:
				case 54:
				case 55:
				case 56:
				case 57: return n - 48;
				case a.TagInteger: return D(t);
				case a.TagLong: return te(t);
				case a.TagDouble: return re(t);
				case a.TagNull: return null;
				case a.TagEmpty: return "";
				case a.TagTrue: return !0;
				case a.TagFalse: return !1;
				case a.TagNaN: return NaN;
				case a.TagInfinity: return ae(t);
				case a.TagDate: return O(e);
				case a.TagTime: return k(e);
				case a.TagBytes: return A(e);
				case a.TagUTF8Char: return le(e);
				case a.TagString: return N(e);
				case a.TagGuid: return P(e);
				case a.TagList: return fe(e);
				case a.TagMap: return e.useHarmonyMap ? he(e) : me(e);
				case a.TagClass: return ve(e), I(e);
				case a.TagObject: return _e(e);
				case a.TagRef: return ye(e);
				case a.TagError: throw Error(ue(e));
				default: s(n);
			}
		}
		function D(e) {
			return T(e, a.TagSemicolon);
		}
		function ee(e) {
			var t = e.readByte();
			switch (t) {
				case 48:
				case 49:
				case 50:
				case 51:
				case 52:
				case 53:
				case 54:
				case 55:
				case 56:
				case 57: return t - 48;
				case a.TagInteger: return D(e);
				default: s(t);
			}
		}
		function te(e) {
			var t = e.readUntil(a.TagSemicolon), n = parseInt(t, 10);
			return n.toString() === t ? n : t;
		}
		function ne(e) {
			var t = e.readByte();
			switch (t) {
				case 48:
				case 49:
				case 50:
				case 51:
				case 52:
				case 53:
				case 54:
				case 55:
				case 56:
				case 57: return t - 48;
				case a.TagInteger:
				case a.TagLong: return te(e);
				default: s(t);
			}
		}
		function re(e) {
			return parseFloat(e.readUntil(a.TagSemicolon));
		}
		function ie(e) {
			var t = e.readByte();
			switch (t) {
				case 48:
				case 49:
				case 50:
				case 51:
				case 52:
				case 53:
				case 54:
				case 55:
				case 56:
				case 57: return t - 48;
				case a.TagInteger:
				case a.TagLong:
				case a.TagDouble: return re(e);
				case a.TagNaN: return NaN;
				case a.TagInfinity: return ae(e);
				default: s(t);
			}
		}
		function ae(e) {
			return e.readByte() === a.TagNeg ? -Infinity : Infinity;
		}
		function oe(e) {
			var t = e.readByte();
			switch (t) {
				case a.TagTrue: return !0;
				case a.TagFalse: return !1;
				default: s(t);
			}
		}
		function O(e) {
			var t = e.stream, n = parseInt(t.readAsciiString(4), 10), r = parseInt(t.readAsciiString(2), 10) - 1, i = parseInt(t.readAsciiString(2), 10), o, s = t.readByte();
			if (s === a.TagTime) {
				var c = parseInt(t.readAsciiString(2), 10), l = parseInt(t.readAsciiString(2), 10), u = parseInt(t.readAsciiString(2), 10), d = 0;
				s = t.readByte(), s === a.TagPoint && (d = parseInt(t.readAsciiString(3), 10), s = t.readByte(), s >= 48 && s <= 57 && (t.skip(2), s = t.readByte(), s >= 48 && s <= 57 && (t.skip(2), s = t.readByte()))), o = s === a.TagUTC ? new Date(Date.UTC(n, r, i, c, l, u, d)) : new Date(n, r, i, c, l, u, d);
			} else o = s === a.TagUTC ? new Date(Date.UTC(n, r, i)) : new Date(n, r, i);
			return e.refer.set(o), o;
		}
		function se(e) {
			var t = e.stream.readByte();
			switch (t) {
				case a.TagNull: return null;
				case a.TagDate: return O(e);
				case a.TagRef: return ye(e);
				default: s(t);
			}
		}
		function k(e) {
			var t = e.stream, n, r = parseInt(t.readAsciiString(2), 10), i = parseInt(t.readAsciiString(2), 10), o = parseInt(t.readAsciiString(2), 10), s = 0, c = t.readByte();
			return c === a.TagPoint && (s = parseInt(t.readAsciiString(3), 10), c = t.readByte(), c >= 48 && c <= 57 && (t.skip(2), c = t.readByte(), c >= 48 && c <= 57 && (t.skip(2), c = t.readByte()))), n = c === a.TagUTC ? new Date(Date.UTC(1970, 0, 1, r, i, o, s)) : new Date(1970, 0, 1, r, i, o, s), e.refer.set(n), n;
		}
		function ce(e) {
			var t = e.stream.readByte();
			switch (t) {
				case a.TagNull: return null;
				case a.TagTime: return k(e);
				case a.TagRef: return ye(e);
				default: s(t);
			}
		}
		function A(e) {
			var t = e.stream, n = T(t, a.TagQuote), r = t.read(n);
			return t.skip(1), e.refer.set(r), r;
		}
		function j(e) {
			var t = e.stream.readByte();
			switch (t) {
				case a.TagNull: return null;
				case a.TagEmpty: return new Uint8Array();
				case a.TagBytes: return A(e);
				case a.TagRef: return ye(e);
				default: s(t);
			}
		}
		function le(e) {
			return e.stream.readString(1);
		}
		function M(e) {
			var t = e.stream, n = t.readString(T(t, a.TagQuote));
			return t.skip(1), n;
		}
		function N(e) {
			var t = M(e);
			return e.refer.set(t), t;
		}
		function ue(e) {
			var t = e.stream.readByte();
			switch (t) {
				case a.TagNull: return null;
				case a.TagEmpty: return "";
				case a.TagUTF8Char: return le(e);
				case a.TagString: return N(e);
				case a.TagRef: return ye(e);
				default: s(t);
			}
		}
		function P(e) {
			var t = e.stream;
			t.skip(1);
			var n = t.readAsciiString(36);
			return t.skip(1), e.refer.set(n), n;
		}
		function de(e) {
			var t = e.stream.readByte();
			switch (t) {
				case a.TagNull: return null;
				case a.TagGuid: return P(e);
				case a.TagRef: return ye(e);
				default: s(t);
			}
		}
		function fe(e) {
			var t = e.stream, n = [];
			e.refer.set(n);
			for (var r = T(t, a.TagOpenbrace), i = 0; i < r; i++) n[i] = E(e);
			return t.skip(1), n;
		}
		function pe(e) {
			var t = e.stream.readByte();
			switch (t) {
				case a.TagNull: return null;
				case a.TagList: return fe(e);
				case a.TagRef: return ye(e);
				default: s(t);
			}
		}
		function me(e) {
			var t = e.stream, n = {};
			e.refer.set(n);
			for (var r = T(t, a.TagOpenbrace), i = 0; i < r; i++) {
				var o = E(e);
				n[o] = E(e);
			}
			return t.skip(1), n;
		}
		function F(e) {
			var t = e.stream.readByte();
			switch (t) {
				case a.TagNull: return null;
				case a.TagMap: return me(e);
				case a.TagRef: return ye(e);
				default: s(t);
			}
		}
		function he(e) {
			var t = e.stream, n = new r();
			e.refer.set(n);
			for (var i = T(t, a.TagOpenbrace), o = 0; o < i; o++) {
				var s = E(e), c = E(e);
				n.set(s, c);
			}
			return t.skip(1), n;
		}
		function ge(e) {
			var t = e.stream.readByte();
			switch (t) {
				case a.TagNull: return null;
				case a.TagMap: return he(e);
				case a.TagRef: return ye(e);
				default: s(t);
			}
		}
		function _e(e) {
			var t = e.stream, n = e.classref[T(t, a.TagOpenbrace)], r = new n.classname();
			e.refer.set(r);
			for (var i = 0; i < n.count; i++) r[n.fields[i]] = E(e);
			return t.skip(1), r;
		}
		function I(e) {
			var t = e.stream.readByte();
			switch (t) {
				case a.TagNull: return null;
				case a.TagClass: return ve(e), I(e);
				case a.TagObject: return _e(e);
				case a.TagRef: return ye(e);
				default: s(t);
			}
		}
		function ve(e) {
			for (var t = e.stream, n = M(e), r = T(t, a.TagOpenbrace), i = [], o = 0; o < r; o++) i[o] = ue(e);
			t.skip(1), n = w(n), e.classref.push({
				classname: n,
				count: r,
				fields: i
			});
		}
		function ye(e) {
			return e.refer.read(T(e.stream, a.TagSemicolon));
		}
		function be(e, t, n) {
			v.call(this, e), this.useHarmonyMap = !!n, Object.defineProperties(this, {
				classref: { value: [] },
				refer: { value: t ? y : x() }
			});
		}
		be.prototype = Object.create(v.prototype), be.prototype.constructor = be, Object.defineProperties(be.prototype, {
			useHarmonyMap: {
				value: !1,
				writable: !0
			},
			checkTag: { value: function(e, t) {
				t === n && (t = this.stream.readByte()), t !== e && s(t, e);
			} },
			checkTags: { value: function(e, t) {
				if (t === n && (t = this.stream.readByte()), e.indexOf(t) >= 0) return t;
				s(t, e);
			} },
			unserialize: { value: function() {
				return E(this);
			} },
			readInteger: { value: function() {
				return ee(this.stream);
			} },
			readLong: { value: function() {
				return ne(this.stream);
			} },
			readDouble: { value: function() {
				return ie(this.stream);
			} },
			readBoolean: { value: function() {
				return oe(this.stream);
			} },
			readDateWithoutTag: { value: function() {
				return O(this);
			} },
			readDate: { value: function() {
				return se(this);
			} },
			readTimeWithoutTag: { value: function() {
				return k(this);
			} },
			readTime: { value: function() {
				return ce(this);
			} },
			readBytesWithoutTag: { value: function() {
				return A(this);
			} },
			readBytes: { value: function() {
				return j(this);
			} },
			readStringWithoutTag: { value: function() {
				return N(this);
			} },
			readString: { value: function() {
				return ue(this);
			} },
			readGuidWithoutTag: { value: function() {
				return P(this);
			} },
			readGuid: { value: function() {
				return de(this);
			} },
			readListWithoutTag: { value: function() {
				return fe(this);
			} },
			readList: { value: function() {
				return pe(this);
			} },
			readMapWithoutTag: { value: function() {
				return this.useHarmonyMap ? he(this) : me(this);
			} },
			readMap: { value: function() {
				return this.useHarmonyMap ? ge(this) : F(this);
			} },
			readObjectWithoutTag: { value: function() {
				return _e(this);
			} },
			readObject: { value: function() {
				return I(this);
			} },
			reset: { value: function() {
				this.classref.length = 0, this.refer.reset();
			} }
		}), e.Reader = be;
	})(n, n.global), (function(e) {
		var t = e.BytesIO, n = e.Writer, r = e.Reader;
		function i(e, r) {
			var i = new t();
			return new n(i, r).serialize(e), i;
		}
		function a(e, n, i) {
			return e instanceof t || (e = new t(e)), new r(e, n, i).unserialize();
		}
		e.Formatter = {
			serialize: function(e, t) {
				return i(e, t).bytes;
			},
			unserialize: a
		}, e.serialize = i, e.unserialize = a;
	})(n), (function(e) {
		e.ResultMode = {
			Normal: 0,
			Serialized: 1,
			Raw: 2,
			RawWithEndTag: 3
		}, e.Normal = e.ResultMode.Normal, e.Serialized = e.ResultMode.Serialized, e.Raw = e.ResultMode.Raw, e.RawWithEndTag = e.ResultMode.RawWithEndTag;
	})(n), (function(e, t, n) {
		var r = t.setImmediate, i = e.Tags, a = e.ResultMode, o = e.BytesIO, s = e.Writer, c = e.Reader, l = e.Future, u = e.parseuri, d = e.isObjectEmpty, f = new Uint8Array(1);
		f[0] = i.TagEnd;
		function p() {}
		var m = "boolean", h = "string", g = "number", _ = "function", v = "object";
		function y(e, t) {
			var r = {};
			this.get = function(i, a) {
				var o = a.toString();
				if (t && (o = t + "_" + o), o === "then") return n;
				if (!i.hasOwnProperty(o)) {
					r[o] = {};
					var s = new y(e, o), c = e(r, o);
					s.apply = function(e, t, n) {
						return c.apply(null, n);
					}, s.set = function(e, t, n) {
						return r[o][t] = n, !0;
					}, i[o] = new Proxy(function() {}, s);
				}
				return i[o];
			};
		}
		function b(e, t, u) {
			var b, x = [], S = -1, C = !1, w = !1, T = 3e4, E = 10, D = !1, ee = !1, te = 0, ne = !1, re = [], ie = !1, ae = p, oe = p, O = [], se = !1, k = [], ce = new l(), A = Object.create(null), j = null, le = !0, M = Ae, N = Fe, ue = _e, P = I, de = [], fe = [], pe = [], me = [], F = this;
			function he(e, t) {
				for (var n = 0, r = O.length; n < r; n++) e = O[n].outputFilter(e, t);
				return e;
			}
			function ge(e, t) {
				for (var n = O.length - 1; n >= 0; n--) e = O[n].inputFilter(e, t);
				return e;
			}
			function _e(e, t) {
				return e = he(e, t), P(e, t).then(function(e) {
					if (!t.oneway) return ge(e, t);
				});
			}
			function I(e, t) {
				return F.sendAndReceive(e, t).catchError(function(n) {
					var r = be(e, t);
					if (r !== null) return r;
					throw n;
				});
			}
			function ve(e, t, n, r) {
				ue(e, t).then(n, r);
			}
			function ye() {
				var e = x.length;
				if (e > 1) {
					var t = S + 1;
					t >= e && (t = 0, te++), S = t, b = x[S];
				} else te++;
				oe(F);
			}
			function be(e, t) {
				if (t.failswitch && ye(), t.idempotent && t.retried < t.retry) {
					var n = ++t.retried * 500;
					return t.failswitch && (n -= (x.length - 1) * 500), n > 5e3 && (n = 5e3), n > 0 ? l.delayed(n, function() {
						return I(e, t);
					}) : I(e, t);
				}
				return null;
			}
			function xe(e) {
				var t = [Object.create(null)];
				for (var r in e) {
					var i = e[r].split("_"), a = i.length - 1;
					if (a > 0) {
						for (var o = t, s = 0; s < a; s++) {
							var c = i[s];
							o[0][c] === n && (o[0][c] = [Object.create(null)]), o = o[0][c];
						}
						o.push(i[a]);
					}
					t.push(e[r]);
				}
				return t;
			}
			function Se(e) {
				ve(f, {
					retry: E,
					retried: 0,
					idempotent: !0,
					failswitch: !0,
					timeout: T,
					client: F,
					userdata: {}
				}, function(t) {
					var n = null;
					try {
						var r = new o(t), a = new c(r, !0);
						switch (r.readByte()) {
							case i.TagError:
								n = Error(a.readString());
								break;
							case i.TagFunctions:
								var s = xe(a.readList());
								a.checkTag(i.TagEnd), L(e, s);
								break;
							default:
								n = /* @__PURE__ */ Error("Wrong Response:\r\n" + o.toString(t));
								break;
						}
					} catch (e) {
						n = e;
					}
					n === null ? ce.resolve(e) : ce.reject(n);
				}, ce.reject);
			}
			function Ce(e, t) {
				return function() {
					return se ? z(e, t, Array.slice(arguments), !0) : l.all(arguments).then(function(n) {
						return z(e, t, n, !1);
					});
				};
			}
			function we(e, t, r, i, a) {
				if (t[i] === n && (t[i] = {}, (typeof a === h || a.constructor === Object) && (a = [a]), Array.isArray(a))) for (var o = 0; o < a.length; o++) {
					var s = a[o];
					if (typeof s === h) t[i][s] = Ce(e, r + i + "_" + s);
					else for (var c in s) we(e, t[i], r + i + "_", c, s[c]);
				}
			}
			function L(e, t) {
				for (var r = 0; r < t.length; r++) {
					var i = t[r];
					if (typeof i === h) e[i] === n && (e[i] = Ce(e, i));
					else for (var a in i) we(e, e, "", a, i[a]);
				}
			}
			function Te(e, t) {
				for (var n = Math.min(e.length, t.length), r = 0; r < n; ++r) t[r] = e[r];
			}
			function Ee(e) {
				return e ? {
					mode: a.Normal,
					byref: C,
					simple: w,
					onsuccess: n,
					onerror: n,
					useHarmonyMap: ie,
					client: F,
					userdata: {}
				} : {
					mode: a.Normal,
					byref: C,
					simple: w,
					timeout: T,
					retry: E,
					retried: 0,
					idempotent: D,
					failswitch: ee,
					oneway: !1,
					sync: !1,
					onsuccess: n,
					onerror: n,
					useHarmonyMap: ie,
					client: F,
					userdata: {}
				};
			}
			function R(e, t, n, r) {
				var i = Ee(r);
				if (t in e) {
					var a = e[t];
					for (var o in a) o in i && (i[o] = a[o]);
				}
				for (var s = 0, c = n.length; s < c && typeof n[s] !== _; ++s);
				if (s === c) return i;
				var l = n.splice(s, c - s);
				for (i.onsuccess = l[0], c = l.length, s = 1; s < c; ++s) {
					var u = l[s];
					switch (typeof u) {
						case _:
							i.onerror = u;
							break;
						case m:
							i.byref = u;
							break;
						case g:
							i.mode = u;
							break;
						case v:
							for (var d in u) d in i && (i[d] = u[d]);
							break;
					}
				}
				return i;
			}
			function De(e, t, n) {
				var r = new o();
				r.writeByte(i.TagCall);
				var a = new s(r, n.simple);
				return a.writeString(e), (t.length > 0 || n.byref) && (a.reset(), a.writeList(t), n.byref && a.writeBoolean(!0)), r;
			}
			function Oe(e, t, n, r) {
				return ne ? l.promise(function(i, a) {
					re.push({
						batch: r,
						name: e,
						args: t,
						context: n,
						resolve: i,
						reject: a
					});
				}) : r ? Ne(e, t, n) : Me(e, t, n);
			}
			function z(e, t, n, r) {
				return Oe(t, n, R(e, t, n, r), r);
			}
			function ke(e, t, n, r) {
				try {
					n.onerror ? n.onerror(e, t) : ae(e, t), r(t);
				} catch (e) {
					r(e);
				}
			}
			function Ae(e, t, n) {
				var r = De(e, t, n);
				return r.writeByte(i.TagEnd), l.promise(function(e, s) {
					ve(r.bytes, n, function(r) {
						if (n.oneway) {
							e();
							return;
						}
						var l = null, u = null;
						try {
							if (n.mode === a.RawWithEndTag) l = r;
							else if (n.mode === a.Raw) l = r.subarray(0, r.byteLength - 1);
							else {
								var d = new o(r), f = new c(d, !1, n.useHarmonyMap), p = d.readByte();
								p === i.TagResult ? (l = n.mode === a.Serialized ? f.readRaw() : f.unserialize(), p = d.readByte(), p === i.TagArgument && (f.reset(), Te(f.readList(), t), p = d.readByte())) : p === i.TagError && (u = Error(f.readString()), p = d.readByte()), p !== i.TagEnd && (u = /* @__PURE__ */ Error("Wrong Response:\r\n" + o.toString(r)));
							}
						} catch (e) {
							u = e;
						}
						u ? s(u) : e(l);
					}, s);
				});
			}
			function je(e) {
				return function() {
					e && (ne = !1, r(function(e) {
						e.forEach(function(e) {
							"settings" in e ? Le(e.settings).then(e.resolve, e.reject) : Oe(e.name, e.args, e.context, e.batch).then(e.resolve, e.reject);
						});
					}, re), re = []);
				};
			}
			function Me(e, t, n) {
				n.sync && (ne = !0);
				var r = l.promise(function(r, i) {
					M(e, t, n).then(function(a) {
						try {
							if (n.onsuccess) try {
								n.onsuccess(a, t);
							} catch (t) {
								n.onerror && n.onerror(e, t), i(t);
							}
							r(a);
						} catch (e) {
							i(e);
						}
					}, function(t) {
						ke(e, t, n, i);
					});
				});
				return r.whenComplete(je(n.sync)), r;
			}
			function Ne(e, t, n) {
				return l.promise(function(r, i) {
					k.push({
						args: t,
						name: e,
						context: n,
						resolve: r,
						reject: i
					});
				});
			}
			function Pe(e) {
				var t = {
					timeout: T,
					retry: E,
					retried: 0,
					idempotent: D,
					failswitch: ee,
					oneway: !1,
					sync: !1,
					client: F,
					userdata: {}
				};
				for (var n in e) n in t && (t[n] = e[n]);
				return t;
			}
			function Fe(e, t) {
				var n = e.reduce(function(e, t) {
					return e.write(De(t.name, t.args, t.context)), e;
				}, new o());
				return n.writeByte(i.TagEnd), l.promise(function(r, s) {
					ve(n.bytes, t, function(n) {
						if (t.oneway) {
							r(e);
							return;
						}
						var l = -1, u = new o(n), d = new c(u, !1), f = u.readByte();
						try {
							for (; f !== i.TagEnd;) {
								var p = null, m = null, h = e[++l].context.mode;
								if (h >= a.Raw && (p = new o()), f === i.TagResult ? (h === a.Serialized ? p = d.readRaw() : h >= a.Raw ? (p.writeByte(i.TagResult), p.write(d.readRaw())) : (d.useHarmonyMap = e[l].context.useHarmonyMap, d.reset(), p = d.unserialize()), f = u.readByte(), f === i.TagArgument && (h >= a.Raw ? (p.writeByte(i.TagArgument), p.write(d.readRaw())) : (d.reset(), Te(d.readList(), e[l].args)), f = u.readByte())) : f === i.TagError && (h >= a.Raw ? (p.writeByte(i.TagError), p.write(d.readRaw())) : (d.reset(), m = Error(d.readString())), f = u.readByte()), [
									i.TagEnd,
									i.TagResult,
									i.TagError
								].indexOf(f) < 0) {
									s(/* @__PURE__ */ Error("Wrong Response:\r\n" + o.toString(n)));
									return;
								}
								h >= a.Raw ? (h === a.RawWithEndTag && p.writeByte(i.TagEnd), e[l].result = p.bytes) : e[l].result = p, e[l].error = m;
							}
						} catch (e) {
							s(e);
							return;
						}
						r(e);
					}, s);
				});
			}
			function Ie() {
				se = !0;
			}
			function Le(e) {
				if (e ||= {}, se = !1, ne) return l.promise(function(t, n) {
					re.push({
						batch: !0,
						settings: e,
						resolve: t,
						reject: n
					});
				});
				if (k.length === 0) return l.value([]);
				var t = Pe(e);
				t.sync && (ne = !0);
				var n = k;
				k = [];
				var r = l.promise(function(e, r) {
					N(n, t).then(function(t) {
						t.forEach(function(e) {
							if (e.error) ke(e.name, e.error, e.context, e.reject);
							else try {
								if (e.context.onsuccess) try {
									e.context.onsuccess(e.result, e.args);
								} catch (t) {
									e.context.onerror && e.context.onerror(e.name, t), e.reject(t);
								}
								e.resolve(e.result);
							} catch (t) {
								e.reject(t);
							}
							delete e.context, delete e.resolve, delete e.reject;
						}), e(t);
					}, function(e) {
						n.forEach(function(t) {
							"reject" in t && ke(t.name, e, t.context, t.reject);
						}), r(e);
					});
				});
				return r.whenComplete(je(t.sync)), r;
			}
			function Re() {
				return ae;
			}
			function ze(e) {
				typeof e === _ && (ae = e);
			}
			function Be() {
				return oe;
			}
			function Ve(e) {
				typeof e === _ && (oe = e);
			}
			function He() {
				return b;
			}
			function Ue() {
				return x;
			}
			function We(e) {
				if (typeof e === h) x = [e];
				else if (Array.isArray(e)) x = e.slice(0), x.sort(function() {
					return Math.random() - .5;
				});
				else return;
				S = 0, b = x[S];
			}
			function Ge() {
				return ee;
			}
			function Ke(e) {
				ee = !!e;
			}
			function qe() {
				return te;
			}
			function Je() {
				return T;
			}
			function Ye(e) {
				T = typeof e == "number" ? e | 0 : 0;
			}
			function Xe() {
				return E;
			}
			function Ze(e) {
				E = typeof e == "number" ? e | 0 : 0;
			}
			function Qe() {
				return D;
			}
			function B(e) {
				D = !!e;
			}
			function $e(e) {
				le = !!e;
			}
			function et() {
				return le;
			}
			function tt() {
				return C;
			}
			function nt(e) {
				C = !!e;
			}
			function rt() {
				return w;
			}
			function it(e) {
				w = !!e;
			}
			function at() {
				return ie;
			}
			function ot(e) {
				ie = !!e;
			}
			function st() {
				return O.length === 0 ? null : O.length === 1 ? O[0] : O.slice();
			}
			function ct(e) {
				O.length = 0, Array.isArray(e) ? e.forEach(function(e) {
					lt(e);
				}) : lt(e);
			}
			function lt(e) {
				e && typeof e.inputFilter == "function" && typeof e.outputFilter == "function" && O.push(e);
			}
			function ut(e) {
				var t = O.indexOf(e);
				return t === -1 ? !1 : (O.splice(t, 1), !0);
			}
			function dt() {
				return O;
			}
			function ft(e, t, i) {
				i === n && (typeof t === m && (i = t, t = !1), t || (typeof e === m ? (i = e, e = !1) : (e && e.constructor === Object || Array.isArray(e)) && (t = e, e = !1)));
				var a = F;
				if (i && (a = {}), !e && !b) return /* @__PURE__ */ Error("You should set server uri first!");
				if (e && (b = e), (typeof t === h || t && t.constructor === Object) && (t = [t]), Array.isArray(t)) L(a, t);
				else if (typeof Proxy > "u") return r(Se, a), ce;
				else a = new Proxy({}, new y(Ce));
				return ce.resolve(a), a;
			}
			function pt(e, t, n) {
				var r = arguments.length;
				if (r < 1 || typeof e !== h) throw Error("name must be a string");
				if (r === 1 && (t = []), r === 2 && !Array.isArray(t)) {
					var i = [];
					typeof t !== _ && i.push(p), i.push(t), t = i;
				}
				if (r > 2) {
					typeof n !== _ && t.push(p);
					for (var a = 2; a < r; a++) t.push(arguments[a]);
				}
				return z(F, e, t, se);
			}
			function mt(e, t) {
				return ce.then(e, t);
			}
			function ht(e, t) {
				if (A[e]) {
					var n = A[e];
					if (n[t]) return n[t];
				}
				return null;
			}
			function gt(e, t, r, i, a) {
				if (typeof e !== h) throw TypeError("topic name must be a string.");
				if (t === n || t === null) if (typeof r === _) t = r;
				else throw TypeError("callback must be a function.");
				if (A[e] || (A[e] = Object.create(null)), typeof t === _) {
					i = r, r = t, St().then(function(t) {
						gt(e, t, r, i, a);
					});
					return;
				}
				if (typeof r !== _) throw TypeError("callback must be a function.");
				if (l.isPromise(t)) {
					t.then(function(t) {
						gt(e, t, r, i, a);
					});
					return;
				}
				i === n && (i = 3e5);
				var o = ht(e, t);
				if (o === null) {
					var s = function() {
						z(F, e, [
							t,
							o.handler,
							s,
							{
								idempotent: !0,
								failswitch: a,
								timeout: i
							}
						], !1);
					};
					o = {
						handler: function(n) {
							var r = ht(e, t);
							if (r) {
								if (n !== null) for (var i = r.callbacks, a = 0, o = i.length; a < o; ++a) try {
									i[a](n);
								} catch {}
								ht(e, t) !== null && s();
							}
						},
						callbacks: [r]
					}, A[e][t] = o, s();
				} else o.callbacks.indexOf(r) < 0 && o.callbacks.push(r);
			}
			function _t(e, t, n) {
				if (e) if (typeof n === _) {
					var r = e[t];
					if (r) {
						var i = r.callbacks, a = i.indexOf(n);
						a >= 0 && (i[a] = i[i.length - 1], i.length--), i.length === 0 && delete e[t];
					}
				} else delete e[t];
			}
			function vt(e, t, r) {
				if (typeof e !== h) throw TypeError("topic name must be a string.");
				if (t === n || t === null) if (typeof r === _) t = r;
				else {
					delete A[e];
					return;
				}
				if (typeof t === _ && (r = t, t = null), t === null) if (j === null) {
					if (A[e]) {
						var i = A[e];
						for (t in i) _t(i, t, r);
					}
				} else j.then(function(t) {
					vt(e, t, r);
				});
				else l.isPromise(t) ? t.then(function(t) {
					vt(e, t, r);
				}) : _t(A[e], t, r);
				d(A[e]) && delete A[e];
			}
			function yt(e) {
				return !!A[e];
			}
			function bt() {
				var e = [];
				for (var t in A) e.push(t);
				return e;
			}
			function xt() {
				return j;
			}
			function St() {
				return j === null && (j = z(F, "#", [], !1)), j;
			}
			St.sync = !0, St.idempotent = !0, St.failswitch = !0;
			function Ct(e) {
				de.push(e), M = de.reduceRight(function(e, t) {
					return function(n, r, i) {
						return l.toPromise(t(n, r, i, e));
					};
				}, Ae);
			}
			function wt(e) {
				fe.push(e), N = fe.reduceRight(function(e, t) {
					return function(n, r) {
						return l.toPromise(t(n, r, e));
					};
				}, Fe);
			}
			function Tt(e) {
				pe.push(e), ue = pe.reduceRight(function(e, t) {
					return function(n, r) {
						return l.toPromise(t(n, r, e));
					};
				}, _e);
			}
			function Et(e) {
				me.push(e), P = me.reduceRight(function(e, t) {
					return function(n, r) {
						return l.toPromise(t(n, r, e));
					};
				}, I);
			}
			function Dt(e) {
				return Ct(e), F;
			}
			var V = Object.create(null, {
				begin: { value: Ie },
				end: { value: Le },
				use: { value: function(e) {
					return wt(e), V;
				} }
			}), Ot = Object.create(null, { use: { value: function(e) {
				return Tt(e), Ot;
			} } }), kt = Object.create(null, { use: { value: function(e) {
				return Et(e), kt;
			} } });
			Object.defineProperties(this, {
				"#": { value: St },
				onerror: {
					get: Re,
					set: ze
				},
				onfailswitch: {
					get: Be,
					set: Ve
				},
				uri: { get: He },
				uriList: {
					get: Ue,
					set: We
				},
				id: { get: xt },
				failswitch: {
					get: Ge,
					set: Ke
				},
				failround: { get: qe },
				timeout: {
					get: Je,
					set: Ye
				},
				retry: {
					get: Xe,
					set: Ze
				},
				idempotent: {
					get: Qe,
					set: B
				},
				keepAlive: {
					get: et,
					set: $e
				},
				byref: {
					get: tt,
					set: nt
				},
				simple: {
					get: rt,
					set: it
				},
				useHarmonyMap: {
					get: at,
					set: ot
				},
				filter: {
					get: st,
					set: ct
				},
				addFilter: { value: lt },
				removeFilter: { value: ut },
				filters: { get: dt },
				useService: { value: ft },
				invoke: { value: pt },
				ready: { value: mt },
				subscribe: { value: gt },
				unsubscribe: { value: vt },
				isSubscribed: { value: yt },
				subscribedList: { value: bt },
				use: { value: Dt },
				batch: { value: V },
				beforeFilter: { value: Ot },
				afterFilter: { value: kt }
			}), u && typeof u === v && [
				"failswitch",
				"timeout",
				"retry",
				"idempotent",
				"keepAlive",
				"byref",
				"simple",
				"useHarmonyMap",
				"filter"
			].forEach(function(e) {
				e in u && (F[e] = u[e]);
			}), e && (We(e), ft(t));
		}
		function x(e) {
			var t = u(e).protocol;
			if (!(t === "http:" || t === "https:" || t === "tcp:" || t === "tcp4:" || t === "tcp6:" || t === "tcps:" || t === "tcp4s:" || t === "tcp6s:" || t === "tls:" || t === "ws:" || t === "wss:")) throw Error("The " + t + " client isn't implemented.");
		}
		function S(t, n, r) {
			try {
				return e.HttpClient.create(t, n, r);
			} catch {}
			try {
				return e.TcpClient.create(t, n, r);
			} catch {}
			try {
				return e.WebSocketClient.create(t, n, r);
			} catch {}
			if (typeof t == "string") x(t);
			else if (Array.isArray(t)) throw t.forEach(function(e) {
				x(e);
			}), Error("Not support multiple protocol.");
			throw Error("You should set server uri first!");
		}
		Object.defineProperty(b, "create", { value: S }), e.Client = b;
	})(n, n.global), (function(e) {
		var t = e.parseuri, n = {};
		function r(e, r) {
			var i = t(r).host, a, o;
			function s(e) {
				var t = e.replace(/(^\s*)|(\s*$)/g, "").split(";"), r = {}, a;
				for (e = t[0].replace(/(^\s*)|(\s*$)/g, "").split("=", 2), e[1] === void 0 && (e[1] = null), r.name = e[0], r.value = e[1], a = 1; a < t.length; a++) e = t[a].replace(/(^\s*)|(\s*$)/g, "").split("=", 2), e[1] === void 0 && (e[1] = null), r[e[0].toUpperCase()] = e[1];
				r.PATH ? (r.PATH.charAt(0) === "\"" && (r.PATH = r.PATH.substr(1)), r.PATH.charAt(r.PATH.length - 1) === "\"" && (r.PATH = r.PATH.substr(0, r.PATH.length - 1))) : r.PATH = "/", r.EXPIRES &&= Date.parse(r.EXPIRES), r.DOMAIN ? r.DOMAIN = r.DOMAIN.toLowerCase() : r.DOMAIN = i, r.SECURE = r.SECURE !== void 0, n[r.DOMAIN] === void 0 && (n[r.DOMAIN] = {}), n[r.DOMAIN][r.name] = r;
			}
			for (a in e) o = e[a], a = a.toLowerCase(), (a === "set-cookie" || a === "set-cookie2") && (typeof o == "string" && (o = [o]), o.forEach(s));
		}
		function i(e) {
			var r = t(e), i = r.host, a = r.path, o = r.protocol === "https:", s = [];
			for (var c in n) if (i.indexOf(c) > -1) {
				var l = [];
				for (var u in n[c]) {
					var d = n[c][u];
					d.EXPIRES && (/* @__PURE__ */ new Date()).getTime() > d.EXPIRES ? l.push(u) : a.indexOf(d.PATH) === 0 && (o && d.SECURE || !d.SECURE) && d.value !== null && s.push(d.name + "=" + d.value);
				}
				for (var f in l) delete n[c][l[f]];
			}
			return s.length > 0 ? s.join("; ") : "";
		}
		e.cookieManager = {
			setCookie: r,
			getCookie: i
		};
	})(n), (function(e, t, n) {
		var r = e.Client, i = e.Future, a = e.BytesIO, o = t.TimeoutError, s = t.location !== n && t.location.protocol === "file:", c = t.XMLHttpRequest, l = !s && c !== void 0 && "withCredentials" in new c(), u = e.parseuri, d = e.cookieManager;
		function f() {}
		function p(e) {
			var t = Object.create(null);
			if (e) {
				e = e.split("\r\n");
				for (var n = 0, r = e.length; n < r; n++) if (e[n] !== "") {
					var i = e[n].split(": ", 2), a = i[0].trim(), o = i[1].trim();
					a in t ? Array.isArray(t[a]) ? t[a].push(o) : t[a] = [t[a], o] : t[a] = o;
				}
			}
			return t;
		}
		function m(e, s, u) {
			if (this.constructor !== m) return new m(e, s, u);
			r.call(this, e, s, u);
			var h = Object.create(null), g = f, _ = f, v = this;
			function y(e) {
				var t = Object.create(null), n, r;
				for (n in h) t[n] = h[n];
				if (e) for (n in e) r = e[n], Array.isArray(r) ? t[n] = r.join(", ") : t[n] = r;
				return t;
			}
			function b(e, t) {
				var r = new i(), a = new c();
				a.open("POST", v.uri, !0), l && (a.withCredentials = "true"), a.responseType = "arraybuffer";
				var s = y(t.httpHeader);
				for (var u in s) a.setRequestHeader(u, s[u]);
				if (a.onload = function() {
					a.onload = f, a.status && (t.httpHeader = p(a.getAllResponseHeaders()), a.status === 200 ? r.resolve(new Uint8Array(a.response)) : r.reject(/* @__PURE__ */ Error(a.status + ":" + a.statusText)));
				}, a.onerror = function() {
					r.reject(/* @__PURE__ */ Error("error"));
				}, a.upload !== n && (a.upload.onprogress = g), a.onprogress = _, t.timeout > 0 && (r = r.timeout(t.timeout).catchError(function(e) {
					throw a.onload = f, a.onerror = f, a.abort(), e;
				}, function(e) {
					return e instanceof o;
				})), e.constructor === String || ArrayBuffer.isView) a.send(e);
				else if (e.buffer.slice) a.send(e.buffer.slice(0, e.length));
				else {
					var d = new Uint8Array(e.length);
					d.set(e), a.send(d.buffer);
				}
				return r;
			}
			function x(e, n) {
				var r = new i(), o = y(n.httpHeader), s = d.getCookie(v.uri());
				return s !== "" && (o.Cookie = s), t.api.ajax({
					url: v.uri,
					method: "post",
					data: { body: a.toString(e) },
					timeout: n.timeout,
					dataType: "text",
					headers: o,
					returnAll: !0,
					certificate: v.certificate
				}, function(e, t) {
					e ? (n.httpHeader = e.headers, e.statusCode === 200 ? (d.setCookie(e.headers, v.uri), r.resolve(new a(e.body).takeBytes())) : r.reject(/* @__PURE__ */ Error(e.statusCode + ":" + e.body))) : r.reject(Error(t.msg));
				}), r;
			}
			function S(e, n) {
				var r = t.api !== void 0 && t.api.ajax !== void 0 ? x(e, n) : b(e, n);
				return n.oneway && r.resolve(), r;
			}
			function C(e) {
				typeof e == "function" && (g = e);
			}
			function w() {
				return g;
			}
			function T(e) {
				typeof e == "function" && (_ = e);
			}
			function E() {
				return _;
			}
			function D(e, t) {
				e.toLowerCase() !== "content-type" && e.toLowerCase() !== "content-length" && (t ? h[e] = t : delete h[e]);
			}
			Object.defineProperties(this, {
				onprogress: {
					get: w,
					set: C
				},
				onRequestProgress: {
					get: w,
					set: C
				},
				onResponseProgress: {
					get: E,
					set: T
				},
				setHeader: { value: D },
				sendAndReceive: { value: S }
			});
		}
		function h(e) {
			var t = u(e);
			if (!(t.protocol === "http:" || t.protocol === "https:")) throw Error("This client desn't support " + t.protocol + " scheme.");
		}
		function g(e, t, n) {
			if (typeof e == "string") h(e);
			else if (Array.isArray(e)) e.forEach(function(e) {
				h(e);
			});
			else throw Error("You should set server uri first!");
			return new m(e, t, n);
		}
		Object.defineProperty(m, "create", { value: g }), e.HttpClient = m;
	})(n, n.global), (function(e, t, n) {
		var r = e.BytesIO, i = e.Client, a = e.Future, o = t.TimeoutError, s = e.parseuri, c = t.WebSocket || t.MozWebSocket;
		function l() {}
		function u(e, t, s) {
			if (c === void 0) throw Error("WebSocket is not supported by this browser.");
			if (this.constructor !== u) return new u(e, t, s);
			i.call(this, e, t, s);
			var d = 0, f = 0, p = [], m = [], h = null, g = null, _ = this;
			function v() {
				return d < 2147483647 ? ++d : d = 0;
			}
			function y(e, t) {
				var n = new r();
				n.writeInt32BE(e), t.constructor === String ? n.writeString(t) : n.write(t);
				var i = n.bytes;
				ArrayBuffer.isView ? g.send(i) : i.buffer.slice ? g.send(i.buffer.slice(0, i.length)) : g.send(i.buffer);
			}
			function b(e) {
				h.resolve(e);
			}
			function x(e) {
				var t = new r(e.data), i = t.readInt32BE(), a = p[i];
				if (delete p[i], a !== n && (--f, a.resolve(t.read(t.length - 4))), f < 100 && m.length > 0) {
					++f;
					var o = m.pop();
					h.then(function() {
						y(o[0], o[1]);
					});
				}
				f === 0 && !_.keepAlive && T();
			}
			function S(e) {
				p.forEach(function(t, n) {
					t.reject(/* @__PURE__ */ Error(e.code + ":" + e.reason)), delete p[n];
				}), f = 0, g = null;
			}
			function C() {
				h = new a(), g = new c(_.uri), g.binaryType = "arraybuffer", g.onopen = b, g.onmessage = x, g.onerror = l, g.onclose = S;
			}
			function w(e, t) {
				var n = v(), r = new a();
				return p[n] = r, t.timeout > 0 && (r = r.timeout(t.timeout).catchError(function(e) {
					throw delete p[n], --f, T(), e;
				}, function(e) {
					return e instanceof o;
				})), (g === null || g.readyState === c.CLOSING || g.readyState === c.CLOSED) && C(), f < 100 ? (++f, h.then(function() {
					y(n, e);
				})) : m.push([n, e]), t.oneway && r.resolve(), r;
			}
			function T() {
				g !== null && (g.onopen = l, g.onmessage = l, g.onclose = l, g.close());
			}
			Object.defineProperties(this, {
				sendAndReceive: { value: w },
				close: { value: T }
			});
		}
		function d(e) {
			var t = s(e);
			if (!(t.protocol === "ws:" || t.protocol === "wss:")) throw Error("This client desn't support " + t.protocol + " scheme.");
		}
		function f(e, t, n) {
			if (typeof e == "string") d(e);
			else if (Array.isArray(e)) e.forEach(function(e) {
				d(e);
			});
			else throw Error("You should set server uri first!");
			return new u(e, t, n);
		}
		Object.defineProperty(u, "create", { value: f }), e.WebSocketClient = u;
	})(n, n.global), (function(e, t, n) {
		var r = e.Future;
		function i() {}
		var a = {}, o = null;
		function s(e) {
			a[e.socketId].onreceive(e.data);
		}
		function c(e) {
			var t = a[e.socketId];
			t.onerror(e.resultCode), t.destroy();
		}
		function l() {
			o === null && (o = t.chrome.sockets.tcp, o.onReceive.addListener(s), o.onReceiveError.addListener(c)), this.socketId = new r(), this.connected = !1, this.timeid = n, this.onclose = i, this.onconnect = i, this.onreceive = i, this.onerror = i;
		}
		Object.defineProperties(l.prototype, {
			connect: { value: function(e, t, n) {
				var r = this;
				o.create({ persistent: n && n.persistent }, function(i) {
					n && ("noDelay" in n && o.setNoDelay(i.socketId, n.noDelay, function(e) {
						e < 0 && (r.socketId.reject(e), o.disconnect(i.socketId), o.close(i.socketId), r.onclose());
					}), "keepAlive" in n && o.setKeepAlive(i.socketId, n.keepAlive, function(e) {
						e < 0 && (r.socketId.reject(e), o.disconnect(i.socketId), o.close(i.socketId), r.onclose());
					})), n && n.tls ? o.setPaused(i.socketId, !0, function() {
						o.connect(i.socketId, e, t, function(e) {
							e < 0 ? (r.socketId.reject(e), o.disconnect(i.socketId), o.close(i.socketId), r.onclose()) : o.secure(i.socketId, function(t) {
								t === 0 ? o.setPaused(i.socketId, !1, function() {
									r.socketId.resolve(i.socketId);
								}) : (r.socketId.reject(e), o.disconnect(i.socketId), o.close(i.socketId), r.onclose());
							});
						});
					}) : o.connect(i.socketId, e, t, function(e) {
						e < 0 ? (r.socketId.reject(e), o.disconnect(i.socketId), o.close(i.socketId), r.onclose()) : r.socketId.resolve(i.socketId);
					});
				}), this.socketId.then(function(e) {
					a[e] = r, r.connected = !0, r.onconnect(e);
				}, function(e) {
					r.onerror(e);
				});
			} },
			send: { value: function(e) {
				var t = this, n = new r();
				return this.socketId.then(function(r) {
					o.send(r, e, function(e) {
						e.resultCode < 0 ? (t.onerror(e.resultCode), n.reject(e.resultCode), t.destroy()) : n.resolve(e.bytesSent);
					});
				}), n;
			} },
			destroy: { value: function() {
				var e = this;
				this.connected = !1, this.socketId.then(function(t) {
					o.disconnect(t), o.close(t), delete a[t], e.onclose();
				});
			} },
			ref: { value: function() {
				this.socketId.then(function(e) {
					o.setPaused(e, !1);
				});
			} },
			unref: { value: function() {
				this.socketId.then(function(e) {
					o.setPaused(e, !0);
				});
			} },
			clearTimeout: { value: function() {
				this.timeid !== n && t.clearTimeout(this.timeid);
			} },
			setTimeout: { value: function(e, n) {
				this.clearTimeout(), this.timeid = t.setTimeout(n, e);
			} }
		}), e.ChromeTcpSocket = l;
	})(n, n.global), (function(e, t, n) {
		var r = e.Future, i = t.atob, a = t.btoa, o = e.toUint8Array, s = e.toBinaryString;
		function c() {}
		var l = {}, u = null;
		function d() {
			u === null && (u = t.api.require("socketManager")), this.socketId = new r(), this.connected = !1, this.timeid = n, this.onclose = c, this.onconnect = c, this.onreceive = c, this.onerror = c;
		}
		Object.defineProperties(d.prototype, {
			connect: { value: function(e, t, n) {
				var r = this;
				u.createSocket({
					type: "tcp",
					host: e,
					port: t,
					timeout: n.timeout,
					returnBase64: !0
				}, function(e) {
					if (e) switch (e.state) {
						case 101: break;
						case 102:
							r.socketId.resolve(e.sid);
							break;
						case 103:
							r.onreceive(o(i(e.data.replace(/\s+/g, ""))));
							break;
						case 201:
							r.socketId.reject(/* @__PURE__ */ Error("Create TCP socket failed"));
							break;
						case 202:
							r.socketId.reject(/* @__PURE__ */ Error("TCP connection failed"));
							break;
						case 203:
							r.onclose(), r.onerror(/* @__PURE__ */ Error("Abnormal disconnect connection"));
							break;
						case 204:
							r.onclose();
							break;
						case 205:
							r.onclose(), r.onerror(/* @__PURE__ */ Error("Unknown error"));
							break;
					}
				}), this.socketId.then(function(e) {
					l[e] = r, r.connected = !0, r.onconnect(e);
				}, function(e) {
					r.onerror(e);
				});
			} },
			send: { value: function(e) {
				var t = this, n = new r();
				return this.socketId.then(function(r) {
					u.write({
						sid: r,
						data: a(s(e)),
						base64: !0
					}, function(e, r) {
						e.status ? n.resolve() : (t.onerror(Error(r.msg)), n.reject(r.msg), t.destroy());
					});
				}), n;
			} },
			destroy: { value: function() {
				var e = this;
				this.connected = !1, this.socketId.then(function(t) {
					u.closeSocket({ sid: t }, function(t, n) {
						t.status || e.onerror(Error(n.msg));
					}), delete l[t];
				});
			} },
			ref: { value: c },
			unref: { value: c },
			clearTimeout: { value: function() {
				this.timeid !== n && t.clearTimeout(this.timeid);
			} },
			setTimeout: { value: function(e, n) {
				this.clearTimeout(), this.timeid = t.setTimeout(n, e);
			} }
		}), e.APICloudTcpSocket = d;
	})(n, n.global), (function(e, t, n) {
		var r = e.ChromeTcpSocket, i = e.APICloudTcpSocket, a = e.Client, o = e.BytesIO, s = e.Future, c = t.TimeoutError, l = e.parseuri;
		function u() {}
		function d(e, t) {
			e.onreceive = function(n) {
				"receiveEntry" in e || (e.receiveEntry = {
					stream: new o(),
					headerLength: 4,
					dataLength: -1,
					id: null
				});
				var r = e.receiveEntry, i = r.stream, a = r.headerLength, s = r.dataLength, c = r.id;
				for (i.write(n); s < 0 && i.length >= a && (s = i.readInt32BE(), s & 2147483648 && (s &= 2147483647, a = 8)), a === 8 && c === null && i.length >= a && (c = i.readInt32BE()), s >= 0 && i.length - a >= s;) t(i.read(s), c), a = 4, c = null, i.trunc(), s = -1;
				r.stream = i, r.headerLength = a, r.dataLength = s, r.id = c;
			};
		}
		function f(e) {
			e && (this.client = e, this.uri = this.client.uri, this.size = 0, this.pool = [], this.requests = []);
		}
		Object.defineProperties(f.prototype, { create: { value: function() {
			var e = l(this.uri), n = e.protocol, a = e.hostname, o = parseInt(e.port, 10), s;
			if (n === "tcp:" || n === "tcp4:" || n === "tcp6:") s = !1;
			else if (n === "tcps:" || n === "tcp4s:" || n === "tcp6s:" || n === "tls:") s = !0;
			else throw Error("Unsupported " + n + " protocol!");
			var c;
			if (t.chrome && t.chrome.sockets && t.chrome.sockets.tcp) c = new r();
			else if (t.api && t.api.require) c = new i();
			else throw Error("TCP Socket is not supported by this browser or platform.");
			var u = this;
			return c.connect(a, o, {
				persistent: !0,
				tls: s,
				timeout: this.client.timeout,
				noDelay: this.client.noDelay,
				keepAlive: this.client.keepAlive
			}), c.onclose = function() {
				--u.size;
			}, ++this.size, c;
		} } });
		function p(e) {
			f.call(this, e);
		}
		p.prototype = Object.create(f.prototype, {
			fetch: { value: function() {
				for (var e = this.pool; e.length > 0;) {
					var t = e.pop();
					if (t.connected) return t.count === 0 && (t.clearTimeout(), t.ref()), t;
				}
				return null;
			} },
			init: { value: function(e) {
				var t = this;
				e.count = 0, e.futures = {}, e.timeoutIds = {}, d(e, function(n, r) {
					var i = e.futures[r];
					i && (t.clean(e, r), e.count === 0 && t.recycle(e), i.resolve(n));
				}), e.onerror = function(n) {
					var r = e.futures;
					for (var i in r) {
						var a = r[i];
						t.clean(e, i), a.reject(n);
					}
				};
			} },
			recycle: { value: function(e) {
				e.unref(), e.setTimeout(this.client.poolTimeout, function() {
					e.destroy();
				});
			} },
			clean: { value: function(e, r) {
				e.timeoutIds[r] !== n && (t.clearTimeout(e.timeoutIds[r]), delete e.timeoutIds[r]), delete e.futures[r], --e.count, this.sendNext(e);
			} },
			sendNext: { value: function(e) {
				if (e.count < 10) if (this.requests.length > 0) {
					var t = this.requests.pop();
					t.push(e), this.send.apply(this, t);
				} else this.pool.lastIndexOf(e) < 0 && this.pool.push(e);
			} },
			send: { value: function(e, n, r, i, a) {
				var s = this, l = i.timeout;
				l > 0 && (a.timeoutIds[r] = t.setTimeout(function() {
					s.clean(a, r), a.count === 0 && s.recycle(a), n.reject(new c("timeout"));
				}, l)), a.count++, a.futures[r] = n;
				var u = e.length, d = new o(8 + u);
				d.writeInt32BE(u | 2147483648), d.writeInt32BE(r), d.write(e), a.send(d.buffer).then(function() {
					s.sendNext(a);
				});
			} },
			getNextId: { value: function() {
				return this.nextid < 2147483647 ? ++this.nextid : this.nextid = 0;
			} },
			sendAndReceive: { value: function(e, t, n) {
				var r = this.fetch(), i = this.getNextId();
				if (r) this.send(e, t, i, n, r);
				else if (this.size < this.client.maxPoolSize) {
					r = this.create(), r.onerror = function(e) {
						t.reject(e);
					};
					var a = this;
					r.onconnect = function() {
						a.init(r), a.send(e, t, i, n, r);
					};
				} else this.requests.push([
					e,
					t,
					i,
					n
				]);
			} }
		}), p.prototype.constructor = f;
		function m(e) {
			f.call(this, e);
		}
		m.prototype = Object.create(f.prototype, {
			fetch: { value: function() {
				for (var e = this.pool; e.length > 0;) {
					var t = e.pop();
					if (t.connected) return t.clearTimeout(), t.ref(), t;
				}
				return null;
			} },
			recycle: { value: function(e) {
				this.pool.lastIndexOf(e) < 0 && (e.unref(), e.setTimeout(this.client.poolTimeout, function() {
					e.destroy();
				}), this.pool.push(e));
			} },
			clean: { value: function(e) {
				e.onreceive = u, e.onerror = u, e.timeoutId !== n && (t.clearTimeout(e.timeoutId), delete e.timeoutId);
			} },
			sendNext: { value: function(e) {
				if (this.requests.length > 0) {
					var t = this.requests.pop();
					t.push(e), this.send.apply(this, t);
				} else this.recycle(e);
			} },
			send: { value: function(e, n, r, i) {
				var a = this, s = r.timeout;
				s > 0 && (i.timeoutId = t.setTimeout(function() {
					a.clean(i), i.destroy(), n.reject(new c("timeout"));
				}, s)), d(i, function(e) {
					a.clean(i), a.sendNext(i), n.resolve(e);
				}), i.onerror = function(e) {
					a.clean(i), n.reject(e);
				};
				var l = e.length, u = new o(4 + l);
				u.writeInt32BE(l), u.write(e), i.send(u.buffer);
			} },
			sendAndReceive: { value: function(e, t, n) {
				var r = this.fetch();
				if (r) this.send(e, t, n, r);
				else if (this.size < this.client.maxPoolSize) {
					r = this.create();
					var i = this;
					r.onerror = function(e) {
						t.reject(e);
					}, r.onconnect = function() {
						i.send(e, t, n, r);
					};
				} else this.requests.push([
					e,
					t,
					n
				]);
			} }
		}), m.prototype.constructor = f;
		function h(e, t, n) {
			if (this.constructor !== h) return new h(e, t, n);
			a.call(this, e, t, n);
			var r = this, i = !0, o = !1, c = 10, l = 3e4, u = null, d = null;
			function f() {
				return i;
			}
			function g(e) {
				i = !!e;
			}
			function _() {
				return o;
			}
			function v(e) {
				o = !!e;
			}
			function y() {
				return c;
			}
			function b(e) {
				typeof e == "number" ? (c = e | 0, c < 1 && (c = 10)) : c = 10;
			}
			function x() {
				return l;
			}
			function S(e) {
				l = typeof e == "number" ? e | 0 : 0;
			}
			function C(e, t) {
				var n = new s();
				return o ? ((u === null || u.uri !== r.uri) && (u = new p(r)), u.sendAndReceive(e, n, t)) : ((d === null || d.uri !== r.uri) && (d = new m(r)), d.sendAndReceive(e, n, t)), t.oneway && n.resolve(), n;
			}
			Object.defineProperties(this, {
				noDelay: {
					get: f,
					set: g
				},
				fullDuplex: {
					get: _,
					set: v
				},
				maxPoolSize: {
					get: y,
					set: b
				},
				poolTimeout: {
					get: x,
					set: S
				},
				sendAndReceive: { value: C }
			});
		}
		function g(e) {
			var t = l(e).protocol;
			if (!(t === "tcp:" || t === "tcp4:" || t === "tcp6:" || t === "tcps:" || t === "tcp4s:" || t === "tcp6s:" || t === "tls:")) throw Error("This client desn't support " + t + " scheme.");
		}
		function _(e, t, n) {
			if (typeof e == "string") g(e);
			else if (Array.isArray(e)) e.forEach(function(e) {
				g(e);
			});
			else throw Error("You should set server uri first!");
			return new h(e, t, n);
		}
		Object.defineProperty(h, "create", { value: _ }), e.TcpClient = h;
	})(n, n.global), (function(e) {
		var t = e.Tags, n = e.BytesIO, r = e.Writer, i = e.Reader, a = 1;
		function o(e) {
			this.version = e || "2.0";
		}
		o.prototype.inputFilter = function(e) {
			var i = n.toString(e);
			i.charAt(0) === "{" && (i = "[" + i + "]");
			for (var a = JSON.parse(i), o = new n(), s = new r(o, !0), c = 0, l = a.length; c < l; ++c) {
				var u = a[c];
				u.error ? (o.writeByte(t.TagError), s.writeString(u.error.message)) : (o.writeByte(t.TagResult), s.serialize(u.result));
			}
			return o.writeByte(t.TagEnd), o.bytes;
		}, o.prototype.outputFilter = function(e) {
			var r = [], o = new n(e), s = new i(o, !1, !1), c = o.readByte();
			do {
				var l = {};
				c === t.TagCall && (l.method = s.readString(), c = o.readByte(), c === t.TagList && (l.params = s.readListWithoutTag(), c = o.readByte()), c === t.TagTrue && (c = o.readByte())), this.version === "1.1" ? l.version = "1.1" : this.version === "2.0" && (l.jsonrpc = "2.0"), l.id = a++, r.push(l);
			} while (c === t.TagCall);
			return r.length > 1 ? JSON.stringify(r) : JSON.stringify(r[0]);
		}, e.JSONRPCClientFilter = o;
	})(n), (function(e) {
		e.common = {
			Completer: e.Completer,
			Future: e.Future,
			ResultMode: e.ResultMode
		}, e.io = {
			BytesIO: e.BytesIO,
			ClassManager: e.ClassManager,
			Tags: e.Tags,
			RawReader: e.RawReader,
			Reader: e.Reader,
			Writer: e.Writer,
			Formatter: e.Formatter
		}, e.client = {
			Client: e.Client,
			HttpClient: e.HttpClient,
			TcpClient: e.TcpClient,
			WebSocketClient: e.WebSocketClient
		}, e.filter = { JSONRPCClientFilter: e.JSONRPCClientFilter }, typeof define == "function" && (define.cmd ? define("hprose", [], e) : define.amd && define("hprose", [], function() {
			return e;
		})), typeof t == "object" && (t.exports = e);
	})(n);
})))(), 1), Ec = "lifedrive.owner-session.v1";
function Dc(e) {
	return e && typeof e == "object" ? e : null;
}
function Oc(e, t) {
	let n = Dc(e), r = Dc(n?.data) || n, i = typeof r?.Sid == "string" ? r.Sid : typeof r?.sid == "string" ? r.sid : "", a = typeof r?.Uid == "string" ? r.Uid : typeof r?.uid == "string" ? r.uid : "";
	if (!i || !a) throw Error("lifedrive.auth.invalid_login_reply");
	return {
		sid: i,
		uid: a,
		username: t.trim()
	};
}
function kc(e = sessionStorage) {
	try {
		let t = e.getItem(Ec);
		if (!t) return null;
		let n = JSON.parse(t);
		return typeof n.sid == "string" && n.sid && typeof n.uid == "string" && n.uid && typeof n.username == "string" ? {
			sid: n.sid,
			uid: n.uid,
			username: n.username
		} : null;
	} catch {
		return null;
	}
}
function Ac(e, t = sessionStorage) {
	t.setItem(Ec, JSON.stringify(e));
}
function jc(e = sessionStorage) {
	e.removeItem(Ec);
}
function Mc(e) {
	return /(?:auth|login|session|permission_denied|access_denied|invalid_sid|expired)/i.test(e);
}
//#endregion
//#region src/leitherClient.ts
var Nc = "v1", Pc = 524288, Fc = null, Ic = null, Lc = null;
function Rc() {
	return mc(), Fc || (Fc = Tc.default.Client.create(`${pc}/webapi/`, [
		"RunMApp",
		"Login",
		"Logout"
	]), Fc.timeout = 45e3), Fc;
}
function zc() {
	return mc(), Ic || (Ic = Tc.default.Client.create(`${pc}/webapi/`, ["RunMApp"]), Ic.timeout = 600 * 1e3), Ic;
}
function Bc() {
	return `web_${Date.now()}_${crypto.randomUUID()}`;
}
async function Vc(e, t, n = {}, r = []) {
	let i = Wc();
	if (!i) throw Error("lifedrive.auth.required");
	let a = {
		aid: fc,
		ver: "last",
		api_version: Nc,
		request_id: Bc(),
		sid: i.sid,
		...n
	}, o = await e.RunMApp(t, a, r);
	if (!o || o.success !== !0 || o.data === void 0) {
		let e = o?.error?.details, t = o?.error?.code || "lifedrive.remote.unavailable";
		throw Mc(t) && Gc(), Error([t, e?.stage].filter(Boolean).join(" · "));
	}
	return o.data;
}
async function Hc(e, t = {}, n = []) {
	return Vc(Rc(), e, t, n);
}
async function Uc(e, t = {}, n = []) {
	return Vc(zc(), e, t, n);
}
function Wc() {
	return Lc ||= kc(), Lc;
}
function Gc() {
	Lc = null, jc();
}
async function Kc(e, t) {
	mc();
	let n = Oc(await Rc().Login(e.trim(), t), e);
	return Lc = n, Ac(n), n;
}
async function qc() {
	let e = Wc();
	if (Gc(), e) try {
		await Rc().Logout(e.sid, "LifeDrive owner logout");
	} catch {}
}
async function Jc() {
	let e = await Hc("access_check", {
		action: "view",
		resource_kind: "drive",
		resource_id: "lifeDrive"
	});
	if (!e.allowed) throw Gc(), Error("lifedrive.auth.not_owner");
	let t = await Hc("drive_open");
	return {
		...e,
		drive_mid: e.drive_mid || t.drive_mid
	};
}
async function Yc() {
	return Hc("health");
}
async function Xc() {
	return Hc("storage_get");
}
async function Zc(e) {
	return Hc("storage_set_limit", { storage_max_gb: e });
}
async function Qc() {
	let e = await Hc("drive_list");
	return Array.isArray(e.objects) ? e.objects : [];
}
async function $c() {
	let e = await Hc("trash_list");
	return Array.isArray(e.objects) ? e.objects : [];
}
async function el(e, t, n) {
	mc();
	let r = await Uc("upload_begin", {
		parent_path: t.parentPath,
		name: e.name,
		size: String(e.size)
	}), i = r.upload_id, a = Math.max(64 * 1024, Math.min(1 * 1024 * 1024, Math.floor(Number(r.min_chunk_size) || 256 * 1024))), o = Math.max(a, Math.min(4 * 1024 * 1024, Math.floor(Number(r.max_chunk_size) || 4 * 1024 * 1024))), s = Math.max(a, Math.min(o, Math.floor(Number(r.chunk_size) || 1 * 1024 * 1024))), c = 0;
	n?.(1);
	try {
		for (; c < e.size;) {
			let t = new Uint8Array(await e.slice(c, Math.min(e.size, c + s)).arrayBuffer()), r = performance.now(), l = await Uc("upload_write", {
				upload_id: i,
				offset: String(c)
			}, [t]), u = Number(l.next_offset);
			if (!Number.isSafeInteger(u) || u <= c || u > e.size) throw Error("lifedrive.upload.invalid_offset");
			c = u;
			let d = performance.now() - r;
			t.byteLength === s && d < 500 ? s = Math.min(o, s * 2) : d > 3e3 && (s = Math.max(a, Math.floor(s / 2))), n?.(Math.max(2, Math.min(95, Math.round(c / Math.max(1, e.size) * 95))));
		}
		let l = await Uc("upload_complete", {
			upload_id: i,
			target_path: r.target_path,
			size: String(e.size),
			mime_type: e.type || "application/octet-stream",
			kind: t.kind
		});
		return n?.(100), l.object;
	} catch (e) {
		try {
			await Uc("upload_abort", { upload_id: i });
		} catch {}
		throw e;
	}
}
async function tl(e, t) {
	return (await Hc("folder_create", {
		name: e,
		parent_path: t
	})).object;
}
async function nl(e, t, n) {
	return Hc("object_move", {
		source_path: e,
		destination_parent: t,
		name: n
	});
}
async function rl(e, t, n) {
	return Hc("object_copy", {
		source_path: e,
		destination_parent: t,
		name: n
	});
}
async function il(e) {
	return Hc("object_trash", { path: e });
}
async function al(e, t, n) {
	return Hc("trash_restore", {
		trash_path: e,
		destination_parent: t,
		name: n
	});
}
async function ol(e) {
	return Hc("object_purge", { trash_path: e });
}
function sl(e) {
	if (e instanceof Uint8Array) return e;
	if (e instanceof ArrayBuffer) return new Uint8Array(e);
	if (Array.isArray(e)) return Uint8Array.from(e);
	if (typeof e == "string") return new TextEncoder().encode(e);
	if (e && typeof e == "object" && "buffer" in e) {
		let t = e;
		return new Uint8Array(t.buffer, t.byteOffset || 0, t.byteLength);
	}
	throw Error("lifedrive.file.invalid_bytes");
}
async function cl(e) {
	let t = [], n = 0;
	for (; n < e.plaintext_size;) {
		let r = await Hc("file_read", {
			path: e.path,
			start: n,
			count: Math.min(Pc, e.plaintext_size - n)
		}), i = sl(r.bytes);
		if (!i.byteLength) throw Error("lifedrive.file.empty_range");
		if (t.push(i), n += i.byteLength, r.eof) break;
	}
	if (n !== e.plaintext_size) throw Error("lifedrive.file.incomplete_read");
	return new Blob(t.map((e) => e.slice().buffer), { type: e.media_type || "application/octet-stream" });
}
//#endregion
//#region src/App.vue?vue&type=script&setup=true&lang.ts
var ll = {
	key: 0,
	class: "owner-auth-shell"
}, ul = {
	class: "owner-auth-card",
	"aria-labelledby": "owner-auth-title"
}, dl = { class: "owner-auth-shield" }, fl = { class: "field-label" }, pl = { class: "field-label" }, ml = {
	key: 0,
	class: "owner-auth-error",
	role: "alert"
}, hl = ["disabled"], gl = { class: "brand-row" }, _l = {
	class: "primary-nav",
	"aria-label": "Primary navigation"
}, vl = ["onClick"], yl = {
	key: 0,
	class: "nav-badge"
}, bl = { class: "storage-card" }, xl = { class: "storage-title" }, Sl = { class: "storage-track" }, Cl = ["src"], wl = { class: "profile-copy" }, Tl = { class: "main-shell" }, El = { class: "topbar" }, Dl = { class: "global-search" }, Ol = { class: "topbar-actions" }, kl = ["src"], Al = { class: "content-scroll" }, jl = {
	key: 0,
	class: "drive-drop-overlay"
}, Ml = { class: "files-topbar" }, Nl = { class: "files-title" }, Pl = { class: "welcome-actions" }, Fl = {
	key: 0,
	class: "add-menu"
}, Il = { class: "browser-heading compact-browser-heading" }, Ll = { class: "breadcrumbs" }, Rl = ["onClick"], zl = { class: "folder-count" }, Bl = { class: "browser-tools" }, Vl = { class: "sort-control" }, Hl = { class: "view-toggle" }, Ul = {
	key: 1,
	class: "selection-toolbar"
}, Wl = ["disabled"], Gl = ["disabled"], Kl = ["disabled"], ql = {
	key: 2,
	class: "file-grid"
}, Jl = [
	"aria-selected",
	"onClick",
	"onDblclick",
	"onKeydown"
], Yl = ["data-file-badge"], Xl = ["aria-label", "onClick"], Zl = ["src", "alt"], Ql = {
	key: 3,
	class: "landscape-shape"
}, $l = {
	key: 4,
	class: "audio-wave"
}, eu = {
	key: 5,
	class: "media-cover-play"
}, tu = ["aria-label", "onClick"], nu = ["onClick"], ru = ["onClick"], iu = ["onClick"], au = ["onClick"], ou = ["onClick"], su = ["onClick"], cu = ["onClick"], lu = { class: "file-card-copy" }, uu = {
	key: 3,
	class: "file-list"
}, du = [
	"aria-pressed",
	"onClick",
	"onDblclick",
	"onKeydown"
], fu = { class: "row-name" }, pu = ["data-file-badge"], mu = ["src", "alt"], hu = {
	key: 2,
	class: "media-cover-play compact"
}, gu = { class: "row-status" }, _u = ["aria-label", "onClick"], vu = ["onClick"], yu = ["onClick"], bu = ["onClick"], xu = ["onClick"], Su = ["onClick"], Cu = ["onClick"], wu = ["onClick"], Tu = {
	key: 4,
	class: "empty-state roomy-empty"
}, Eu = {
	key: 1,
	class: "page inner-page"
}, Du = { class: "page-title-row" }, Ou = { class: "search-hero" }, ku = { class: "filter-chips" }, Au = {
	key: 0,
	class: "search-filter-panel"
}, ju = { class: "results-heading" }, Mu = { class: "search-results" }, Nu = ["onClick"], Pu = ["data-file-badge"], Fu = ["src", "alt"], Iu = {
	key: 2,
	class: "media-cover-play compact"
}, Lu = { class: "result-copy" }, Ru = {
	key: 0,
	class: "empty-state"
}, zu = {
	key: 2,
	class: "page inner-page"
}, Bu = { class: "page-title-row" }, Vu = ["disabled"], Hu = { class: "panel transfer-panel" }, Uu = { class: "panel-heading" }, Wu = ["data-file-badge"], Gu = { class: "transfer-main" }, Ku = { class: "progress-track" }, qu = {
	key: 0,
	class: "empty-state"
}, Ju = {
	key: 0,
	class: "panel transfer-panel completed-panel"
}, Yu = ["data-file-badge"], Xu = { class: "transfer-main" }, Zu = ["onClick"], Qu = { class: "panel transfer-panel completed-panel" }, $u = { class: "panel-heading" }, ed = ["disabled"], td = ["data-file-badge"], nd = { class: "transfer-main" }, rd = {
	key: 0,
	class: "empty-state compact-empty"
}, id = {
	key: 3,
	class: "page inner-page"
}, ad = { class: "page-title-row" }, od = ["disabled"], sd = { class: "notice-card" }, cd = { class: "panel trash-panel" }, ld = { class: "row-name" }, ud = ["data-file-badge"], dd = { class: "trash-actions" }, fd = ["onClick"], pd = ["onClick"], md = {
	key: 0,
	class: "empty-state"
}, hd = {
	key: 4,
	class: "page inner-page settings-page"
}, gd = { class: "settings-grid" }, _d = { class: "panel protection-panel" }, vd = { class: "panel-heading" }, yd = { class: "panel storage-panel" }, bd = { class: "panel-heading" }, xd = { class: "storage-donut" }, Sd = { class: "panel capacity-panel" }, Cd = { class: "panel-heading" }, wd = { key: 0 }, Td = {
	key: 0,
	class: "capacity-summary"
}, Ed = { class: "capacity-track" }, Dd = { class: "capacity-form" }, Od = ["disabled"], kd = { class: "capacity-note" }, Ad = {
	key: 1,
	class: "capacity-restart"
}, jd = {
	key: 2,
	class: "capacity-error"
}, Md = { class: "panel node-panel" }, Nd = { class: "panel-heading" }, Pd = { class: "node-details" }, Fd = { class: "app-id-value" }, Id = { class: "compatibility-note" }, Ld = { class: "panel devices-panel" }, Rd = { class: "panel-heading" }, zd = { class: "device-row" }, Bd = { class: "device-trust" }, Vd = {
	key: 1,
	class: "details-drawer",
	"aria-label": "File details"
}, Hd = { class: "drawer-header" }, Ud = ["data-file-badge"], Wd = ["src", "alt"], Gd = {
	key: 2,
	class: "media-cover-play large"
}, Kd = { class: "drawer-body" }, qd = { class: "detail-title" }, Jd = { class: "drawer-actions" }, Yd = ["aria-label"], Xd = { class: "preview-header" }, Zd = { class: "preview-header-actions" }, Qd = ["aria-label"], $d = { class: "preview-stage" }, ef = {
	key: 0,
	class: "preview-placeholder"
}, tf = ["src", "alt"], nf = ["src"], rf = {
	key: 3,
	class: "preview-audio"
}, af = ["src"], of = ["src", "title"], sf = {
	key: 5,
	class: "preview-text"
}, cf = ["data-file-badge"], lf = { key: 0 }, uf = { key: 1 }, df = { class: "preview-footer" }, ff = {
	key: 1,
	class: "modal-card",
	role: "dialog"
}, pf = { class: "modal-header" }, mf = { class: "eyebrow" }, hf = { class: "prepared-files" }, gf = ["data-file-badge"], _f = { class: "modal-footer" }, vf = ["disabled"], yf = {
	key: 2,
	class: "modal-card small-modal",
	role: "dialog"
}, bf = { class: "modal-header" }, xf = { class: "field-label" }, Sf = { class: "field-help" }, Cf = { class: "modal-footer" }, wf = ["disabled"], Tf = {
	key: 3,
	class: "modal-card small-modal",
	role: "dialog"
}, Ef = { class: "modal-header" }, Df = { class: "field-label" }, Of = { class: "modal-footer" }, kf = {
	key: 4,
	class: "modal-card small-modal",
	role: "dialog"
}, Af = { class: "modal-header" }, jf = { class: "field-label" }, Mf = ["value"], Nf = { class: "modal-footer" }, Pf = {
	key: 5,
	class: "modal-card small-modal",
	role: "dialog"
}, Ff = { class: "modal-header" }, If = { class: "field-label" }, Lf = ["value"], Rf = { class: "modal-footer" }, zf = ["disabled"], Bf = {
	key: 6,
	class: "modal-card share-modal",
	role: "dialog",
	"aria-modal": "true"
}, Vf = { class: "modal-header" }, Hf = { class: "share-settings" }, Uf = { class: "field-label" }, Wf = ["min"], Gf = { class: "field-label" }, Kf = ["aria-pressed"], qf = {
	key: 0,
	class: "share-password-panel"
}, Jf = { class: "field-label" }, Yf = { class: "share-password-control" }, Xf = ["value"], Zf = { class: "modal-footer" }, Qf = ["disabled"], $f = { class: "share-created" }, ep = {
	key: 0,
	class: "field-label share-created-password"
}, tp = { class: "share-copy-control" }, np = ["value"], rp = { class: "field-help" }, ip = { class: "field-label share-link-bottom" }, ap = { class: "share-copy-control" }, op = ["value"], sp = {
	key: 7,
	class: "modal-card small-modal",
	role: "dialog",
	"aria-modal": "true"
}, cp = { class: "modal-header" }, lp = { class: "field-label" }, up = { class: "modal-footer" }, dp = ["disabled"], fp = { class: "modal-footer" }, pp = {
	key: 8,
	class: "modal-card update-modal",
	role: "dialog",
	"aria-modal": "true",
	"aria-labelledby": "update-title"
}, mp = { class: "modal-header" }, hp = { class: "update-version-row" }, gp = { class: "latest-version" }, _p = { class: "update-intro" }, vp = { class: "update-steps" }, yp = { class: "update-command" }, bp = { class: "modal-footer" }, xp = {
	key: 9,
	class: "modal-card guide-modal",
	role: "dialog"
}, Sp = { class: "modal-header" }, Cp = { class: "guide-status" }, wp = { class: "modal-footer" }, Tp = {
	key: 10,
	class: "modal-card profile-editor-modal",
	role: "dialog",
	"aria-modal": "true",
	"aria-labelledby": "profile-title"
}, Ep = { class: "modal-header" }, Dp = { class: "profile-avatar-editor" }, Op = ["src"], kp = { key: 1 }, Ap = { class: "profile-avatar-actions" }, jp = {
	key: 0,
	class: "profile-avatar-error",
	role: "alert"
}, Mp = { class: "profile-fields" }, Np = { class: "field-label" }, Pp = { class: "field-label" }, Fp = { class: "profile-storage-note" }, Ip = { key: 0 }, Lp = {
	key: 1,
	class: "profile-save-error",
	role: "alert"
}, Rp = { class: "profile-account-details" }, zp = { class: "modal-footer profile-modal-footer" }, Bp = ["disabled"], Vp = {
	key: 11,
	class: "modal-card",
	role: "dialog"
}, Hp = { class: "modal-header" }, Up = { class: "technical-grid" }, Wp = { class: "modal-footer" }, Gp = {
	key: 0,
	class: "toast-message"
}, Kp = { class: "mobile-bottom-nav" }, qp = ["onClick"], Jp = /* @__PURE__ */ rr({
	__name: "App",
	setup(e) {
		let t = Date.now(), n = [
			{
				id: "family",
				name: "Family photos",
				kind: "folder",
				parentId: null,
				sizeBytes: 0,
				size: "1 item",
				modified: "Today",
				modifiedAt: t - 1e3,
				detail: "Photographs gathered from family devices.",
				accent: "folder-family",
				protected: !0,
				demo: !0
			},
			{
				id: "letters",
				name: "Letters & documents",
				kind: "folder",
				parentId: null,
				sizeBytes: 0,
				size: "Empty folder",
				modified: "Yesterday",
				modifiedAt: t - 864e5,
				detail: "Scanned letters and certificates.",
				accent: "folder-letters",
				protected: !0,
				demo: !0
			},
			{
				id: "hangzhou",
				name: "1998 — Summer in Hangzhou.jpg",
				kind: "image",
				parentId: null,
				sizeBytes: 48e5,
				size: "4.8 MB",
				modified: "Today",
				modifiedAt: t - 2e3,
				detail: "Scanned from a family album.",
				accent: "memory-lake",
				protected: !0,
				demo: !0
			},
			{
				id: "voice",
				name: "Dad's voice — Sunday lunch.m4a",
				kind: "audio",
				parentId: null,
				sizeBytes: 182e5,
				size: "18.2 MB",
				modified: "Aug 18",
				modifiedAt: t - 3456e5,
				detail: "12 min 48 sec · Recorded on iPhone",
				accent: "memory-audio",
				protected: !0,
				demo: !0
			},
			{
				id: "videos",
				name: "Home videos",
				kind: "folder",
				parentId: null,
				sizeBytes: 0,
				size: "Empty folder",
				modified: "Aug 16",
				modifiedAt: t - 5184e5,
				detail: "Birthdays, holidays, and ordinary days.",
				accent: "folder-videos",
				protected: !0,
				demo: !0
			},
			{
				id: "travel",
				name: "Travel documents.pdf",
				kind: "pdf",
				parentId: null,
				sizeBytes: 21e5,
				size: "2.1 MB",
				modified: "Aug 12",
				modifiedAt: t - 864e6,
				detail: "Saved locally · Protection pending",
				accent: "memory-document",
				protected: !1,
				demo: !0
			},
			{
				id: "picnic",
				name: "Family picnic — West Lake.jpg",
				kind: "image",
				parentId: "family",
				sizeBytes: 32e5,
				size: "3.2 MB",
				modified: "Aug 20",
				modifiedAt: t - 1728e5,
				detail: "Inside Family photos",
				accent: "memory-garden",
				protected: !0,
				demo: !0
			}
		], r = [], i = yc(), a = new Set(["recipe", "notes"]), o = new Set([
			"t1",
			"t2",
			"t3",
			"t4"
		]), s = (i?.items ?? n).filter((e) => !a.has(e.id)), c = (i?.transfers ?? r).filter((e) => !o.has(e.id)).map((e) => e.status === "active" || e.status === "paused" ? {
			...e,
			status: "failed",
			detail: "Interrupted before completion"
		} : e), l = /* @__PURE__ */ U(s), u = /* @__PURE__ */ U(c), d = /* @__PURE__ */ U(i?.shares ?? []), f = /* @__PURE__ */ U(i?.profiles ?? {}), p = /* @__PURE__ */ U("connecting"), m = /* @__PURE__ */ U({}), h = /* @__PURE__ */ U(Wc() ?? {
			sid: "demo-session",
			uid: "demo-owner",
			username: "local-owner"
		}), g = /* @__PURE__ */ U("authenticated"), _ = /* @__PURE__ */ U(h.value?.username ?? ""), v = /* @__PURE__ */ U(""), y = /* @__PURE__ */ U(!1), b = /* @__PURE__ */ U(""), x = /* @__PURE__ */ U(""), S = /* @__PURE__ */ U(null), C = /* @__PURE__ */ U(""), w = /* @__PURE__ */ U(!1), T = /* @__PURE__ */ U(!1), E = /* @__PURE__ */ U(""), D = /* @__PURE__ */ U(!1), ee = /* @__PURE__ */ U(h.value ? f.value[h.value.uid] ?? null : null), te = /* @__PURE__ */ U(!1), ne = /* @__PURE__ */ U(""), re = /* @__PURE__ */ U("files"), ie = /* @__PURE__ */ U(null), ae = /* @__PURE__ */ U("grid"), oe = /* @__PURE__ */ U("Recently modified"), O = /* @__PURE__ */ U(""), se = /* @__PURE__ */ U("all"), k = /* @__PURE__ */ U("all"), ce = /* @__PURE__ */ U(!1), A = /* @__PURE__ */ U(null), j = /* @__PURE__ */ U(null), le = /* @__PURE__ */ U(null), M = /* @__PURE__ */ U(!1), N = /* @__PURE__ */ U(null), ue = /* @__PURE__ */ U(null), P = /* @__PURE__ */ U(!1), de = /* @__PURE__ */ U(/* @__PURE__ */ new Set()), fe = /* @__PURE__ */ U(""), pe = /* @__PURE__ */ U(""), F = /* @__PURE__ */ U("root"), he = /* @__PURE__ */ U([]), ge = /* @__PURE__ */ U(!1), _e = /* @__PURE__ */ U(""), ve = /* @__PURE__ */ U(""), ye = /* @__PURE__ */ U(!1), be = /* @__PURE__ */ U(""), xe = /* @__PURE__ */ U(10), Se = /* @__PURE__ */ U(!1), Ce = /* @__PURE__ */ U(""), we = /* @__PURE__ */ U(""), Te = /* @__PURE__ */ U(""), Ee = /* @__PURE__ */ U(""), R = /* @__PURE__ */ U(!1), De = /* @__PURE__ */ U(""), Oe = /* @__PURE__ */ U(""), z = /* @__PURE__ */ U(null), ke = /* @__PURE__ */ U(""), Ae = /* @__PURE__ */ U(""), je = /* @__PURE__ */ U(""), Me = /* @__PURE__ */ U(""), Ne = /* @__PURE__ */ U(!1), Pe = 0, Fe = /* @__PURE__ */ U(null), Ie = /* @__PURE__ */ U(null), Le = /* @__PURE__ */ U(null), Re = /* @__PURE__ */ U({}), ze = /* @__PURE__ */ U(""), Be = /* @__PURE__ */ U(null), Ve = /* @__PURE__ */ U(!1), He, Ue, We = 0, Ge = Q(() => [
			{
				id: "files",
				label: "Files",
				icon: Is
			},
			{
				id: "search",
				label: "Search",
				icon: Zs
			},
			{
				id: "transfers",
				label: "Transfers",
				icon: _s,
				badge: u.value.filter((e) => e.status === "active").length || void 0
			},
			{
				id: "trash",
				label: "Trash",
				icon: tc
			},
			{
				id: "settings",
				label: "Settings",
				icon: Qs
			}
		]), Ke = Q(() => ie.value ? l.value.find((e) => e.id === ie.value) ?? null : null), qe = Q(() => {
			let e = [], t = Ke.value;
			for (; t;) e.unshift(t), t = t.parentId ? l.value.find((e) => e.id === t?.parentId) ?? null : null;
			return e;
		});
		function Je(e) {
			return [...e].sort((e, t) => oe.value === "Name" ? e.name.localeCompare(t.name) : oe.value === "Size" ? t.sizeBytes - e.sizeBytes : oe.value === "Type" ? e.kind.localeCompare(t.kind) || e.name.localeCompare(t.name) : t.modifiedAt - e.modifiedAt);
		}
		let Ye = Q(() => Je(l.value.filter((e) => !e.trashedAt && e.parentId === ie.value))), Xe = Q(() => Ye.value.filter((e) => de.value.has(e.id))), Ze = Q(() => {
			let e = O.value.trim().toLowerCase();
			return Je(l.value.filter((t) => !t.trashedAt && (se.value === "all" || t.kind === se.value) && (k.value === "all" || k.value === "protected" === t.protected) && (!e || t.name.toLowerCase().includes(e) || t.detail.toLowerCase().includes(e))));
		}), Qe = Q(() => Je(l.value.filter((e) => e.trashedAt && !l.value.find((t) => t.id === e.parentId)?.trashedAt))), B = Q(() => l.value.find((e) => e.id === ue.value) ?? null), $e = Q(() => l.value.filter((e) => !e.trashedAt && e.kind !== "folder" && e.parentId === (B.value?.parentId ?? null))), et = Q(() => l.value.filter((e) => !e.trashedAt && e.kind !== "folder").reduce((e, t) => e + t.sizeBytes, 0)), tt = Q(() => S.value?.usage_available ? Number(S.value.used_bytes) || 0 : et.value), nt = Q(() => S.value?.storage_max_bytes ? Math.min(100, tt.value / S.value.storage_max_bytes * 100) : 0), rt = Q(() => u.value.filter((e) => e.status === "active" || e.status === "paused")), it = Q(() => u.value.filter((e) => e.status === "failed")), at = Q(() => u.value.filter((e) => e.status === "complete")), ot = Q(() => p.value === "connected" ? "LifeDrive connected" : p.value === "connecting" ? "Connecting…" : "Local cache"), st = Q(() => p.value === "connected" ? "Stored on LifeDrive" : "Saved locally"), ct = Q(() => !!(Oe.value && z.value?.version && Oe.value !== z.value.version)), lt = Q(() => d.value.find((e) => e.token === we.value) ?? null), ut = Q(() => Number.isInteger(xe.value) && xe.value > 0 && xe.value <= 1e4 && Date.parse(be.value) > Date.now() && (!Se.value || Ce.value.length === 6)), dt = Q(() => ee.value ?? void 0), ft = Q(() => dt.value?.displayName.trim() || h.value?.username || "LifeDrive owner"), pt = Q(() => dt.value?.avatarDataUrl || ""), mt = Q(() => ft.value.trim().split(/\s+/).map((e) => e[0]).join("").slice(0, 2).toUpperCase() || "LO"), ht = Q(() => ke.value.trim().split(/\s+/).map((e) => e[0]).join("").slice(0, 2).toUpperCase() || mt.value);
		bc({
			version: 4,
			items: l.value,
			transfers: u.value,
			shares: d.value,
			profiles: f.value
		}), In([
			l,
			u,
			d,
			f
		], () => bc({
			version: 4,
			items: l.value,
			transfers: u.value,
			shares: d.value,
			profiles: f.value
		}), { deep: !0 }), In(() => l.value.map((e) => `${e.id}:${e.blobId ?? ""}:${e.trashedAt ?? ""}`).join("|"), H, { immediate: !0 }), In(Te, () => {
			R.value || (Ee.value = "");
		}), In(N, (e, t) => {
			t === "preview" && e !== "preview" && Vt();
		}), In(ie, () => _t());
		function gt() {
			j.value = null, le.value = null, M.value = !1;
		}
		function _t() {
			P.value = !1, de.value = /* @__PURE__ */ new Set();
		}
		function vt(e) {
			re.value = e, A.value = null, e !== "files" && _t(), gt(), ye.value = !1, e === "settings" && Sn();
		}
		function yt() {
			_t(), ie.value = null, vt("files");
		}
		function bt(e) {
			let t = e.lastIndexOf(".");
			return t >= 0 ? e.slice(t + 1).toLowerCase() : "";
		}
		function xt(e, t, n = "") {
			let r = bt(e), i = n.toLowerCase();
			return t === "folder" ? "folder" : t === "image" ? "image" : t === "audio" ? "audio" : t === "video" ? "video" : t === "pdf" || r === "pdf" || i === "application/pdf" ? "pdf" : [
				"doc",
				"docx",
				"docm",
				"dot",
				"dotx",
				"odt",
				"rtf"
			].includes(r) || i.includes("wordprocessingml") || i.includes("msword") ? "word" : [
				"xls",
				"xlsx",
				"xlsm",
				"ods",
				"csv"
			].includes(r) || i.includes("spreadsheetml") || i.includes("ms-excel") ? "sheet" : [
				"ppt",
				"pptx",
				"pptm",
				"odp",
				"key"
			].includes(r) || i.includes("presentationml") || i.includes("ms-powerpoint") ? "presentation" : [
				"zip",
				"rar",
				"7z",
				"tar",
				"gz",
				"bz2",
				"xz"
			].includes(r) || i.includes("zip") || i.includes("compressed") ? "archive" : [
				"txt",
				"md",
				"markdown",
				"log"
			].includes(r) || i.startsWith("text/plain") ? "text" : [
				"json",
				"xml",
				"yaml",
				"yml",
				"html",
				"css",
				"js",
				"jsx",
				"ts",
				"tsx",
				"py",
				"go",
				"swift",
				"kt",
				"java",
				"c",
				"cpp",
				"h"
			].includes(r) ? "code" : "file";
		}
		function St(e, t, n = "") {
			let r = xt(e, t, n);
			return r === "folder" ? Ls : r === "image" ? As : r === "audio" ? Os : r === "video" ? Ps : r === "pdf" ? Ms : r === "word" ? Ns : r === "sheet" ? js : r === "presentation" ? Ys : r === "archive" ? Ds : r === "code" ? ks : r === "text" ? Ms : Fs;
		}
		function Ct(e, t, n = "") {
			let r = xt(e, t, n);
			return r === "pdf" ? "PDF" : r === "word" ? "DOC" : r === "sheet" ? "XLS" : r === "presentation" ? "PPT" : r === "archive" ? "ZIP" : r === "text" ? "TXT" : r === "code" ? "</>" : "";
		}
		function wt(e, t, n = "") {
			return `file-visual-${xt(e, t, n)}`;
		}
		function Tt(e) {
			return e === "folder" ? "folder-new" : e === "image" ? "memory-garden" : e === "audio" ? "memory-audio" : "memory-document";
		}
		function Et(e) {
			if (!e) return "0 B";
			let t = [
				"B",
				"KB",
				"MB",
				"GB",
				"TB",
				"PB"
			], n = Math.min(Math.floor(Math.log(e) / Math.log(1024)), t.length - 1), r = e / 1024 ** n;
			return `${r >= 10 || !n ? r.toFixed(0) : r.toFixed(1)} ${t[n]}`;
		}
		function Dt(e) {
			let t = e.name.toLowerCase().split(".").pop() ?? "";
			return e.type.startsWith("image/") || [
				"jpg",
				"jpeg",
				"png",
				"gif",
				"webp",
				"svg",
				"bmp",
				"avif",
				"heic",
				"heif"
			].includes(t) ? "image" : e.type.startsWith("audio/") || [
				"mp3",
				"m4a",
				"aac",
				"wav",
				"ogg",
				"flac",
				"opus"
			].includes(t) ? "audio" : e.type.startsWith("video/") || [
				"mp4",
				"mov",
				"m4v",
				"webm",
				"avi",
				"mkv"
			].includes(t) ? "video" : e.type === "application/pdf" || t === "pdf" ? "pdf" : "file";
		}
		function V(e, t = 3400) {
			ve.value = e, He && clearTimeout(He), He = window.setTimeout(() => ve.value = "", t);
		}
		async function Ot() {
			try {
				let e = await fetch("/lifedrive-release.json", { cache: "no-store" });
				if (!e.ok) return;
				let t = await e.json();
				typeof t.product == "string" && typeof t.version == "string" && typeof t.releasedAt == "string" && typeof t.command == "string" && (z.value = t);
			} catch {}
		}
		async function kt() {
			let e = z.value?.command;
			if (e) try {
				await navigator.clipboard.writeText(e), V("Upgrade command copied to clipboard.");
			} catch {
				V("Select and copy the command manually.");
			}
		}
		function At(e) {
			_t(), ie.value = e.id, vt("files");
		}
		function jt(e) {
			A.value = e, j.value = null;
		}
		function Mt(e) {
			let t = new Set(de.value);
			t.has(e.id) ? t.delete(e.id) : t.add(e.id), de.value = t;
		}
		function Nt() {
			Ue &&= (clearTimeout(Ue), void 0), P.value = !0, A.value = null, j.value = null;
		}
		function Pt() {
			de.value = de.value.size === Ye.value.length ? /* @__PURE__ */ new Set() : new Set(Ye.value.map((e) => e.id));
		}
		function Ft(e) {
			P.value ? Mt(e) : Rt(e);
		}
		function It(e) {
			P.value || zt(e);
		}
		function Lt(e) {
			P.value ? Mt(e) : Bt(e);
		}
		function Rt(e) {
			Ue && clearTimeout(Ue), Ue = window.setTimeout(() => {
				e.kind === "folder" ? At(e) : Wt(e), Ue = void 0;
			}, 220);
		}
		function zt(e) {
			Ue &&= (clearTimeout(Ue), void 0), jt(e);
		}
		function Bt(e) {
			e.kind === "folder" ? At(e) : Wt(e);
		}
		function Vt() {
			ze.value &&= (URL.revokeObjectURL(ze.value), ""), Be.value = null;
		}
		function Ht(e) {
			return !!(e.mimeType?.toLowerCase().startsWith("text/") || /\.(txt|md|markdown|json|csv|log|xml|yaml|yml)$/i.test(e.name));
		}
		async function H() {
			let e = ++We, t = {};
			for (let e of l.value) {
				if (!["image", "video"].includes(e.kind) || e.trashedAt) continue;
				let n = await vn(e);
				if (n) if (e.kind === "image") t[e.id] = URL.createObjectURL(n);
				else {
					let r = await Ut(n);
					r && (t[e.id] = r);
				}
			}
			if (e !== We) {
				for (let e of Object.values(t)) URL.revokeObjectURL(e);
				return;
			}
			for (let e of Object.values(Re.value)) URL.revokeObjectURL(e);
			Re.value = t;
		}
		function Ut(e) {
			return new Promise((t) => {
				let n = URL.createObjectURL(e), r = document.createElement("video"), i = document.createElement("canvas"), a = !1, o = window.setTimeout(() => s(null), 1e4);
				function s(e) {
					if (a) {
						e && URL.revokeObjectURL(e);
						return;
					}
					a = !0, clearTimeout(o), r.removeAttribute("src"), r.load(), URL.revokeObjectURL(n), t(e);
				}
				function c() {
					if (!r.videoWidth || !r.videoHeight) return s(null);
					let e = Math.min(1, 640 / r.videoWidth);
					i.width = Math.max(1, Math.round(r.videoWidth * e)), i.height = Math.max(1, Math.round(r.videoHeight * e));
					let t = i.getContext("2d");
					if (!t) return s(null);
					t.drawImage(r, 0, 0, i.width, i.height), i.toBlob((e) => s(e ? URL.createObjectURL(e) : null), "image/jpeg", .82);
				}
				r.preload = "auto", r.muted = !0, r.playsInline = !0, r.addEventListener("loadeddata", c, { once: !0 }), r.addEventListener("error", () => s(null), { once: !0 }), r.src = n, r.load();
			});
		}
		async function Wt(e) {
			if (e.kind === "folder") return At(e);
			A.value = null, j.value = null, ue.value = e.id, Vt(), Ve.value = !0, N.value = "preview";
			let t = await vn(e);
			t && (Ht(e) ? Be.value = await t.text() : ze.value = URL.createObjectURL(t)), Ve.value = !1;
		}
		function Gt(e) {
			let t = B.value;
			if (!t) return;
			let n = $e.value.findIndex((e) => e.id === t.id);
			if (n < 0) return;
			let r = $e.value[(n + e + $e.value.length) % $e.value.length];
			r && Wt(r);
		}
		function Kt() {
			let e = B.value;
			e && (N.value = null, jt(e));
		}
		function qt() {
			let e = B.value;
			e && (N.value = null, rr(e));
		}
		function Jt() {
			M.value = !1, he.value = [], N.value = "upload";
		}
		function Yt(e) {
			he.value = Array.from(e);
		}
		function Xt() {
			Fe.value?.click();
		}
		function Zt(e) {
			let t = e.target;
			t.files && Yt(t.files), t.value = "";
		}
		function Qt(e) {
			e.dataTransfer?.files.length && Yt(e.dataTransfer.files);
		}
		function $t(e) {
			return Array.from(e.dataTransfer?.types ?? []).includes("Files");
		}
		function en(e) {
			$t(e) && (Pe += 1, Ne.value = !0);
		}
		function tn(e) {
			$t(e) && (e.dataTransfer && (e.dataTransfer.dropEffect = "copy"), Ne.value = !0);
		}
		function nn() {
			Pe = Math.max(0, Pe - 1), Pe || (Ne.value = !1);
		}
		function rn(e) {
			return new Promise((t, n) => e.file(t, n));
		}
		function an(e) {
			return new Promise((t, n) => e.readEntries(t, n));
		}
		async function on(e, t, n, r) {
			let i = t ? `${t}/${e.name}` : e.name;
			if (e.isFile) {
				n.push({
					file: await rn(e),
					relativePath: i
				});
				return;
			}
			if (!e.isDirectory) return;
			r.add(i);
			let a = e.createReader();
			for (;;) {
				let e = await an(a);
				if (!e.length) break;
				for (let t of e) await on(t, i, n, r);
			}
		}
		async function sn(e) {
			let t = [], n = /* @__PURE__ */ new Set(), r = Array.from(e.items).filter((e) => e.kind === "file").map((e) => typeof e.webkitGetAsEntry == "function" ? e.webkitGetAsEntry() : null).filter((e) => !!e);
			if (r.length) {
				for (let e of r) await on(e, "", t, n);
				return {
					files: t,
					directories: [...n]
				};
			}
			for (let r of Array.from(e.files)) {
				let e = r.webkitRelativePath || r.name;
				t.push({
					file: r,
					relativePath: e
				});
				let i = e.split("/").filter(Boolean);
				i.pop();
				let a = "";
				for (let e of i) a = a ? `${a}/${e}` : e, n.add(a);
			}
			return {
				files: t,
				directories: [...n]
			};
		}
		function cn(e, t) {
			let n = t.split("/").filter(Boolean).join("/");
			return n ? `${e === "/" ? "" : e}/${n}` : e;
		}
		function ln(e) {
			let t = e.lastIndexOf("/");
			return t < 0 ? "" : e.slice(0, t);
		}
		function un(e, t) {
			let n = u.value.find((t) => t.id === e);
			n && Object.assign(n, t);
		}
		function dn(e) {
			return [
				"folder",
				"image",
				"audio",
				"video",
				"pdf",
				"file"
			].includes(e) ? e : "file";
		}
		function fn(e) {
			let t = e ? Date.parse(e) : NaN;
			return Number.isFinite(t) ? t : Date.now();
		}
		function pn(e) {
			if (!e) return "/";
			if (e.remoteId?.startsWith("/")) return e.remoteId;
			let t = [], n = e;
			for (; n;) t.unshift(n.name), n = n.parentId ? l.value.find((e) => e.id === n?.parentId) ?? null : null;
			return `/${t.join("/")}`;
		}
		function mn(e) {
			if (e.remoteId?.startsWith("/")) return e.remoteId;
			let t = e.parentId ? l.value.find((t) => t.id === e.parentId) ?? null : null;
			return `${pn(t) === "/" ? "" : pn(t)}/${e.name}`;
		}
		function hn(e, t) {
			for (let n of l.value) (n.remoteId === e || n.remoteId?.startsWith(e + "/")) && (n.remoteId = t + n.remoteId.slice(e.length));
			let n = {};
			for (let [r, i] of Object.entries(m.value)) {
				let a = r === e || r.startsWith(e + "/") ? t + r.slice(e.length) : r;
				n[a] = {
					...i,
					object_id: a,
					path: a
				};
			}
			m.value = n;
		}
		function gn(e, t = !1) {
			let n = dn(e.kind), r = e.parent_id === "root" ? null : l.value.find((t) => t.id === e.parent_id || t.remoteId === e.parent_id) ?? null, i = fn(e.modified_at);
			return {
				id: e.object_id,
				name: e.display_name,
				kind: n,
				parentId: r?.id ?? null,
				sizeBytes: Number(e.plaintext_size) || 0,
				size: n === "folder" ? "Folder" : Et(Number(e.plaintext_size) || 0),
				modified: t ? "Deleted from LifeDrive" : new Date(i).toLocaleDateString(void 0, {
					month: "short",
					day: "numeric"
				}),
				modifiedAt: i,
				detail: "Stored on LifeDrive · Direct Leither File path",
				accent: Tt(n),
				protected: !0,
				mimeType: e.media_type,
				remoteId: e.original_path || e.object_id,
				trashPath: e.trash_path,
				trashedAt: t ? i : null
			};
		}
		async function vn(e) {
			if (e.blobId) {
				let t = await Cc(e.blobId);
				if (t) return t;
			}
			if (Tr()) return null;
			let t = e.remoteId ? m.value[e.remoteId] : void 0;
			if (!t) return null;
			try {
				let n = await cl(t), r = `remote_${t.object_id}`;
				return await Sc(r, n), e.blobId = r, n;
			} catch {
				return null;
			}
		}
		async function yn() {
			p.value = "connecting";
			try {
				Oe.value = (await Yc()).server_version ?? "";
				let [e, t] = await Promise.all([Qc(), $c().catch(() => [])]);
				e.sort((e, t) => e.path.split("/").length - t.path.split("/").length), m.value = Object.fromEntries(e.map((e) => [e.object_id, e]));
				for (let t of e) {
					let e = l.value.find((e) => e.id === t.object_id || e.remoteId === t.object_id || !e.trashedAt && mn(e) === t.path);
					if (e) {
						let n = gn(t);
						Object.assign(e, n, {
							id: e.id,
							blobId: e.blobId,
							trashedAt: null,
							originalParentId: void 0,
							trashPath: void 0,
							remoteId: t.object_id
						});
					} else l.value.push(gn(t));
				}
				for (let e of t) {
					let t = e.original_path || e.path, n = l.value.find((e) => e.remoteId === t || e.id === t);
					n ? (n.trashedAt = n.trashedAt || Date.now(), n.trashPath = e.trash_path, n.modified = "Deleted from LifeDrive", n.protected = !0) : l.value.push(gn(e, !0));
				}
				p.value = "connected", await H();
			} catch {
				p.value = "offline", Wc() || (h.value = null, g.value = "required");
			}
		}
		async function bn() {
			x.value = "demo-lifeDrive-file-mimei", g.value = "authenticated", p.value = "offline", await Tn();
		}
		async function xn() {
			if (!(y.value || !_.value.trim())) {
				y.value = !0, b.value = "";
				try {
					let e = await Kc(_.value, v.value);
					x.value = (await Jc()).drive_mid ?? "", h.value = e, v.value = "", g.value = "authenticated", await Promise.all([Tn(), yn()]);
				} catch (e) {
					await qc(), x.value = "", h.value = null;
					let t = e instanceof Error ? e.message : "";
					b.value = t.includes("not_owner") || t.includes("permission") ? "This Leither account is not a LifeDrive owner." : "The owner name or password was not accepted.";
				} finally {
					v.value = "", y.value = !1;
				}
			}
		}
		async function Sn() {
			if (!(g.value !== "authenticated" || w.value)) {
				w.value = !0, E.value = "";
				try {
					let e = await Xc();
					S.value = e, C.value = String(e.storage_max_gb || Math.max(1, Math.round(e.storage_max_bytes / 1e9))), D.value = e.usage_available ? e.restart_required : D.value || e.restart_required;
				} catch {
					E.value = "The storage limit is unavailable. Check that Leither can read its datastore configuration.";
				} finally {
					w.value = !1;
				}
			}
		}
		async function Cn() {
			let e = C.value.trim(), t = Number(e);
			if (w.value || !/^\d+$/.test(e) || !Number.isSafeInteger(t) || t <= 0) {
				E.value = "Enter a whole number of gigabytes greater than zero.";
				return;
			}
			w.value = !0, T.value = !0, E.value = "";
			try {
				let t = await Zc(e);
				S.value = t, C.value = String(t.storage_max_gb), D.value = !0, V("Storage limit saved. Restart the Leither service or the server to apply it.", 6500);
			} catch (e) {
				E.value = (e instanceof Error ? e.message : "").includes("limit_below_usage") ? "Choose a limit larger than the data already stored on this Leither node." : "The storage limit could not be saved on the Leither node.";
			} finally {
				T.value = !1, w.value = !1;
			}
		}
		function wn() {
			let e = dt.value;
			ke.value = e?.displayName || h.value?.username || "", Ae.value = e?.bio || "", je.value = e?.avatarDataUrl || "", Me.value = "", ne.value = "", N.value = "profile";
		}
		async function Tn() {
			let e = h.value;
			e && (ee.value = f.value[e.uid] ?? {
				uid: e.uid,
				displayName: "Local Owner",
				bio: "Keeping family memories close.",
				avatarDataUrl: "",
				updatedAt: Date.now()
			});
		}
		function En() {
			Ie.value?.click();
		}
		function Dn(e) {
			return new Promise((t, n) => {
				let r = new FileReader();
				r.onload = () => typeof r.result == "string" ? t(r.result) : n(/* @__PURE__ */ Error("invalid image")), r.onerror = () => n(r.error ?? /* @__PURE__ */ Error("image read failed")), r.readAsDataURL(e);
			});
		}
		async function On(e) {
			let t = e.target, n = t.files?.[0];
			if (t.value = "", n) {
				if (Me.value = "", ![
					"image/jpeg",
					"image/png",
					"image/webp",
					"image/gif",
					"image/avif"
				].includes(n.type)) {
					Me.value = "Choose a JPG, PNG, WebP, GIF, or AVIF image.";
					return;
				}
				if (n.size > 15e5) {
					Me.value = "Choose an image smaller than 1.5 MB.";
					return;
				}
				try {
					je.value = await Dn(n);
				} catch {
					Me.value = "That image could not be opened.";
				}
			}
		}
		function jn() {
			je.value = "", Me.value = "";
		}
		async function Mn() {
			let e = h.value, t = ke.value.trim();
			if (!e || !t) return;
			te.value = !0, ne.value = "";
			let n = {
				uid: e.uid,
				displayName: t,
				bio: Ae.value.trim(),
				avatarDataUrl: je.value,
				updatedAt: Date.now()
			};
			try {
				f.value = {
					...f.value,
					[e.uid]: n
				}, ee.value = n, V("Demo profile saved in this browser."), N.value = null;
			} catch {
				ne.value = "Your profile could not be saved on the LifeDrive node.";
			} finally {
				te.value = !1;
			}
		}
		async function Nn(e) {
			if (ge.value || !e.length) return !1;
			ge.value = !0;
			let t = e.map((e) => {
				let t = Dt(e.file);
				return {
					...e,
					kind: t,
					transfer: {
						id: `t_${crypto.randomUUID()}`,
						name: e.file.name,
						detail: `${Et(e.file.size)} · Waiting to upload`,
						progress: 1,
						status: "active",
						kind: t
					}
				};
			});
			u.value.unshift(...t.map((e) => e.transfer)), V(`${t.length} file${t.length === 1 ? " is" : "s are"} uploading in the background. Keep this page open until finished, especially for large files.`, 6500);
			let n = 0, r = 0;
			try {
				for (let { file: e, parentPath: i, parentId: a, kind: o, transfer: s } of t) {
					let t = `blob_${crypto.randomUUID()}`, c = `file_${crypto.randomUUID()}`, u = null;
					un(s.id, { detail: `${Et(e.size)} · Preparing upload` });
					try {
						await Sc(t, e);
						let r = Date.now();
						u = {
							id: c,
							name: e.name,
							kind: o,
							parentId: a,
							sizeBytes: e.size,
							size: Et(e.size),
							modified: "Just now",
							modifiedAt: r,
							detail: "Saved locally · Sending to LifeDrive",
							accent: Tt(o),
							protected: !1,
							blobId: t,
							mimeType: e.type
						}, l.value.unshift(u), un(s.id, { detail: `${Et(e.size)} · Sending to LifeDrive` });
						let d = await el(e, {
							parentPath: i,
							kind: o
						}, (t) => un(s.id, {
							progress: t,
							detail: `${Et(e.size)} · ${t >= 95 ? "Finalizing on your server" : "Sending to LifeDrive"}`
						}));
						m.value[d.object_id] = d, Object.assign(u, {
							detail: "Stored on LifeDrive · Direct Leither File path",
							protected: !0,
							remoteId: d.object_id
						}), p.value = "connected", un(s.id, {
							status: "complete",
							progress: 100,
							detail: `${Et(e.size)} · Stored on LifeDrive`
						}), n++;
					} catch (e) {
						let t = e instanceof Error ? e.message : "lifedrive.remote.unavailable";
						u && (u.detail = "Saved locally · LifeDrive upload failed"), un(s.id, {
							status: "failed",
							detail: `${u ? "Saved locally · " : ""}Upload failed · ${t}`
						}), p.value = "offline", r++;
					}
				}
			} finally {
				H(), ge.value = !1;
			}
			return r ? V(n ? `${n} uploaded; ${r} need${r === 1 ? "s" : ""} attention in Transfers.` : `${r} upload${r === 1 ? "" : "s"} failed. Open Transfers for details.`, 5200) : V(`${n} file${n === 1 ? "" : "s"} uploaded to LifeDrive.`), !0;
		}
		async function Pn() {
			if (ge.value || !he.value.length) return;
			let e = pn(Ke.value), t = ie.value, n = he.value.map((n) => ({
				file: n,
				parentPath: e,
				parentId: t
			}));
			he.value = [], N.value = null, await Nn(n);
		}
		async function Fn(e) {
			Pe = 0, Ne.value = !1;
			let t = e.dataTransfer;
			if (!t) return;
			if (ge.value) {
				V("An upload is already running. Drop these items again when it finishes.", 5200);
				return;
			}
			let n = pn(Ke.value), r = ie.value;
			try {
				let e = await sn(t);
				if (!e.files.length && !e.directories.length) {
					V("No readable files or folders were dropped.");
					return;
				}
				let i = [...new Set(e.directories)].sort((e, t) => e.split("/").length - t.split("/").length || e.localeCompare(t));
				if (i.length) {
					V(`Preparing ${i.length} folder${i.length === 1 ? "" : "s"} on LifeDrive…`, 5200);
					for (let e of i) {
						let t = e.split("/").filter(Boolean), r = t.pop();
						r && await tl(r, cn(n, t.join("/")));
					}
					await yn();
				}
				if (!e.files.length) {
					V(`${i.length} folder${i.length === 1 ? "" : "s"} added to LifeDrive.`);
					return;
				}
				await Nn(e.files.map(({ file: e, relativePath: t }) => {
					let i = cn(n, ln(t));
					return {
						file: e,
						parentPath: i,
						parentId: i === n ? r : l.value.find((e) => e.kind === "folder" && !e.trashedAt && (e.remoteId === i || mn(e) === i))?.id ?? r
					};
				})), i.length && await yn();
			} catch {
				V("The dropped items could not be prepared for upload.", 5200);
			}
		}
		function Ln(e) {
			ge.value && (e.preventDefault(), e.returnValue = "");
		}
		async function Rn() {
			let e = fe.value.trim();
			if (!e) return;
			let t = {
				id: `fld_${crypto.randomUUID()}`,
				name: e,
				kind: "folder",
				parentId: ie.value,
				sizeBytes: 0,
				size: "Empty folder",
				modified: "Just now",
				modifiedAt: Date.now(),
				detail: "Saved locally · Sending to LifeDrive",
				accent: "folder-new",
				protected: !1
			};
			l.value.unshift(t), fe.value = "", N.value = null;
			try {
				let n = await tl(e, pn(Ke.value));
				m.value[n.object_id] = n, Object.assign(t, {
					detail: "Stored on LifeDrive · Direct Leither File path",
					protected: !0,
					remoteId: n.object_id
				}), p.value = "connected", V(`${e} created on LifeDrive.`);
			} catch {
				t.detail = "Saved locally · LifeDrive folder creation failed", p.value = "offline", V(`${e} was saved locally.`);
			}
		}
		async function zn(e) {
			if (e.kind === "folder") return At(e);
			let t = De.value && location.hash === `#share=${De.value}` ? d.value.find((t) => t.token === De.value && t.itemId === e.id) : void 0;
			if (t && t.expiresAt <= Date.now()) return V("This share link has expired.");
			if (t && t.downloads >= t.maxDownloads) return V("This share link has reached its download limit.");
			let n = await vn(e);
			if (!n && e.demo && (n = new Blob([`Inoku demo item\nName: ${e.name}\n${e.detail}\n`], { type: "text/plain" })), !n) return V("The file could not be read from LifeDrive.");
			let r = URL.createObjectURL(n), i = document.createElement("a");
			i.href = r, i.download = e.name, i.style.display = "none", document.body.appendChild(i), i.click(), i.remove(), setTimeout(() => URL.revokeObjectURL(r), 1e3), t && (t.downloads += 1), V(t ? `${e.name} downloaded · ${t.maxDownloads - t.downloads} remaining.` : `${e.name} downloaded.`);
		}
		function Bn(e) {
			ue.value = e.id, pe.value = e.name, j.value = null, N.value = "rename";
		}
		async function Vn() {
			let e = B.value, t = pe.value.trim();
			if (!e || !t) return;
			let n = !!e.remoteId;
			if (l.value.some((n) => n.id !== e.id && n.parentId === e.parentId && !n.trashedAt && n.name === t)) return V("An item with that name already exists here.");
			try {
				if (e.remoteId) {
					let n = e.parentId ? l.value.find((t) => t.id === e.parentId) ?? null : null, r = await nl(e.remoteId, pn(n), t);
					hn(r.source_path, r.destination_path);
				}
				e.name = t, e.modified = "Just now", e.modifiedAt = Date.now(), N.value = null, V(n ? "Item renamed on LifeDrive." : "Item renamed locally.");
			} catch {
				V("Rename could not be completed on LifeDrive.");
			}
		}
		function Hn(e) {
			let t = new Set([e]), n = !0;
			for (; n;) {
				n = !1;
				for (let e of l.value) e.parentId && t.has(e.parentId) && !t.has(e.id) && (t.add(e.id), n = !0);
			}
			return t;
		}
		let Un = Q(() => {
			let e = B.value ? Hn(B.value.id) : /* @__PURE__ */ new Set();
			return l.value.filter((t) => t.kind === "folder" && !t.trashedAt && !e.has(t.id));
		}), Wn = Q(() => {
			let e = /* @__PURE__ */ new Set();
			for (let t of Xe.value) for (let n of Hn(t.id)) e.add(n);
			return l.value.filter((t) => t.kind === "folder" && !t.trashedAt && !e.has(t.id));
		}), Gn = Q(() => (F.value === "root" ? null : F.value) === ie.value);
		function Kn(e) {
			ue.value = e.id, F.value = e.parentId ?? "root", j.value = null, N.value = "move";
		}
		async function qn() {
			let e = B.value;
			if (!e) return;
			let t = !!e.remoteId, n = F.value === "root" ? null : F.value, r = n ? l.value.find((e) => e.id === n) ?? null : null;
			if (l.value.some((t) => t.id !== e.id && t.parentId === n && !t.trashedAt && t.name === e.name)) return V("An item with that name already exists there.");
			try {
				if (e.remoteId) {
					let t = await nl(e.remoteId, pn(r), e.name);
					hn(t.source_path, t.destination_path);
				}
				e.parentId = n, e.modified = "Just now", e.modifiedAt = Date.now(), N.value = null, A.value = null, V(t ? "Item moved on LifeDrive." : "Item moved locally.");
			} catch {
				V("Move could not be completed on LifeDrive.");
			}
		}
		function Jn(e) {
			if (e.kind === "folder") return `${e.name} copy`;
			let t = e.name.lastIndexOf(".");
			return t > 0 ? `${e.name.slice(0, t)} copy${e.name.slice(t)}` : `${e.name} copy`;
		}
		function Yn(e, t, n, r, i, a = !0) {
			let o = l.value.find((t) => t.id === e);
			if (!o) return [];
			let s = l.value.filter((t) => t.parentId === e && !t.trashedAt), c = `copy_${crypto.randomUUID()}`, u = o.remoteId && r && i && o.remoteId.startsWith(r) ? i + o.remoteId.slice(r.length) : void 0, d = {
				...o,
				id: c,
				name: a ? n : o.name,
				parentId: t,
				modified: "Just now",
				modifiedAt: Date.now(),
				protected: !!u,
				trashedAt: null,
				originalParentId: void 0,
				trashPath: void 0,
				remoteId: u
			};
			l.value.push(d);
			let f = [d];
			for (let e of s) f.push(...Yn(e.id, c, n, r, i, !1));
			return f;
		}
		async function Xn(e) {
			let t = Jn(e), n = e.parentId ? l.value.find((t) => t.id === e.parentId) ?? null : null;
			if (l.value.some((n) => n.parentId === e.parentId && !n.trashedAt && n.name === t)) return !1;
			if (e.remoteId) {
				let r = await rl(e.remoteId, pn(n), t);
				Yn(e.id, e.parentId, t, r.source_path, r.destination_path);
			} else Yn(e.id, e.parentId, t);
			return !0;
		}
		async function Zn(e) {
			j.value = null;
			let t = !!e.remoteId;
			try {
				V(await Xn(e) ? `${e.name} copied${t ? " on LifeDrive" : " locally"}.` : "A copy with that name already exists.");
			} catch {
				V("Copy could not be completed on LifeDrive.");
			}
		}
		async function Qn() {
			let e = [...Xe.value], t = 0;
			for (let n of e) try {
				await Xn(n) && t++;
			} catch {}
			_t(), V(`${t} of ${e.length} item${e.length === 1 ? "" : "s"} copied.`);
		}
		function $n() {
			Xe.value.length && (F.value = ie.value ?? "root", N.value = "batchMove");
		}
		async function er() {
			let e = [...Xe.value];
			if (!e.length) return;
			let t = F.value === "root" ? null : F.value, n = t ? l.value.find((e) => e.id === t) ?? null : null, r = Date.now(), i = 0;
			for (let a of e) try {
				if (a.remoteId) {
					let e = await nl(a.remoteId, pn(n), a.name);
					hn(e.source_path, e.destination_path);
				}
				a.parentId = t, a.modified = "Just now", a.modifiedAt = r, i++;
			} catch {}
			N.value = null, _t(), V(`${i} of ${e.length} item${e.length === 1 ? "" : "s"} moved.`);
		}
		function tr(e, t) {
			let n = Hn(e.id), r = Date.now();
			for (let e of l.value) n.has(e.id) && (e.trashedAt = r, e.originalParentId = e.parentId, e.modified = "Deleted just now", e.modifiedAt = r);
			e.trashPath = t;
		}
		async function nr(e) {
			let t;
			e.remoteId && (t = (await il(e.remoteId)).trash_path), tr(e, t);
		}
		async function rr(e) {
			let t = !!e.remoteId;
			try {
				await nr(e), A.value = null, j.value = null, V(`${e.name} moved to Trash${t ? " on LifeDrive" : " locally"}.`);
			} catch {
				V("The item could not be moved to Trash on LifeDrive.");
			}
		}
		async function ir() {
			let e = [...Xe.value];
			if (!e.length) return;
			let t = 0;
			for (let n of e) try {
				await nr(n), t++;
			} catch {}
			_t(), V(`${t} of ${e.length} item${e.length === 1 ? "" : "s"} moved to Trash.`);
		}
		async function ar(e) {
			let t = !!(e.remoteId && e.trashPath), n = e.remoteId?.slice(0, e.remoteId.lastIndexOf("/")) || "/", r = l.value.find((t) => !t.trashedAt && t.kind === "folder" && (t.id === e.originalParentId || t.remoteId === n)) ?? null;
			try {
				if (e.remoteId && e.trashPath) {
					let t = await al(e.trashPath, pn(r), e.name);
					hn(e.remoteId, t.destination_path);
				}
				for (let t of l.value) Hn(e.id).has(t.id) && (t.trashedAt = null);
				e.parentId = r?.id ?? null, e.trashPath = void 0, e.modified = "Restored just now", e.modifiedAt = Date.now(), V(`${e.name} restored${t ? " on LifeDrive" : " locally"}.`);
			} catch {
				V("The item could not be restored on LifeDrive.");
			}
		}
		async function or(e) {
			let t = l.value.filter((t) => e.has(t.id)), n = l.value.filter((t) => !e.has(t.id));
			l.value = n;
			let r = new Set(n.map((e) => e.blobId).filter(Boolean));
			for (let e of new Set(t.map((e) => e.blobId).filter(Boolean))) r.has(e) || await wc(e);
		}
		async function sr(e) {
			if (confirm(`Permanently delete “${e.name}”? This cannot be undone.`)) try {
				e.trashPath && await ol(e.trashPath), await or(Hn(e.id)), V(`${e.name} permanently removed from LifeDrive.`);
			} catch {
				V("Permanent deletion failed; the item remains in Trash.");
			}
		}
		async function cr() {
			if (!Qe.value.length || !confirm("Permanently remove every item in Trash?")) return;
			let e = [...Qe.value], t = e.length, n = 0;
			for (let t of e) try {
				t.trashPath && await ol(t.trashPath), await or(Hn(t.id)), n++;
			} catch {}
			V(n === t ? "Trash emptied." : `${n} of ${t} Trash items permanently removed.`);
		}
		function lr(e) {
			let t = new Date(e).getTimezoneOffset() * 6e4;
			return new Date(e - t).toISOString().slice(0, 16);
		}
		function ur(e) {
			let t = Math.floor(256 / e) * e, n = new Uint8Array(1);
			do
				crypto.getRandomValues(n);
			while (n[0] >= t);
			return n[0] % e;
		}
		function dr() {
			let e = "ABCDEFGHJKLMNPQRSTUVWXYZ", t = "abcdefghijkmnopqrstuvwxyz", n = "23456789", r = e + t + n, i = [
				e[ur(24)],
				t[ur(25)],
				n[ur(8)]
			];
			for (; i.length < 6;) i.push(r[ur(r.length)]);
			for (let e = i.length - 1; e > 0; e--) {
				let t = ur(e + 1);
				[i[e], i[t]] = [i[t], i[e]];
			}
			Ce.value = i.join("");
		}
		function fr(e) {
			ue.value = e.id, be.value = lr(Date.now() + 10080 * 60 * 1e3), xe.value = 10, Se.value = !1, Ce.value = "", we.value = "", _e.value = "", j.value = null, N.value = "share";
		}
		function pr() {
			Se.value = !Se.value, Se.value && !Ce.value && dr();
		}
		function mr() {
			let e = B.value, t = Date.parse(be.value);
			if (!e || !ut.value || !Number.isFinite(t)) return;
			let n = crypto.randomUUID(), r = {
				token: n,
				itemId: e.id,
				createdAt: Date.now(),
				expiresAt: t,
				maxDownloads: xe.value,
				downloads: 0
			};
			Se.value && (r.password = Ce.value), d.value.push(r), we.value = n, _e.value = `${location.origin}${location.pathname}#share=${n}`;
		}
		async function hr() {
			try {
				await navigator.clipboard.writeText(_e.value), N.value = null, V("Link copied to clipboard.");
			} catch {
				V("Copy the selected link manually.");
			}
		}
		async function gr() {
			let e = lt.value?.password ?? "";
			try {
				await navigator.clipboard.writeText(e), V("Share password copied.");
			} catch {
				V("Copy the password manually.");
			}
		}
		function _r() {
			vt("files"), Jt(), V("Choose the file again to restart its upload.");
		}
		function yr(e) {
			u.value = u.value.filter((t) => t.id !== e.id), le.value = null;
		}
		function br() {
			!at.value.length || !confirm("Clear completed transfers from this activity list?") || (u.value = u.value.filter((e) => e.status !== "complete"), V("Completed transfers cleared."));
		}
		function Sr(e) {
			se.value = e, e === "all" && (k.value = "all");
		}
		function Cr() {
			se.value = "all", k.value = "all", oe.value = "Recently modified";
		}
		function wr(e) {
			return l.value.find((t) => t.id === e.parentId)?.name ?? "Home";
		}
		function Tr() {
			return /^#share=([\w-]+)$/.test(location.hash);
		}
		function Er() {
			let e = location.hash.match(/^#share=([\w-]+)$/);
			if (e) {
				let t = d.value.find((t) => t.token === e[1]), n = t ? l.value.find((e) => e.id === t.itemId && !e.trashedAt) : void 0;
				if (ue.value = n?.id ?? null, Te.value = "", R.value = !1, De.value = "", !t || !n) Ee.value = "This share link is not available in this browser.", R.value = !0;
				else if (t.expiresAt <= Date.now()) Ee.value = "This share link has expired.", R.value = !0;
				else if (t.downloads >= t.maxDownloads) Ee.value = "This share link has reached its download limit.", R.value = !0;
				else if (t.password) {
					Ee.value = "", N.value = "shareAccess";
					return;
				} else {
					Dr(t, n);
					return;
				}
				N.value = "shareAccess";
				return;
			}
			let t = location.hash.match(/^#item=(.+)$/);
			if (!t) return;
			let n = l.value.find((e) => e.id === decodeURIComponent(t[1]) && !e.trashedAt);
			n && (ie.value = n.parentId, vt("files"), n.kind === "folder" ? At(n) : Wt(n));
		}
		function Dr(e, t) {
			N.value = null, De.value = e.token, ie.value = t.parentId, vt("files"), t.kind === "folder" ? At(t) : Wt(t), De.value = e.token;
		}
		function Or() {
			let e = location.hash.match(/^#share=([\w-]+)$/)?.[1], t = d.value.find((t) => t.token === e), n = t ? l.value.find((e) => e.id === t.itemId && !e.trashedAt) : void 0;
			if (!t || !n) return R.value = !0, Ee.value = "This share link is no longer available.";
			if (t.expiresAt <= Date.now()) return R.value = !0, Ee.value = "This share link has expired.";
			if (t.downloads >= t.maxDownloads) return R.value = !0, Ee.value = "This share link has reached its download limit.";
			if (Te.value !== t.password) return Ee.value = "That password is incorrect. Passwords are case-sensitive.";
			Ee.value = "", Dr(t, n);
		}
		function Ar(e) {
			(e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k" && (e.preventDefault(), vt("search"), _n(() => Le.value?.focus())), N.value === "preview" && (e.key === "ArrowLeft" || e.key === "ArrowRight") && (e.preventDefault(), Gt(e.key === "ArrowLeft" ? -1 : 1)), e.key === "Escape" && (N.value = null, A.value = null, j.value = null, M.value = !1, _t());
		}
		return vr(() => {
			addEventListener("keydown", Ar), addEventListener("hashchange", Er), addEventListener("beforeunload", Ln);
			let e = Tr();
			Er(), e ? p.value = "offline" : (Ot(), bn());
		}), xr(() => {
			removeEventListener("keydown", Ar), removeEventListener("hashchange", Er), removeEventListener("beforeunload", Ln), He && clearTimeout(He), Ue && clearTimeout(Ue), Vt();
			for (let e of Object.values(Re.value)) URL.revokeObjectURL(e);
		}), (e, t) => g.value !== "authenticated" && !Tr() ? (K(), q("div", ll, [J("section", ul, [t[100] ||= J("div", { class: "owner-auth-brand" }, [J("span", { class: "brand-mark" }, [J("span", { class: "brand-seed" })]), J("strong", null, "Inoku")], -1), g.value === "checking" ? (K(), q(G, { key: 0 }, [
			Y(W(Xs), {
				class: "preview-spinner owner-auth-spinner",
				size: 30
			}),
			t[92] ||= J("h1", { id: "owner-auth-title" }, "Checking your owner session…", -1),
			t[93] ||= J("p", null, "LifeDrive is confirming access with your Leither server.", -1)
		], 64)) : (K(), q("form", {
			key: 1,
			onSubmit: ns(xn, ["prevent"])
		}, [
			J("span", dl, [Y(W($s), { size: 29 })]),
			t[96] ||= J("p", { class: "eyebrow" }, "YOUR LIFEDRIVE", -1),
			t[97] ||= J("h1", { id: "owner-auth-title" }, "Sign in as the owner", -1),
			t[98] ||= J("p", null, "Your password stays on your Leither server. This browser keeps only an expiring session.", -1),
			J("label", fl, [t[94] ||= X("Owner name", -1), An(J("input", {
				"onUpdate:modelValue": t[0] ||= (e) => _.value = e,
				autocomplete: "username",
				autofocus: "",
				placeholder: "Your LifeDrive username"
			}, null, 512), [[Xo, _.value]])]),
			J("label", pl, [t[95] ||= X("Password", -1), An(J("input", {
				"onUpdate:modelValue": t[1] ||= (e) => v.value = e,
				type: "password",
				autocomplete: "current-password",
				placeholder: "Your Leither password"
			}, null, 512), [[Xo, v.value]])]),
			b.value ? (K(), q("p", ml, L(b.value), 1)) : Z("", !0),
			J("button", {
				class: "primary-button owner-auth-submit",
				type: "submit",
				disabled: y.value || !_.value.trim()
			}, [y.value ? (K(), ta(W(Xs), {
				key: 0,
				class: "preview-spinner",
				size: 17
			})) : (K(), ta(W(Ws), {
				key: 1,
				size: 17
			})), X(L(y.value ? "Signing in…" : "Open LifeDrive"), 1)], 8, hl),
			t[99] ||= J("small", null, [
				X("First time here? Run "),
				J("a", {
					href: "https://www.npmjs.com/package/@inoku/lifedrive",
					target: "_blank",
					rel: "noreferrer"
				}, "npx --yes @inoku/lifedrive"),
				X(" once on your Leither server. The node’s retained identity remains the recovery authority.")
			], -1)
		], 32))])])) : (K(), q("div", {
			key: 1,
			class: "app-shell",
			onClick: gt
		}, [
			J("aside", { class: I(["sidebar", { "sidebar-open": ye.value }]) }, [
				J("div", gl, [
					J("button", {
						class: "brand-mark",
						"aria-label": "Inoku home",
						onClick: yt
					}, [...t[101] ||= [J("span", { class: "brand-seed" }, null, -1)]]),
					J("button", {
						class: "brand-name",
						onClick: yt
					}, "Inoku"),
					J("button", {
						class: "icon-button sidebar-close",
						"aria-label": "Close menu",
						onClick: t[2] ||= (e) => ye.value = !1
					}, [Y(W(rc), { size: 20 })])
				]),
				J("nav", _l, [(K(!0), q(G, null, Mr(Ge.value, (e) => (K(), q("button", {
					key: e.id,
					class: I(["nav-item", { active: re.value === e.id }]),
					onClick: (t) => e.id === "files" ? yt() : vt(e.id)
				}, [
					(K(), ta(kr(e.icon), { size: 19 })),
					J("span", null, L(e.label), 1),
					e.badge ? (K(), q("span", yl, L(e.badge), 1)) : Z("", !0)
				], 10, vl))), 128))]),
				t[104] ||= J("div", { class: "sidebar-spacer" }, null, -1),
				J("section", bl, [
					J("div", xl, [t[102] ||= J("span", null, "Local storage", -1), J("span", null, L(Et(et.value)) + " in this browser", 1)]),
					J("div", Sl, [J("span", { style: me({ width: `${Math.min(100, et.value / 1e7)}%` }) }, null, 4)]),
					J("button", { onClick: t[3] ||= (e) => vt("settings") }, [t[103] ||= X("View storage ", -1), Y(W(xs), { size: 14 })])
				]),
				J("button", {
					class: "profile-card",
					onClick: wn
				}, [
					J("span", { class: I(["avatar", { "avatar-has-image": pt.value }]) }, [pt.value ? (K(), q("img", {
						key: 0,
						src: pt.value,
						alt: ""
					}, null, 8, Cl)) : (K(), q(G, { key: 1 }, [X(L(mt.value), 1)], 64))], 2),
					J("span", wl, [J("strong", null, L(ft.value), 1), J("small", null, "@" + L(h.value?.username), 1)]),
					Y(W(Es), { size: 18 })
				])
			], 2),
			ye.value ? (K(), q("div", {
				key: 0,
				class: "sidebar-scrim",
				onClick: t[4] ||= (e) => ye.value = !1
			})) : Z("", !0),
			J("main", Tl, [J("header", El, [
				J("button", {
					class: "icon-button mobile-menu",
					"aria-label": "Open menu",
					onClick: t[5] ||= (e) => ye.value = !0
				}, [Y(W(Gs), { size: 21 })]),
				J("label", Dl, [
					Y(W(Zs), { size: 18 }),
					An(J("input", {
						ref_key: "searchInput",
						ref: Le,
						"onUpdate:modelValue": t[6] ||= (e) => O.value = e,
						type: "search",
						placeholder: "Search your drive",
						"aria-label": "Search your drive",
						onFocus: t[7] ||= (e) => re.value = "search"
					}, null, 544), [[Xo, O.value]]),
					t[105] ||= J("kbd", null, "⌘ K", -1)
				]),
				J("div", Ol, [
					ct.value ? (K(), q("button", {
						key: 0,
						class: "update-available-button",
						"aria-label": "Update available",
						onClick: t[8] ||= (e) => N.value = "update"
					}, [Y(W(_s), { size: 16 }), t[106] ||= J("span", null, "Update available", -1)])) : Z("", !0),
					J("span", { class: I(["connection-pill", p.value]) }, [t[107] ||= J("span", null, null, -1), X(L(ot.value), 1)], 2),
					J("button", {
						class: "icon-button",
						"aria-label": "Help",
						onClick: t[9] ||= (e) => N.value = "help"
					}, [Y(W(Ss), { size: 19 })]),
					J("button", {
						class: I(["avatar avatar-button", { "avatar-has-image": pt.value }]),
						"aria-label": "Open profile",
						onClick: wn
					}, [pt.value ? (K(), q("img", {
						key: 0,
						src: pt.value,
						alt: ""
					}, null, 8, kl)) : (K(), q(G, { key: 1 }, [X(L(mt.value), 1)], 64))], 2)
				])
			]), J("div", Al, [re.value === "files" ? (K(), q("section", {
				key: 0,
				class: "page page-files",
				onDragenter: ns(en, ["prevent"]),
				onDragover: ns(tn, ["prevent"]),
				onDragleave: nn,
				onDrop: ns(Fn, ["prevent"])
			}, [
				Ne.value ? (K(), q("div", jl, [
					J("span", null, [Y(W(nc), { size: 38 })]),
					J("strong", null, "Drop to upload to " + L(Ke.value?.name ?? "Files"), 1),
					t[108] ||= J("p", null, "Files upload immediately. Folder structure is preserved.", -1)
				])) : Z("", !0),
				J("div", Ml, [J("div", Nl, [J("div", null, [t[109] ||= J("p", { class: "eyebrow" }, "MY DRIVE", -1), J("h1", null, L(Ke.value?.name ?? "Files"), 1)]), J("button", {
					class: "local-save-status",
					onClick: t[10] ||= (e) => N.value = "info"
				}, [
					Y(W($s), { size: 16 }),
					J("span", null, L(st.value), 1),
					Y(W(xs), { size: 14 })
				])]), J("div", Pl, [J("div", {
					class: "add-action-wrap",
					onClick: t[13] ||= ns(() => {}, ["stop"])
				}, [J("button", {
					class: "primary-button",
					onClick: t[11] ||= (e) => M.value = !M.value
				}, [
					Y(W(Js), { size: 18 }),
					t[110] ||= X("Add ", -1),
					Y(W(bs), { size: 15 })
				]), M.value ? (K(), q("div", Fl, [J("button", { onClick: Jt }, [Y(W(nc), { size: 17 }), t[111] ||= X("Upload files", -1)]), J("button", { onClick: t[12] ||= (e) => {
					N.value = "folder", M.value = !1;
				} }, [Y(W(Rs), { size: 17 }), t[112] ||= X("New folder", -1)])])) : Z("", !0)])])]),
				J("div", Il, [J("div", Ll, [
					J("button", { onClick: t[14] ||= (e) => ie.value = null }, "Home"),
					(K(!0), q(G, null, Mr(qe.value, (e) => (K(), q(G, { key: e.id }, [Y(W(xs), { size: 14 }), J("button", { onClick: (t) => ie.value = e.id }, L(e.name), 9, Rl)], 64))), 128)),
					J("span", zl, L(Ye.value.length) + " item" + L(Ye.value.length === 1 ? "" : "s"), 1)
				]), J("div", Bl, [
					J("button", {
						class: I(["select-mode-button", { active: P.value }]),
						onClick: t[15] ||= (e) => P.value ? _t() : Nt()
					}, L(P.value ? "Cancel" : "Select"), 3),
					J("label", Vl, [Y(W(ec), { size: 16 }), An(J("select", {
						"onUpdate:modelValue": t[16] ||= (e) => oe.value = e,
						"aria-label": "Sort files"
					}, [...t[113] ||= [
						J("option", null, "Recently modified", -1),
						J("option", null, "Name", -1),
						J("option", null, "Size", -1),
						J("option", null, "Type", -1)
					]], 512), [[Zo, oe.value]])]),
					J("div", Hl, [J("button", {
						"aria-label": "Grid view",
						class: I({ active: ae.value === "grid" }),
						onClick: t[17] ||= (e) => ae.value = "grid"
					}, [Y(W(zs), { size: 17 })], 2), J("button", {
						"aria-label": "List view",
						class: I({ active: ae.value === "list" }),
						onClick: t[18] ||= (e) => ae.value = "list"
					}, [Y(W(Hs), { size: 18 })], 2)])
				])]),
				P.value ? (K(), q("div", Ul, [
					J("strong", null, L(Xe.value.length) + " selected", 1),
					J("button", {
						class: "text-button",
						onClick: Pt
					}, L(de.value.size === Ye.value.length ? "Clear all" : "Select all"), 1),
					t[117] ||= J("span", null, null, -1),
					J("button", {
						disabled: !Xe.value.length,
						onClick: $n
					}, [Y(W(Ks), { size: 16 }), t[114] ||= X("Move", -1)], 8, Wl),
					J("button", {
						disabled: !Xe.value.length,
						onClick: Qn
					}, [Y(W(ws), { size: 16 }), t[115] ||= X("Copy", -1)], 8, Gl),
					J("button", {
						class: "selection-delete",
						disabled: !Xe.value.length,
						onClick: ir
					}, [Y(W(tc), { size: 16 }), t[116] ||= X("Move to Trash", -1)], 8, Kl)
				])) : Z("", !0),
				Ye.value.length && ae.value === "grid" ? (K(), q("div", ql, [(K(!0), q(G, null, Mr(Ye.value, (e) => (K(), q("article", {
					key: e.id,
					class: I(["file-card", {
						selected: P.value ? de.value.has(e.id) : A.value?.id === e.id,
						selecting: P.value
					}]),
					tabindex: "0",
					"aria-selected": P.value ? de.value.has(e.id) : void 0,
					onClick: (t) => Ft(e),
					onDblclick: ns((t) => It(e), ["stop"]),
					onKeydown: is((t) => Lt(e), ["enter"])
				}, [
					J("div", {
						class: I(["thumbnail", [e.accent, wt(e.name, e.kind, e.mimeType)]]),
						"data-file-badge": Ct(e.name, e.kind, e.mimeType)
					}, [
						P.value ? (K(), q("button", {
							key: 0,
							class: I(["selection-check", { checked: de.value.has(e.id) }]),
							"aria-label": `${de.value.has(e.id) ? "Deselect" : "Select"} ${e.name}`,
							onClick: ns((t) => Mt(e), ["stop"])
						}, [de.value.has(e.id) ? (K(), ta(W(ys), {
							key: 0,
							size: 15
						})) : Z("", !0)], 10, Xl)) : Z("", !0),
						Re.value[e.id] ? (K(), q("img", {
							key: 1,
							class: "content-thumbnail",
							src: Re.value[e.id],
							alt: e.name
						}, null, 8, Zl)) : [
							"folder",
							"pdf",
							"file"
						].includes(e.kind) ? (K(), ta(kr(St(e.name, e.kind, e.mimeType)), {
							key: 2,
							size: 48
						})) : e.kind === "image" ? (K(), q("span", Ql)) : e.kind === "audio" ? (K(), q("span", $l, [(K(), q(G, null, Mr(9, (e) => J("i", { key: e })), 64))])) : Z("", !0),
						["video", "audio"].includes(e.kind) ? (K(), q("span", eu, [Y(W(qs), {
							size: 21,
							fill: "currentColor"
						})])) : Z("", !0),
						P.value ? Z("", !0) : (K(), q("button", {
							key: 6,
							class: "card-menu visible",
							"aria-label": `More actions for ${e.name}`,
							onClick: ns((t) => j.value = j.value === e.id ? null : e.id, ["stop"])
						}, [Y(W(Es), { size: 18 })], 8, tu))
					], 10, Yl),
					!P.value && j.value === e.id ? (K(), q("div", {
						key: 0,
						class: "item-action-menu card-action-menu",
						role: "menu",
						onClick: t[19] ||= ns((e) => j.value = null, ["stop"])
					}, [
						e.kind === "folder" ? (K(), q("button", {
							key: 0,
							onClick: (t) => At(e)
						}, "Open", 8, nu)) : Z("", !0),
						J("button", { onClick: (t) => fr(e) }, [Y(W(Us), { size: 16 }), t[118] ||= X("Share", -1)], 8, ru),
						e.kind === "folder" ? Z("", !0) : (K(), q("button", {
							key: 1,
							onClick: (t) => zn(e)
						}, "Download", 8, iu)),
						J("button", { onClick: (t) => Bn(e) }, "Rename", 8, au),
						J("button", { onClick: (t) => Kn(e) }, [Y(W(Ks), { size: 16 }), t[119] ||= X("Move", -1)], 8, ou),
						J("button", { onClick: (t) => Zn(e) }, [Y(W(ws), { size: 16 }), t[120] ||= X("Copy", -1)], 8, su),
						J("button", {
							class: "danger-menu-item",
							onClick: (t) => rr(e)
						}, [Y(W(tc), { size: 16 }), t[121] ||= X("Move to Trash", -1)], 8, cu)
					])) : Z("", !0),
					J("div", lu, [J("strong", null, L(e.name), 1), J("span", null, L(e.size) + " · " + L(e.modified), 1)]),
					J("span", { class: I(["status-dot", e.protected ? "protected" : "pending"]) }, null, 2)
				], 42, Jl))), 128))])) : Ye.value.length ? (K(), q("div", uu, [t[123] ||= J("div", { class: "file-list-head" }, [
					J("span", null, "Name"),
					J("span", null, "Modified"),
					J("span", null, "Size"),
					J("span", null, "Status")
				], -1), (K(!0), q(G, null, Mr(Ye.value, (e) => (K(), q("div", {
					key: e.id,
					class: I(["file-row file-row-functional", { selected: P.value && de.value.has(e.id) }])
				}, [
					J("button", {
						class: "row-main-button",
						"aria-pressed": P.value ? de.value.has(e.id) : void 0,
						onClick: (t) => Ft(e),
						onDblclick: ns((t) => It(e), ["stop"]),
						onKeydown: is((t) => Lt(e), ["enter"])
					}, [
						J("span", fu, [
							P.value ? (K(), q("span", {
								key: 0,
								class: I(["selection-check inline", { checked: de.value.has(e.id) }])
							}, [de.value.has(e.id) ? (K(), ta(W(ys), {
								key: 0,
								size: 13
							})) : Z("", !0)], 2)) : Z("", !0),
							J("span", {
								class: I(["row-icon", [e.accent, wt(e.name, e.kind, e.mimeType)]]),
								"data-file-badge": Ct(e.name, e.kind, e.mimeType)
							}, [Re.value[e.id] ? (K(), q("img", {
								key: 0,
								class: "row-thumbnail",
								src: Re.value[e.id],
								alt: e.name
							}, null, 8, mu)) : (K(), ta(kr(St(e.name, e.kind, e.mimeType)), {
								key: 1,
								size: 28
							})), ["video", "audio"].includes(e.kind) ? (K(), q("span", hu, [Y(W(qs), {
								size: 10,
								fill: "currentColor"
							})])) : Z("", !0)], 10, pu),
							J("strong", null, L(e.name), 1)
						]),
						J("span", null, L(e.modified), 1),
						J("span", null, L(e.size), 1),
						J("span", gu, L(e.protected ? "Protected" : "Pending"), 1)
					], 40, du),
					P.value ? Z("", !0) : (K(), q("button", {
						key: 0,
						class: "icon-button row-more",
						"aria-label": `More actions for ${e.name}`,
						onClick: ns((t) => j.value = j.value === e.id ? null : e.id, ["stop"])
					}, [Y(W(Es), { size: 18 })], 8, _u)),
					!P.value && j.value === e.id ? (K(), q("div", {
						key: 1,
						class: "item-action-menu list-menu",
						onClick: t[20] ||= ns((e) => j.value = null, ["stop"])
					}, [
						e.kind === "folder" ? (K(), q("button", {
							key: 0,
							onClick: (t) => At(e)
						}, "Open", 8, vu)) : Z("", !0),
						J("button", { onClick: (t) => fr(e) }, [Y(W(Us), { size: 16 }), t[122] ||= X("Share", -1)], 8, yu),
						e.kind === "folder" ? Z("", !0) : (K(), q("button", {
							key: 1,
							onClick: (t) => zn(e)
						}, "Download", 8, bu)),
						J("button", { onClick: (t) => Bn(e) }, "Rename", 8, xu),
						J("button", { onClick: (t) => Kn(e) }, "Move", 8, Su),
						J("button", { onClick: (t) => Zn(e) }, "Copy", 8, Cu),
						J("button", {
							class: "danger-menu-item",
							onClick: (t) => rr(e)
						}, "Move to Trash", 8, wu)
					])) : Z("", !0)
				], 2))), 128))])) : (K(), q("div", Tu, [
					J("span", null, [Y(W(Rs), { size: 25 })]),
					t[125] ||= J("h3", null, "This folder is empty", -1),
					t[126] ||= J("p", null, "Upload a file or create a folder.", -1),
					J("button", {
						class: "primary-button",
						onClick: Jt
					}, [Y(W(nc), { size: 17 }), t[124] ||= X("Upload files", -1)])
				]))
			], 32)) : re.value === "search" ? (K(), q("section", Eu, [
				J("div", Du, [t[128] ||= J("div", null, [J("p", { class: "eyebrow" }, "FIND A FILE"), J("h1", null, "Search")], -1), J("button", {
					class: "secondary-button",
					onClick: t[21] ||= (e) => ce.value = !ce.value
				}, [Y(W(ec), { size: 17 }), t[127] ||= X("Filters", -1)])]),
				J("label", Ou, [
					Y(W(Zs), { size: 24 }),
					An(J("input", {
						"onUpdate:modelValue": t[22] ||= (e) => O.value = e,
						placeholder: "Try a name or file type"
					}, null, 512), [[Xo, O.value]]),
					O.value ? (K(), q("button", {
						key: 0,
						"aria-label": "Clear search",
						onClick: t[23] ||= (e) => O.value = ""
					}, [Y(W(rc), { size: 18 })])) : Z("", !0)
				]),
				J("div", ku, [
					J("button", {
						class: I({ active: se.value === "all" }),
						onClick: t[24] ||= (e) => Sr("all")
					}, "Everything", 2),
					J("button", {
						class: I({ active: se.value === "image" }),
						onClick: t[25] ||= (e) => Sr("image")
					}, "Photos", 2),
					J("button", {
						class: I({ active: se.value === "video" }),
						onClick: t[26] ||= (e) => Sr("video")
					}, "Videos", 2),
					J("button", {
						class: I({ active: se.value === "pdf" }),
						onClick: t[27] ||= (e) => Sr("pdf")
					}, "Documents", 2),
					J("button", {
						class: I({ active: se.value === "audio" }),
						onClick: t[28] ||= (e) => Sr("audio")
					}, "Audio", 2)
				]),
				ce.value ? (K(), q("div", Au, [
					J("label", null, [t[130] ||= X("Protection", -1), An(J("select", { "onUpdate:modelValue": t[29] ||= (e) => k.value = e }, [...t[129] ||= [
						J("option", { value: "all" }, "Any status", -1),
						J("option", { value: "protected" }, "Protected", -1),
						J("option", { value: "pending" }, "Pending", -1)
					]], 512), [[Zo, k.value]])]),
					J("label", null, [t[132] ||= X("Sort", -1), An(J("select", { "onUpdate:modelValue": t[30] ||= (e) => oe.value = e }, [...t[131] ||= [
						J("option", null, "Recently modified", -1),
						J("option", null, "Name", -1),
						J("option", null, "Size", -1),
						J("option", null, "Type", -1)
					]], 512), [[Zo, oe.value]])]),
					J("button", {
						class: "text-button clear-filters",
						onClick: Cr
					}, "Clear filters")
				])) : Z("", !0),
				J("div", ju, [J("h2", null, L(O.value ? `${Ze.value.length} results` : "Suggested from your drive"), 1)]),
				J("div", Mu, [(K(!0), q(G, null, Mr(Ze.value, (e) => (K(), q("button", {
					key: e.id,
					class: "search-result",
					onClick: (t) => e.kind === "folder" ? At(e) : Wt(e)
				}, [
					J("span", {
						class: I(["result-thumb", [e.accent, wt(e.name, e.kind, e.mimeType)]]),
						"data-file-badge": Ct(e.name, e.kind, e.mimeType)
					}, [Re.value[e.id] ? (K(), q("img", {
						key: 0,
						src: Re.value[e.id],
						alt: e.name
					}, null, 8, Fu)) : (K(), ta(kr(St(e.name, e.kind, e.mimeType)), {
						key: 1,
						size: 28
					})), ["video", "audio"].includes(e.kind) ? (K(), q("span", Iu, [Y(W(qs), {
						size: 10,
						fill: "currentColor"
					})])) : Z("", !0)], 10, Pu),
					J("span", Lu, [J("strong", null, L(e.name), 1), J("small", null, L(e.detail), 1)]),
					Y(W(xs), { size: 17 })
				], 8, Nu))), 128)), Ze.value.length ? Z("", !0) : (K(), q("div", Ru, [...t[133] ||= [J("h3", null, "No files found", -1), J("p", null, "Try another name or filter.", -1)]]))])
			])) : re.value === "transfers" ? (K(), q("section", zu, [
				J("div", Bu, [t[135] ||= J("div", null, [
					J("p", { class: "eyebrow" }, "ACTIVITY"),
					J("h1", null, "Transfers"),
					J("p", null, "Only uploads performed in this browser appear here.")
				], -1), J("button", {
					class: "secondary-button",
					disabled: !it.value.length,
					onClick: _r
				}, [Y(W(nc), { size: 17 }), t[134] ||= X("Upload failed file again", -1)], 8, Vu)]),
				J("div", Hu, [
					J("div", Uu, [t[136] ||= J("h2", null, "In progress", -1), J("span", null, L(rt.value.length ? `${rt.value.length} active` : "Idle"), 1)]),
					(K(!0), q(G, null, Mr(rt.value, (e) => (K(), q("article", {
						key: e.id,
						class: "transfer-row compact"
					}, [
						J("span", {
							class: I(["transfer-type", [Tt(e.kind), wt(e.name, e.kind)]]),
							"data-file-badge": Ct(e.name, e.kind)
						}, [(K(), ta(kr(St(e.name, e.kind)), { size: 25 }))], 10, Wu),
						J("div", Gu, [
							J("div", null, [J("strong", null, L(e.name), 1), J("span", null, L(e.detail), 1)]),
							J("div", Ku, [J("span", { style: me({ width: `${e.progress}%` }) }, null, 4)]),
							J("small", null, L(e.progress) + "%", 1)
						]),
						Y(W(Xs), {
							class: "preview-spinner",
							size: 17
						})
					]))), 128)),
					rt.value.length ? Z("", !0) : (K(), q("div", qu, [...t[137] ||= [J("h3", null, "Nothing is being transferred", -1), J("p", null, "New uploads will appear here while they are being saved.", -1)]]))
				]),
				it.value.length ? (K(), q("div", Ju, [t[138] ||= J("div", { class: "panel-heading" }, [J("h2", null, "Needs attention")], -1), (K(!0), q(G, null, Mr(it.value, (e) => (K(), q("article", {
					key: e.id,
					class: "transfer-row compact"
				}, [
					J("span", {
						class: I(["transfer-type", [Tt(e.kind), wt(e.name, e.kind)]]),
						"data-file-badge": Ct(e.name, e.kind)
					}, [(K(), ta(kr(St(e.name, e.kind)), { size: 25 }))], 10, Yu),
					J("div", Xu, [J("strong", null, L(e.name), 1), J("span", null, L(e.detail), 1)]),
					J("button", {
						class: "text-button",
						onClick: _r
					}, "Choose again"),
					J("button", {
						class: "icon-button",
						"aria-label": "Remove transfer record",
						onClick: (t) => yr(e)
					}, [Y(W(rc), { size: 17 })], 8, Zu)
				]))), 128))])) : Z("", !0),
				J("div", Qu, [
					J("div", $u, [t[139] ||= J("h2", null, "Completed", -1), J("button", {
						disabled: !at.value.length,
						onClick: br
					}, "Clear history", 8, ed)]),
					(K(!0), q(G, null, Mr(at.value, (e) => (K(), q("article", {
						key: e.id,
						class: "transfer-row compact"
					}, [
						J("span", {
							class: I(["transfer-type", [Tt(e.kind), wt(e.name, e.kind)]]),
							"data-file-badge": Ct(e.name, e.kind)
						}, [(K(), ta(kr(St(e.name, e.kind)), { size: 25 }))], 10, td),
						J("div", nd, [J("strong", null, L(e.name), 1), J("span", null, L(e.detail), 1)]),
						Y(W(ys), { size: 17 })
					]))), 128)),
					at.value.length ? Z("", !0) : (K(), q("div", rd, [...t[140] ||= [J("p", null, "No completed uploads in this browser.", -1)]]))
				])
			])) : re.value === "trash" ? (K(), q("section", id, [
				J("div", ad, [t[142] ||= J("div", null, [
					J("p", { class: "eyebrow" }, "RECOVERY"),
					J("h1", null, "Trash"),
					J("p", null, "Restore an item or remove it permanently.")
				], -1), J("button", {
					class: "danger-quiet",
					disabled: !Qe.value.length,
					onClick: cr
				}, [Y(W(tc), { size: 17 }), t[141] ||= X("Empty trash", -1)], 8, od)]),
				J("div", sd, [Y(W(Vs), { size: 18 }), t[143] ||= X("Permanent deletion cannot be undone.", -1)]),
				J("div", cd, [
					t[146] ||= J("div", { class: "file-list-head" }, [
						J("span", null, "Name"),
						J("span", null, "Deleted"),
						J("span", null, "Size"),
						J("span")
					], -1),
					(K(!0), q(G, null, Mr(Qe.value, (e) => (K(), q("div", {
						key: e.id,
						class: "trash-row"
					}, [
						J("span", ld, [J("span", {
							class: I(["row-icon", [e.accent, wt(e.name, e.kind, e.mimeType)]]),
							"data-file-badge": Ct(e.name, e.kind, e.mimeType)
						}, [(K(), ta(kr(St(e.name, e.kind, e.mimeType)), { size: 23 }))], 10, ud), J("span", null, [J("strong", null, L(e.name), 1), J("small", null, L(e.detail), 1)])]),
						J("span", null, L(e.modified), 1),
						J("span", null, L(e.size), 1),
						J("span", dd, [J("button", { onClick: (t) => ar(e) }, [Y(W(ms), { size: 16 }), t[144] ||= X("Restore", -1)], 8, fd), J("button", {
							class: "danger-text-button",
							onClick: (t) => sr(e)
						}, "Delete forever", 8, pd)])
					]))), 128)),
					Qe.value.length ? Z("", !0) : (K(), q("div", md, [...t[145] ||= [J("h3", null, "Trash is empty", -1)]]))
				])
			])) : (K(), q("section", hd, [
				t[166] ||= J("div", { class: "page-title-row" }, [J("div", null, [
					J("p", { class: "eyebrow" }, "YOUR INOKU"),
					J("h1", null, "Settings & protection"),
					J("p", null, "Your files stay private on this Leither node and are not published or advertised to other providers.")
				])], -1),
				J("div", gd, [J("section", _d, [
					J("div", vd, [J("div", null, [t[147] ||= J("p", { class: "eyebrow" }, "STATUS", -1), J("h2", null, L(p.value === "connected" ? "LifeDrive + local cache" : "Local cache"), 1)]), Y(W($s), { size: 30 })]),
					t[149] ||= J("p", null, "Completed changes are committed to your local File MiMei. IndexedDB keeps a browser cache for faster previews.", -1),
					J("button", {
						class: "text-button",
						onClick: t[31] ||= (e) => N.value = "info"
					}, [t[148] ||= X("View technical details ", -1), Y(W(xs), { size: 15 })])
				]), J("section", yd, [J("div", bd, [J("div", null, [t[150] ||= J("p", { class: "eyebrow" }, "DRIVE CONTENT", -1), J("h2", null, L(Et(et.value)) + " in files", 1)]), t[151] ||= J("span", null, "Private", -1)]), J("div", xd, [J("div", null, [J("strong", null, L(l.value.filter((e) => !e.trashedAt).length), 1), t[152] ||= J("small", null, "items", -1)])])])]),
				J("section", Sd, [
					J("div", Cd, [t[153] ||= J("div", null, [J("p", { class: "eyebrow" }, "SERVER CAPACITY"), J("h2", null, "Leither storage limit")], -1), S.value ? (K(), q("span", wd, L(S.value.storage_max), 1)) : Z("", !0)]),
					S.value ? (K(), q("div", Td, [
						J("div", null, [J("strong", null, L(Et(tt.value)) + " used", 1), J("span", null, "of " + L(S.value.storage_max), 1)]),
						J("div", Ed, [J("span", { style: me({ width: `${nt.value}%` }) }, null, 4)]),
						J("small", null, L(S.value.usage_available ? "Usage reported by Leither" : "Usage shown from files visible in this browser"), 1)
					])) : Z("", !0),
					J("div", Dd, [J("label", null, [t[155] ||= J("span", null, "Maximum storage", -1), J("div", null, [An(J("input", {
						"onUpdate:modelValue": t[32] ||= (e) => C.value = e,
						inputmode: "numeric",
						pattern: "[0-9]*",
						"aria-label": "Maximum storage in gigabytes"
					}, null, 512), [[Xo, C.value]]), t[154] ||= J("strong", null, "GB", -1)])]), J("button", {
						class: "primary-button",
						disabled: w.value || !C.value,
						onClick: Cn
					}, [w.value ? (K(), ta(W(Xs), {
						key: 0,
						class: "preview-spinner",
						size: 16
					})) : Z("", !0), X(L(T.value ? "Saving…" : w.value ? "Loading…" : "Save limit"), 1)], 8, Od)]),
					J("p", kd, [Y(W(Vs), { size: 17 }), t[156] ||= J("span", null, "This is the limit for all data stored by this Leither node, including LifeDrive. LifeDrive will not restart anything automatically.", -1)]),
					D.value ? (K(), q("p", Ad, [Y(W(ys), { size: 17 }), t[157] ||= X("Saved. Restart the Leither service—or restart the server—to use the new limit.", -1)])) : Z("", !0),
					E.value ? (K(), q("p", jd, L(E.value), 1)) : Z("", !0)
				]),
				J("section", Md, [
					J("div", Nd, [t[159] ||= J("div", null, [J("p", { class: "eyebrow" }, "SERVER TARGET"), J("h2", null, "LifeDrive on Leither")], -1), J("span", { class: I(["connection-pill", p.value]) }, [t[158] ||= J("span", null, null, -1), X(L(ot.value), 1)], 2)]),
					J("div", Pd, [J("span", null, [
						J("i", null, [Y(W(Bs), { size: 18 })]),
						t[160] ||= J("small", null, "App ID", -1),
						J("strong", Fd, L(W(fc)), 1)
					]), J("span", null, [
						J("i", null, [Y(W(Cs), { size: 18 })]),
						t[161] ||= J("small", null, "Node", -1),
						J("strong", null, L(W(pc)), 1)
					])]),
					J("div", Id, [
						Y(W($s), { size: 17 }),
						t[162] ||= J("p", null, [
							J("strong", null, "Native owner authentication"),
							J("br"),
							X("Leither verifies the expiring browser session and the owner’s MiMei rights before every operation.")
						], -1),
						J("button", { onClick: t[33] ||= (e) => N.value = "info" }, "Learn more")
					])
				]),
				J("section", Ld, [J("div", Rd, [t[163] ||= J("div", null, [J("p", { class: "eyebrow" }, "ACCESS MODEL"), J("h2", null, "Household drive")], -1), Y(W(Ws), { size: 22 })]), J("div", zd, [
					J("span", null, [Y(W(Bs), { size: 20 })]),
					J("div", null, [J("strong", null, L(ft.value), 1), J("small", null, "@" + L(h.value?.username) + " · The password remains on this physically owned Leither node.", 1)]),
					J("span", Bd, [Y(W($s), { size: 16 }), t[164] ||= X("Owner", -1)]),
					t[165] ||= J("span", null, null, -1)
				])])
			]))])]),
			A.value ? (K(), q("aside", Vd, [
				J("div", Hd, [t[167] ||= J("span", null, "Details", -1), J("button", {
					class: "icon-button",
					"aria-label": "Close details",
					onClick: t[34] ||= (e) => A.value = null
				}, [Y(W(rc), { size: 19 })])]),
				J("div", {
					class: I(["detail-preview", [A.value.accent, wt(A.value.name, A.value.kind, A.value.mimeType)]]),
					"data-file-badge": Ct(A.value.name, A.value.kind, A.value.mimeType)
				}, [Re.value[A.value.id] ? (K(), q("img", {
					key: 0,
					src: Re.value[A.value.id],
					alt: A.value.name
				}, null, 8, Wd)) : (K(), ta(kr(St(A.value.name, A.value.kind, A.value.mimeType)), {
					key: 1,
					size: 68
				})), ["video", "audio"].includes(A.value.kind) ? (K(), q("span", Gd, [Y(W(qs), {
					size: 25,
					fill: "currentColor"
				})])) : Z("", !0)], 10, Ud),
				J("div", Kd, [
					J("div", qd, [(K(), ta(kr(St(A.value.name, A.value.kind, A.value.mimeType)), { size: 22 })), J("h2", null, L(A.value.name), 1)]),
					J("p", null, L(A.value.detail), 1),
					J("div", Jd, [
						A.value.kind === "folder" ? (K(), q("button", {
							key: 0,
							onClick: t[35] ||= (e) => At(A.value)
						}, [Y(W(Rs), { size: 17 }), t[168] ||= X("Open", -1)])) : (K(), q("button", {
							key: 1,
							onClick: t[36] ||= (e) => Wt(A.value)
						}, [Y(W(qs), { size: 17 }), t[169] ||= X("Preview", -1)])),
						A.value.kind === "folder" ? Z("", !0) : (K(), q("button", {
							key: 2,
							onClick: t[37] ||= (e) => zn(A.value)
						}, [Y(W(Ts), { size: 17 }), t[170] ||= X("Download", -1)])),
						J("button", { onClick: t[38] ||= (e) => fr(A.value) }, [Y(W(Us), { size: 17 }), t[171] ||= X("Share", -1)]),
						J("button", {
							"aria-label": "More file actions",
							onClick: t[39] ||= ns((e) => j.value = j.value === A.value.id ? null : A.value.id, ["stop"])
						}, [Y(W(Es), { size: 17 })])
					]),
					j.value === A.value.id ? (K(), q("div", {
						key: 0,
						class: "drawer-action-list",
						onClick: t[44] ||= ns((e) => j.value = null, ["stop"])
					}, [
						J("button", { onClick: t[40] ||= (e) => Bn(A.value) }, "Rename"),
						J("button", { onClick: t[41] ||= (e) => Kn(A.value) }, "Move"),
						J("button", { onClick: t[42] ||= (e) => Zn(A.value) }, "Copy"),
						J("button", {
							class: "danger-menu-item",
							onClick: t[43] ||= (e) => rr(A.value)
						}, "Move to Trash")
					])) : Z("", !0),
					J("dl", null, [
						J("div", null, [t[172] ||= J("dt", null, "Kind", -1), J("dd", null, L(A.value.kind), 1)]),
						J("div", null, [t[173] ||= J("dt", null, "Size", -1), J("dd", null, L(A.value.size), 1)]),
						J("div", null, [t[174] ||= J("dt", null, "Modified", -1), J("dd", null, L(A.value.modified), 1)]),
						J("div", null, [t[175] ||= J("dt", null, "Location", -1), J("dd", null, L(wr(A.value)), 1)])
					]),
					J("button", {
						class: "advanced-button",
						onClick: t[45] ||= (e) => N.value = "info"
					}, [t[176] ||= X("Advanced details ", -1), Y(W(bs), { size: 15 })])
				])
			])) : Z("", !0),
			N.value ? (K(), q("div", {
				key: 2,
				class: I(["modal-backdrop", { "preview-backdrop": N.value === "preview" }]),
				onClick: t[91] ||= ns((e) => N.value = null, ["self"])
			}, [N.value === "preview" ? (K(), q("section", {
				key: 0,
				class: "preview-modal",
				role: "dialog",
				"aria-modal": "true",
				"aria-label": `Preview ${B.value?.name ?? "file"}`
			}, [
				J("header", Xd, [J("div", null, [J("small", null, L(B.value?.kind) + " · " + L(B.value?.size), 1), J("h2", null, L(B.value?.name), 1)]), J("div", Zd, [
					J("button", {
						class: "preview-action",
						onClick: Kt
					}, [Y(W(Vs), { size: 18 }), t[177] ||= X("Details", -1)]),
					B.value ? (K(), q("button", {
						key: 0,
						class: "preview-action",
						onClick: t[46] ||= (e) => zn(B.value)
					}, [Y(W(Ts), { size: 18 }), t[178] ||= X("Download", -1)])) : Z("", !0),
					B.value ? (K(), q("button", {
						key: 1,
						class: "preview-action preview-more",
						"aria-label": `More actions for ${B.value.name}`,
						onClick: t[47] ||= ns((e) => j.value = j.value === B.value.id ? null : B.value.id, ["stop"])
					}, [Y(W(Es), { size: 20 })], 8, Qd)) : Z("", !0),
					B.value && j.value === B.value.id ? (K(), q("div", {
						key: 2,
						class: "item-action-menu preview-action-menu",
						onClick: t[52] ||= ns((e) => j.value = null, ["stop"])
					}, [
						J("button", { onClick: t[48] ||= (e) => fr(B.value) }, [Y(W(Us), { size: 16 }), t[179] ||= X("Share", -1)]),
						J("button", { onClick: t[49] ||= (e) => Bn(B.value) }, "Rename"),
						J("button", { onClick: t[50] ||= (e) => Kn(B.value) }, [Y(W(Ks), { size: 16 }), t[180] ||= X("Move", -1)]),
						J("button", { onClick: t[51] ||= (e) => Zn(B.value) }, [Y(W(ws), { size: 16 }), t[181] ||= X("Copy", -1)]),
						J("button", {
							class: "danger-menu-item",
							onClick: qt
						}, [Y(W(tc), { size: 16 }), t[182] ||= X("Delete — move to Trash", -1)])
					])) : Z("", !0),
					J("button", {
						class: "preview-close",
						"aria-label": "Close preview",
						onClick: t[53] ||= (e) => N.value = null
					}, [Y(W(rc), { size: 23 })])
				])]),
				J("div", $d, [
					Ve.value ? (K(), q("div", ef, [Y(W(Xs), {
						class: "preview-spinner",
						size: 32
					}), t[183] ||= J("strong", null, "Opening preview…", -1)])) : B.value?.kind === "image" && (ze.value || Re.value[B.value.id]) ? (K(), q("img", {
						key: 1,
						class: "preview-image",
						src: ze.value || Re.value[B.value.id],
						alt: B.value.name
					}, null, 8, tf)) : B.value?.kind === "video" && ze.value ? (K(), q("video", {
						key: 2,
						class: "preview-video",
						src: ze.value,
						controls: "",
						autoplay: ""
					}, null, 8, nf)) : B.value?.kind === "audio" && ze.value ? (K(), q("div", rf, [
						J("span", { class: I(B.value.accent) }, [Y(W(Os), { size: 54 })], 2),
						J("h3", null, L(B.value.name), 1),
						J("audio", {
							src: ze.value,
							controls: "",
							autoplay: ""
						}, null, 8, af)
					])) : B.value?.kind === "pdf" && ze.value ? (K(), q("iframe", {
						key: 4,
						class: "preview-pdf",
						src: ze.value,
						title: B.value.name
					}, null, 8, of)) : Be.value === null ? (K(), q("div", {
						key: 6,
						class: I(["preview-placeholder", [B.value?.accent, wt(B.value?.name ?? "", B.value?.kind ?? "file", B.value?.mimeType)]]),
						"data-file-badge": Ct(B.value?.name ?? "", B.value?.kind ?? "file", B.value?.mimeType)
					}, [
						(K(), ta(kr(St(B.value?.name ?? "", B.value?.kind ?? "file", B.value?.mimeType)), { size: 84 })),
						J("h3", null, L(B.value?.name), 1),
						B.value?.demo ? (K(), q("p", lf, "This sample shows how the preview opens. Its original file bytes are not stored in the demo.")) : (K(), q("p", uf, "This file type does not have a browser preview. You can download it to open it in another app.")),
						B.value ? (K(), q("button", {
							key: 2,
							class: "preview-download",
							onClick: t[54] ||= (e) => zn(B.value)
						}, [Y(W(Ts), { size: 18 }), t[184] ||= X("Download file", -1)])) : Z("", !0)
					], 10, cf)) : (K(), q("pre", sf, L(Be.value), 1)),
					$e.value.length > 1 ? (K(), q("button", {
						key: 7,
						class: "preview-nav preview-previous",
						"aria-label": "Previous file",
						onClick: t[55] ||= (e) => Gt(-1)
					}, [Y(W(hs), { size: 24 })])) : Z("", !0),
					$e.value.length > 1 ? (K(), q("button", {
						key: 8,
						class: "preview-nav preview-next",
						"aria-label": "Next file",
						onClick: t[56] ||= (e) => Gt(1)
					}, [Y(W(gs), { size: 24 })])) : Z("", !0)
				]),
				J("footer", df, [J("span", null, L($e.value.findIndex((e) => e.id === B.value?.id) + 1) + " of " + L($e.value.length) + " in " + L(B.value ? wr(B.value) : "Home"), 1), t[185] ||= J("span", null, "← → to browse · Esc to close", -1)])
			], 8, Yd)) : N.value === "upload" ? (K(), q("section", ff, [
				J("div", pf, [J("div", null, [J("p", mf, "ADD TO " + L(Ke.value?.name?.toUpperCase() ?? "HOME"), 1), t[186] ||= J("h2", null, "Upload files", -1)]), J("button", {
					class: "icon-button",
					"aria-label": "Close",
					onClick: t[57] ||= (e) => N.value = null
				}, [Y(W(rc), { size: 19 })])]),
				J("input", {
					ref_key: "fileInput",
					ref: Fe,
					class: "visually-hidden",
					type: "file",
					multiple: "",
					onChange: Zt
				}, null, 544),
				J("div", {
					class: "drop-zone",
					onDragover: t[58] ||= ns(() => {}, ["prevent"]),
					onDrop: ns(Qt, ["prevent"])
				}, [
					Y(W(nc), { size: 25 }),
					t[187] ||= J("strong", null, "Drop files here", -1),
					t[188] ||= J("p", null, "or choose from your device", -1),
					J("button", {
						class: "secondary-button",
						onClick: Xt
					}, "Choose files")
				], 32),
				J("div", hf, [(K(!0), q(G, null, Mr(he.value, (e) => (K(), q("div", {
					key: `${e.name}-${e.size}`,
					class: "prepared-file"
				}, [
					J("span", {
						class: I(["prepared-file-icon", wt(e.name, Dt(e), e.type)]),
						"data-file-badge": Ct(e.name, Dt(e), e.type)
					}, [(K(), ta(kr(St(e.name, Dt(e), e.type)), { size: 25 }))], 10, gf),
					J("div", null, [J("strong", null, L(e.name), 1), J("small", null, L(Et(e.size)) + " · Ready", 1)]),
					Y(W(ys), { size: 18 })
				]))), 128))]),
				J("div", _f, [J("button", {
					class: "secondary-button",
					onClick: t[59] ||= (e) => N.value = null
				}, "Cancel"), J("button", {
					class: "primary-button",
					disabled: ge.value || !he.value.length,
					onClick: Pn
				}, "Upload " + L(he.value.length || "") + " file" + L(he.value.length === 1 ? "" : "s"), 9, vf)])
			])) : N.value === "folder" ? (K(), q("section", yf, [
				J("div", bf, [t[189] ||= J("h2", null, "Create a folder", -1), J("button", {
					class: "icon-button",
					"aria-label": "Close",
					onClick: t[60] ||= (e) => N.value = null
				}, [Y(W(rc), { size: 19 })])]),
				J("label", xf, [t[190] ||= X("Folder name", -1), An(J("input", {
					"onUpdate:modelValue": t[61] ||= (e) => fe.value = e,
					autofocus: "",
					placeholder: "e.g. Childhood stories",
					onKeydown: is(Rn, ["enter"])
				}, null, 544), [[Xo, fe.value]])]),
				J("p", Sf, "Created inside " + L(Ke.value?.name ?? "Home") + ".", 1),
				J("div", Cf, [J("button", {
					class: "secondary-button",
					onClick: t[62] ||= (e) => N.value = null
				}, "Cancel"), J("button", {
					class: "primary-button",
					disabled: !fe.value.trim(),
					onClick: Rn
				}, "Create folder", 8, wf)])
			])) : N.value === "rename" ? (K(), q("section", Tf, [
				J("div", Ef, [t[191] ||= J("h2", null, "Rename item", -1), J("button", {
					class: "icon-button",
					"aria-label": "Close",
					onClick: t[63] ||= (e) => N.value = null
				}, [Y(W(rc), { size: 19 })])]),
				J("label", Df, [t[192] ||= X("Name", -1), An(J("input", {
					"onUpdate:modelValue": t[64] ||= (e) => pe.value = e,
					autofocus: "",
					onKeydown: is(Vn, ["enter"])
				}, null, 544), [[Xo, pe.value]])]),
				J("div", Of, [J("button", {
					class: "secondary-button",
					onClick: t[65] ||= (e) => N.value = null
				}, "Cancel"), J("button", {
					class: "primary-button",
					onClick: Vn
				}, "Rename")])
			])) : N.value === "move" ? (K(), q("section", kf, [
				J("div", Af, [J("h2", null, "Move " + L(B.value?.name), 1), J("button", {
					class: "icon-button",
					"aria-label": "Close",
					onClick: t[66] ||= (e) => N.value = null
				}, [Y(W(rc), { size: 19 })])]),
				J("label", jf, [t[194] ||= X("Destination", -1), An(J("select", { "onUpdate:modelValue": t[67] ||= (e) => F.value = e }, [t[193] ||= J("option", { value: "root" }, "Home", -1), (K(!0), q(G, null, Mr(Un.value, (e) => (K(), q("option", {
					key: e.id,
					value: e.id
				}, L(e.name), 9, Mf))), 128))], 512), [[Zo, F.value]])]),
				J("div", Nf, [J("button", {
					class: "secondary-button",
					onClick: t[68] ||= (e) => N.value = null
				}, "Cancel"), J("button", {
					class: "primary-button",
					onClick: qn
				}, "Move")])
			])) : N.value === "batchMove" ? (K(), q("section", Pf, [
				J("div", Ff, [J("h2", null, "Move " + L(Xe.value.length) + " items", 1), J("button", {
					class: "icon-button",
					"aria-label": "Close",
					onClick: t[69] ||= (e) => N.value = null
				}, [Y(W(rc), { size: 19 })])]),
				J("label", If, [t[196] ||= X("Destination", -1), An(J("select", { "onUpdate:modelValue": t[70] ||= (e) => F.value = e }, [t[195] ||= J("option", { value: "root" }, "Home", -1), (K(!0), q(G, null, Mr(Wn.value, (e) => (K(), q("option", {
					key: e.id,
					value: e.id
				}, L(e.name), 9, Lf))), 128))], 512), [[Zo, F.value]])]),
				t[197] ||= J("p", { class: "field-help" }, "All selected items will move to the same folder.", -1),
				J("div", Rf, [J("button", {
					class: "secondary-button",
					onClick: t[71] ||= (e) => N.value = null
				}, "Cancel"), J("button", {
					class: "primary-button",
					disabled: Gn.value,
					onClick: er
				}, "Move items", 8, zf)])
			])) : N.value === "share" ? (K(), q("section", Bf, [J("div", Vf, [J("div", null, [t[198] ||= J("p", { class: "eyebrow" }, "SECURE LINK", -1), J("h2", null, "Share " + L(B.value?.name), 1)]), J("button", {
				class: "icon-button",
				"aria-label": "Close",
				onClick: t[72] ||= (e) => N.value = null
			}, [Y(W(rc), { size: 19 })])]), lt.value ? (K(), q(G, { key: 1 }, [
				J("div", $f, [J("span", null, [Y(W(ys), { size: 22 })]), J("div", null, [t[207] ||= J("strong", null, "Share link created", -1), J("p", null, "Expires " + L(new Date(lt.value.expiresAt).toLocaleString()) + " · " + L(lt.value.maxDownloads) + " downloads", 1)])]),
				lt.value.password ? (K(), q("label", ep, [t[209] ||= X("Password", -1), J("div", tp, [J("input", {
					value: lt.value.password,
					readonly: ""
				}, null, 8, np), J("button", {
					type: "button",
					class: "secondary-button",
					onClick: gr
				}, [Y(W(ws), { size: 16 }), t[208] ||= X("Copy", -1)])])])) : Z("", !0),
				J("p", rp, "Anyone with the link" + L(lt.value.password ? " and password" : "") + " can open this item until either limit is reached.", 1),
				J("label", ip, [t[211] ||= X("Share link", -1), J("div", ap, [J("input", {
					value: _e.value,
					readonly: ""
				}, null, 8, op), J("button", {
					type: "button",
					class: "primary-button",
					onClick: hr
				}, [Y(W(ws), { size: 16 }), t[210] ||= X("Copy", -1)])])])
			], 64)) : (K(), q(G, { key: 0 }, [
				t[205] ||= J("p", { class: "share-intro" }, "Choose when the link stops working and how many times the item can be downloaded.", -1),
				J("div", Hf, [J("label", Uf, [t[199] ||= X("Expiry date", -1), An(J("input", {
					"onUpdate:modelValue": t[73] ||= (e) => be.value = e,
					type: "datetime-local",
					min: lr(Date.now() + 6e4)
				}, null, 8, Wf), [[Xo, be.value]])]), J("label", Gf, [t[200] ||= X("Download limit", -1), An(J("input", {
					"onUpdate:modelValue": t[74] ||= (e) => xe.value = e,
					type: "number",
					min: "1",
					max: "10000",
					inputmode: "numeric"
				}, null, 512), [[
					Xo,
					xe.value,
					void 0,
					{ number: !0 }
				]])])]),
				J("button", {
					class: "share-password-toggle",
					type: "button",
					"aria-pressed": Se.value,
					onClick: pr
				}, [J("span", { class: I(["switch-control", { active: Se.value }]) }, [...t[201] ||= [J("span", null, null, -1)]], 2), t[202] ||= J("span", null, [J("strong", null, "Require a password"), J("small", null, "Optional · six case-sensitive letters and digits")], -1)], 8, Kf),
				Se.value ? (K(), q("div", qf, [J("label", Jf, [t[204] ||= X("Autogenerated password", -1), J("div", Yf, [J("input", {
					value: Ce.value,
					readonly: "",
					"aria-label": "Autogenerated share password"
				}, null, 8, Xf), J("button", {
					type: "button",
					class: "secondary-button",
					onClick: dr
				}, [Y(W(Xs), { size: 15 }), t[203] ||= X("Regenerate", -1)])])])])) : Z("", !0),
				t[206] ||= J("p", { class: "field-help" }, "This local preview link works only in this browser until Leither sharing rights are enabled.", -1),
				J("div", Zf, [J("button", {
					class: "secondary-button",
					onClick: t[75] ||= (e) => N.value = null
				}, "Cancel"), J("button", {
					class: "primary-button",
					disabled: !ut.value,
					onClick: mr
				}, "Create share link", 8, Qf)])
			], 64))])) : N.value === "shareAccess" ? (K(), q("section", sp, [J("div", cp, [J("div", null, [t[212] ||= J("p", { class: "eyebrow" }, "SHARED ITEM", -1), J("h2", null, L(R.value ? Ee.value : `Open ${B.value?.name ?? "item"}`), 1)]), J("button", {
				class: "icon-button",
				"aria-label": "Close",
				onClick: t[76] ||= (e) => N.value = null
			}, [Y(W(rc), { size: 19 })])]), R.value ? (K(), q(G, { key: 1 }, [t[215] ||= J("p", { class: "share-unavailable" }, "Ask the owner to create a new share link.", -1), J("div", fp, [J("button", {
				class: "primary-button",
				onClick: t[79] ||= (e) => N.value = null
			}, "Done")])], 64)) : (K(), q(G, { key: 0 }, [
				t[214] ||= J("p", { class: "share-intro" }, "Enter the six-character password supplied with this link.", -1),
				J("label", lp, [t[213] ||= X("Password", -1), An(J("input", {
					"onUpdate:modelValue": t[77] ||= (e) => Te.value = e,
					type: "password",
					maxlength: "6",
					autocomplete: "one-time-code",
					autofocus: "",
					onKeydown: is(Or, ["enter"])
				}, null, 544), [[Xo, Te.value]])]),
				J("p", { class: I(["field-help", { "field-error": Ee.value }]) }, L(Ee.value || "Passwords are case-sensitive."), 3),
				J("div", up, [J("button", {
					class: "secondary-button",
					onClick: t[78] ||= (e) => N.value = null
				}, "Cancel"), J("button", {
					class: "primary-button",
					disabled: Te.value.length !== 6,
					onClick: Or
				}, "Open item", 8, dp)])
			], 64))])) : N.value === "update" ? (K(), q("section", pp, [
				J("div", mp, [t[216] ||= J("div", null, [J("p", { class: "eyebrow" }, "LIFEDRIVE UPDATE"), J("h2", { id: "update-title" }, "Update your app")], -1), J("button", {
					class: "icon-button",
					"aria-label": "Close",
					onClick: t[80] ||= (e) => N.value = null
				}, [Y(W(rc), { size: 19 })])]),
				J("div", hp, [
					J("span", null, [t[217] ||= J("small", null, "Installed", -1), J("strong", null, "v" + L(Oe.value), 1)]),
					Y(W(gs), { size: 20 }),
					J("span", gp, [t[218] ||= J("small", null, "Latest", -1), J("strong", null, "v" + L(z.value?.version), 1)])
				]),
				J("div", _p, [Y(W($s), { size: 21 }), t[219] ||= J("div", null, [J("strong", null, "Your files stay in LifeDrive"), J("p", null, "This updates the app code on your private node. Back up important data before maintaining the node.")], -1)]),
				J("ol", vp, [
					t[226] ||= J("li", null, [J("span", null, "1"), J("div", null, [J("strong", null, "Open Terminal"), J("p", null, "Use Terminal on the device running LifeDrive, or connect to that device with SSH.")])], -1),
					J("li", null, [t[223] ||= J("span", null, "2", -1), J("div", null, [
						t[221] ||= J("strong", null, "Run the LifeDrive update script", -1),
						t[222] ||= J("p", null, "This uploads and activates the newest official app package.", -1),
						J("div", yp, [J("code", null, L(z.value?.command), 1), J("button", {
							type: "button",
							"aria-label": "Copy upgrade command",
							onClick: kt
						}, [Y(W(ws), { size: 16 }), t[220] ||= X("Copy", -1)])])
					])]),
					J("li", null, [t[225] ||= J("span", null, "3", -1), J("div", null, [t[224] ||= J("strong", null, "Return and reload", -1), J("p", null, "Refresh this page after the script finishes. The update button disappears when the node reports v" + L(z.value?.version) + ".", 1)])])
				]),
				t[227] ||= J("p", { class: "update-help" }, "The browser cannot safely install private-node software by itself, so this version requires one terminal command.", -1),
				J("div", bp, [J("button", {
					class: "primary-button",
					onClick: t[81] ||= (e) => N.value = null
				}, "Done")])
			])) : N.value === "help" ? (K(), q("section", xp, [
				J("div", Sp, [t[228] ||= J("div", null, [J("p", { class: "eyebrow" }, "BEGINNER'S GUIDE"), J("h2", null, "Using Inoku")], -1), J("button", {
					class: "icon-button",
					"aria-label": "Close",
					onClick: t[82] ||= (e) => N.value = null
				}, [Y(W(rc), { size: 19 })])]),
				J("div", Cp, [Y(W($s), { size: 22 }), J("div", null, [J("strong", null, L(p.value === "connected" ? "Your uploads are stored on LifeDrive" : "Your files remain available locally"), 1), t[229] ||= J("p", null, "Completed uploads are committed to the LifeDrive File MiMei, and this browser keeps a local cache for fast previews.", -1)])]),
				t[230] ||= la("<div class=\"help-content guide-steps\"><p><strong>Open content</strong><span>Click a folder to enter it. Click a file to preview it.</span></p><p><strong>See details</strong><span>Double-click an item or choose Details from its three-dot menu.</span></p><p><strong>Add and organize</strong><span>Choose Add to upload files or create a folder. Use Select for batch actions.</span></p><p><strong>Find anything</strong><span>Use Search or press ⌘K / Ctrl+K.</span></p></div>", 1),
				J("div", wp, [J("button", {
					class: "secondary-button",
					onClick: t[83] ||= (e) => N.value = "info"
				}, "Protection details"), J("button", {
					class: "primary-button",
					onClick: t[84] ||= (e) => N.value = null
				}, "Start using Inoku")])
			])) : N.value === "profile" ? (K(), q("section", Tp, [
				J("div", Ep, [t[231] ||= J("div", null, [J("p", { class: "eyebrow" }, "YOUR PROFILE"), J("h2", { id: "profile-title" }, "Profile and account")], -1), J("button", {
					class: "icon-button",
					"aria-label": "Close",
					onClick: t[85] ||= (e) => N.value = null
				}, [Y(W(rc), { size: 19 })])]),
				J("div", Dp, [
					J("button", {
						class: "profile-avatar-picker",
						type: "button",
						"aria-label": "Choose profile picture",
						onClick: En
					}, [je.value ? (K(), q("img", {
						key: 0,
						src: je.value,
						alt: "Profile picture preview"
					}, null, 8, Op)) : (K(), q("span", kp, L(ht.value), 1)), J("i", null, [Y(W(vs), { size: 17 })])]),
					J("input", {
						ref_key: "profileFileInput",
						ref: Ie,
						class: "visually-hidden",
						type: "file",
						accept: "image/jpeg,image/png,image/webp,image/gif,image/avif",
						onChange: On
					}, null, 544),
					J("div", null, [
						t[232] ||= J("strong", null, "Profile picture", -1),
						t[233] ||= J("p", null, "JPG, PNG, WebP, GIF, or AVIF · up to 1.5 MB", -1),
						J("div", Ap, [J("button", {
							type: "button",
							onClick: En
						}, L(je.value ? "Change" : "Add picture"), 1), je.value ? (K(), q("button", {
							key: 0,
							type: "button",
							class: "danger-text-button",
							onClick: jn
						}, "Remove")) : Z("", !0)])
					])
				]),
				Me.value ? (K(), q("p", jp, L(Me.value), 1)) : Z("", !0),
				J("div", Mp, [J("label", Np, [t[234] ||= X("Display name", -1), An(J("input", {
					"onUpdate:modelValue": t[86] ||= (e) => ke.value = e,
					maxlength: "80",
					placeholder: "Name shown in LifeDrive"
				}, null, 512), [[Xo, ke.value]])]), J("label", Pp, [
					t[235] ||= X("Profile content", -1),
					An(J("textarea", {
						"onUpdate:modelValue": t[87] ||= (e) => Ae.value = e,
						maxlength: "500",
						rows: "4",
						placeholder: "A short introduction, family note, or anything you want to remember."
					}, null, 512), [[Xo, Ae.value]]),
					J("small", null, L(Ae.value.length) + " / 500", 1)
				])]),
				J("div", Fp, [Y(W($s), { size: 20 }), J("div", null, [t[236] ||= J("strong", null, "Where this information is saved", -1), (K(), q("p", Ip, "This is the hosted demo, so its sample profile stays only in this browser. An installed LifeDrive saves the profile privately in its File MiMei."))])]),
				ne.value ? (K(), q("p", Lp, L(ne.value), 1)) : Z("", !0),
				J("dl", Rp, [
					J("div", null, [t[237] ||= J("dt", null, "Leither username", -1), J("dd", null, "@" + L(h.value?.username), 1)]),
					J("div", null, [t[238] ||= J("dt", null, "User ID", -1), J("dd", null, L(h.value?.uid), 1)]),
					J("div", null, [t[239] ||= J("dt", null, "Drive MiMei", -1), J("dd", null, L(x.value || "—"), 1)])
				]),
				J("div", zp, [
					Z("", !0),
					t[240] ||= J("span", null, null, -1),
					J("button", {
						class: "secondary-button",
						onClick: t[88] ||= (e) => N.value = null
					}, "Cancel"),
					J("button", {
						class: "primary-button",
						disabled: te.value || !ke.value.trim(),
						onClick: Mn
					}, [te.value ? (K(), ta(W(Xs), {
						key: 0,
						class: "preview-spinner",
						size: 16
					})) : Z("", !0), X(L(te.value ? "Saving…" : "Save profile"), 1)], 8, Bp)
				])
			])) : (K(), q("section", Vp, [
				J("div", Hp, [t[241] ||= J("div", null, [J("p", { class: "eyebrow" }, "LIFEDRIVE STATUS"), J("h2", null, "Technical details")], -1), J("button", {
					class: "icon-button",
					"aria-label": "Close",
					onClick: t[89] ||= (e) => N.value = null
				}, [Y(W(rc), { size: 19 })])]),
				J("div", Up, [
					J("div", null, [t[242] ||= J("small", null, "Leither app ID", -1), J("strong", null, L(W(fc)), 1)]),
					J("div", null, [t[243] ||= J("small", null, "Node", -1), J("strong", null, L(W(pc)), 1)]),
					t[244] ||= la("<div><small>Server storage</small><strong>Private local File MiMei</strong></div><div><small>Distribution</small><strong>Not published or advertised</strong></div><div><small>Local cache</small><strong>IndexedDB</strong></div><div><small>Read state</small><strong>last</strong></div><div><small>Write commit</small><strong>/appDrive → MFSetCid</strong></div><div><small>Data model</small><strong>Direct files and directories</strong></div><div><small>Authorization</small><strong>Leither SID + native MiMei rights</strong></div>", 7)
				]),
				J("div", Wp, [J("button", {
					class: "primary-button",
					onClick: t[90] ||= (e) => N.value = null
				}, "Done")])
			]))], 2)) : Z("", !0),
			Y(Qa, { name: "toast" }, {
				default: kn(() => [ve.value ? (K(), q("div", Gp, [Y(W(ys), { size: 20 }), X(L(ve.value), 1)])) : Z("", !0)]),
				_: 1
			}),
			J("nav", Kp, [(K(!0), q(G, null, Mr(Ge.value, (e) => (K(), q("button", {
				key: e.id,
				class: I({ active: re.value === e.id }),
				onClick: (t) => e.id === "files" ? yt() : vt(e.id)
			}, [(K(), ta(kr(e.icon), { size: 19 })), J("span", null, L(e.label), 1)], 10, qp))), 128))])
		]));
	}
}), Yp = document.querySelector("#inoku-app, #app");
Yp && cs(Jp).mount(Yp);
//#endregion
