// Package lapp implements LifeDrive as one interpreted Go MApp.
package lapp

import (
	"fmt"
	"io"

	"Leither/lapi"
)

type entryFunc func(*ctx) (any, error)

type ctx struct {
	api   lapi.LApi
	entry string
	req   map[string]string
	args  []any
	wr    io.Writer
}

// RunMApp is the single dispatcher Leither calls for every LifeDrive entry.
func RunMApp(entry string, request map[string]string, args []any, wr io.Writer) (any, error) {
	api := lapi.GetLApi()
	if api == nil {
		return nil, fmt.Errorf("LifeDrive requires the Leither MApp runtime")
	}
	if request == nil {
		request = map[string]string{}
	}
	if entry == "" {
		entry = request["entry"]
	}
	c := &ctx{api: api, entry: entry, req: request, args: args, wr: wr}
	if entry == "" {
		return c.serveWebRoot()
	}
	handler, ok := entryTable()[entry]
	if !ok {
		return nil, fmt.Errorf("unknown LifeDrive entry %q", entry)
	}
	return handler(c)
}

func entryTable() map[string]entryFunc {
	return map[string]entryFunc{
		"health":                   entryHealth,
		"server_capabilities":      entryServerCapabilities,
		"access_get_security_mode": entryAccessGetSecurityMode,
		"access_check":             entryAccessCheck,
		"drive_get_state":          entryDriveGetState,
		"storage_get":              entryStorageGet,
		"storage_set_limit":        entryStorageSetLimit,
		"profile_get":              entryProfileGet,
		"profile_set":              entryProfileSet,
		"profile_avatar_upload":    entryProfileAvatarUpload,
		"profile_avatar_abort":     entryProfileAvatarAbort,
		"drive_open":               entryDriveOpen,
		"drive_list":               entryDriveList,
		"folder_create":            entryFolderCreate,
		"file_get_info":            entryFileGetInfo,
		"file_read":                entryFileRead,
		"object_move":              entryObjectMove,
		"object_copy":              entryObjectCopy,
		"object_trash":             entryObjectTrash,
		"trash_list":               entryTrashList,
		"trash_restore":            entryTrashRestore,
		"object_purge":             entryObjectPurge,
		"upload_begin":             entryUploadBegin,
		"upload_write":             entryUploadWrite,
		"upload_complete":          entryUploadComplete,
		"upload_abort":             entryUploadAbort,
		"share_create":             entryShareCreate,
		"share_list":               entryShareList,
		"share_revoke":             entryShareRevoke,
		"share_open":               entryShareOpen,
		"link_upload_begin":        entryLinkUploadBegin,
		"link_upload_write":        entryLinkUploadWrite,
		"link_upload_complete":     entryLinkUploadComplete,
		"link_upload_abort":        entryLinkUploadAbort,
	}
}

func (c *ctx) serveWebRoot() (any, error) {
	data, err := c.api.BEReadFile("index.html", "web")
	if err != nil {
		return nil, nil
	}
	if c.wr != nil {
		if _, err := c.wr.Write(data); err == nil {
			return nil, nil
		}
	}
	return string(data), nil
}
