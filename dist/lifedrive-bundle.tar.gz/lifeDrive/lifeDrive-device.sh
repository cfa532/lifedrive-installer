#!/usr/bin/env bash
set -euo pipefail

LEITHER_WORKDIR="${LIFEDRIVE_WORKDIR:-/home/pi/demo}"
LEITHER_BIN="${LIFEDRIVE_LEITHER_PATH:-$LEITHER_WORKDIR/Leither}"
APP_NAME="${LIFEDRIVE_APP_NAME:-lifeDrive}"
APP_STATE="$LEITHER_WORKDIR/$APP_NAME.appid"
DEVICE_STATE="${LIFEDRIVE_DEVICE_STATE:-$LEITHER_WORKDIR/$APP_NAME.devices}"
PUBLISHER_KEY="${LIFEDRIVE_PUBLISHER_KEY:-}"
PUBLISHER_KEY_STATE="$LEITHER_WORKDIR/$APP_NAME.publisher-key"
SERVICE_NODE="${LIFEDRIVE_SERVICE_NODE:-}"

usage() {
  echo "Usage: lifeDrive-device.sh list | revoke <device-uid>" >&2
}

command_name="${1:-}"
if [[ "$command_name" == "list" ]]; then
  if [[ ! -s "$DEVICE_STATE" ]]; then echo "No authorized LifeDrive devices."; exit 0; fi
  printf '%-29s  %-24s  %s\n' "DEVICE UID" "LABEL" "AUTHORIZED"
  while IFS=$'\t' read -r uid label created_at; do
    [[ -n "$uid" ]] && printf '%-29s  %-24s  %s\n' "$uid" "$label" "$created_at"
  done < "$DEVICE_STATE"
  exit 0
fi
if [[ "$command_name" != "revoke" || $# -ne 2 ]]; then usage; exit 2; fi

target_uid="$2"
if [[ ! "$target_uid" =~ ^[A-Za-z0-9_-]{27}$ ]]; then
  echo "LifeDrive device revocation stopped: invalid Leither key ID." >&2
  exit 2
fi
if [[ ! -s "$APP_STATE" || ! -s "$DEVICE_STATE" ]]; then
  echo "LifeDrive device revocation stopped: application or device state is missing." >&2
  exit 1
fi
app_id=$(tr -d '[:space:]' < "$APP_STATE")
if (( ${#app_id} < 8 || ${#app_id} > 256 )) || [[ ! "$app_id" =~ ^[A-Za-z0-9_-]+$ ]]; then
  echo "LifeDrive device revocation stopped: the saved application MID is invalid." >&2
  exit 1
fi
active_count=$(awk 'NF {count++} END {print count+0}' "$DEVICE_STATE")
if (( active_count <= 1 )); then
  echo "LifeDrive device revocation stopped: authorize a replacement device first." >&2
  exit 1
fi
if ! awk -F '\t' -v uid="$target_uid" '$1 == uid {found=1} END {exit !found}' "$DEVICE_STATE"; then
  echo "LifeDrive device revocation stopped: that device is not in the active registry." >&2
  exit 1
fi

if [[ -z "$PUBLISHER_KEY" && -s "$PUBLISHER_KEY_STATE" ]]; then PUBLISHER_KEY=$(tr -d '\r\n' < "$PUBLISHER_KEY_STATE"); fi
if [[ ! -x "$LEITHER_BIN" ]]; then echo "LifeDrive device revocation stopped: Leither was not found at $LEITHER_BIN." >&2; exit 1; fi
node_bin=$(command -v node 2>/dev/null || true)
if [[ -z "$node_bin" ]]; then echo "LifeDrive device revocation stopped: Node.js was not found." >&2; exit 1; fi
request_data=$(LIFEDRIVE_REVOKE_UID="$target_uid" LIFEDRIVE_APP_ID="$app_id" "$node_bin" -e '
  const hex=value=>Buffer.from(value||"","utf8").toString("hex");process.stdout.write(`uid_hex=${hex(process.env.LIFEDRIVE_REVOKE_UID)};appid_hex=${hex(process.env.LIFEDRIVE_APP_ID)}`);')
revoke_script="local mimei=require('mimei'); local function fromhex(value) if not value then return '' end; return (value:gsub('..',function(byte) return string.char(tonumber(byte,16)) end)); end; local uid=fromhex(request.uid_hex); local appid=fromhex(request.appid_hex); local mid,createErr=mimei.MMCreate(request.sid,appid,'lifedrive.app-drive/v1','lifeDrive',1,0x07276704); if createErr~=nil then return {error=tostring(createErr)}; end; local profileMid,profileErr=mimei.MMCreate(request.sid,appid,'lifedrive.user-profile/v1','owner-profile',1,0x07276704); if profileErr~=nil then return {error=tostring(profileErr)}; end; local _,profileRightErr=mimei.MMSetRight(request.sid,profileMid,uid,0); if profileRightErr~=nil then return {error=tostring(profileRightErr)}; end; local _,rightErr=mimei.MMSetRight(request.sid,mid,uid,0); if rightErr~=nil then return {error=tostring(rightErr)}; end; return {uid=uid,mid=mid,profile_mid=profileMid,revoked=true}"
command_args=(lpki runscript -t lua -s "$revoke_script" -r "$request_data" --json)
if [[ -n "$PUBLISHER_KEY" ]]; then command_args+=(-k "$PUBLISHER_KEY"); fi
if [[ -n "$SERVICE_NODE" ]]; then command_args+=(-n "$SERVICE_NODE"); fi
cd "$LEITHER_WORKDIR"
revoke_output=$("$LEITHER_BIN" "${command_args[@]}")
LIFEDRIVE_REVOKE_OUTPUT="$revoke_output" LIFEDRIVE_REVOKE_UID="$target_uid" "$node_bin" -e '
  const reply=JSON.parse(process.env.LIFEDRIVE_REVOKE_OUTPUT);const result=reply?.data?.result??reply?.data;const nativeError=result?.error||reply?.error?.message;
  if(reply?.exit_code!==0||nativeError||result?.uid!==process.env.LIFEDRIVE_REVOKE_UID||result?.revoked!==true){console.error(`LifeDrive device revocation stopped: ${nativeError||"Leither did not confirm revocation."}`);process.exit(1)}'

registry_work=$(mktemp "$LEITHER_WORKDIR/.lifedrive-devices.XXXXXX")
trap 'rm -f -- "$registry_work"' EXIT
awk -F '\t' -v uid="$target_uid" '$1 != uid' "$DEVICE_STATE" > "$registry_work"
chmod 600 "$registry_work"
mv "$registry_work" "$DEVICE_STATE"
trap - EXIT
echo "LifeDrive device $target_uid was revoked. It can no longer change drive data."
echo "Drive contents stay readable: Leither leaves every authenticated UID a read right."
