package lapp

import (
	"encoding/json"
	"fmt"
	"os"
)

// This file is written only by the private identity service. It carries no
// keys or device sessions. In household mode only service-held per-user
// author sessions can enter the MApp, including handle-based upload entries.
type householdRoute struct {
	UserID       string `json:"user_id"`
	DriveMID     string `json:"drive_mid"`
	IdentityMID  string `json:"identity_mid"`
	PrivateRight uint64 `json:"private_right"`
	Initializing bool   `json:"initializing"`
}

func prepareHousehold(c *ctx) error {
	root, err := leitherRootDirectory()
	if err != nil {
		return err
	}
	bytes, err := os.ReadFile(joinUnixPath(root, "lifeDrive.households.json"))
	if os.IsNotExist(err) {
		return nil
	}
	if err != nil {
		return err
	}
	var routes struct {
		Version int                       `json:"version"`
		Users   map[string]householdRoute `json:"users"`
	}
	if json.Unmarshal(bytes, &routes) != nil || routes.Version != 1 {
		return fmt.Errorf("invalid household routes")
	}
	// The HTML and non-sensitive discovery remain available on the loopback
	// upstream. Legacy QR and public-share entries are not household auth paths.
	// Upload-link deliveries are public too: each forwards to the identity
	// service, which checks the link on every call and owns where files land.
	if c.entry == "" || c.entry == "health" || c.entry == "node_ips" || c.entry == "household_request" || c.entry == "household_file" || c.entry == "household_info" || c.entry == "share_open" ||
		c.entry == "android_update_info" || c.entry == "android_update_publish" || c.entry == "android_update_providers" ||
		c.entry == "link_upload_begin" || c.entry == "link_upload_write" || c.entry == "link_upload_complete" || c.entry == "link_upload_abort" {
		return nil
	}
	sid := c.str("sid")
	if sid == "" {
		return fmt.Errorf("identity service required")
	}
	value, err := c.api.GetVar(sid, "userid")
	if err != nil {
		return err
	}
	uid, _ := value.(string)
	route, ok := routes.Users[uid]
	if !ok || !validMID(route.DriveMID) || !validMID(route.IdentityMID) {
		return fmt.Errorf("unknown user authority")
	}
	c.household = &route
	switch c.entry {
	case "qr_login_deposit", "qr_login_claim", "share_create", "share_open":
		return fmt.Errorf("use household service")
	}
	// Reconstruct staging from last on each mutation: failed cur writes must
	// never leak into another operation. The service serializes these requests.
	switch c.entry {
	case "folder_create", "object_move", "object_copy", "object_trash", "trash_restore", "object_purge", "upload_complete", "pending_accept", "pending_reject":
		stage := c.workRoot()
		if _, err := c.api.FilesStat(sid, mimeiURL(route.DriveMID, "last", "/")); err != nil {
			return err
		}
		if _, err := ensureDirectory(c, sid, "/lifedrive-work"); err != nil {
			return err
		}
		if _, err := c.api.FilesStat(sid, stage); err == nil {
			if err := c.api.FilesRm(sid, stage, true, false); err != nil {
				return err
			}
		}
		if err := c.api.FilesCopy(sid, mimeiURL(route.DriveMID, "last", "/"), stage, false); err != nil {
			return err
		}
	}
	return nil
}
func (c *ctx) workRoot() string {
	if c.household != nil {
		return "/lifedrive-work/" + c.household.DriveMID
	}
	return driveWorkRoot
}
func (c *ctx) workPath(path string) string { return c.workRoot() + path }
func (c *ctx) creationRight() uint64 {
	if c.household != nil {
		return c.household.PrivateRight
	}
	return driveRight
}

func householdActive() bool {
	root, err := leitherRootDirectory()
	if err != nil {
		return false
	}
	_, err = os.Stat(joinUnixPath(root, "lifeDrive.households.json"))
	return err == nil
}
