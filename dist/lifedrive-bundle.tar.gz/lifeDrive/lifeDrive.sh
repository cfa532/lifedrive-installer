#!/usr/bin/env bash
set -euo pipefail

LEITHER_WORKDIR="${LIFEDRIVE_WORKDIR:-/home/pi/demo}"
LEITHER_BIN="${LIFEDRIVE_LEITHER_PATH:-$LEITHER_WORKDIR/Leither}"
APP_NAME="${LIFEDRIVE_APP_NAME:-lifeDrive}"
SERVICE_NODE="${LIFEDRIVE_SERVICE_NODE:-}"
PUBLISHER_KEY="${LIFEDRIVE_PUBLISHER_KEY:-}"
PUBLISHER_CERT="${LIFEDRIVE_PUBLISHER_CERT:-}"
SERVICE_REQUEST="${LIFEDRIVE_SERVICE_REQUEST:-RequestService=mimei}"
STATE_FILE="${LIFEDRIVE_PUBLICATION_STATE:-$LEITHER_WORKDIR/$APP_NAME.appid}"
PUBLISHER_KEY_STATE="${LIFEDRIVE_PUBLISHER_KEY_STATE:-$LEITHER_WORKDIR/$APP_NAME.publisher-key}"

if [[ -z "$PUBLISHER_KEY" && -s "$PUBLISHER_KEY_STATE" ]]; then
  PUBLISHER_KEY=$(tr -d '\r\n' < "$PUBLISHER_KEY_STATE")
fi

run_leither() {
  local command_args=("$@")
  if [[ -n "$PUBLISHER_KEY" ]]; then
    command_args+=(-k "$PUBLISHER_KEY")
  fi
  if [[ -n "$SERVICE_NODE" ]]; then
    command_args+=(-n "$SERVICE_NODE")
  fi
  "$LEITHER_BIN" "${command_args[@]}"
}

cd "$LEITHER_WORKDIR"

if [[ -s "$STATE_FILE" ]]; then
  saved_app_id=$(tr -d '[:space:]' < "$STATE_FILE")
  identity_json=$(run_leither lapp showapp -a "$APP_NAME" --json 2>/dev/null || true)
  identity_app_id=$(sed -n 's/.*"app_id":"\([^"]*\)".*/\1/p' <<<"$identity_json")
  if [[ -z "$identity_app_id" || "$identity_app_id" != "$saved_app_id" ]]; then
    echo "LifeDrive publication stopped: the selected publisher identity does not match saved app MID $saved_app_id." >&2
    echo "Set LIFEDRIVE_PUBLISHER_KEY or restore $PUBLISHER_KEY_STATE before publishing." >&2
    exit 1
  fi
fi

if [[ -n "$SERVICE_NODE" ]]; then
  request_args=(lpki reqservice -m "$SERVICE_REQUEST")
  if [[ -n "$PUBLISHER_CERT" ]]; then
    request_args+=(-c "$PUBLISHER_CERT")
  fi
  run_leither "${request_args[@]}"
fi

run_leither lapp uploadapp "$APP_NAME"
run_leither lapp backup -a "$APP_NAME"

app_json=$(run_leither lapp showapp -a "$APP_NAME" --json)
app_id=$(sed -n 's/.*"app_id":"\([^"]*\)".*/\1/p' <<<"$app_json")
reported_name=$(sed -n 's/.*"name":"\([^"]*\)".*/\1/p' <<<"$app_json")

if [[ -z "$app_id" || "$reported_name" != "$APP_NAME" ]]; then
  echo "LifeDrive publication stopped: Leither did not return an application MID." >&2
  exit 1
fi

run_leither mimei publish --mid "$app_id"

umask 077
printf '%s\n' "$app_id" > "$STATE_FILE"
if [[ -n "$PUBLISHER_KEY" ]]; then
  printf '%s\n' "$PUBLISHER_KEY" > "$PUBLISHER_KEY_STATE"
fi

echo "LifeDrive published"
echo "App MID: $app_id"
echo "The SSH setup command can now create or recover the owner and request an Inoku address:"
echo "$LEITHER_WORKDIR/$APP_NAME/lifeDrive-setup.sh"
echo "AV1 administrators can register an address manually with:"
echo "register-username.sh <username> $app_id"
