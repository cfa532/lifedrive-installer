package lapp

import (
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"time"

	"Leither/lapi"
)

// Signing a browser in by scanning a code with the phone. See
// docs/LIFEDRIVE_QR_LOGIN.md.
//
// The phone holds the identity. It mints a short passport, encrypts it to an
// ephemeral public key the browser put in the QR, and deposits the result here;
// the browser claims it by the same token, decrypts it and calls LoginWithPPT.
// The browser never holds a key, so it needs no secure origin and can address a
// household node over plain HTTP.
//
// The phone cannot reach the browser, so the node holds the ciphertext in
// between. Leither offers an application no key-value store, so the hand-off is
// a small file MiMei the owner authors, one record per pending request, in the
// same shape as the share registry.

const (
	qrLoginExt  = "lifedrive.qr-login/v1"
	qrLoginMark = "qr-login"
	// A hand-off is a hand-off: the phone and the browser are in the same room,
	// so the window is the time it takes to scan, not a session lifetime.
	qrLoginTTL           = 2 * time.Minute
	qrLoginMaxPending    = 32
	qrLoginMaxBytes      = 262144
	qrLoginMaxSealed     = 8192
	qrLoginSchemaVersion = 1
)

// qrLoginRecord is one pending sign-in. Sealed is the whole answer: the
// passport, and the identity it belongs to, encrypted to the browser's
// ephemeral public key. Nothing about the owner is stored beside it, because
// this MiMei is readable without a session -- see openQRLoginRegistry.
type qrLoginRecord struct {
	Token     string `json:"token"`
	Sealed    string `json:"sealed"`
	CreatedAt string `json:"created_at"`
	ExpiresAt string `json:"expires_at"`
}

type qrLoginRegistry struct {
	Version int             `json:"version"`
	Pending []qrLoginRecord `json:"pending"`
}

// qrLoginStatePath names the hand-off pointer beside the running service, for
// the same reason the share registry has one: the MiMei is authored by the
// owner's key, and MMCreate is deterministic in its author, so the browser --
// which has no session at all -- cannot derive the MID for itself.
func qrLoginStatePath() (string, error) {
	root, err := leitherRootDirectory()
	if err != nil {
		return "", err
	}
	return joinUnixPath(root, driveID+".qrlogin"), nil
}

// openQRLoginRegistry resolves the hand-off under the phone's own session,
// creating it the first time an owner signs a browser in.
//
// The owner authors it deliberately. The application's own identity could
// author it instead, which would let the claim delete a record as it is read --
// but that identity can be assumed by any node running LifeDrive, so a deposit
// would then be open to anyone with a Leither session, and a browser could be
// handed a passport for somebody else's uid. Authoring it with the owner's key
// means Leither refuses every write but the owner's, which is the property this
// flow actually depends on. What it costs is deletion on claim; see
// entryQRLoginClaim.
func openQRLoginRegistry(c *ctx, callerSID string) (string, error) {
	path, err := qrLoginStatePath()
	if err != nil {
		return "", err
	}
	if data, readErr := os.ReadFile(path); readErr == nil {
		if mid := strings.TrimSpace(string(data)); validMID(mid) {
			return mid, nil
		}
	}
	mid, err := c.api.MMCreate(callerSID, c.str("aid"), qrLoginExt, qrLoginMark, fileType, c.creationRight())
	if err != nil {
		return "", fmt.Errorf("create qr login registry: %w", err)
	}
	if err := os.WriteFile(path, []byte(mid+"\n"), 0o600); err != nil {
		return "", fmt.Errorf("record qr login registry: %w", err)
	}
	return mid, nil
}

// recordedQRLoginRegistry is the read-only half, for the browser. It never
// creates: a browser showing a code before any phone has ever deposited finds
// no registry, and therefore nothing to claim.
func recordedQRLoginRegistry() (string, error) {
	path, err := qrLoginStatePath()
	if err != nil {
		return "", err
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return "", fmt.Errorf("no qr login registry recorded for this node")
	}
	mid := strings.TrimSpace(string(data))
	if !validMID(mid) {
		return "", fmt.Errorf("invalid qr login registry recorded for this node")
	}
	return mid, nil
}

func readQRLogins(c *ctx, sid, mid string) (qrLoginRegistry, error) {
	registry := qrLoginRegistry{Version: qrLoginSchemaVersion}
	handle, err := c.api.MMOpen(sid, mid, "last")
	if err != nil {
		return registry, nil
	}
	defer closeHandle(c, handle)
	size, err := c.api.MFGetSize(handle)
	if err != nil {
		return registry, err
	}
	if size <= 0 {
		return registry, nil
	}
	if size > qrLoginMaxBytes {
		return registry, fmt.Errorf("invalid qr login registry size")
	}
	data, err := c.api.MFGetData(handle, 0, int(size))
	if err != nil {
		return registry, err
	}
	if err := json.Unmarshal(data, &registry); err != nil || registry.Version != qrLoginSchemaVersion {
		return qrLoginRegistry{Version: qrLoginSchemaVersion}, fmt.Errorf("invalid qr login registry record")
	}
	return registry, nil
}

// writeQRLogins commits with MFSetData plus MMBackup, as writeShares does. This
// MiMei holds its own bytes rather than a staged directory CID, so MMBackup is
// the correct commit here.
func writeQRLogins(c *ctx, ownerSID, mid string, registry qrLoginRegistry) error {
	registry.Version = qrLoginSchemaVersion
	payload, err := json.Marshal(registry)
	if err != nil {
		return err
	}
	if len(payload) > qrLoginMaxBytes {
		return fmt.Errorf("qr login registry too large")
	}
	handle, err := c.api.MMOpen(ownerSID, mid, "cur")
	if err != nil {
		return err
	}
	written, err := c.api.MFSetData(handle, payload, 0)
	if err != nil || written != len(payload) {
		closeHandle(c, handle)
		return fmt.Errorf("write qr login registry")
	}
	if err := c.api.MFTruncate(handle, int64(len(payload))); err != nil {
		closeHandle(c, handle)
		return err
	}
	closeHandle(c, handle)
	_, err = c.api.MMBackup(ownerSID, mid, "qr login deposit", "delref=false")
	return err
}

// validSealed accepts the opaque envelope the phone produced. The node never
// opens it -- only the browser holding the ephemeral private key can -- so this
// checks shape and size and nothing else. Base64url, because that is what
// survives a JSON record and a QR-adjacent hand-off unmangled.
func validSealed(value string) bool {
	if len(value) < 64 || len(value) > qrLoginMaxSealed {
		return false
	}
	for _, character := range value {
		switch {
		case character >= 'A' && character <= 'Z':
		case character >= 'a' && character <= 'z':
		case character >= '0' && character <= '9':
		case character == '-' || character == '_':
		default:
			return false
		}
	}
	return true
}

func qrLoginExpired(record qrLoginRecord, now time.Time) bool {
	expires, err := time.Parse(time.RFC3339, record.ExpiresAt)
	if err != nil {
		return true
	}
	return !now.Before(expires)
}

func sweepQRLogins(registry qrLoginRegistry, now time.Time) qrLoginRegistry {
	remaining := []qrLoginRecord{}
	for _, record := range registry.Pending {
		if qrLoginExpired(record, now) {
			continue
		}
		remaining = append(remaining, record)
	}
	registry.Pending = remaining
	return registry
}

// ownsDrive answers whether this caller is the household's owner, rather than
// merely somebody with a Leither session.
//
// requireAccess cannot answer it. Every other entry gets the answer for free,
// because every mutation commits with MFSetCid on the caller's own session and
// Leither admits only the drive's author -- so an unauthorized device is refused
// by the node. A deposit has no such moment: the write it performs is to the
// hand-off MiMei, and it decides who a browser will be signed in as. So it is
// checked here, against the drive's recorded author.
//
// mminfo carries it: verified on a live node, where GetVar("", "mminfo", mid)
// answers a MiMeiInfo whose Author is the uid that created the MiMei.
func ownsDrive(c *ctx, access *driveAccess) bool {
	if access.userID == "" {
		return false
	}
	raw, err := c.api.GetVar("", "mminfo", access.driveMID)
	if err != nil {
		logError(c, "resolve drive author %s: %v", access.driveMID, err)
		return false
	}
	info, ok := raw.(lapi.MiMeiInfo)
	if !ok {
		pointer, isPointer := raw.(*lapi.MiMeiInfo)
		if !isPointer || pointer == nil {
			logError(c, "unexpected mminfo type %T", raw)
			return false
		}
		info = *pointer
	}
	return info.Author == access.userID
}

// entryQRLoginDeposit is the phone's half. It runs on the phone's own session,
// so Leither admits the write only if that session holds the owner's key: a
// deposit is therefore proof that the household's owner scanned this code.
//
// It leaves an encrypted passport for one token and nothing else. The token
// came off the QR the browser drew, so a phone that never scanned cannot name
// one a browser is waiting on.
func entryQRLoginDeposit(c *ctx) (any, error) {
	if failure := versionFailure(c); failure != nil {
		return failure, nil
	}
	token := c.str("token")
	if !validToken(token) {
		return fail(c, "lifedrive.qr_login.invalid_token", "error.qr_login.invalid_token", false), nil
	}
	sealed := c.str("sealed")
	if !validSealed(sealed) {
		return fail(c, "lifedrive.qr_login.invalid_payload", "error.qr_login.invalid_payload", false), nil
	}
	access, err := requireAccess(c, "modify", "drive")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	// Checked before the registry is opened, so a caller who is not the owner
	// cannot become its author by being the first to deposit.
	if !ownsDrive(c, access) {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	mid, err := openQRLoginRegistry(c, access.sid)
	if err != nil {
		logError(c, "qr login registry unavailable: %v", err)
		return fail(c, "lifedrive.qr_login.deposit_failed", "error.qr_login.deposit_failed", true), nil
	}
	registry, err := readQRLogins(c, access.sid, mid)
	if err != nil {
		logError(c, "qr login registry unreadable: %v", err)
		return fail(c, "lifedrive.qr_login.deposit_failed", "error.qr_login.deposit_failed", true), nil
	}
	now := serverNow()
	// Expired requests go now rather than later: this is the only entry that can
	// write, so a record nobody claimed is dropped by the next person to sign in.
	registry = sweepQRLogins(registry, now)
	for _, existing := range registry.Pending {
		if existing.Token == token {
			return fail(c, "lifedrive.qr_login.invalid_token", "error.qr_login.invalid_token", false), nil
		}
	}
	if len(registry.Pending) >= qrLoginMaxPending {
		return fail(c, "lifedrive.qr_login.too_many", "error.qr_login.too_many", false), nil
	}
	expires := now.Add(qrLoginTTL)
	registry.Pending = append(registry.Pending, qrLoginRecord{
		Token: token, Sealed: sealed,
		CreatedAt: serverTime(), ExpiresAt: expires.Format(time.RFC3339),
	})
	if err := writeQRLogins(c, access.sid, mid, registry); err != nil {
		logError(c, "qr login deposit failed: %v", err)
		return fail(c, "lifedrive.qr_login.deposit_failed", "error.qr_login.deposit_failed", true), nil
	}
	return ok(c, map[string]any{"token": token, "expires_at": expires.Format(time.RFC3339)}), nil
}

// entryQRLoginClaim is the browser's half, and it is public: a browser waiting
// to be signed in has no identity and no session, which is the entire point.
//
// It reads and does not delete. Deleting would be a write, and this MiMei is
// authored by the owner's key precisely so that nobody else can write to it --
// so the choice was between a claim that can delete and a deposit that only the
// owner can make, and the deposit is what the flow's security rests on. What
// carries single use instead is the pairing itself: the record expires in two
// minutes, and it is ciphertext sealed to one ephemeral public key, so a second
// reader gets bytes no key of theirs will open. The next deposit sweeps it.
func entryQRLoginClaim(c *ctx) (any, error) {
	if failure := versionFailure(c); failure != nil {
		return failure, nil
	}
	token := c.str("token")
	if !validToken(token) {
		return fail(c, "lifedrive.qr_login.invalid_token", "error.qr_login.invalid_token", false), nil
	}
	mid, err := recordedQRLoginRegistry()
	if err != nil {
		return fail(c, "lifedrive.qr_login.pending", "error.qr_login.pending", true), nil
	}
	// No session, like every other read on this node.
	registry, err := readQRLogins(c, "", mid)
	if err != nil {
		logError(c, "qr login claim failed: %v", err)
		return fail(c, "lifedrive.qr_login.claim_failed", "error.qr_login.claim_failed", true), nil
	}
	now := serverNow()
	for _, record := range registry.Pending {
		if record.Token != token {
			continue
		}
		if qrLoginExpired(record, now) {
			return fail(c, "lifedrive.qr_login.expired", "error.qr_login.expired", false), nil
		}
		return ok(c, map[string]any{"token": token, "sealed": record.Sealed, "expires_at": record.ExpiresAt}), nil
	}
	// Not an error: the browser polls this from the moment it draws the code,
	// and until the phone has scanned there is genuinely nothing there yet.
	return fail(c, "lifedrive.qr_login.pending", "error.qr_login.pending", true), nil
}
