#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
LEITHER_WORKDIR="${LIFEDRIVE_WORKDIR:-$(cd "$SCRIPT_DIR/.." && pwd)}"
LEITHER_BIN="${LIFEDRIVE_LEITHER_PATH:-$LEITHER_WORKDIR/Leither}"
REGISTRY_URL="${LIFEDRIVE_REGISTRY_URL:-https://registry.inoku.uk/v1/usernames/register}"
RESET_PASSWORD=0
SKIP_DOMAIN=0

usage() {
  cat <<'EOF'
Usage: lifeDrive-setup.sh [options]

Options:
  --recover                 Reset the saved owner's password and restore its drive grant.
  --skip-domain             Finish local setup without registering an inoku.uk address.
  --registry-url URL        AV1 public-address registration endpoint.
  --publisher-key FILE      Publish with a retained key instead of hostkey.cfg.
  -h, --help                Show this help.
EOF
}

while (( $# )); do
  case "$1" in
    --recover) RESET_PASSWORD=1 ;;
    --skip-domain) SKIP_DOMAIN=1 ;;
    --registry-url)
      shift
      [[ $# -gt 0 ]] || { echo "--registry-url requires a URL" >&2; exit 2; }
      REGISTRY_URL="$1"
      ;;
    --publisher-key)
      shift
      [[ $# -gt 0 ]] || { echo "--publisher-key requires a file" >&2; exit 2; }
      export LIFEDRIVE_PUBLISHER_KEY="$1"
      ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
  shift
done

if [[ ! -x "$LEITHER_BIN" ]]; then
  echo "LifeDrive setup stopped: Leither was not found at $LEITHER_BIN." >&2
  echo "Run this installer from the Leither root or set LIFEDRIVE_WORKDIR." >&2
  exit 1
fi

version_json=$(cd "$LEITHER_WORKDIR" && "$LEITHER_BIN" version --json 2>/dev/null || true)
version=$(sed -n 's/.*"version":"V\{0,1\}\([0-9][0-9.]*\)".*/\1/p' <<<"$version_json")
if [[ ! "$version" =~ ^([0-9]+)\.([0-9]+)\.([0-9]+)$ ]]; then
  echo "LifeDrive setup stopped: the Leither version could not be verified." >&2
  exit 1
fi
if (( BASH_REMATCH[1] == 0 && (BASH_REMATCH[2] < 24 || (BASH_REMATCH[2] == 24 && BASH_REMATCH[3] < 4)) )); then
  echo "LifeDrive requires Leither V0.24.04 or newer; this node has V$version." >&2
  exit 1
fi

export LIFEDRIVE_WORKDIR="$LEITHER_WORKDIR"
export LIFEDRIVE_LEITHER_PATH="$LEITHER_BIN"
export LIFEDRIVE_APP_NAME="lifeDrive"

owner_state="$LEITHER_WORKDIR/lifeDrive.owner"
domain_state="$LEITHER_WORKDIR/lifeDrive.domain"
saved_owner_name=""
saved_owner_uid=""
if [[ -s "$owner_state" ]]; then
  saved_owner_name=$(sed -n '1p' "$owner_state")
  saved_owner_uid=$(sed -n '2p' "$owner_state")
fi

is_identifier() {
  local value="$1"
  (( ${#value} >= 8 && ${#value} <= 256 )) && [[ "$value" =~ ^[A-Za-z0-9_-]+$ ]]
}

leither_service_port() {
  local vars_file="$LEITHER_WORKDIR/SystemVars.json"
  if [[ ! -f "$vars_file" ]]; then vars_file="$LEITHER_WORKDIR/systemvars.json"; fi
  local port=""
  if [[ -f "$vars_file" ]]; then
    port=$(sed -n 's/.*"ServicePort"[[:space:]]*:[[:space:]]*\([0-9][0-9]*\).*/\1/p' "$vars_file" | head -n 1)
  fi
  if [[ ! "$port" =~ ^[0-9]+$ ]] || (( port < 1 || port > 65535 )); then port=4800; fi
  printf '%s' "$port"
}

leither_lan_ip() {
  local candidates="" candidate="" fallback=""
  if command -v hostname >/dev/null 2>&1; then
    candidates=$(hostname -I 2>/dev/null || true)
  fi
  if [[ -z "$candidates" ]] && command -v ifconfig >/dev/null 2>&1; then
    candidates=$(ifconfig 2>/dev/null | awk '/inet / { print $2 }' | tr '\n' ' ')
  fi
  for candidate in $candidates; do
    [[ "$candidate" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || continue
    [[ "$candidate" == 127.* || "$candidate" == 169.254.* ]] && continue
    if [[ "$candidate" == 10.* || "$candidate" == 192.168.* || "$candidate" =~ ^172\.(1[6-9]|2[0-9]|3[01])\. ]]; then
      printf '%s' "$candidate"
      return
    fi
    fallback="${fallback:-$candidate}"
  done
  printf '%s' "$fallback"
}

owner_name="${LIFEDRIVE_OWNER_NAME:-}"
if [[ -z "$owner_name" ]]; then
  if [[ -n "$saved_owner_name" ]]; then
    read -r -p "LifeDrive username [$saved_owner_name]: " owner_name
    owner_name="${owner_name:-$saved_owner_name}"
  else
    read -r -p "LifeDrive username: " owner_name
  fi
fi
owner_name=$(printf '%s' "$owner_name" | tr '[:upper:]' '[:lower:]')
if (( ${#owner_name} < 1 || ${#owner_name} > 63 )) || [[ ! "$owner_name" =~ ^[a-z0-9]([a-z0-9-]*[a-z0-9])?$ ]]; then
  echo "Use 1-63 lowercase letters, numbers, or interior hyphens for the LifeDrive username." >&2
  exit 1
fi

owner_password="${LIFEDRIVE_OWNER_PASSWORD:-}"
owner_password_provided="${LIFEDRIVE_OWNER_PASSWORD_PROVIDED:-0}"
if (( RESET_PASSWORD )) || [[ "$owner_name" != "$saved_owner_name" ]] || ! is_identifier "$saved_owner_uid"; then
  if [[ "$owner_password_provided" != "1" ]]; then
    read -r -s -p "Owner password: " owner_password
    echo
    read -r -s -p "Confirm password: " owner_password_confirmation
    echo
    if [[ "$owner_password" != "$owner_password_confirmation" ]]; then
      echo "The passwords did not match." >&2
      exit 1
    fi
  fi
fi

registration_enabled=0
if [[ -s "$domain_state" ]]; then
  domain=$(tr -d '\r\n' < "$domain_state")
  echo "Public address already registered: https://$domain/"
elif (( SKIP_DOMAIN )); then
  echo "Public-address registration skipped."
else
  registration_enabled=1
  export LIFEDRIVE_REGISTRY_URL="$REGISTRY_URL"
  if [[ -n "$saved_owner_name" && "$owner_name" == "$saved_owner_name" ]]; then
    echo "Local LifeDrive owner '$owner_name' already exists; its public address is not registered yet."
  fi
  LIFEDRIVE_PUBLIC_USERNAME="$owner_name" "$SCRIPT_DIR/lifeDrive-register.sh" --check "$owner_name"
fi

echo "Publishing LifeDrive with this node's retained identity..."
"$SCRIPT_DIR/lifeDrive.sh"

if (( RESET_PASSWORD )); then
  export LIFEDRIVE_RESET_PASSWORD=1
fi
LIFEDRIVE_OWNER_NAME="$owner_name" \
  LIFEDRIVE_OWNER_PASSWORD="$owner_password" \
  LIFEDRIVE_OWNER_PASSWORD_PROVIDED=1 \
  "$SCRIPT_DIR/lifeDrive-owner.sh"
unset owner_password owner_password_confirmation LIFEDRIVE_OWNER_PASSWORD LIFEDRIVE_OWNER_PASSWORD_PROVIDED
unset LIFEDRIVE_RESET_PASSWORD

if (( registration_enabled )); then
  LIFEDRIVE_PUBLIC_USERNAME="$owner_name" "$SCRIPT_DIR/lifeDrive-register.sh"
elif [[ ! -s "$domain_state" && "$SKIP_DOMAIN" != "1" ]]; then
  echo "Local LifeDrive setup is complete."
  echo "Rerun with --registry-url when the AV1 registration endpoint is available."
fi

"$SCRIPT_DIR/lifeDrive-remove-stream-service.sh"

echo
echo "LifeDrive setup finished."
if [[ -s "$domain_state" ]]; then
  domain=$(tr -d '\r\n' < "$domain_state")
  echo "Open LifeDrive: https://$domain/"
else
  app_mid=$(tr -d '\r\n' < "$LEITHER_WORKDIR/lifeDrive.appid")
  echo "App MID: $app_mid"
  lan_ip=$(leither_lan_ip)
  service_port=$(leither_service_port)
  if [[ -n "$lan_ip" ]]; then
    echo "Open on this LAN: http://$lan_ip:$service_port/entry?aid=$app_mid&ver=last"
  else
    echo "Open from another device with this server's LAN IP: http://<LAN-IP>:$service_port/entry?aid=$app_mid&ver=last"
  fi
fi
