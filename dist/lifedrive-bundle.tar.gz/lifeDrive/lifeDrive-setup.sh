#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
default_root=$(cd "$SCRIPT_DIR/.." && pwd)
if [[ "$(basename "$default_root")" == lepan && -f "$default_root/.installer-layout-v1" ]]; then
  default_root=$(cd "$default_root/.." && pwd)
fi
LEITHER_WORKDIR="${LIFEDRIVE_WORKDIR:-$default_root}"
LEITHER_BIN="${LIFEDRIVE_LEITHER_PATH:-$LEITHER_WORKDIR/Leither}"
REGISTRY_URL="${LIFEDRIVE_REGISTRY_URL:-https://registry.lepan.org/v1/usernames/register}"
# The one published LifeDrive, the same MID the web client carries as
# PUBLISHED_APP_ID. A household node syncs this rather than publishing its own:
# see docs/LIFEDRIVE_UNIVERSAL_APP_AND_HTTPS.md. Overridable so a candidate
# application can be installed for testing.
PUBLISHED_APP_MID="${LIFEDRIVE_PUBLISHED_APP_MID:-FKI2uZtAp6ZjUeecxQ4PvBq4bvK}"
ADD_DEVICE=0
DEVICE_LABEL="${LIFEDRIVE_DEVICE_LABEL:-Primary browser}"
IDENTITY_OUT="${LIFEDRIVE_IDENTITY_OUT:-}"
DEVICE_COMMAND=""
REVOKE_DEVICE_UID=""
SKIP_DOMAIN=0
UPGRADE_ONLY=0
OPERATION_COUNT=0

usage() {
  cat <<'EOF'
Usage: lifeDrive-setup.sh [options]

Options:
  --upgrade                 Take a newer application version without changing device authorization.
  --add-device LABEL        Create and authorize a separate Leither identity for another device.
  --identity-out FILE       Write the new device identity to this new file.
  --list-devices            List authorized device key IDs and labels.
  --revoke-device UID       Remove one device's native LePan grant.
  --skip-domain             Finish local setup without registering a lepan.org address.
  --registry-url URL        AV1 public-address registration endpoint.
  --publisher-key FILE      Publish with a retained key instead of hostkey.cfg (publishing node only).
  -h, --help                Show this help.
EOF
}

while (( $# )); do
  case "$1" in
    --upgrade) UPGRADE_ONLY=1; OPERATION_COUNT=$((OPERATION_COUNT + 1)) ;;
    --add-device)
      shift
      [[ $# -gt 0 ]] || { echo "--add-device requires a device label" >&2; exit 2; }
      ADD_DEVICE=1
      OPERATION_COUNT=$((OPERATION_COUNT + 1))
      DEVICE_LABEL="$1"
      ;;
    --identity-out)
      shift
      [[ $# -gt 0 ]] || { echo "--identity-out requires a file" >&2; exit 2; }
      IDENTITY_OUT="$1"
      ;;
    --list-devices) DEVICE_COMMAND="list"; OPERATION_COUNT=$((OPERATION_COUNT + 1)) ;;
    --revoke-device)
      shift
      [[ $# -gt 0 ]] || { echo "--revoke-device requires a device UID" >&2; exit 2; }
      DEVICE_COMMAND="revoke"
      OPERATION_COUNT=$((OPERATION_COUNT + 1))
      REVOKE_DEVICE_UID="$1"
      ;;
    --skip-domain) SKIP_DOMAIN=1 ;;
    --registry-url)
      shift
      [[ $# -gt 0 ]] || { echo "--registry-url requires a URL" >&2; exit 2; }
      REGISTRY_URL="$1"
      ;;
    --publisher-key)
      shift
      [[ $# -gt 0 ]] || { echo "--publisher-key requires a file" >&2; exit 2; }
      export LIFEDRIVE_PUBLISHER_KEY="$1"
      ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
  shift
done

if (( OPERATION_COUNT > 1 )); then
  echo "Choose only one of --upgrade, --add-device, --list-devices, or --revoke-device." >&2
  exit 2
fi
if [[ -n "$IDENTITY_OUT" ]] && { (( UPGRADE_ONLY )) || [[ -n "$DEVICE_COMMAND" ]]; }; then
  echo "--identity-out is only valid during initial setup or with --add-device." >&2
  exit 2
fi

if [[ ! -x "$LEITHER_BIN" ]]; then
  echo "LePan setup stopped: Leither was not found at $LEITHER_BIN." >&2
  echo "Run this installer from the Leither root or set LIFEDRIVE_WORKDIR." >&2
  exit 1
fi

version_json=$(cd "$LEITHER_WORKDIR" && "$LEITHER_BIN" version --json 2>/dev/null || true)
version=$(sed -n 's/.*"version":"V\{0,1\}\([0-9][0-9.]*\)".*/\1/p' <<<"$version_json")
if [[ ! "$version" =~ ^([0-9]+)\.([0-9]+)\.([0-9]+)$ ]]; then
  echo "LePan setup stopped: the Leither version could not be verified." >&2
  exit 1
fi
if (( BASH_REMATCH[1] == 0 && (BASH_REMATCH[2] < 24 || (BASH_REMATCH[2] == 24 && BASH_REMATCH[3] < 11)) )); then
  echo "LePan key authentication requires Leither V0.24.11 or newer; this node has V$version." >&2
  exit 1
fi

export LIFEDRIVE_WORKDIR="$LEITHER_WORKDIR"
export LIFEDRIVE_LEITHER_PATH="$LEITHER_BIN"
export LIFEDRIVE_APP_NAME="lifeDrive"

detail_log="$LEITHER_WORKDIR/lifeDrive-setup.log"
umask 077
: > "$detail_log"

owner_state="$LEITHER_WORKDIR/lifeDrive.owner"
domain_state="$LEITHER_WORKDIR/lifeDrive.domain"
saved_owner_name=""
saved_owner_uid=""
saved_owner_device=""
if [[ -s "$owner_state" && "$(sed -n '1p' "$owner_state")" == "lifedrive-key-auth-v1" ]]; then
  saved_owner_name=$(sed -n '2p' "$owner_state")
  saved_owner_uid=$(sed -n '3p' "$owner_state")
  saved_owner_device=$(sed -n '4p' "$owner_state")
fi

is_identifier() {
  local value="$1"
  (( ${#value} >= 8 && ${#value} <= 256 )) && [[ "$value" =~ ^[A-Za-z0-9_-]+$ ]]
}

leither_service_port() {
  local vars_file="$LEITHER_WORKDIR/SystemVars.json"
  if [[ ! -f "$vars_file" ]]; then vars_file="$LEITHER_WORKDIR/systemvars.json"; fi
  local port=""
  if [[ -f "$vars_file" ]]; then
    port=$(sed -n 's/.*"ServicePort"[[:space:]]*:[[:space:]]*\([0-9][0-9]*\).*/\1/p' "$vars_file" | head -n 1)
  fi
  if [[ ! "$port" =~ ^[0-9]+$ ]] || (( port < 1 || port > 65535 )); then port=4800; fi
  printf '%s' "$port"
}

# The identifier this node answers as -- the first line of "Leither swarm id".
# It is how a browser reaches a household now that addresses are routed by node
# id rather than by a per-household DNS name.
leither_node_id() {
  "$LEITHER_BIN" swarm id 2>/dev/null | head -n 1 | tr -d '[:space:]'
}
# What to do after setup: where to open LePan. drive.lepan.org carries the node id
# in the link, so it works from any network and finds this node's address itself;
# the node's own address serves the same app directly while at home. There is no
# per-household or gateway address to print.
print_open_instructions() {
  local app_id="$1" node_id lan_ip service_port
  if [[ -s "$domain_state" ]]; then
    echo "Open LePan: https://$(tr -d '\r\n' < "$domain_state")/"
    return
  fi
  node_id=$(leither_node_id)
  lan_ip=$(leither_lan_ip)
  service_port=$(leither_service_port)
  echo "To use LePan in a browser, open this address and scan the code it shows with the"
  echo "LePan app on your phone (Settings > My devices > Pair a browser):"
  echo
  if [[ -n "$node_id" ]]; then
    echo "  http://drive.lepan.org/?n=$node_id"
  else
    echo "  http://drive.lepan.org/"
  fi
  if [[ -n "$lan_ip" ]]; then
    echo
    echo "At home, this node also serves LePan itself:"
    echo "  http://$lan_ip:$service_port/entry?aid=$app_id&ver=last"
  fi
}
leither_lan_ip() {
  local candidates="" candidate="" fallback=""
  if command -v hostname >/dev/null 2>&1; then
    candidates=$(hostname -I 2>/dev/null || true)
  fi
  if [[ -z "$candidates" ]] && command -v ifconfig >/dev/null 2>&1; then
    candidates=$(ifconfig 2>/dev/null | awk '/inet / { print $2 }' | tr '\n' ' ')
  fi
  for candidate in $candidates; do
    [[ "$candidate" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || continue
    [[ "$candidate" == 127.* || "$candidate" == 169.254.* ]] && continue
    if [[ "$candidate" == 10.* || "$candidate" == 192.168.* || "$candidate" =~ ^172\.(1[6-9]|2[0-9]|3[01])\. ]]; then
      printf '%s' "$candidate"
      return
    fi
    fallback="${fallback:-$candidate}"
  done
  printf '%s' "$fallback"
}

if [[ -n "$DEVICE_COMMAND" ]]; then
  if [[ "$DEVICE_COMMAND" == "list" ]]; then
    "$SCRIPT_DIR/lifeDrive-device.sh" list
  else
    "$SCRIPT_DIR/lifeDrive-device.sh" revoke "$REVOKE_DEVICE_UID"
  fi
  exit 0
fi

prepare_pairing_qr() {
  if [[ -n "${LIFEDRIVE_PAIRING_RESULT:-}" ]]; then
    (umask 077
      cp -- "$1" "$LIFEDRIVE_PAIRING_RESULT"
      printf '%s' "$LEITHER_WORKDIR" > "$LIFEDRIVE_PAIRING_RESULT.directory")
  fi
}

if (( ADD_DEVICE )); then
  app_state="$LEITHER_WORKDIR/lifeDrive.appid"
  if [[ -z "$saved_owner_name" || ! -s "$app_state" ]]; then
    echo "LePan device setup stopped: this installation has no key-authenticated owner." >&2
    exit 1
  fi
  echo "Creating a separate Leither identity for '$DEVICE_LABEL'..."
  if ! LIFEDRIVE_OWNER_NAME="$saved_owner_name" LIFEDRIVE_DEVICE_LABEL="$DEVICE_LABEL" \
    LIFEDRIVE_IDENTITY_OUT="$IDENTITY_OUT" LIFEDRIVE_ADD_DEVICE=1 \
    "$SCRIPT_DIR/lifeDrive-owner.sh" >> "$detail_log" 2>&1; then
    echo "LePan device setup failed." >&2
    echo "Details: $detail_log" >&2
    exit 1
  fi
  identity_path=$(tr -d '\r\n' < "$LEITHER_WORKDIR/lifeDrive.identity-path")
  echo "Device authorized."
  echo "Identity file: $identity_path"
  if [[ -z "${LIFEDRIVE_PAIRING_RESULT:-}" ]]; then
    echo "Copy this file to that device and choose it in the LePan app (Settings > Set up users),"
    echo "then keep the original somewhere safe and offline."
  fi
  prepare_pairing_qr "$identity_path"
  exit 0
fi

if (( UPGRADE_ONLY )); then
  app_state="$LEITHER_WORKDIR/lifeDrive.appid"
  if [[ ! -s "$owner_state" || ! -s "$app_state" ]]; then
    echo "LePan upgrade stopped: the existing owner or application identity is missing." >&2
    echo "Run the ordinary installer to finish setup before using --upgrade." >&2
    exit 1
  fi
  if [[ -z "$saved_owner_name" ]] || ! is_identifier "$saved_owner_uid"; then
    echo "LePan upgrade stopped: this installation does not use the required key-auth owner state." >&2
    echo "Install this development branch as a new LePan rather than migrating a password owner." >&2
    exit 1
  fi

  saved_app_mid=$(tr -d '[:space:]' < "$app_state")
  if ! is_identifier "$saved_app_mid"; then
    echo "LePan upgrade stopped: the saved application identity is invalid." >&2
    exit 1
  fi

  # An upgrade takes the newer published version; it does not publish one. The
  # node runs the application from the synced MiMei, so this is the whole of it.
  echo "Synchronizing the published LePan application..."
  if ! "$LEITHER_BIN" mimei sync --mid "$saved_app_mid" >> "$detail_log" 2>&1; then
    echo "LePan upgrade stopped: could not synchronize application $saved_app_mid." >&2
    echo "The node needs to reach a peer that provides it. Details: $detail_log" >&2
    exit 1
  fi
  # Leither refreshes published applications automatically. Its shared service
  # may host other apps and must not be restarted just to clear a cached entry.
  echo "Synchronized. Allow Leither's application cache to refresh."
  upgraded_app_mid=$(tr -d '[:space:]' < "$app_state")
  if [[ "$upgraded_app_mid" != "$saved_app_mid" ]]; then
    echo "LePan upgrade stopped: the application identity changed unexpectedly." >&2
    echo "Details: $detail_log" >&2
    exit 1
  fi

  "$SCRIPT_DIR/lifeDrive-remove-stream-service.sh"
  echo
  echo "LePan upgrade complete."
  echo "Owner: $saved_owner_name"
  echo "App MID: $upgraded_app_mid"
  # An upgrade keeps the existing device authorization, so it creates no
  # identity and used to print none. That is exactly when an owner goes looking
  # for one -- to pair a browser they had not paired before, or to pair again
  # after clearing site data -- and the file lives on a node they may only reach
  # over SSH. Offer the existing identity through the launcher QR code or,
  # when invoked directly, as a copyable invitation.
  identity_path_state="$LEITHER_WORKDIR/lifeDrive.identity-path"
  if [[ -s "$identity_path_state" ]]; then
    existing_identity=$(tr -d '\r\n' < "$identity_path_state")
    if [[ -r "$existing_identity" ]]; then
      echo
      echo "Identity file: $existing_identity"
      prepare_pairing_qr "$existing_identity"
      if [[ -z "${LIFEDRIVE_PAIRING_RESULT:-}" ]]; then
        echo "To connect a phone, paste the block below into the LePan app (Settings > Set up users):"
        echo
        cat "$existing_identity"
        echo
        echo "This block contains a device private key. Clear the terminal afterwards,"
        echo "and give another device its own identity with --add-device LABEL."
      fi
    else
      echo
      echo "Identity file recorded at $existing_identity but not readable now."
      echo "Pair another browser with --add-device LABEL."
    fi
  fi
  echo
  print_open_instructions "$upgraded_app_mid"
  exit 0
fi

owner_name="${LIFEDRIVE_OWNER_NAME:-}"
if [[ -z "$owner_name" ]]; then
  read -r -p "LePan public name: " owner_name
fi
owner_name=$(printf '%s' "$owner_name" | tr '[:upper:]' '[:lower:]')
if (( ${#owner_name} < 1 || ${#owner_name} > 63 )) || [[ ! "$owner_name" =~ ^[a-z0-9]([a-z0-9-]*[a-z0-9])?$ ]]; then
  echo "Use 1-63 lowercase letters, numbers, or interior hyphens for the LePan username." >&2
  exit 1
fi

if [[ -e "$owner_state" ]]; then
  echo "LePan setup stopped: owner state already exists." >&2
  echo "Use --upgrade for application updates or --add-device LABEL for another browser." >&2
  exit 1
fi

# Registering <name>.lepan.org binds a username to an application MID. That only
# distinguishes households while each has its own application, and none does any
# more -- the second household to register the shared MID would be refused with
# app_already_registered. So a node running the published application does not
# register an address; it is reached by node id through the gateway, and
# public_username is a display name again. See LIFEDRIVE_NODE_ID_GATEWAY.md.
#
# Set LIFEDRIVE_REGISTER_DOMAIN=1 to register anyway, which is only meaningful
# for a node running an application of its own.
registration_enabled=0
if [[ -s "$domain_state" ]]; then
  domain=$(tr -d '\r\n' < "$domain_state")
  echo "Public address already registered: https://$domain/"
elif [[ -z "${LIFEDRIVE_REGISTER_DOMAIN:-}" ]]; then
  : # reached by node id; nothing to register or announce
elif (( SKIP_DOMAIN )); then
  echo "Public-address registration skipped."
else
  registration_enabled=1
  export LIFEDRIVE_REGISTRY_URL="$REGISTRY_URL"
  LIFEDRIVE_PUBLIC_USERNAME="$owner_name" "$SCRIPT_DIR/lifeDrive-register.sh" --check "$owner_name"
fi

# A household node adopts the published application; it does not publish one.
#
# It used to publish, which made every household its own application with its own
# MID, and made an upgrade an N-node operation. One published MID that every node
# syncs is what makes publishing a new version reach those nodes without anyone
# touching them. Syncing is a one-time step -- Leither tracks later versions on
# its own. See docs/LIFEDRIVE_UNIVERSAL_APP_AND_HTTPS.md.
echo "Synchronizing the published LePan application..."
if ! "$LEITHER_BIN" mimei sync --mid "$PUBLISHED_APP_MID" >> "$detail_log" 2>&1; then
  echo "LePan setup stopped: could not synchronize application $PUBLISHED_APP_MID." >&2
  echo "The node needs to reach a peer that provides it. Details: $detail_log" >&2
  exit 1
fi
umask 077
printf '%s\n' "$PUBLISHED_APP_MID" > "$LEITHER_WORKDIR/lifeDrive.appid"
app_mid="$PUBLISHED_APP_MID"
echo "LePan application synchronized."

echo "Creating the primary LePan device identity..."
if ! LIFEDRIVE_OWNER_NAME="$owner_name" \
  LIFEDRIVE_DEVICE_LABEL="$DEVICE_LABEL" \
  LIFEDRIVE_IDENTITY_OUT="$IDENTITY_OUT" \
  "$SCRIPT_DIR/lifeDrive-owner.sh" >> "$detail_log" 2>&1; then
  echo "LePan owner setup failed." >&2
  echo "Details: $detail_log" >&2
  exit 1
fi
identity_path=$(tr -d '\r\n' < "$LEITHER_WORKDIR/lifeDrive.identity-path")
echo "Primary device '$DEVICE_LABEL' is authorized."

if (( registration_enabled )); then
  echo "Registering the public LePan address..."
  set +e
  registration_output=$(LIFEDRIVE_PUBLIC_USERNAME="$owner_name" "$SCRIPT_DIR/lifeDrive-register.sh" 2>&1)
  registration_status=$?
  set -e
  printf '%s\n' "$registration_output" >> "$detail_log"
  if (( registration_status != 0 )); then
    echo
    echo "LePan was updated locally, but its public address was not registered." >&2
    case "$registration_output" in
      *inoku.registry.username_taken*) echo "The requested username is bound to a different LePan app." >&2 ;;
      *inoku.registry.app_already_registered*) echo "This LePan app is already bound to a different username." >&2 ;;
      *registry_timeout*|*registry_unavailable*) echo "AV1 could not be reached. The local drive remains ready." >&2 ;;
      *) echo "AV1 rejected the address request." >&2 ;;
    esac
    echo "Details: $detail_log" >&2
    exit "$registration_status"
  fi
  echo "Public address registered."
fi

"$SCRIPT_DIR/lifeDrive-remove-stream-service.sh"

echo
echo "LePan setup complete."
echo
echo "  Owner:         $owner_name"
echo "  Identity file: $identity_path"
node_id=$(leither_node_id)
if [[ -n "$node_id" ]]; then echo "  Node id:       $node_id"; fi
echo "  Application:   $app_mid"
echo
echo "The identity file is the key to this drive. Keep the original somewhere safe and offline."
echo
if [[ -z "${LIFEDRIVE_PAIRING_RESULT:-}" ]]; then
  echo "Next steps"
  echo "  1. Install the LePan app on your phone: https://lepan.org/download/"
  echo "  2. Copy the identity file to the phone, open the app, and choose it under"
  echo "     Settings > Set up users. This connects your phone to this node."
  echo "  3. Keep this computer on and connected to the network."
  echo
fi
print_open_instructions "$app_mid"
prepare_pairing_qr "$identity_path"
