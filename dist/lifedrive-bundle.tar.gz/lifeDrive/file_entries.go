package lapp

import (
	"fmt"
	"strings"
)

func entryDriveOpen(c *ctx) (any, error) {
	if failure := versionFailure(c); failure != nil {
		return failure, nil
	}
	access, err := requireAccess(c, "modify", "drive")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	initialized, err := ensureDriveRoot(c, access.authorSID, access.driveMID)
	if err != nil {
		logError(c, "drive open failed: %v", err)
		return fail(c, "lifedrive.drive.open_failed", "error.drive.open_failed", true), nil
	}
	return ok(c, map[string]any{
		"drive_id": driveID, "drive_mid": access.driveMID, "root_path": "/", "work_root": driveWorkRoot,
		"initialized": initialized, "storage_type": "file", "storage_model": "direct-filesystem/v1",
		"security_mode": "leither-native/v1",
	}), nil
}

func entryDriveList(c *ctx) (any, error) {
	root, err := normalizeDirectory(c.str("path"))
	if err != nil {
		return fail(c, "lifedrive.drive.list_failed", "error.drive.list_failed", true), nil
	}
	access, err := requireAccess(c, "view", "drive")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	objects := []map[string]any{}
	pending := []string{root}
	for len(pending) > 0 && len(objects) < maxItems {
		directory := pending[0]
		pending = pending[1:]
		entries, listErr := c.api.FilesLs(access.authorSID, mimeiURL(access.driveMID, "last", directory))
		if listErr != nil {
			if directory == root && root != "/" {
				return fail(c, "lifedrive.drive.list_failed", "error.drive.list_failed", true), nil
			}
			continue
		}
		for _, link := range entries {
			if len(objects) >= maxItems {
				break
			}
			if link.Name == "" || (directory == "/" && link.Name == ".lifedrive-trash") {
				continue
			}
			path := joinPath(directory, link.Name)
			objects = append(objects, objectFromLink(path, link))
			if link.Type == 1 || link.Type == 5 {
				pending = append(pending, path)
			}
		}
	}
	return ok(c, map[string]any{
		"drive_id": driveID, "drive_mid": access.driveMID, "root_path": root, "storage_type": "file",
		"storage_model": "direct-filesystem/v1", "objects": objects, "truncated": len(pending) > 0,
	}), nil
}

func entryFileGetInfo(c *ctx) (any, error) {
	pathValue := c.str("path")
	if pathValue == "" {
		pathValue = c.str("object_id")
	}
	path, err := normalizeObjectPath(pathValue)
	if err != nil {
		return fail(c, "lifedrive.file.not_found", "error.file.not_found", false), nil
	}
	access, err := requireAccess(c, "view", "file")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	handle, err := c.api.MMOpenUrl("", mimeiURL(access.driveMID, "last", path))
	if err != nil {
		return fail(c, "lifedrive.file.not_found", "error.file.not_found", false), nil
	}
	defer closeHandle(c, handle)
	stat, err := c.api.MFStat(handle)
	if err != nil {
		return fail(c, "lifedrive.file.not_found", "error.file.not_found", false), nil
	}
	size, err := c.api.MFGetSize(handle)
	if err != nil {
		return fail(c, "lifedrive.file.not_found", "error.file.not_found", false), nil
	}
	mimeType, err := c.api.MFGetMimeType(handle)
	if err != nil || mimeType == "" {
		mimeType = "application/octet-stream"
	}
	return ok(c, map[string]any{
		"path": path, "object_id": path, "drive_mid": access.driveMID, "stat": stat,
		"plaintext_size": size, "media_type": mimeType, "supports_ranges": true,
	}), nil
}

func entryFileRead(c *ctx) (any, error) {
	start := parseInt64(c.str("start"), 0)
	count64 := parseInt64(c.str("count"), maxReadChunk)
	if count64 > maxReadChunk {
		count64 = maxReadChunk
	}
	if start < 0 || count64 <= 0 {
		return fail(c, "lifedrive.request.invalid_range", "error.request.invalid_range", false), nil
	}
	pathValue := c.str("path")
	if pathValue == "" {
		pathValue = c.str("object_id")
	}
	path, err := normalizeObjectPath(pathValue)
	if err != nil {
		return fail(c, "lifedrive.file.read_failed", "error.file.read_failed", true), nil
	}
	access, err := requireAccess(c, "view", "file")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	handle, err := c.api.MMOpenUrl("", mimeiURL(access.driveMID, "last", path))
	if err != nil {
		return fail(c, "lifedrive.file.read_failed", "error.file.read_failed", true), nil
	}
	defer closeHandle(c, handle)
	size, err := c.api.MFGetSize(handle)
	if err != nil {
		return fail(c, "lifedrive.file.read_failed", "error.file.read_failed", true), nil
	}
	bytes, err := c.api.MFGetData(handle, start, int(count64))
	if err != nil {
		return fail(c, "lifedrive.file.read_failed", "error.file.read_failed", true), nil
	}
	return ok(c, map[string]any{
		"object_id": path, "path": path, "start": start, "count": len(bytes),
		"eof": start+int64(len(bytes)) >= size, "plaintext_size": size, "bytes": bytes,
	}), nil
}

func normalizeTrashPath(value string) (string, string, error) {
	if strings.Contains(value, "\x00") || strings.Contains(value, "\\") {
		return "", "", fmt.Errorf("invalid trash path")
	}
	parts, err := splitCleanPath(value)
	if err != nil || len(parts) != 2 || parts[0] != ".lifedrive-trash" {
		return "", "", fmt.Errorf("invalid trash path")
	}
	original, err := percentDecode(parts[1])
	if err != nil || !strings.HasPrefix(original, "/") {
		return "", "", fmt.Errorf("invalid trash path")
	}
	if _, err := normalizeObjectPath(original); err != nil {
		return "", "", fmt.Errorf("invalid trash path")
	}
	return "/" + strings.Join(parts, "/"), original, nil
}

func entryTrashList(c *ctx) (any, error) {
	access, err := requireAccess(c, "view", "drive")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	entries, err := c.api.FilesLs(access.authorSID, mimeiURL(access.driveMID, "last", trashRoot))
	if err != nil {
		entries = nil
	}
	objects := []map[string]any{}
	for _, link := range entries {
		original, decodeErr := percentDecode(link.Name)
		if decodeErr != nil || !strings.HasPrefix(original, "/") || strings.Contains(original, "\x00") {
			continue
		}
		name := baseName(original)
		directory := link.Type == 1 || link.Type == 5
		kind := kindOf(name, directory, "")
		size := uint64(0)
		if !directory {
			size = link.Size
		}
		objects = append(objects, map[string]any{
			"object_id": original, "path": original, "original_path": original,
			"trash_path": trashRoot + "/" + link.Name, "kind": kind, "display_name": name,
			"parent_id": "root", "parent_path": "root", "media_type": mediaTypeOf(name, kind),
			"plaintext_size": size, "created_at": nil, "modified_at": nil,
		})
	}
	return ok(c, map[string]any{"drive_mid": access.driveMID, "objects": objects}), nil
}
