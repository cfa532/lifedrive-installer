package lapp

import (
	"Leither/lapi"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"strings"
)

// The endpoint is fixed to this node. The helper supplies Leither's Hprose
// transport without importing network packages into the interpreter.
type householdStub struct {
	HouseholdNetworkShare func(string) (string, error)                 `timeout:"60000"`
	HouseholdShareOpen    func(string, string, string) (string, error) `timeout:"60000"`
	HouseholdInfo         func() (string, error)                       `timeout:"5000"`
	HouseholdClose        func() error                                 `timeout:"1000"`
	HouseholdRequest      func(string) (string, error)                 `timeout:"60000"`
	HouseholdChunk        func(string, []byte) (string, error)         `timeout:"60000"`
	HouseholdFile         func(string, int64) (string, error)          `timeout:"60000"`
	HouseholdLinkUpload   func(string) (string, error)                 `timeout:"60000"`
}

func entryHouseholdInfo(c *ctx) (any, error) {
	rpc := householdClient()
	defer rpc.HouseholdClose()
	raw, err := rpc.HouseholdInfo()
	value, err := householdResponse(raw, err)
	if err != nil {
		return nil, err
	}
	return ok(c, value), nil
}

func householdClient() *householdStub {
	rpc := &householdStub{}
	lapi.InitStubByUrl(rpc, "http://127.0.0.1:4811")
	return rpc
}
func householdResponse(raw string, err error) (map[string]any, error) {
	if err != nil {
		return nil, fmt.Errorf("household service: %v", err)
	}
	if len(raw) == 0 || len(raw) > 12*1024*1024 {
		return nil, fmt.Errorf("invalid household response")
	}
	var result map[string]any
	if json.Unmarshal([]byte(raw), &result) != nil || result == nil {
		return nil, fmt.Errorf("invalid household response")
	}
	return result, nil
}
func entryHouseholdRequest(c *ctx) (any, error) {
	packet := c.str("packet")
	if len(packet) == 0 || len(packet) > 9*1024*1024 {
		return nil, fmt.Errorf("invalid household request size")
	}
	rpc := householdClient()
	defer rpc.HouseholdClose()
	// An upload chunk travels beside the sealed packet as an encrypted binary
	// argument. Inside the packet it cost base64 twice, so a 4 MiB chunk was a
	// 7.5 MB request. Any other request carries no argument.
	if len(c.args) > 0 {
		chunk, err := chunkArg(c.args)
		if err != nil || len(chunk) == 0 || len(chunk) > binaryChunkMaxSize {
			return nil, fmt.Errorf("invalid household chunk")
		}
		raw, err := rpc.HouseholdChunk(packet, chunk)
		return householdResponse(raw, err)
	}
	raw, err := rpc.HouseholdRequest(packet)
	return householdResponse(raw, err)
}

// Serves the file behind a ticket, honouring a Range.
//
// The Range arrives as an ordinary parameter: Leither passes request headers
// through to the entry. Reading it here is what keeps a video from costing one
// interpreter entry per 512KB -- the client asks once for the span it wants
// instead of once per chunk, and a household_request per chunk was saturating
// ixgo badly enough that unrelated screens timed out behind it.
//
// `wr` is a plain io.Writer, so this cannot answer 206 or set Content-Range.
// The only client that sends a Range here is LifeDrive's own file protocol,
// which knows what it asked for and builds those headers itself.
func entryHouseholdFile(c *ctx) (any, error) {
	token := c.str("ticket")
	if len(token) != 43 || c.wr == nil {
		return nil, fmt.Errorf("invalid file request")
	}
	start, remaining, ranged, err := requestedRange(c.str("range"))
	if err != nil {
		return nil, err
	}
	rpc := householdClient()
	defer rpc.HouseholdClose()
	for offset := start; ; {
		raw, err := rpc.HouseholdFile(token, offset)
		result, err := householdResponse(raw, err)
		if err != nil {
			return nil, err
		}
		if result["success"] != true {
			return nil, fmt.Errorf("file access refused or expired")
		}
		encoded, _ := result["bytes"].(string)
		data, err := base64.StdEncoding.DecodeString(encoded)
		if err != nil {
			return nil, err
		}
		if len(data) > 524288 {
			return nil, fmt.Errorf("invalid file chunk")
		}
		// The last chunk of a range usually overshoots, because the service
		// answers in fixed 512KB reads and knows nothing about the span asked
		// for here.
		if ranged && int64(len(data)) > remaining {
			data = data[:remaining]
		}
		if len(data) > 0 {
			if _, err = c.wr.Write(data); err != nil {
				return nil, err
			}
			offset += int64(len(data))
			remaining -= int64(len(data))
		}
		if ranged && remaining <= 0 {
			return nil, nil
		}
		if result["eof"] == true {
			return nil, nil
		}
		if len(data) == 0 {
			return nil, fmt.Errorf("incomplete file")
		}
	}
}

// bytes=START-END, the only form served. An open end is deliberately refused
// rather than guessed: answering it would mean asking the service for the file
// size first, and the one client that sends a Range always names both ends.
func requestedRange(value string) (start, count int64, ranged bool, err error) {
	if value == "" {
		return 0, 0, false, nil
	}
	if !strings.HasPrefix(value, "bytes=") {
		return 0, 0, false, fmt.Errorf("unsupported range")
	}
	parts := strings.SplitN(strings.TrimPrefix(value, "bytes="), "-", 2)
	if len(parts) != 2 || parts[0] == "" || parts[1] == "" {
		return 0, 0, false, fmt.Errorf("unsupported range")
	}
	start = parseInt64(parts[0], -1)
	end := parseInt64(parts[1], -1)
	if start < 0 || end < start {
		return 0, 0, false, fmt.Errorf("invalid range")
	}
	return start, end - start + 1, true, nil
}

// Resolve only a managed share token. No visitor-supplied authority or path is
// forwarded, and the private drive never appears in the response.
func entryHouseholdShareOpen(c *ctx) (any, error) {
	token, viewer, password := c.str("token"), c.str("viewer"), c.str("password_hash")
	if !validToken(token) || !validToken(viewer) || (password != "" && !validPasswordDigest(password)) {
		return fail(c, "lifedrive.share.invalid_token", "error.share.invalid_token", false), nil
	}
	rpc := householdClient()
	defer rpc.HouseholdClose()
	raw, err := rpc.HouseholdShareOpen(token, viewer, password)
	value, err := householdResponse(raw, err)
	if err != nil {
		return fail(c, "lifedrive.share.open_failed", "error.share.open_failed", true), nil
	}
	if code, _ := value["share_error"].(string); code != "" {
		switch code {
		case "lifedrive.share.invalid_token", "lifedrive.share.not_found", "lifedrive.share.expired", "lifedrive.share.password_required", "lifedrive.share.password_invalid", "lifedrive.share.exhausted":
			return fail(c, code, "error.share."+strings.TrimPrefix(code, "lifedrive.share."), false), nil
		default:
			return fail(c, "lifedrive.share.open_failed", "error.share.open_failed", true), nil
		}
	}
	return ok(c, value), nil
}

// A visitor's delivery over an upload link. Only the token, the visitor's own
// receipt, the password digest and the transfer fields are forwarded: the
// identity service owns the link record, the size and file limits, and the
// holding folder the file lands in. A chunk travels base64-encoded inside the
// packet, within the same bound as a household request.
func entryHouseholdLinkUpload(c *ctx, op string) (any, error) {
	if failure := versionFailure(c); failure != nil {
		return failure, nil
	}
	token, viewer, password := c.str("token"), c.str("viewer"), c.str("password_hash")
	if !validToken(token) || !validToken(viewer) || (password != "" && !validPasswordDigest(password)) {
		return fail(c, "lifedrive.share.invalid_token", "error.share.invalid_token", false), nil
	}
	request := map[string]string{"op": op, "token": token, "viewer": viewer, "password_hash": password,
		"file_key": c.str("file_key"), "name": c.str("name"), "dir": c.str("dir"), "size": c.str("size"), "upload_id": c.str("upload_id"), "offset": c.str("offset")}
	if op == "write" {
		chunk, err := chunkArg(c.args)
		if err != nil || len(chunk) == 0 || len(chunk) > uploadMaxChunkSize {
			return fail(c, "lifedrive.request.invalid_chunk", "error.request.invalid_chunk", false), nil
		}
		request["chunk"] = base64.StdEncoding.EncodeToString(chunk)
	}
	packet, err := json.Marshal(request)
	if err != nil {
		return fail(c, "lifedrive.upload.begin_failed", "error.upload.begin_failed", true), nil
	}
	rpc := householdClient()
	defer rpc.HouseholdClose()
	raw, err := rpc.HouseholdLinkUpload(string(packet))
	value, err := householdResponse(raw, err)
	if err != nil {
		return fail(c, "lifedrive.upload.write_failed", "error.upload.write_failed", true), nil
	}
	if code, _ := value["link_error"].(string); code != "" {
		retryable := code == "lifedrive.upload.begin_failed" || code == "lifedrive.upload.write_failed" || code == "lifedrive.upload.complete_failed"
		key := "error." + strings.TrimPrefix(code, "lifedrive.")
		if details, _ := value["details"].(map[string]any); details != nil {
			return failDetails(c, code, key, retryable, details), nil
		}
		return fail(c, code, key, retryable), nil
	}
	return ok(c, value), nil
}

// The service owns the selected root and checks this capability on every read.
func entryNetworkShare(c *ctx) (any, error) {
	if failure := versionFailure(c); failure != nil {
		return failure, nil
	}
	if !householdActive() {
		return fail(c, "lifedrive.share.not_found", "error.share.not_found", false), nil
	}
	values := map[string]string{}
	for _, key := range []string{"op", "token", "viewer", "password_hash", "path", "version", "offset", "count"} {
		values[key] = c.str(key)
	}
	if !validToken(values["token"]) || !validToken(values["viewer"]) || len(values["path"]) > 4096 || len(values["version"]) > 100 {
		return fail(c, "lifedrive.share.invalid_token", "error.share.invalid_token", false), nil
	}
	packet, err := json.Marshal(values)
	if err != nil {
		return nil, err
	}
	rpc := householdClient()
	defer rpc.HouseholdClose()
	raw, err := rpc.HouseholdNetworkShare(string(packet))
	value, err := householdResponse(raw, err)
	if err != nil {
		return fail(c, "lifedrive.share.unavailable", "error.share.open_failed", true), nil
	}
	if code, _ := value["share_error"].(string); code != "" {
		return fail(c, code, "error.share.open_failed", false), nil
	}
	return ok(c, value), nil
}
