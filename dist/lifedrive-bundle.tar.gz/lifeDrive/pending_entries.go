package lapp

import (
	"fmt"
	"strings"
)

// Confirming what an anonymous sender delivered.
//
// An upload link is the one write path LifeDrive opens to somebody with no
// device key. Until now a delivery landed straight in the owner's folder, which
// means a link handed to one person put whatever they sent into the drive with
// no one having agreed to it. The file now lands in a holding area instead, and
// the owner accepts or rejects it.
//
// The holding area is a reserved root in the drive, exactly like the trash: it
// is the same tree, committed the same way, and it is hidden from drive_list by
// reservedRootName, so nothing else has to learn about it. One directory per
// link token, so a delivery carries the token that admitted it without a second
// registry to keep in step.

const pendingRoot = "/.lifedrive-pending"

func pendingTokenPath(token string) string { return pendingRoot + "/" + token }

// pendingDestination is where an accepted file goes: the folder the owner named
// when they published the link. A link that has since been revoked or expired
// leaves its deliveries behind with nothing to name a destination, so the owner
// may supply one -- rejecting is not the only way out of that state.
func pendingDestination(c *ctx, access *driveAccess, token string) string {
	mid, err := openShareRegistry(c, access.sid)
	if err != nil {
		return ""
	}
	registry, err := readShares(c, access.sid, mid)
	if err != nil {
		return ""
	}
	for _, record := range registry.Shares {
		if record.Token == token && record.Kind == "upload" {
			return record.Path
		}
	}
	return ""
}

// entryPendingList reports everything waiting for the owner's decision.
//
// It reads the staged tree rather than the committed one, for the same reason
// share_create checks the staged tree: a delivery that has just been committed
// is present in both, and one the owner is midway through accepting is only in
// the staged one.
func entryPendingList(c *ctx) (any, error) {
	if failure := versionFailure(c); failure != nil {
		return failure, nil
	}
	access, err := requireAccess(c, "view", "drive")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	deliveries := []map[string]any{}
	tokens, err := c.api.FilesLs(access.sid, mimeiURL(access.driveMID, "last", pendingRoot))
	if err != nil {
		// No holding area yet simply means nothing has been sent.
		return ok(c, map[string]any{"deliveries": deliveries}), nil
	}
	for _, folder := range tokens {
		if !validToken(folder.Name) {
			continue
		}
		destination := pendingDestination(c, access, folder.Name)
		files, listErr := c.api.FilesLs(access.sid, mimeiURL(access.driveMID, "last", pendingTokenPath(folder.Name)))
		if listErr != nil {
			continue
		}
		for _, link := range files {
			if link.Name == "" || len(deliveries) >= maxItems {
				continue
			}
			path := joinPath(pendingTokenPath(folder.Name), link.Name)
			delivery := objectFromLink(path, link)
			delivery["token"] = folder.Name
			delivery["pending_path"] = path
			// Empty when the link is gone. The client then asks the owner where
			// it should go instead of offering an accept that cannot work.
			delivery["destination"] = destination
			deliveries = append(deliveries, delivery)
		}
	}
	return ok(c, map[string]any{"deliveries": deliveries}), nil
}

// pendingObject resolves and validates a pending path from the request. It is
// deliberately strict about the shape -- three segments under the holding root,
// the middle one a valid token -- so this entry cannot be turned into a way to
// move or delete anything else in the drive.
func pendingObject(c *ctx) (string, string, string, error) {
	value := c.str("pending_path")
	if strings.Contains(value, "\x00") || strings.Contains(value, "\\") {
		return "", "", "", fmt.Errorf("invalid pending path")
	}
	parts := strings.Split(strings.TrimPrefix(value, "/"), "/")
	if len(parts) != 3 || "/"+parts[0] != pendingRoot || !validToken(parts[1]) {
		return "", "", "", fmt.Errorf("invalid pending path")
	}
	name := cleanName(parts[2])
	if name == "" {
		return "", "", "", fmt.Errorf("invalid pending path")
	}
	return pendingRoot + "/" + parts[1] + "/" + name, parts[1], name, nil
}

// entryPendingAccept moves one delivery into the drive proper.
//
// The name is kept as delivered, suffix and all. linkTargetName gave it that
// suffix so a public write path could never land on a name the owner already
// uses, and accepting is not the moment to give that protection up -- the owner
// can rename afterwards like any other file.
func entryPendingAccept(c *ctx) (any, error) {
	if failure := versionFailure(c); failure != nil {
		return failure, nil
	}
	path, token, name, err := pendingObject(c)
	if err != nil {
		return fail(c, "lifedrive.pending.invalid_path", "error.pending.invalid_path", false), nil
	}
	access, err := requireAccess(c, "modify", "drive")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	destination := pendingDestination(c, access, token)
	if requested := c.str("destination_parent"); requested != "" {
		destination, err = normalizeDirectory(requested)
		if err != nil {
			return fail(c, "lifedrive.pending.invalid_destination", "error.pending.invalid_destination", false), nil
		}
	}
	if destination == "" {
		// The link that admitted this file is gone. Rather than guessing a
		// folder, say so: the owner names one or rejects the delivery.
		return fail(c, "lifedrive.pending.destination_unknown", "error.pending.destination_unknown", false), nil
	}
	if _, err := ensureDirectory(c, access.sid, c.workPath(destination)); err != nil {
		logError(c, "pending accept: ensure destination %s: %v", destination, err)
		return fail(c, "lifedrive.pending.accept_failed", "error.pending.accept_failed", true), nil
	}
	target := joinPath(destination, name)
	if err := c.api.FilesMv(access.sid, c.workPath(path), c.workPath(target), false); err != nil {
		logError(c, "pending accept: move %s: %v", path, err)
		return fail(c, "lifedrive.pending.accept_failed", "error.pending.accept_failed", true), nil
	}
	// The token's folder is left behind empty. It costs nothing, and the next
	// delivery on the same link reuses it.
	if _, err := commitDrive(c, access); err != nil {
		logError(c, "pending accept: commit: %v", err)
		return fail(c, "lifedrive.pending.accept_failed", "error.pending.accept_failed", true), nil
	}
	return ok(c, map[string]any{"pending_path": path, "destination_path": target, "accepted": true}), nil
}

// entryPendingReject deletes a delivery outright rather than moving it to the
// trash. The trash is for things the owner once had; this is a thing the owner
// has just declined to have, and putting it in the drive to delete it later is
// the outcome the confirmation step exists to avoid.
func entryPendingReject(c *ctx) (any, error) {
	if failure := versionFailure(c); failure != nil {
		return failure, nil
	}
	path, _, _, err := pendingObject(c)
	if err != nil {
		return fail(c, "lifedrive.pending.invalid_path", "error.pending.invalid_path", false), nil
	}
	access, err := requireAccess(c, "modify", "drive")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	if err := c.api.FilesRm(access.sid, c.workPath(path), false, true); err != nil {
		logError(c, "pending reject: remove %s: %v", path, err)
		return fail(c, "lifedrive.pending.reject_failed", "error.pending.reject_failed", true), nil
	}
	if _, err := commitDrive(c, access); err != nil {
		logError(c, "pending reject: commit: %v", err)
		return fail(c, "lifedrive.pending.reject_failed", "error.pending.reject_failed", true), nil
	}
	return ok(c, map[string]any{"pending_path": path, "rejected": true}), nil
}
