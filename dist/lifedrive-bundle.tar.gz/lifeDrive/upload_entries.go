package lapp

import "fmt"

func entryUploadBegin(c *ctx) (any, error) {
	name := cleanName(c.str("name"))
	size := parseInt64(c.str("size"), -1)
	// The scratch MiMei is marked with a token the browser generated, which is
	// what keeps two concurrent uploads from sharing one staging object.
	token := c.str("upload_token")
	if name == "" || size < 0 || !validToken(token) {
		return fail(c, "lifedrive.request.invalid_upload", "error.request.invalid_upload", false), nil
	}
	parent, err := normalizeDirectory(c.str("parent_path"))
	if err != nil {
		return fail(c, "lifedrive.request.invalid_upload", "error.request.invalid_upload", false), nil
	}
	access, err := requireAccess(c, "modify", "file")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	if _, err := ensureDriveRoot(c, access.sid, access.driveMID); err != nil {
		return fail(c, "lifedrive.upload.begin_failed", "error.upload.begin_failed", true), nil
	}
	// Incoming bytes are staged in a MiMei the owner creates rather than in node
	// scratch space. MFOpenTempFile is author-only -- it refuses the caller's
	// session and the anonymous session alike with 1101:Permission denied -- and
	// an application published once cannot rely on an author session existing on
	// the node that runs it. A device key can create and write its own MiMei, so
	// the upload stages there and is copied into the drive on completion.
	scratch, err := c.api.MMCreate(access.sid, c.str("aid"), uploadScratchExt, token, fileType, c.creationRight())
	if err != nil {
		logError(c, "upload scratch unavailable: %v", err)
		return fail(c, "lifedrive.upload.begin_failed", "error.upload.begin_failed", true), nil
	}
	handle, err := c.api.MMOpen(access.sid, scratch, "cur")
	if err != nil || handle == "" {
		logError(c, "upload scratch would not open: %v", err)
		return fail(c, "lifedrive.upload.begin_failed", "error.upload.begin_failed", true), nil
	}
	return ok(c, map[string]any{
		"upload_id": handle, "scratch_mid": scratch, "drive_mid": access.driveMID, "parent_path": parent,
		"target_path": joinPath(parent, name),
		"chunk_size":  uploadInitialChunkSize, "min_chunk_size": uploadMinChunkSize,
		"max_chunk_size": uploadMaxChunkSize, "expires_in_seconds": 1800,
	}), nil
}

func entryUploadWrite(c *ctx) (any, error) {
	handle := c.str("upload_id")
	offset := parseInt64(c.str("offset"), -1)
	chunk, err := chunkArg(c.args)
	if handle == "" || offset < 0 || err != nil || len(chunk) == 0 || len(chunk) > uploadMaxChunkSize {
		return fail(c, "lifedrive.request.invalid_chunk", "error.request.invalid_chunk", false), nil
	}
	if _, err := requireAccess(c, "modify", "file"); err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	count, err := c.api.MFSetData(handle, chunk, offset)
	if err != nil {
		logError(c, "write failed upload=%s offset=%d bytes=%d: %v", handle, offset, len(chunk), err)
		return fail(c, "lifedrive.upload.write_failed", "error.upload.write_failed", true), nil
	}
	return ok(c, map[string]any{
		"upload_id": handle, "offset": offset, "received": count, "next_offset": offset + int64(count),
	}), nil
}

func entryUploadComplete(c *ctx) (any, error) {
	handle := c.str("upload_id")
	declaredSize := parseInt64(c.str("size"), -1)
	if handle == "" || declaredSize < 0 {
		return fail(c, "lifedrive.request.invalid_completion", "error.request.invalid_completion", false), nil
	}
	scratch := c.str("scratch_mid")
	if !validMID(scratch) {
		return fail(c, "lifedrive.request.invalid_completion", "error.request.invalid_completion", false), nil
	}
	target, err := normalizeObjectPath(c.str("target_path"))
	if err != nil {
		return uploadCompleteFailure(c, "normalize_target", err), nil
	}
	actualSize, err := c.api.MFGetSize(handle)
	if err != nil {
		return uploadCompleteFailure(c, "verify_size", err), nil
	}
	if actualSize != declaredSize {
		return failDetails(c, "lifedrive.upload.size_mismatch", "error.upload.size_mismatch", true,
			map[string]any{"expected": declaredSize, "actual": actualSize}), nil
	}
	access, err := requireAccess(c, "modify", "file")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	if _, err := ensureDriveRoot(c, access.sid, access.driveMID); err != nil {
		return uploadCompleteFailure(c, "open_drive", err), nil
	}
	if _, err := ensureDirectory(c, access.sid, c.workPath(parentPath(target))); err != nil {
		return uploadCompleteFailure(c, "ensure_parent", err), nil
	}
	targetWork := c.workPath(target)
	if _, err := c.api.FilesStat(access.sid, targetWork); err == nil {
		return failDetails(c, "lifedrive.file.already_exists", "error.file.already_exists", false, map[string]any{"path": target}), nil
	}
	// The staging MiMei has to be committed before its bytes can be addressed:
	// MFSetData writes into cur, and only MMBackup makes last resolve. That is
	// correct here and wrong on the drive -- the drive commits with MFSetCid,
	// which backs up internally, and adding MMBackup there would overwrite the
	// tree it just committed.
	closeHandle(c, handle)
	if _, err := c.api.MMBackup(access.sid, scratch, "upload", "delref=false"); err != nil {
		return uploadCompleteFailure(c, "commit_upload", err), nil
	}
	if err := c.api.FilesCopy(access.sid, mimeiURL(scratch, "last", "/"), targetWork, false); err != nil {
		return uploadCompleteFailure(c, "copy_to_drive", err), nil
	}
	cid := ""
	if stat, statErr := c.api.FilesStat(access.sid, targetWork); statErr == nil {
		cid = stat.Hash
	}
	rootCID, err := c.api.FilesFlush(access.sid, c.workRoot())
	if err != nil {
		rollbackUploadedPath(c, access.sid, targetWork)
		return uploadCompleteFailure(c, "flush_drive", err), nil
	}
	version, err := c.api.MFSetCid(access.sid, access.driveMID, rootCID)
	if err != nil {
		rollbackUploadedPath(c, access.sid, targetWork)
		return uploadCompleteFailure(c, "commit_drive", err), nil
	}
	if _, err := c.api.FilesStat(access.sid, mimeiURL(access.driveMID, "last", target)); err != nil {
		return uploadCompleteFailure(c, "verify_commit", err), nil
	}
	// The staged copy is content addressed, so dropping the scratch version
	// leaves the drive's copy intact and reclaims the duplicate reference.
	if _, err := c.api.MMDelVers(access.sid, scratch); err != nil {
		logError(c, "upload scratch not released: %v", err)
	}
	mediaType := c.str("mime_type")
	if mediaType == "" {
		mediaType = "application/octet-stream"
	}
	if len(mediaType) > 128 {
		mediaType = mediaType[:128]
	}
	now := serverTime()
	name := baseName(target)
	item := map[string]any{
		"object_id": target, "path": target, "kind": kindOf(name, false, c.str("kind")), "display_name": name,
		"parent_id": parentID(target), "parent_path": parentID(target), "media_type": mediaType,
		"plaintext_size": actualSize, "content_id": cid, "created_at": now, "modified_at": now,
	}
	return ok(c, map[string]any{
		"drive_mid": access.driveMID, "version": version, "object": item, "storage_state": "committed",
	}), nil
}

func rollbackUploadedPath(c *ctx, author, target string) {
	if err := c.api.FilesRm(author, target, true, false); err == nil {
		_, _ = c.api.FilesFlush(author, c.workRoot())
	}
}

func uploadCompleteFailure(c *ctx, stage string, err error) map[string]any {
	logError(c, "upload completion failed stage=%s: %v", stage, err)
	return failDetails(c, "lifedrive.upload.complete_failed", "error.upload.complete_failed", true,
		map[string]any{"stage": stage, "cause": fmt.Sprintf("%v", err)})
}

func entryUploadAbort(c *ctx) (any, error) {
	handle := c.str("upload_id")
	access, err := requireAccess(c, "modify", "file")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	closeHandle(c, handle)
	// An abandoned upload leaves its staging MiMei behind, so release it here
	// rather than leaving an owner's drive littered with partial objects.
	if scratch := c.str("scratch_mid"); validMID(scratch) {
		if _, delErr := c.api.MMDelVers(access.sid, scratch); delErr != nil {
			logError(c, "upload scratch not released on abort: %v", delErr)
		}
	}
	return ok(c, map[string]any{"upload_id": handle, "state": "aborted"}), nil
}
