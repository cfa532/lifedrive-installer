package lapp

import "fmt"

func entryUploadBegin(c *ctx) (any, error) {
	name := cleanName(c.str("name"))
	size := parseInt64(c.str("size"), -1)
	if name == "" || size < 0 {
		return fail(c, "lifedrive.request.invalid_upload", "error.request.invalid_upload", false), nil
	}
	parent, err := normalizeDirectory(c.str("parent_path"))
	if err != nil {
		return fail(c, "lifedrive.request.invalid_upload", "error.request.invalid_upload", false), nil
	}
	access, err := requireAccess(c, "modify", "file")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	if _, err := ensureDriveRoot(c, access.authorSID, access.driveMID); err != nil {
		return fail(c, "lifedrive.upload.begin_failed", "error.upload.begin_failed", true), nil
	}
	handle, err := c.api.MFOpenTempFile(access.authorSID)
	if err != nil || handle == "" {
		return fail(c, "lifedrive.upload.begin_failed", "error.upload.begin_failed", true), nil
	}
	return ok(c, map[string]any{
		"upload_id": handle, "drive_mid": access.driveMID, "parent_path": parent,
		"target_path": joinPath(parent, name),
		"chunk_size": uploadInitialChunkSize, "min_chunk_size": uploadMinChunkSize,
		"max_chunk_size": uploadMaxChunkSize, "expires_in_seconds": 1800,
	}), nil
}

func entryUploadWrite(c *ctx) (any, error) {
	handle := c.str("upload_id")
	offset := parseInt64(c.str("offset"), -1)
	chunk, err := chunkArg(c.args)
	if handle == "" || offset < 0 || err != nil || len(chunk) == 0 || len(chunk) > uploadMaxChunkSize {
		return fail(c, "lifedrive.request.invalid_chunk", "error.request.invalid_chunk", false), nil
	}
	if _, err := requireAccess(c, "modify", "file"); err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	count, err := c.api.MFSetData(handle, chunk, offset)
	if err != nil {
		logError(c, "write failed upload=%s offset=%d bytes=%d: %v", handle, offset, len(chunk), err)
		return fail(c, "lifedrive.upload.write_failed", "error.upload.write_failed", true), nil
	}
	return ok(c, map[string]any{
		"upload_id": handle, "offset": offset, "received": count, "next_offset": offset + int64(count),
	}), nil
}

func entryUploadComplete(c *ctx) (any, error) {
	handle := c.str("upload_id")
	declaredSize := parseInt64(c.str("size"), -1)
	if handle == "" || declaredSize < 0 {
		return fail(c, "lifedrive.request.invalid_completion", "error.request.invalid_completion", false), nil
	}
	defer closeHandle(c, handle)
	target, err := normalizeObjectPath(c.str("target_path"))
	if err != nil {
		return uploadCompleteFailure(c, "normalize_target", err), nil
	}
	actualSize, err := c.api.MFGetSize(handle)
	if err != nil {
		return uploadCompleteFailure(c, "verify_size", err), nil
	}
	if actualSize != declaredSize {
		return failDetails(c, "lifedrive.upload.size_mismatch", "error.upload.size_mismatch", true,
			map[string]any{"expected": declaredSize, "actual": actualSize}), nil
	}
	access, err := requireAccess(c, "modify", "file")
	if err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	if _, err := ensureDriveRoot(c, access.authorSID, access.driveMID); err != nil {
		return uploadCompleteFailure(c, "open_drive", err), nil
	}
	if _, err := ensureDirectory(c, access.authorSID, workPath(parentPath(target))); err != nil {
		return uploadCompleteFailure(c, "ensure_parent", err), nil
	}
	targetWork := workPath(target)
	if _, err := c.api.FilesStat(access.authorSID, targetWork); err == nil {
		return failDetails(c, "lifedrive.file.already_exists", "error.file.already_exists", false, map[string]any{"path": target}), nil
	}
	cid, err := c.api.MFTemp2Files(handle, targetWork)
	if err != nil {
		return uploadCompleteFailure(c, "copy_to_drive", err), nil
	}
	rootCID, err := c.api.FilesFlush(access.authorSID, driveWorkRoot)
	if err != nil {
		rollbackUploadedPath(c, access.authorSID, targetWork)
		return uploadCompleteFailure(c, "flush_drive", err), nil
	}
	version, err := c.api.MFSetCid(access.authorSID, access.driveMID, rootCID)
	if err != nil {
		rollbackUploadedPath(c, access.authorSID, targetWork)
		return uploadCompleteFailure(c, "commit_drive", err), nil
	}
	if _, err := c.api.FilesStat(access.authorSID, mimeiURL(access.driveMID, "last", target)); err != nil {
		return uploadCompleteFailure(c, "verify_commit", err), nil
	}
	mediaType := c.str("mime_type")
	if mediaType == "" {
		mediaType = "application/octet-stream"
	}
	if len(mediaType) > 128 {
		mediaType = mediaType[:128]
	}
	now := serverTime()
	name := baseName(target)
	item := map[string]any{
		"object_id": target, "path": target, "kind": kindOf(name, false, c.str("kind")), "display_name": name,
		"parent_id": parentID(target), "parent_path": parentID(target), "media_type": mediaType,
		"plaintext_size": actualSize, "content_id": cid, "created_at": now, "modified_at": now,
	}
	return ok(c, map[string]any{
		"drive_mid": access.driveMID, "version": version, "object": item, "storage_state": "committed",
	}), nil
}

func rollbackUploadedPath(c *ctx, author, target string) {
	if err := c.api.FilesRm(author, target, true, false); err == nil {
		_, _ = c.api.FilesFlush(author, driveWorkRoot)
	}
}

func uploadCompleteFailure(c *ctx, stage string, err error) map[string]any {
	logError(c, "upload completion failed stage=%s: %v", stage, err)
	return failDetails(c, "lifedrive.upload.complete_failed", "error.upload.complete_failed", true,
		map[string]any{"stage": stage, "cause": fmt.Sprintf("%v", err)})
}

func entryUploadAbort(c *ctx) (any, error) {
	handle := c.str("upload_id")
	if _, err := requireAccess(c, "modify", "file"); err != nil {
		return fail(c, "lifedrive.security.permission_denied", "error.security.permission_denied", false), nil
	}
	closeHandle(c, handle)
	return ok(c, map[string]any{"upload_id": handle, "state": "aborted"}), nil
}
