#!/usr/bin/env bash
set -euo pipefail

LEITHER_WORKDIR="${LIFEDRIVE_WORKDIR:-/home/pi/demo}"
LEITHER_BIN="${LIFEDRIVE_LEITHER_PATH:-$LEITHER_WORKDIR/Leither}"
APP_NAME="${LIFEDRIVE_APP_NAME:-lifeDrive}"
STATE_FILE="${LIFEDRIVE_PUBLICATION_STATE:-$LEITHER_WORKDIR/$APP_NAME.appid}"
OWNER_STATE_FILE="${LIFEDRIVE_OWNER_STATE:-$LEITHER_WORKDIR/$APP_NAME.owner}"
DRIVE_STATE_FILE="${LIFEDRIVE_DRIVE_STATE:-$LEITHER_WORKDIR/$APP_NAME.drivemid}"
PUBLISHER_KEY="${LIFEDRIVE_PUBLISHER_KEY:-}"
PUBLISHER_KEY_STATE="${LIFEDRIVE_PUBLISHER_KEY_STATE:-$LEITHER_WORKDIR/$APP_NAME.publisher-key}"
SERVICE_NODE="${LIFEDRIVE_SERVICE_NODE:-}"
NODE_BIN="${LIFEDRIVE_NODE_PATH:-}"
RESET_PASSWORD="${LIFEDRIVE_RESET_PASSWORD:-0}"

if [[ -z "$PUBLISHER_KEY" && -s "$PUBLISHER_KEY_STATE" ]]; then
  PUBLISHER_KEY=$(tr -d '\r\n' < "$PUBLISHER_KEY_STATE")
fi

if [[ -z "$NODE_BIN" ]]; then
  NODE_BIN=$(command -v node 2>/dev/null || true)
fi
if [[ -z "$NODE_BIN" ]]; then
  USER_HOME_DIR=""
  if command -v getent >/dev/null 2>&1; then
    USER_HOME_DIR=$(getent passwd "$(id -u)" 2>/dev/null | cut -d: -f6 || true)
  fi
  USER_HOME_DIR="${USER_HOME_DIR:-${HOME:-}}"
  for candidate in "$USER_HOME_DIR"/.nvm/versions/node/*/bin/node /opt/homebrew/bin/node /usr/local/bin/node; do
    if [[ -x "$candidate" ]]; then
      NODE_BIN="$candidate"
      break
    fi
  done
fi
if [[ -z "$NODE_BIN" || ! -x "$NODE_BIN" ]]; then
  echo "LifeDrive owner setup stopped: Node.js was not found." >&2
  echo "Set LIFEDRIVE_NODE_PATH to the installed node executable and run setup again." >&2
  exit 1
fi

if [[ ! -s "$STATE_FILE" ]]; then
  echo "LifeDrive owner setup stopped: publish the app first so $STATE_FILE exists." >&2
  exit 1
fi

app_id=$(tr -d '[:space:]' < "$STATE_FILE")
is_identifier() {
  local value="$1"
  (( ${#value} >= 8 && ${#value} <= 256 )) && [[ "$value" =~ ^[A-Za-z0-9_-]+$ ]]
}

if ! is_identifier "$app_id"; then
  echo "LifeDrive owner setup stopped: the saved application MID is invalid." >&2
  exit 1
fi

saved_owner_name=""
saved_owner_uid=""
if [[ -s "$OWNER_STATE_FILE" ]]; then
  saved_owner_name=$(sed -n '1p' "$OWNER_STATE_FILE")
  saved_owner_uid=$(sed -n '2p' "$OWNER_STATE_FILE")
fi

owner_name="${LIFEDRIVE_OWNER_NAME:-}"
if [[ -z "$owner_name" ]]; then
  owner_default="${saved_owner_name:-drive}"
  if [[ -n "$saved_owner_name" && ! -t 0 ]]; then
    owner_name="$saved_owner_name"
  else
    read -r -p "LifeDrive owner name [$owner_default]: " owner_name
    owner_name="${owner_name:-$owner_default}"
  fi
fi
owner_name=$(printf '%s' "$owner_name" | tr '[:upper:]' '[:lower:]')
if [[ ! "$owner_name" =~ ^[A-Za-z0-9._-]{1,64}$ ]]; then
  echo "Use 1-64 letters, numbers, dots, underscores, or hyphens for the owner name." >&2
  exit 1
fi

owner_uid=""
if [[ "$RESET_PASSWORD" != "1" && "$owner_name" == "$saved_owner_name" ]] && is_identifier "$saved_owner_uid"; then
  owner_uid="$saved_owner_uid"
fi

owner_password="${LIFEDRIVE_OWNER_PASSWORD:-}"
owner_password_provided="${LIFEDRIVE_OWNER_PASSWORD_PROVIDED:-0}"
if [[ -z "$owner_uid" && -z "$owner_password" && "$owner_password_provided" != "1" ]]; then
  read -r -s -p "Owner password: " owner_password
  echo
  read -r -s -p "Confirm password: " owner_password_confirmation
  echo
  if [[ "$owner_password" != "$owner_password_confirmation" ]]; then
    echo "The passwords did not match." >&2
    exit 1
  fi
fi

run_leither() {
  local command_args=("$@")
  if [[ -n "$PUBLISHER_KEY" ]]; then
    command_args+=(-k "$PUBLISHER_KEY")
  fi
  if [[ -n "$SERVICE_NODE" ]]; then
    command_args+=(-n "$SERVICE_NODE")
  fi
  "$LEITHER_BIN" "${command_args[@]}"
}

request_data=$(LIFEDRIVE_SETUP_NAME="$owner_name" LIFEDRIVE_SETUP_PASSWORD="$owner_password" LIFEDRIVE_SETUP_UID="$owner_uid" LIFEDRIVE_SETUP_APP_ID="$app_id" "$NODE_BIN" -e '
  const hex=value=>Buffer.from(value||"","utf8").toString("hex");
  process.stdout.write(`username_hex=${hex(process.env.LIFEDRIVE_SETUP_NAME)};password_hex=${hex(process.env.LIFEDRIVE_SETUP_PASSWORD)};uid_hex=${hex(process.env.LIFEDRIVE_SETUP_UID)};appid_hex=${hex(process.env.LIFEDRIVE_SETUP_APP_ID)}`);')
unset owner_password LIFEDRIVE_OWNER_PASSWORD LIFEDRIVE_OWNER_PASSWORD_PROVIDED

setup_script="local auth=require('auth'); local mimei=require('mimei'); local function fromhex(value) if not value then return '' end; return (value:gsub('..',function(byte) return string.char(tonumber(byte,16)) end)); end; local username=fromhex(request.username_hex); local password=fromhex(request.password_hex); local uid=fromhex(request.uid_hex); local appid=fromhex(request.appid_hex); if uid=='' then local setErr=auth.SetUserInfo(request.sid,{newname=username,newpass=password}); if setErr~=nil then return {error=tostring(setErr)}; end; uid=lapi.GetVar(request.sid,'userid'); if not uid or uid=='' then return {error='Leither did not expose the node user ID after account setup'}; end; end; local mid,createErr=mimei.MMCreate(request.sid,appid,'lifedrive.app-drive/v1','lifeDrive',1,0x07276704); if createErr~=nil then return {error=tostring(createErr)}; end; local _,rightErr=mimei.MMSetRight(request.sid,mid,uid,0x07276704); if rightErr~=nil then return {error=tostring(rightErr)}; end; return {uid=uid,mid=mid}"

cd "$LEITHER_WORKDIR"
set +e
setup_output=$(run_leither lpki runscript -t lua -s "$setup_script" -r "$request_data" --json)
setup_status=$?
set -e
if (( setup_status != 0 )); then
  echo "LifeDrive owner setup stopped: Leither command exited with status $setup_status." >&2
  exit "$setup_status"
fi
setup_values=$(LIFEDRIVE_SETUP_OUTPUT="$setup_output" "$NODE_BIN" -e '
  const reply=JSON.parse(process.env.LIFEDRIVE_SETUP_OUTPUT);
  const result=reply?.data?.result??reply?.data;
  const nativeError=result?.error||reply?.error?.message;
  if(reply?.exit_code!==0||nativeError){console.error(`LifeDrive owner setup stopped: ${nativeError||"Leither returned an unsuccessful result."}`);process.exit(1)}
  const uid=result?.uid,mid=result?.mid;
  if(typeof uid!=="string"||!uid||typeof mid!=="string"||!mid){console.error("LifeDrive owner setup stopped: Leither returned an incomplete owner result.");process.exit(1)}
  process.stdout.write(`${uid}\n${mid}`);')
registered_uid=$(sed -n '1p' <<<"$setup_values")
drive_mid=$(sed -n '2p' <<<"$setup_values")
if ! is_identifier "$drive_mid"; then
  echo "LifeDrive owner setup stopped: Leither did not return a valid drive MID." >&2
  exit 1
fi

umask 077
printf '%s\n%s\n' "$owner_name" "$registered_uid" > "$OWNER_STATE_FILE"
printf '%s\n' "$drive_mid" > "$DRIVE_STATE_FILE"

echo "LifeDrive owner '$owner_name' is ready."
echo "Open the LifeDrive domain and sign in with this owner name."
echo "Running this setup again restores the saved owner's grant after a node repair."
echo "Run lifeDrive-setup.sh --recover to reset the password with the retained node identity."
