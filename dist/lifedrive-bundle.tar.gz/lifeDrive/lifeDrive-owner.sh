#!/usr/bin/env bash
set -euo pipefail

LEITHER_WORKDIR="${LIFEDRIVE_WORKDIR:-/home/pi/demo}"
LEITHER_BIN="${LIFEDRIVE_LEITHER_PATH:-$LEITHER_WORKDIR/Leither}"
APP_NAME="${LIFEDRIVE_APP_NAME:-lifeDrive}"
STATE_FILE="${LIFEDRIVE_PUBLICATION_STATE:-$LEITHER_WORKDIR/$APP_NAME.appid}"
OWNER_STATE_FILE="${LIFEDRIVE_OWNER_STATE:-$LEITHER_WORKDIR/$APP_NAME.owner}"
DRIVE_STATE_FILE="${LIFEDRIVE_DRIVE_STATE:-$LEITHER_WORKDIR/$APP_NAME.drivemid}"
DEVICE_STATE_FILE="${LIFEDRIVE_DEVICE_STATE:-$LEITHER_WORKDIR/$APP_NAME.devices}"
IDENTITY_PATH_STATE="${LIFEDRIVE_IDENTITY_PATH_STATE:-$LEITHER_WORKDIR/$APP_NAME.identity-path}"
PUBLISHER_KEY="${LIFEDRIVE_PUBLISHER_KEY:-}"
PUBLISHER_KEY_STATE="${LIFEDRIVE_PUBLISHER_KEY_STATE:-$LEITHER_WORKDIR/$APP_NAME.publisher-key}"
SERVICE_NODE="${LIFEDRIVE_SERVICE_NODE:-}"
NODE_BIN="${LIFEDRIVE_NODE_PATH:-}"
ADD_DEVICE="${LIFEDRIVE_ADD_DEVICE:-0}"

if [[ -z "$PUBLISHER_KEY" && -s "$PUBLISHER_KEY_STATE" ]]; then
  PUBLISHER_KEY=$(tr -d '\r\n' < "$PUBLISHER_KEY_STATE")
fi

if [[ -z "$NODE_BIN" ]]; then NODE_BIN=$(command -v node 2>/dev/null || true); fi
if [[ -z "$NODE_BIN" ]]; then
  USER_HOME_DIR=""
  if command -v getent >/dev/null 2>&1; then
    USER_HOME_DIR=$(getent passwd "$(id -u)" 2>/dev/null | cut -d: -f6 || true)
  fi
  USER_HOME_DIR="${USER_HOME_DIR:-${HOME:-}}"
  for candidate in "$USER_HOME_DIR"/.nvm/versions/node/*/bin/node /opt/homebrew/bin/node /usr/local/bin/node; do
    if [[ -x "$candidate" ]]; then NODE_BIN="$candidate"; break; fi
  done
fi
if [[ -z "$NODE_BIN" || ! -x "$NODE_BIN" ]]; then
  echo "LifeDrive device setup stopped: Node.js was not found." >&2
  echo "Set LIFEDRIVE_NODE_PATH to the installed node executable and run setup again." >&2
  exit 1
fi
if [[ ! -x "$LEITHER_BIN" ]]; then
  echo "LifeDrive device setup stopped: Leither was not found at $LEITHER_BIN." >&2
  exit 1
fi

if [[ ! -s "$STATE_FILE" ]]; then
  echo "LifeDrive device setup stopped: publish the app first so $STATE_FILE exists." >&2
  exit 1
fi

app_id=$(tr -d '[:space:]' < "$STATE_FILE")
is_identifier() {
  local value="$1"
  (( ${#value} >= 8 && ${#value} <= 256 )) && [[ "$value" =~ ^[A-Za-z0-9_-]+$ ]]
}
if ! is_identifier "$app_id"; then
  echo "LifeDrive device setup stopped: the saved application MID is invalid." >&2
  exit 1
fi

saved_owner_name=""
if [[ -s "$OWNER_STATE_FILE" && "$(sed -n '1p' "$OWNER_STATE_FILE")" == "lifedrive-key-auth-v1" ]]; then
  saved_owner_name=$(sed -n '2p' "$OWNER_STATE_FILE")
fi

owner_name="${LIFEDRIVE_OWNER_NAME:-$saved_owner_name}"
if [[ -z "$owner_name" ]]; then read -r -p "LifeDrive public name: " owner_name; fi
owner_name=$(printf '%s' "$owner_name" | tr '[:upper:]' '[:lower:]')
if (( ${#owner_name} < 1 || ${#owner_name} > 63 )) || [[ ! "$owner_name" =~ ^[a-z0-9]([a-z0-9-]*[a-z0-9])?$ ]]; then
  echo "Use 1-63 lowercase letters, numbers, or interior hyphens for the LifeDrive public name." >&2
  exit 1
fi
if (( ADD_DEVICE )) && [[ -z "$saved_owner_name" ]]; then
  echo "LifeDrive device setup stopped: the key-authenticated owner has not been initialized." >&2
  exit 1
fi
if (( ADD_DEVICE )) && [[ "$owner_name" != "$saved_owner_name" ]]; then
  echo "LifeDrive device setup stopped: the public owner name does not match this installation." >&2
  exit 1
fi
if (( ! ADD_DEVICE )) && [[ -e "$OWNER_STATE_FILE" ]]; then
  echo "LifeDrive owner setup stopped: owner state already exists. Use --upgrade or --add-device." >&2
  exit 1
fi

device_label="${LIFEDRIVE_DEVICE_LABEL:-Primary browser}"
if (( ${#device_label} < 1 || ${#device_label} > 80 )) || [[ "$device_label" == *$'\n'* || "$device_label" == *$'\r'* || "$device_label" == *$'\t'* ]]; then
  echo "Use a 1-80 character device label without tabs or line breaks." >&2
  exit 1
fi

safe_label=$(printf '%s' "$device_label" | tr '[:upper:]' '[:lower:]' | tr -cs 'a-z0-9' '-' | sed 's/^-//;s/-$//')
safe_label="${safe_label:-device}"
identity_output="${LIFEDRIVE_IDENTITY_OUT:-$LEITHER_WORKDIR/$APP_NAME-$safe_label-$(date -u +%Y%m%dT%H%M%SZ).identity.json}"
identity_parent=$(dirname "$identity_output")
identity_name=$(basename "$identity_output")
if [[ ! -d "$identity_parent" || ! -w "$identity_parent" || "$identity_name" == "." || "$identity_name" == ".." ]]; then
  echo "LifeDrive device setup stopped: the identity output directory must already exist and be writable." >&2
  exit 1
fi
identity_parent=$(cd "$identity_parent" && pwd)
identity_output="$identity_parent/$identity_name"
if [[ -e "$identity_output" ]]; then
  echo "LifeDrive device setup stopped: identity output already exists: $identity_output" >&2
  exit 1
fi

identity_work=$(mktemp -d "$LEITHER_WORKDIR/.lifedrive-device.XXXXXX")
cleanup_identity_work() {
  if [[ -n "${identity_work:-}" && -d "$identity_work" && "$identity_work" == "$LEITHER_WORKDIR"/.lifedrive-device.* ]]; then
    rm -rf -- "$identity_work"
  fi
}
trap cleanup_identity_work EXIT
umask 077

"$LEITHER_BIN" lpki genkey -o "$identity_work/device.key" >/dev/null
"$LEITHER_BIN" lpki gencert -k "$identity_work/device.key" -m "name=$owner_name-$safe_label" -o "$identity_work/device.ca" >/dev/null
"$LEITHER_BIN" lpki signppt -c "$identity_work/device.ca" -p 15 -m "CertFor=Self" -o "$identity_work/login.ppt" >/dev/null
"$LEITHER_BIN" lpki verifyppt -c "$identity_work/device.ca" -i "$identity_work/login.ppt" >/dev/null

LIFEDRIVE_KEY_PATH="$identity_work/device.key" \
LIFEDRIVE_PPT_PATH="$identity_work/login.ppt" \
LIFEDRIVE_IDENTITY_OUT="$identity_work/device.identity.json" \
LIFEDRIVE_DEVICE_LABEL="$device_label" \
LIFEDRIVE_PUBLIC_USERNAME="$owner_name" \
LIFEDRIVE_APP_ID="$app_id" \
"$NODE_BIN" -e '
  const fs=require("fs");
  // Leither writes the key file as two concatenated JSON documents: a key-type
  // line, then {"Sk","Pk"} in standard base64. That is not one parsable JSON
  // value, and the base64url identity bundle cannot carry "+" or "/", so read
  // the key-pair line on its own and convert both fields.
  const keyText=fs.readFileSync(process.env.LIFEDRIVE_KEY_PATH,"utf8");
  const toBase64Url=value=>value.replace(/\s+/g,"").replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");
  let keyPair=null;
  for(const line of keyText.split("\n")){const trimmed=line.trim();if(!trimmed.startsWith("{"))continue;try{const parsed=JSON.parse(trimmed);if(typeof parsed?.Sk==="string"&&typeof parsed?.Pk==="string"){keyPair=parsed;break}}catch{}}
  if(!keyPair){console.error("LifeDrive device setup stopped: Leither produced an unreadable key file.");process.exit(1)}
  const publicKey=toBase64Url(keyPair.Pk),privateKey=toBase64Url(keyPair.Sk);
  let ppt;try{ppt=JSON.parse(fs.readFileSync(process.env.LIFEDRIVE_PPT_PATH,"utf8").trim())}catch{console.error("LifeDrive device setup stopped: Leither produced an invalid PPT.");process.exit(1)}
  const decode=value=>Buffer.from(value.replace(/-/g,"+").replace(/_/g,"/"),"base64");
  if(!publicKey||decode(publicKey).length!==32||!privateKey||decode(privateKey).length!==64||ppt.KeyType!=="sodiumv2"||typeof ppt.SignerID!=="string"||!/^[A-Za-z0-9_-]{27}$/.test(ppt.SignerID)||typeof ppt.SignerInfo!=="string"||!ppt.SignerInfo){console.error("LifeDrive device setup stopped: Leither produced an unsupported sodiumv2 identity.");process.exit(1)}
  const bundle={type:"lifedrive-device-identity",version:1,app_id:process.env.LIFEDRIVE_APP_ID,uid:ppt.SignerID,label:process.env.LIFEDRIVE_DEVICE_LABEL,public_username:process.env.LIFEDRIVE_PUBLIC_USERNAME,key_type:"sodiumv2",public_key:publicKey.replace(/=+$/,""),private_key:privateKey.replace(/=+$/,""),signer_info:ppt.SignerInfo,created_at:new Date().toISOString()};
  const fd=fs.openSync(process.env.LIFEDRIVE_IDENTITY_OUT,"wx",0o600);try{fs.writeFileSync(fd,JSON.stringify(bundle,null,2)+"\n")}finally{fs.closeSync(fd)}'

device_uid=$(LIFEDRIVE_PPT_PATH="$identity_work/login.ppt" "$NODE_BIN" -e 'const ppt=JSON.parse(require("fs").readFileSync(process.env.LIFEDRIVE_PPT_PATH,"utf8"));process.stdout.write(ppt.SignerID||"")')
if [[ ! "$device_uid" =~ ^[A-Za-z0-9_-]{27}$ ]]; then
  echo "LifeDrive device setup stopped: the generated Leither key ID is invalid." >&2
  exit 1
fi

run_leither() {
  local command_args=("$@")
  if [[ -n "$PUBLISHER_KEY" ]]; then command_args+=(-k "$PUBLISHER_KEY"); fi
  if [[ -n "$SERVICE_NODE" ]]; then command_args+=(-n "$SERVICE_NODE"); fi
  "$LEITHER_BIN" "${command_args[@]}"
}
request_data=$(LIFEDRIVE_SETUP_UID="$device_uid" LIFEDRIVE_SETUP_APP_ID="$app_id" "$NODE_BIN" -e '
  const hex=value=>Buffer.from(value||"","utf8").toString("hex");
  process.stdout.write(`uid_hex=${hex(process.env.LIFEDRIVE_SETUP_UID)};appid_hex=${hex(process.env.LIFEDRIVE_SETUP_APP_ID)}`);')
setup_script="local mimei=require('mimei'); local function fromhex(value) if not value then return '' end; return (value:gsub('..',function(byte) return string.char(tonumber(byte,16)) end)); end; local uid=fromhex(request.uid_hex); local appid=fromhex(request.appid_hex); local mid,createErr=mimei.MMCreate(request.sid,appid,'lifedrive.app-drive/v1','lifeDrive',1,0x07276704); if createErr~=nil then return {error=tostring(createErr)}; end; local _,rightErr=mimei.MMSetRight(request.sid,mid,uid,0x07276704); if rightErr~=nil then return {error=tostring(rightErr)}; end; return {uid=uid,mid=mid}"

cd "$LEITHER_WORKDIR"
set +e
setup_output=$(run_leither lpki runscript -t lua -s "$setup_script" -r "$request_data" --json)
setup_status=$?
set -e
if (( setup_status != 0 )); then
  echo "LifeDrive device setup stopped: Leither command exited with status $setup_status." >&2
  exit "$setup_status"
fi
setup_values=$(LIFEDRIVE_SETUP_OUTPUT="$setup_output" LIFEDRIVE_EXPECTED_UID="$device_uid" "$NODE_BIN" -e '
  const reply=JSON.parse(process.env.LIFEDRIVE_SETUP_OUTPUT);const result=reply?.data?.result??reply?.data;const nativeError=result?.error||reply?.error?.message;
  if(reply?.exit_code!==0||nativeError){console.error(`LifeDrive device setup stopped: ${nativeError||"Leither returned an unsuccessful result."}`);process.exit(1)}
  if(result?.uid!==process.env.LIFEDRIVE_EXPECTED_UID||typeof result?.mid!=="string"||!result.mid){console.error("LifeDrive device setup stopped: Leither returned an incomplete device grant.");process.exit(1)}
  process.stdout.write(`${result.uid}\n${result.mid}`);')
registered_uid=$(sed -n '1p' <<<"$setup_values")
drive_mid=$(sed -n '2p' <<<"$setup_values")
if [[ "$registered_uid" != "$device_uid" ]] || ! is_identifier "$drive_mid"; then
  echo "LifeDrive device setup stopped: Leither did not return the expected device grant." >&2
  exit 1
fi

mv "$identity_work/device.identity.json" "$identity_output"
chmod 600 "$identity_output"

created_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)
if (( ADD_DEVICE )); then
  printf '%s\t%s\t%s\n' "$device_uid" "$device_label" "$created_at" >> "$DEVICE_STATE_FILE"
else
  printf 'lifedrive-key-auth-v1\n%s\n%s\n%s\n' "$owner_name" "$device_uid" "$device_label" > "$OWNER_STATE_FILE"
  printf '%s\n' "$drive_mid" > "$DRIVE_STATE_FILE"
  printf '%s\t%s\t%s\n' "$device_uid" "$device_label" "$created_at" > "$DEVICE_STATE_FILE"
fi
printf '%s\n' "$identity_output" > "$IDENTITY_PATH_STATE"

echo "LifeDrive device '$device_label' is authorized as $device_uid."
echo "Identity file: $identity_output"
echo "Import that file once in the LifeDrive browser, then keep it as an offline recovery copy."
