package lapp

import (
	"fmt"
	"strings"
)

// An upload link is the one write path LifeDrive exposes without a device
// identity. Every entry here is public, so each call re-validates the token and
// the password against the registry rather than trusting a prior step, and the
// uploader never names a path: they supply a filename, the record supplies the
// destination folder. See entryShareCreate for how the record is published.

// uploadGrant is what a validated upload call is allowed to do. It is rebuilt
// per call and never handed to the caller.
type uploadGrant struct {
	access *driveAccess
	record shareRecord
	index  int
	shares shareRegistry
	mid    string
}

// publicDriveAccess resolves the drive for a delivery that has no owner behind
// it. The session is the application's, granted deliverRight on this drive when
// the owner published the link.
//
// This used to run on the author session and carried a note saying that was why
// the application could not be published once, because a node supposedly cannot
// obtain an author session for an application it did not publish. That was
// wrong: measured on gen8, which only ever synced the application, both
// BELoginAsAuthor and BELoginAsApp return a session. The real obstacle was
// never the session but the rights -- a drive is authored by its owner's device,
// so whoever delivers has to be granted.
func publicDriveAccess(c *ctx, deliverer string) (*driveAccess, error) {
	mid, _, err := driveMIDForNode()
	if err != nil {
		return nil, err
	}
	if mid == "" {
		return nil, fmt.Errorf("no drive recorded for this node")
	}
	return &driveAccess{sid: deliverer, driveMID: mid, version: "cur"}, nil
}

// authorizeUpload resolves the token to a live upload link. It returns a failure
// response rather than an error so every entry reports the same way.
func authorizeUpload(c *ctx) (*uploadGrant, map[string]any) {
	if failure := versionFailure(c); failure != nil {
		return nil, failure
	}
	token := c.str("token")
	uploader := c.str("viewer")
	if !validToken(token) || !validToken(uploader) {
		return nil, fail(c, "lifedrive.share.invalid_token", "error.share.invalid_token", false)
	}
	mid, err := recordedShareRegistry()
	if err != nil {
		return nil, fail(c, "lifedrive.share.not_found", "error.share.not_found", false)
	}
	// Resolving the link needs no session, like any other read on this node.
	registry, err := readShares(c, "", mid)
	if err != nil {
		return nil, fail(c, "lifedrive.upload.begin_failed", "error.upload.begin_failed", true)
	}
	// Delivering the file does need a session, and a sender has none, so the
	// application supplies one. Reading a share link stays session-less.
	deliverer, err := authSID(c)
	if err != nil {
		logError(c, "upload link cannot accept a delivery without a delivery session: %v", err)
		return nil, fail(c, "lifedrive.upload.begin_failed", "error.upload.begin_failed", true)
	}
	for index, record := range registry.Shares {
		if record.Token != token || record.Kind != "upload" {
			continue
		}
		if shareExpired(record, serverNow()) {
			return nil, fail(c, "lifedrive.share.expired", "error.share.expired", false)
		}
		// The password is mandatory on an upload link, so an empty hash on the
		// record would mean an unprotected write path: refuse it outright.
		if record.PasswordHash == "" || c.str("password_hash") != record.PasswordHash {
			if c.str("password_hash") == "" {
				return nil, fail(c, "lifedrive.share.password_required", "error.share.password_required", false)
			}
			return nil, fail(c, "lifedrive.share.password_invalid", "error.share.password_invalid", false)
		}
		if shareExhausted(record) {
			return nil, fail(c, "lifedrive.share.exhausted", "error.share.exhausted", false)
		}
		access, accessErr := publicDriveAccess(c, deliverer)
		if accessErr != nil {
			return nil, fail(c, "lifedrive.upload.begin_failed", "error.upload.begin_failed", true)
		}
		return &uploadGrant{access: access, record: record, index: index, shares: registry, mid: mid}, nil
	}
	return nil, fail(c, "lifedrive.share.not_found", "error.share.not_found", false)
}

func splitFileName(name string) (string, string) {
	if index := strings.LastIndex(name, "."); index > 0 {
		return name[:index], name[index:]
	}
	return name, ""
}

// linkTargetName makes an anonymous upload unable to land on a name the owner
// already uses. It does not ask whether the name is free, because nothing here
// can answer that: FilesLs, FilesStat and MMOpenUrl were each observed reporting
// a folder's existing files inaccurately from inside the MApp, and MFTemp2Files
// then wrote where the owner's file was, whose content the next commit replaced.
//
// So every uploaded file carries a suffix from the sender's viewer token, which
// the browser generated with crypto.getRandomValues and validToken has already
// restricted to path-safe characters. Two files can only collide if one sender
// sends the same name twice, and MFTemp2Files refuses that write rather than
// overwriting -- the sender is told, and nothing of the owner's is at risk.
//
// The cost is that received files are never named exactly as sent. That is the
// deliberate trade: a public write path must not be able to destroy data.
func linkTargetName(folder, name, unique string) string {
	base, ext := splitFileName(name)
	if len(unique) > 8 {
		unique = unique[:8]
	}
	if unique == "" {
		unique = "sent"
	}
	return joinPath(folder, fmt.Sprintf("%s (%s)%s", base, unique, ext))
}

func entryLinkUploadBegin(c *ctx) (any, error) {
	if householdActive() {
		return entryHouseholdLinkUpload(c, "begin")
	}
	name := cleanName(c.str("name"))
	size := parseInt64(c.str("size"), -1)
	if name == "" || size < 0 {
		return fail(c, "lifedrive.request.invalid_upload", "error.request.invalid_upload", false), nil
	}
	grant, failure := authorizeUpload(c)
	if failure != nil {
		return failure, nil
	}
	if size > grant.record.MaxBytes {
		return failDetails(c, "lifedrive.upload.too_large", "error.upload.too_large", false,
			map[string]any{"max_bytes": grant.record.MaxBytes, "size": size}), nil
	}
	if _, err := ensureDriveRoot(c, grant.access.sid, grant.access.driveMID); err != nil {
		logError(c, "link upload begin: open drive root mid=%s: %v", grant.access.driveMID, err)
		return fail(c, "lifedrive.upload.begin_failed", "error.upload.begin_failed", true), nil
	}
	handle, err := c.api.MFOpenTempFile(grant.access.sid)
	if err != nil || handle == "" {
		logError(c, "link upload begin: open temp file: %v", err)
		return fail(c, "lifedrive.upload.begin_failed", "error.upload.begin_failed", true), nil
	}
	return ok(c, map[string]any{
		"upload_id": handle, "name": name, "chunk_size": uploadInitialChunkSize,
		"min_chunk_size": uploadMinChunkSize, "max_chunk_size": uploadMaxChunkSize,
		"max_bytes": grant.record.MaxBytes, "expires_in_seconds": 1800,
	}), nil
}

func entryLinkUploadWrite(c *ctx) (any, error) {
	if householdActive() {
		return entryHouseholdLinkUpload(c, "write")
	}
	handle := c.str("upload_id")
	offset := parseInt64(c.str("offset"), -1)
	chunk, err := chunkArg(c.args)
	if handle == "" || offset < 0 || err != nil || len(chunk) == 0 || len(chunk) > uploadMaxChunkSize {
		return fail(c, "lifedrive.request.invalid_chunk", "error.request.invalid_chunk", false), nil
	}
	grant, failure := authorizeUpload(c)
	if failure != nil {
		return failure, nil
	}
	// Enforced per chunk as well as on completion, so a link cannot be used to
	// fill the drive by streaming past the declared size.
	if offset+int64(len(chunk)) > grant.record.MaxBytes {
		return failDetails(c, "lifedrive.upload.too_large", "error.upload.too_large", false,
			map[string]any{"max_bytes": grant.record.MaxBytes}), nil
	}
	count, err := c.api.MFSetData(handle, chunk, offset)
	if err != nil {
		logError(c, "link upload write failed offset=%d bytes=%d: %v", offset, len(chunk), err)
		return fail(c, "lifedrive.upload.write_failed", "error.upload.write_failed", true), nil
	}
	return ok(c, map[string]any{"upload_id": handle, "offset": offset, "received": count,
		"next_offset": offset + int64(count)}), nil
}

// entryLinkUploadAbort releases the temp file behind an interrupted transfer.
// Without it a failed write leaves the handle open until Leither expires it,
// because no other call closes a transfer that never reached completion.
func entryLinkUploadAbort(c *ctx) (any, error) {
	if householdActive() {
		return entryHouseholdLinkUpload(c, "abort")
	}
	handle := c.str("upload_id")
	if _, failure := authorizeUpload(c); failure != nil {
		return failure, nil
	}
	closeHandle(c, handle)
	return ok(c, map[string]any{"upload_id": handle, "state": "aborted"}), nil
}

func entryLinkUploadComplete(c *ctx) (any, error) {
	if householdActive() {
		return entryHouseholdLinkUpload(c, "complete")
	}
	handle := c.str("upload_id")
	declaredSize := parseInt64(c.str("size"), -1)
	name := cleanName(c.str("name"))
	if handle == "" || declaredSize < 0 || name == "" {
		return fail(c, "lifedrive.request.invalid_completion", "error.request.invalid_completion", false), nil
	}
	defer closeHandle(c, handle)
	grant, failure := authorizeUpload(c)
	if failure != nil {
		return failure, nil
	}
	actualSize, err := c.api.MFGetSize(handle)
	if err != nil {
		return uploadCompleteFailure(c, "verify_size", err), nil
	}
	if actualSize != declaredSize || actualSize > grant.record.MaxBytes {
		return failDetails(c, "lifedrive.upload.too_large", "error.upload.too_large", false,
			map[string]any{"max_bytes": grant.record.MaxBytes, "size": actualSize}), nil
	}
	auth := grant.access.sid
	if _, err := ensureDriveRoot(c, auth, grant.access.driveMID); err != nil {
		return uploadCompleteFailure(c, "open_drive", err), nil
	}
	// Held for the owner rather than delivered. Nobody has agreed to this file
	// yet: the sender holds a link, which is not the same as the owner having
	// seen what is arriving. entryPendingAccept moves it into record.Path.
	holding := pendingTokenPath(grant.record.Token)
	if _, err := ensureDirectory(c, auth, c.workPath(holding)); err != nil {
		return uploadCompleteFailure(c, "ensure_destination", err), nil
	}
	target := linkTargetName(holding, name, c.str("viewer"))
	// MFTemp2Files refuses a destination that already exists, which is the only
	// authoritative answer available -- reads of the folder are not. Report it
	// rather than trying to write past it.
	if _, err := c.api.MFTemp2Files(handle, c.workPath(target)); err != nil {
		if strings.Contains(fmt.Sprintf("%v", err), "already exists") {
			return failDetails(c, "lifedrive.upload.already_sent", "error.upload.already_sent", false,
				map[string]any{"name": baseName(target)}), nil
		}
		return uploadCompleteFailure(c, "copy_to_drive", err), nil
	}
	if _, err := commitDrive(c, grant.access); err != nil {
		rollbackUploadedPath(c, auth, c.workPath(target))
		return uploadCompleteFailure(c, "commit_drive", err), nil
	}
	// Counted per file once it has landed, so a failed transfer spends nothing
	// and a sender delivering several files spends one of the link for each.
	grant.record.Uploads++
	grant.shares.Shares[grant.index] = grant.record
	if err := writeShares(c, auth, grant.mid, grant.shares); err != nil {
		logError(c, "upload link accounting failed: %v", err)
	}
	// "held", not "stored": the sender is told their file arrived and is waiting
	// to be accepted, because telling them it is in the drive would be untrue.
	return ok(c, map[string]any{
		"stored": true, "held_for_owner": true, "display_name": baseName(target),
		"plaintext_size": actualSize,
		"uploads_used":   grant.record.Uploads, "max_uploads": grant.record.MaxViewers,
	}), nil
}
