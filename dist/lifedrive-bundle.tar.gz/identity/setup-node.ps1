[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$LeitherRoot,
    [switch]$Upgrade,
    [string]$RecoverDevice
)

$ErrorActionPreference = "Stop"
if ($Upgrade -and $RecoverDevice) { throw "Choose upgrade or phone reconnect." }
$taskName = "LifeDrive Identity"
$identityDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$binary = Join-Path $identityDir "lifedrive-identity-windows-amd64.exe"
$root = [IO.Path]::GetFullPath($LeitherRoot)

if (-not (Test-Path -LiteralPath $binary -PathType Leaf)) {
    throw "The release is missing the Windows identity service."
}
if (-not (Test-Path -LiteralPath (Join-Path $root "Leither.exe") -PathType Leaf)) {
    throw "Leither.exe was not found in $root."
}

$principal = [Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Run Windows Terminal or PowerShell as Administrator."
}

function Protect-PrivateDirectory {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
    $acl = [Security.AccessControl.DirectorySecurity]::new()
    $acl.SetAccessRuleProtection($true, $false)
    $inheritance = [Security.AccessControl.InheritanceFlags]"ContainerInherit, ObjectInherit"
    $propagation = [Security.AccessControl.PropagationFlags]::None
    foreach ($sidText in @("S-1-5-18", "S-1-5-32-544", [Security.Principal.WindowsIdentity]::GetCurrent().User.Value)) {
        $sid = [Security.Principal.SecurityIdentifier]::new($sidText)
        $rule = [Security.AccessControl.FileSystemAccessRule]::new(
            $sid, [Security.AccessControl.FileSystemRights]::FullControl, $inheritance,
            $propagation, [Security.AccessControl.AccessControlType]::Allow)
        $acl.AddAccessRule($rule)
    }
    Set-Acl -LiteralPath $Path -AclObject $acl
}

Protect-PrivateDirectory (Join-Path $root ".lifedrive-household")

$configOutput = & $binary -configure-node $root 2>&1
if ($LASTEXITCODE -ne 0) {
    throw "LifeDrive identity configuration failed: $($configOutput -join ' ')"
}
$config = [string]($configOutput | Select-Object -Last 1)
if (-not [IO.Path]::IsPathRooted($config) -or -not (Test-Path -LiteralPath $config -PathType Leaf)) {
    throw "The identity service returned an invalid configuration path."
}
$expected = Get-Content -LiteralPath $config -Raw | ConvertFrom-Json
$identityArguments = '-config "' + $config + '"'

function Test-ManagedIdentityTask {
    param($Task)
    if (-not $Task -or $Task.Actions.Count -ne 1) { return $false }
    $action = $Task.Actions[0]
    return ([IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($action.Execute)) -eq [IO.Path]::GetFullPath($binary)) -and
        ($action.Arguments -eq $identityArguments) -and
        ([IO.Path]::GetFullPath($action.WorkingDirectory) -eq $root)
}

$existing = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
if ($existing -and -not (Test-ManagedIdentityTask $existing)) {
    throw "A different scheduled task named '$taskName' already exists. It was not replaced."
}

# A fresh owner invitation must never replace an existing or interrupted account.
# The binary checks this again under its exclusive lock after the task stops.
$skipInvitation = $false
if (-not $Upgrade) {
    if (-not [IO.Path]::IsPathRooted([string]$expected.state_dir)) {
        throw "Invalid household state directory. No invitation was changed."
    }
    $statePath = Join-Path $expected.state_dir "state.json"
    if (Test-Path -LiteralPath $statePath -PathType Leaf) {
        try { $state = Get-Content -LiteralPath $statePath -Raw | ConvertFrom-Json }
        catch { throw "Could not inspect household setup state. No invitation was changed." }
        if ($state.node_id -ne $expected.node_id -or $state.version -lt 1 -or
            $state.users -isnot [System.Management.Automation.PSCustomObject]) {
            throw "Invalid household setup state. No invitation was changed."
        }
        $hasUsers = @($state.users.PSObject.Properties).Count -gt 0
        if ($RecoverDevice -and -not $hasUsers) { throw "No existing account is available to reconnect." }
        $skipInvitation = $hasUsers -and -not $RecoverDevice
    } elseif ($existing) {
        throw "The installed account service has no saved state. Restore its protected state before pairing."
    }
}

$restoreTask = $existing -and $existing.State -eq "Running"
try {
    if ($existing) {
        Stop-ScheduledTask -TaskName $taskName
        for ($attempt = 0; $attempt -lt 30; $attempt++) {
            if ((Get-ScheduledTask -TaskName $taskName).State -ne "Running") { break }
            Start-Sleep -Seconds 1
        }
        if ((Get-ScheduledTask -TaskName $taskName).State -eq "Running") {
            throw "The account service did not stop. No invitation was changed."
        }
    }

    $invitation = $null
    if (-not $Upgrade -and -not $skipInvitation) {
        if ($RecoverDevice) {
            $invitationOutput = & $binary -config $config -issue-device-recovery $RecoverDevice 2>&1
        } else {
            $invitationOutput = & $binary -config $config -issue-setup 2>&1
        }
        if ($LASTEXITCODE -ne 0) {
            throw "Could not create the mobile invitation. For reconnect, use an existing active account name or exact user ID."
        }
        $invitation = $invitationOutput -join [Environment]::NewLine
        try { $null = $invitation | ConvertFrom-Json } catch { throw "The identity service returned an invalid invitation." }
    }

    $action = New-ScheduledTaskAction -Execute $binary -Argument $identityArguments -WorkingDirectory $root
    $trigger = New-ScheduledTaskTrigger -AtStartup
    $trigger.Delay = "PT30S"
    $taskPrincipal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
    $settingsParameters = @{
        AllowStartIfOnBatteries = $true
        DontStopIfGoingOnBatteries = $true
        ExecutionTimeLimit = [TimeSpan]::Zero
        RestartCount = 999
        RestartInterval = (New-TimeSpan -Minutes 1)
        StartWhenAvailable = $true
        MultipleInstances = "IgnoreNew"
    }
    $settings = New-ScheduledTaskSettingsSet @settingsParameters
    $definition = New-ScheduledTask -Action $action -Trigger $trigger -Principal $taskPrincipal -Settings $settings -Description "LifeDrive household identity service"
    Register-ScheduledTask -TaskName $taskName -InputObject $definition -Force | Out-Null
    Start-ScheduledTask -TaskName $taskName

    $ready = $false
    for ($attempt = 0; $attempt -lt 30; $attempt++) {
        try {
            $health = Invoke-RestMethod -Uri "http://127.0.0.1:4811/health" -TimeoutSec 2
            if ($health.service -eq "lifedrive-identity" -and $health.node_id -eq $expected.node_id) {
                $ready = $true
                break
            }
        } catch {}
        Start-Sleep -Seconds 1
    }
    if (-not $ready) {
        throw "LifeDrive identity did not become ready. Check Task Scheduler history for '$taskName'."
    }
    $restoreTask = $false
} finally {
    if ($restoreTask) {
        try { Start-ScheduledTask -TaskName $taskName }
        catch { Write-Warning "Could not restore the account service. Run: Start-ScheduledTask -TaskName 'LifeDrive Identity'" }
    }
}

if ($skipInvitation) {
    Write-Host "This node already has users or a setup claim in progress. Existing identities were preserved."
    Write-Host "To connect another phone, create an invitation from My devices on a paired phone."
    Write-Host "If first setup was interrupted, resume it on the original phone with its original invitation."
    return
}

if ($Upgrade) {
    Write-Host "LifeDrive identity restarted with the upgraded files. Existing users and keys were preserved."
    return
}

Write-Host ""
Write-Host "LePan setup complete."
Write-Host "The account service is ready and will start automatically with Windows."
if ($env:LIFEDRIVE_PAIRING_RESULT) {
    [IO.File]::WriteAllText($env:LIFEDRIVE_PAIRING_RESULT, $invitation, [Text.UTF8Encoding]::new($false))
    # This directory has an explicit private ACL, including on existing nodes.
    [IO.File]::WriteAllText(($env:LIFEDRIVE_PAIRING_RESULT + ".directory"), (Join-Path $root ".lifedrive-household"), [Text.UTF8Encoding]::new($false))
} else {
    Write-Host ""
    Write-Host "Next: pair your phone"
    Write-Host "Open LePan > Settings > Set up users and paste this invitation:"
    Write-Host ""
    Write-Output $invitation
    Write-Host ""
    Write-Host "Keep this invitation private. It expires ten minutes after creation."
}
