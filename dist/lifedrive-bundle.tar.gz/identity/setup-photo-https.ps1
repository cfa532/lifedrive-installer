[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$Domain,
    [string]$PhotoListen = "0.0.0.0:8443",
    [string]$Config,
    [string]$Binary,
    [string]$TaskName = "LifeDrive Identity",
    [switch]$AgreeAcmeTerms
)

$ErrorActionPreference = "Stop"
if (-not $AgreeAcmeTerms) {
    throw "Automatic HTTPS requires -AgreeAcmeTerms."
}

$principal = [Security.Principal.WindowsPrincipal]::new([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Run Windows Terminal or PowerShell as Administrator."
}

$identityDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Split-Path -Parent $identityDir
if (-not $Config) { $Config = Join-Path $root ".lifedrive-household\identity.json" }
if (-not $Binary) { $Binary = Join-Path $identityDir "lifedrive-identity-windows-amd64.exe" }
if (-not (Test-Path -LiteralPath $Config -PathType Leaf)) { throw "Missing identity configuration: $Config" }
if (-not (Test-Path -LiteralPath $Binary -PathType Leaf)) { throw "Missing identity binary: $Binary" }

$saved = Get-Content -LiteralPath $Config -Raw | ConvertFrom-Json
if ($saved.transport -ne "leither" -or -not $saved.state_dir -or -not $saved.node_id) {
    throw "This is not a complete LifeDrive identity configuration."
}
$stateDir = [string]$saved.state_dir
if (-not (Test-Path -LiteralPath $stateDir -PathType Container)) {
    throw "The configured private state directory is unavailable."
}

function Test-ManagedIdentityTask {
    param($Task)
    if (-not $Task -or $Task.Actions.Count -ne 1) { return $false }
    $action = $Task.Actions[0]
    $arguments = '-config "' + $Config + '"'
    return ([IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($action.Execute)) -eq [IO.Path]::GetFullPath($Binary)) -and
        ($action.Arguments -eq $arguments) -and
        ([IO.Path]::GetFullPath($action.WorkingDirectory) -eq [IO.Path]::GetFullPath($root))
}

function Restart-IdentityTask {
    Stop-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    for ($attempt = 0; $attempt -lt 30; $attempt++) {
        if ((Get-ScheduledTask -TaskName $TaskName).State -ne "Running") { break }
        Start-Sleep -Seconds 1
    }
    if ((Get-ScheduledTask -TaskName $TaskName).State -eq "Running") {
        throw "The LifeDrive identity task did not stop."
    }
    Start-ScheduledTask -TaskName $TaskName
}

$task = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if (-not (Test-ManagedIdentityTask $task)) {
    throw "The managed '$TaskName' scheduled task was not found for this LifeDrive installation."
}

$separator = $PhotoListen.LastIndexOf(":")
if ($separator -lt 0) { throw "PhotoListen must use HOST:PORT format." }
$bind = $PhotoListen.Substring(0, $separator)
$port = 0
if (-not [Int32]::TryParse($PhotoListen.Substring($separator + 1), [ref]$port) -or $port -lt 1 -or $port -gt 65535) {
    throw "PhotoListen must contain a valid TCP port."
}
$probeAddress = if ($bind -in @("", "0.0.0.0", "127.0.0.1", "[::]", "::")) { "127.0.0.1" } else { $bind }
$firewallName = "LifeDrive-PhotoHTTPS"

$lock = Join-Path $stateDir "photo-https-setup.lock"
try {
    New-Item -ItemType Directory -Path $lock -ErrorAction Stop | Out-Null
} catch {
    throw "Another photo HTTPS setup is running, or $lock needs manual removal after an interrupted setup."
}
$backup = Join-Path $stateDir ("identity-before-photo-https-{0}.json" -f (Get-Date -Format "yyyyMMddHHmmssfff"))
$configured = $false
$firewallCreated = $false
$success = $false

try {
    Copy-Item -LiteralPath $Config -Destination $backup
    $configured = $true
    & $Binary -config $Config -configure-photo-acme ("https://" + $Domain) -photo-upload-listen $PhotoListen -agree-acme-terms
    if ($LASTEXITCODE -ne 0) { throw "The identity service rejected the photo HTTPS configuration." }

    $firewall = Get-NetFirewallRule -Name $firewallName -ErrorAction SilentlyContinue
    if ($firewall) {
        $application = $firewall | Get-NetFirewallApplicationFilter
        $portFilter = $firewall | Get-NetFirewallPortFilter
        if ([IO.Path]::GetFullPath($application.Program) -ne [IO.Path]::GetFullPath($Binary) -or
            [string]$portFilter.LocalPort -ne [string]$port -or [string]$portFilter.Protocol -ne "TCP") {
            throw "An existing firewall rule named $firewallName has a different program or port. It was not replaced."
        }
        Enable-NetFirewallRule -Name $firewallName | Out-Null
    } else {
        New-NetFirewallRule -Name $firewallName -DisplayName "LifeDrive photo HTTPS" -Direction Inbound -Action Allow -Enabled True -Profile Any -Protocol TCP -LocalPort $port -Program $Binary | Out-Null
        $firewallCreated = $true
    }

    Restart-IdentityTask

    $ready = $false
    for ($attempt = 0; $attempt -lt 30; $attempt++) {
        try {
            $health = Invoke-RestMethod -Uri "http://127.0.0.1:4811/health" -TimeoutSec 2
            if ($health.service -eq "lifedrive-identity" -and $health.node_id -eq $saved.node_id) {
                $ready = $true
                break
            }
        } catch {}
        Start-Sleep -Seconds 1
    }
    if (-not $ready) { throw "LifeDrive identity did not become ready after restart." }

    $status = & curl.exe --silent --show-error --output NUL --write-out "%{http_code}" `
        --max-time 180 --connect-to ("{0}:443:{1}:{2}" -f $Domain, $probeAddress, $port) `
        ("https://{0}/v1/photo-control" -f $Domain)
    if ($LASTEXITCODE -ne 0 -or $status -ne "405") {
        throw "Certificate issuance failed. Confirm DNS and public TCP 443 forwarding, then retry."
    }
    $success = $true
    Write-Host "Photo HTTPS is ready at https://$Domain. Keep public TCP 443 forwarded to $PhotoListen. Port 80 is not needed."
    Write-Host "Windows Firewall now allows private TCP $port for the LifeDrive identity binary."
    Write-Host "The certificate account and renewed certificates stay private in $stateDir\photo-acme."
    Write-Host "Leither was not restarted. Reopen LePan on paired iPhones to discover the endpoint."
} finally {
    if (-not $success -and $configured) {
        Copy-Item -LiteralPath $backup -Destination $Config -Force
        try { Restart-IdentityTask } catch {}
        if ($firewallCreated) {
            Remove-NetFirewallRule -Name $firewallName -ErrorAction SilentlyContinue
        }
        Write-Warning "Photo HTTPS setup failed. The previous identity configuration was restored."
    }
    Remove-Item -LiteralPath $lock -Force -ErrorAction SilentlyContinue
}
