#!/usr/bin/env bash
set -euo pipefail
umask 077
if [[ $# -ne 1 || ! -f "$1" ]]; then
  echo "Usage: install.sh /absolute/path/to/identity-config.json" >&2
  exit 2
fi
case "$1" in /*) ;; *) echo "Use an absolute configuration path." >&2; exit 2 ;; esac
identity_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
case "$(uname -s)" in Linux) identity_os=linux ;; Darwin) identity_os=darwin ;; *) echo "Unsupported platform." >&2; exit 1 ;; esac
case "$(uname -m)" in x86_64|amd64) identity_arch=amd64 ;; aarch64|arm64) identity_arch=arm64 ;; *) echo "Unsupported architecture." >&2; exit 1 ;; esac
identity_binary="$identity_dir/lifedrive-identity-$identity_os-$identity_arch"
[[ -f "$identity_binary" ]] || { echo "The release is missing the identity service for this platform." >&2; exit 1; }
chmod 700 "$identity_binary"
echo "Creating a one-time mobile setup invitation. Keep this block private until the phone claims it."
if [[ -n "${LIFEDRIVE_PAIRING_RESULT:-}" ]]; then
  "$identity_binary" -config "$1" -issue-setup > "$LIFEDRIVE_PAIRING_RESULT"
  printf '%s' "${LIFEDRIVE_WORKDIR:?Leither root required}" > "$LIFEDRIVE_PAIRING_RESULT.directory"
  cat "$LIFEDRIVE_PAIRING_RESULT"
else
  "$identity_binary" -config "$1" -issue-setup
fi
echo
echo "Start the identity service with the same configuration before pasting this invitation on mobile:"
printf '%q -config %q\n' "$identity_binary" "$1"
echo "For Linux boot startup, adapt the included lifedrive-identity.service unit. Leither is not restarted."
