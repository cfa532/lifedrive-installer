#!/usr/bin/env bash
set -euo pipefail
umask 077
root=$(cd -- "${1:?Leither root required}" && pwd)
recover_user="${2:-}"
identity_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
case "$(uname -s)" in Linux) os=linux ;; Darwin) os=darwin ;; *) echo "Unsupported platform" >&2; exit 1 ;; esac
case "$(uname -m)" in x86_64|amd64) arch=amd64 ;; aarch64|arm64) arch=arm64 ;; *) echo "Unsupported architecture" >&2; exit 1 ;; esac
binary="$identity_dir/lifedrive-identity-$os-$arch"
[[ -f "$binary" ]] || { echo "The release is missing the identity service for this platform." >&2; exit 1; }
chmod 700 "$binary"
if [[ $(id -u) == 0 ]]; then
  echo "Run household setup as the account running Leither; sudo is used only to install its identity service." >&2
  exit 1
fi
config=$("$binary" -configure-node "$root")
command -v node >/dev/null || { echo "Household setup requires Node.js." >&2; exit 1; }
# Inspect only whether setup has started. Never print state, keys or invitations.
# The binary rechecks under its exclusive lock after the service stops, so a
# claim that wins this race cannot be replaced by a new owner invitation.
has_users=$(node - "$config" <<'NODE'
const fs = require("node:fs"), path = require("node:path");
try {
  const config = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
  if (typeof config.state_dir !== "string" || !path.isAbsolute(config.state_dir)) throw new Error();
  const file = path.join(config.state_dir, "state.json");
  let state;
  try { state = JSON.parse(fs.readFileSync(file, "utf8")); }
  catch (error) { if (error.code !== "ENOENT") throw error; }
  if (state && (state.node_id !== config.node_id || !Number.isInteger(state.version) || state.version < 1 ||
      !state.users || typeof state.users !== "object" || Array.isArray(state.users))) throw new Error();
  process.stdout.write(!state ? "2" : Object.keys(state.users).length ? "1" : "0");
} catch {
  console.error("Could not inspect household setup state. No invitation was changed.");
  process.exit(1);
}
NODE
)
setup_work=$(mktemp -d)
service_needs_restore=""
cleanup_setup() {
  local status=$?
  trap - EXIT
  # Restore a service we stopped even if invitation issuance fails or the
  # operator interrupts setup. Never stop or restart the Leither service.
  if [[ "$service_needs_restore" == linux ]]; then
    if ! sudo systemctl start lifedrive-identity.service; then
      echo "Could not restore the account service. Run: sudo systemctl start lifedrive-identity.service" >&2
      status=1
    fi
  elif [[ "$service_needs_restore" == darwin ]]; then
    if ! launchctl print "$service_target" >/dev/null 2>&1 &&
       ! sudo launchctl bootstrap system "$installed_plist"; then
      echo "Could not restore the account service. Run: sudo launchctl bootstrap system $installed_plist" >&2
      status=1
    fi
  fi
  rm -f -- "$setup_work/invitation.json" "$setup_work/lifedrive-identity.service" "$setup_work/identity.plist"
  rmdir -- "$setup_work"
  exit "$status"
}
trap cleanup_setup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
trap 'exit 129' HUP
explain_existing_users() {
  echo "This node already has users or a setup claim in progress. Existing identities were preserved."
  echo "To connect another phone, create an invitation from My devices on a paired phone."
  echo "If first setup was interrupted, resume it on the original phone with its original invitation."
}
check_renewal_state() {
  if (( has_users == 2 )); then
    echo "The running account service has no saved state. Restore its protected state before pairing." >&2
    exit 1
  fi
  if [[ -n "$recover_user" ]]; then
    (( has_users == 1 )) || { echo "No existing account is available to reconnect." >&2; exit 1; }
    return
  fi
  if (( has_users == 1 )); then explain_existing_users; exit 0; fi
}
identity_health_ready() {
  curl --fail --silent --max-time 2 http://127.0.0.1:4811/health | node -e '
    const fs = require("node:fs");
    try {
      const expected = JSON.parse(fs.readFileSync(process.argv[1], "utf8"));
      const health = JSON.parse(fs.readFileSync(0, "utf8"));
      process.exit(health.service === "lifedrive-identity" && health.node_id === expected.node_id ? 0 : 1);
    } catch { process.exit(1); }
  ' "$config"
}
if [[ "$os" == linux ]] && command -v systemctl >/dev/null; then
  # This owns only LifeDrive's identity process, never the Leither service.
  if systemctl is-active --quiet lifedrive-identity.service; then
    running_command=$(systemctl show lifedrive-identity.service --property=ExecStart --value)
    if [[ "$running_command" != *"$config"* || "$running_command" != *"path=$binary ;"* ||
          "$(systemctl show lifedrive-identity.service --property=User --value)" != "$(id -un)" ||
          "$(systemctl show lifedrive-identity.service --property=WorkingDirectory --value)" != "$root" ]]; then
      echo "An identity service for another configuration already owns the local port." >&2
      exit 1
    fi
    check_renewal_state
    if [[ -n "$recover_user" ]]; then echo "Preparing a phone reconnect invitation..."; else echo "Renewing the first-phone invitation..."; fi
    service_needs_restore=linux
    sudo systemctl stop lifedrive-identity.service
  fi
fi
if [[ "$os" == darwin ]]; then
  for required in node launchctl plutil lsof; do
    command -v "$required" >/dev/null || { echo "macOS setup requires $required." >&2; exit 1; }
  done
  label=uk.inoku.lifedrive-identity
  service_target="system/$label"
  installed_plist="/Library/LaunchDaemons/$label.plist"
  account=$(id -un)
  # A system daemon survives logout and works on Macs managed over SSH, but
  # runs as the Leither account. Never take over another node's service.
  if [[ -e "$installed_plist" ]]; then
    saved_config=$(/usr/libexec/PlistBuddy -c 'Print :ProgramArguments:2' "$installed_plist")
    saved_account=$(/usr/libexec/PlistBuddy -c 'Print :UserName' "$installed_plist")
    saved_binary=$(/usr/libexec/PlistBuddy -c 'Print :ProgramArguments:0' "$installed_plist")
    if [[ "$saved_config" != "$config" || "$saved_account" != "$account" || "$saved_binary" != "$binary" ]]; then
      echo "A LifeDrive identity daemon for another installation already exists at $installed_plist." >&2
      exit 1
    fi
  elif launchctl print "$service_target" >/dev/null 2>&1; then
    echo "An unmanaged LifeDrive identity daemon is already loaded; stop it before setup." >&2
    exit 1
  fi
  macos_identity_ready() {
    local service_pid
    service_pid=$(launchctl print "$service_target" 2>/dev/null | awk '/^[[:space:]]*pid = / {print $3; exit}') || return 1
    [[ "$service_pid" =~ ^[0-9]+$ ]] || return 1
    # A different process answering /health must not make startup look successful.
    lsof -nP -a -p "$service_pid" -iTCP:4811 -sTCP:LISTEN -t >/dev/null 2>&1 || return 1
    identity_health_ready
  }
  if launchctl print "$service_target" >/dev/null 2>&1; then
    if macos_identity_ready; then
      check_renewal_state
      if [[ -n "$recover_user" ]]; then echo "Preparing a phone reconnect invitation..."; else echo "Renewing the first-phone invitation..."; fi
      service_needs_restore=darwin
      sudo launchctl bootout "$service_target"
      # launchd can return before the old process releases its listener and lock.
      for attempt in {1..30}; do
        if ! lsof -nP -iTCP:4811 -sTCP:LISTEN -t >/dev/null 2>&1; then break; fi
        sleep 1
      done
    else
      echo "The LifeDrive identity daemon is loaded but not ready. Check $root/.lifedrive-household/identity.log." >&2
      echo "Stop only this daemon with: sudo launchctl bootout $service_target" >&2
      echo "Then rerun household setup." >&2
      exit 1
    fi
  fi
  if lsof -nP -iTCP:4811 -sTCP:LISTEN -t >/dev/null 2>&1; then
    echo "Port 4811 is already in use. Stop the foreground identity service before installing its macOS daemon." >&2
    exit 1
  fi
fi
# Do not print a usable invitation until its service has started successfully.
invitation_args=(-issue-setup)
if [[ -n "$recover_user" ]]; then invitation_args=(-issue-device-recovery "$recover_user"); fi
if ! "$binary" -config "$config" "${invitation_args[@]}" > "$setup_work/invitation.json"; then
  exit 1
fi
show_invitation() {
  if [[ -n "${LIFEDRIVE_PAIRING_RESULT:-}" ]]; then
    cp -- "$setup_work/invitation.json" "$LIFEDRIVE_PAIRING_RESULT"
    printf '%s' "$root" > "$LIFEDRIVE_PAIRING_RESULT.directory"
  else
    printf '\nNext: pair your phone\n'
    printf 'Open LePan > Settings > Set up users and paste this invitation:\n\n'
    cat "$setup_work/invitation.json"
    printf '\nKeep this invitation private. It expires ten minutes after creation.\n'
  fi
}
if [[ "$os" == linux ]] && command -v systemctl >/dev/null; then
  # Fixed line structure; reject paths that systemd could interpret as directives.
  case "$root$binary$config" in *$'\n'*|*$'\r'*|*'"'*|*'%'*|*'\\'*) echo "Unsupported service path" >&2; exit 1 ;; esac
  unit="$setup_work/lifedrive-identity.service"
  account=$(id -un)
  cat > "$unit" <<UNIT
[Unit]
Description=LifeDrive household identity
After=network-online.target lifedrive-leither.service
[Service]
User=$account
WorkingDirectory=$root
ExecStart="$binary" -config "$config"
UMask=0077
Restart=on-failure
RestartSec=5
NoNewPrivileges=true
[Install]
WantedBy=multi-user.target
UNIT
  # WorkingDirectory takes a path, not ExecStart-style quoted arguments.
  if command -v systemd-analyze >/dev/null && ! systemd-analyze verify "$unit"; then
    echo "Identity service configuration is invalid; setup stopped." >&2
    exit 1
  fi
  if ! sudo install -m 644 "$unit" /etc/systemd/system/lifedrive-identity.service ||
     ! sudo systemctl daemon-reload ||
     ! sudo systemctl enable --now lifedrive-identity.service; then
    echo "Identity service failed to start. Pairing is not ready; rerun setup after correcting the service error." >&2
    exit 1
  fi
  # enable --now can report success before the process exits during startup.
  ready=0
  for attempt in {1..30}; do
    if systemctl is-active --quiet lifedrive-identity.service &&
       identity_health_ready; then
      ready=1
      break
    fi
    sleep 1
  done
  if (( ! ready )); then
    echo "Identity service is not ready. Check systemctl status lifedrive-identity.service before pairing." >&2
    exit 1
  fi
  printf '\nLePan setup complete.\n'
  service_needs_restore=""
  echo "The account service is ready and will start automatically at boot."
  show_invitation
elif [[ "$os" == darwin ]]; then
  plist="$setup_work/identity.plist"
  # JSON-to-plist conversion preserves spaces and XML metacharacters in paths.
  node - "$label" "$account" "$root" "$binary" "$config" <<'NODE' > "$plist"
const [label, account, root, binary, config] = process.argv.slice(2);
process.stdout.write(JSON.stringify({
  Label: label,
  UserName: account,
  ProgramArguments: [binary, "-config", config],
  WorkingDirectory: root,
  EnvironmentVariables: {
    HOME: process.env.HOME,
    PATH: "/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
  },
  RunAtLoad: true,
  KeepAlive: true,
  ThrottleInterval: 5,
  Umask: 63,
  StandardOutPath: `${root}/.lifedrive-household/identity.log`,
  StandardErrorPath: `${root}/.lifedrive-household/identity.log`
}));
NODE
  plutil -convert xml1 "$plist"
  plutil -lint "$plist" >/dev/null
  if ! sudo install -o root -g wheel -m 644 "$plist" "$installed_plist" ||
     ! sudo launchctl enable "$service_target" ||
     ! sudo launchctl bootstrap system "$installed_plist"; then
    echo "Identity service failed to start. Pairing is not ready; correct the launchd error and rerun setup." >&2
    exit 1
  fi
  ready=0
  for attempt in {1..30}; do
    if macos_identity_ready; then ready=1; break; fi
    sleep 1
  done
  if (( ! ready )); then
    echo "Identity service is not ready. Check $root/.lifedrive-household/identity.log before pairing." >&2
    echo "Inspect it with: sudo launchctl print $service_target" >&2
    exit 1
  fi
  printf '\nLePan setup complete.\n'
  service_needs_restore=""
  echo "The account service is ready and will start automatically at boot."
  show_invitation
else
  echo "Start the service in another terminal before pairing:"
  printf '%q -config %q\n' "$binary" "$config"
  show_invitation
fi
