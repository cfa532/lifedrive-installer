#!/usr/bin/env bash
# Configure LifeDrive's built-in ACME TLS-ALPN-01 endpoint. The public router
# forwards TCP 443 directly to this listener; port 80 and nginx are not used.
set -euo pipefail
umask 077

usage() {
  cat <<'USAGE'
Usage on an installed Linux or macOS node:
  bash setup-photo-https.sh --domain photos.example.com --agree-acme-terms

Options:
  --domain HOST             Dedicated DNS hostname for this node (required)
  --photo-listen HOST:PORT  Private listener; default 0.0.0.0:8443
  --config PATH             Existing identity.json (normally auto-detected)
  --binary PATH             Identity binary (normally auto-detected)
  --agree-acme-terms        Accept the certificate authority subscriber agreement

Before running this command, point the hostname at this node and forward public
TCP 443 to the private listener (8443 by default). Do not forward port 80.
Run this command as the account that runs Leither, not with sudo. The helper uses
sudo only to restart the LifeDrive identity service. It never restarts Leither.
USAGE
}

if [[ "${1:-}" == --help || "${1:-}" == -h ]]; then usage; exit 0; fi

domain=''
listen='0.0.0.0:8443'
config=''
binary=''
agree=0
while (( $# )); do
  case "$1" in
    --domain|--photo-listen|--config|--binary)
      option=$1
      [[ $# -ge 2 && -n "$2" && "$2" != --* ]] || { echo "$option needs a value." >&2; exit 2; }
      case "$option" in
        --domain) domain=$2 ;;
        --photo-listen) listen=$2 ;;
        --config) config=$2 ;;
        --binary) binary=$2 ;;
      esac
      shift 2 ;;
    --agree-acme-terms) agree=1; shift ;;
    *) echo "Unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
done

[[ -n "$domain" ]] || { echo "Choose --domain for this node." >&2; usage >&2; exit 2; }
(( agree )) || { echo "Automatic HTTPS requires --agree-acme-terms." >&2; exit 2; }
if [[ $(id -u) == 0 ]]; then
  echo "Run this command as the account that runs Leither, without sudo." >&2
  exit 1
fi
for command in curl node; do
  command -v "$command" >/dev/null || { echo "Missing prerequisite: $command" >&2; exit 1; }
done

identity_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
root=$(cd -- "$identity_dir/.." && pwd)
if [[ "$(basename "$root")" == lepan && -f "$root/.installer-layout-v1" ]]; then
  root=$(cd -- "$root/.." && pwd)
fi
case "$(uname -s)" in Linux) os=linux ;; Darwin) os=darwin ;; *) echo "Use setup-photo-https.ps1 on Windows." >&2; exit 1 ;; esac
case "$(uname -m)" in x86_64|amd64) arch=amd64 ;; aarch64|arm64) arch=arm64 ;; *) echo "Unsupported architecture." >&2; exit 1 ;; esac
[[ -n "$config" ]] || config="$root/.lifedrive-household/identity.json"
[[ -n "$binary" ]] || binary="$identity_dir/lifedrive-identity-$os-$arch"
[[ "$config" == /* && "$binary" == /* ]] || { echo "Configuration and binary paths must be absolute." >&2; exit 1; }
[[ -f "$config" && -w "$config" ]] || { echo "The current Leither account cannot update $config." >&2; exit 1; }
[[ -x "$binary" ]] || { echo "Missing executable identity binary: $binary" >&2; exit 1; }

# Let the identity binary perform the authoritative URL/listener validation. A
# small JSON read is used only to ensure this helper targets the installed node.
node - "$config" <<'NODE'
const fs = require("node:fs");
try {
  const value = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
  if (value.transport !== "leither" || !value.state_dir || !value.node_id) throw new Error();
} catch {
  console.error("This is not a complete LifeDrive identity configuration.");
  process.exit(1);
}
NODE

state_dir=$(node -e 'const c=require(process.argv[1]); process.stdout.write(c.state_dir)' "$config")
[[ "$state_dir" == /* && -d "$state_dir" ]] || { echo "The configured private state directory is unavailable." >&2; exit 1; }
lock="$state_dir/photo-https-setup.lock"
if ! mkdir "$lock" 2>/dev/null; then
  echo "Another photo HTTPS setup is running, or $lock needs manual removal after an interrupted setup." >&2
  exit 1
fi
backup="$state_dir/identity-before-photo-https-$(date +%Y%m%d%H%M%S)-$$.json"
configured=0
success=0

restart_identity() {
  if [[ "$os" == linux ]] && command -v systemctl >/dev/null && systemctl cat lifedrive-identity.service >/dev/null 2>&1; then
    sudo systemctl restart lifedrive-identity.service
  elif [[ "$os" == darwin ]] && sudo launchctl print system/uk.inoku.lifedrive-identity >/dev/null 2>&1; then
    sudo launchctl kickstart -k system/uk.inoku.lifedrive-identity
  else
    echo "The managed LifeDrive identity service is not installed on this node." >&2
    return 1
  fi
}

cleanup() {
  if (( ! success && configured )); then
    cp -p -- "$backup" "$config"
    restart_identity >/dev/null 2>&1 || true
    echo "Photo HTTPS setup failed. The previous identity configuration was restored." >&2
  fi
  rmdir -- "$lock" 2>/dev/null || true
}
trap cleanup EXIT

cp -p -- "$config" "$backup"
"$binary" -config "$config" -configure-photo-acme "https://$domain" \
  -photo-upload-listen "$listen" -agree-acme-terms
configured=1
restart_identity

identity_ready() {
  curl -q --fail --silent --max-time 2 http://127.0.0.1:4811/health | node -e '
    const fs = require("node:fs");
    try {
      const expected = JSON.parse(fs.readFileSync(process.argv[1], "utf8"));
      const health = JSON.parse(fs.readFileSync(0, "utf8"));
      process.exit(health.service === "lifedrive-identity" && health.node_id === expected.node_id ? 0 : 1);
    } catch { process.exit(1); }
  ' "$config"
}

ready=0
for _ in {1..30}; do
  if identity_ready; then
    ready=1
    break
  fi
  sleep 1
done
(( ready )) || { echo "LifeDrive identity did not become ready after restart." >&2; exit 1; }

port=${listen##*:}
bind=${listen%:*}
case "$bind" in ''|0.0.0.0|127.0.0.1|'[::]'|'::') probe_address=127.0.0.1 ;; *) probe_address=$bind ;; esac
status=$(curl --silent --show-error --output /dev/null --write-out '%{http_code}' \
  --max-time 180 --connect-to "$domain:443:$probe_address:$port" \
  "https://$domain/v1/photo-control") || {
    echo "Certificate issuance failed. Confirm DNS and public TCP 443 forwarding, then retry." >&2
    exit 1
  }
[[ "$status" == 405 ]] || { echo "The photo HTTPS readiness check returned HTTP $status instead of 405." >&2; exit 1; }

success=1
echo "Photo HTTPS is ready at https://$domain. Keep public TCP 443 forwarded to $listen. Port 80 is not needed."
echo "The certificate account and renewed certificates stay private in $state_dir/photo-acme."
echo "Leither was not restarted. Reopen LePan on paired iPhones to discover the endpoint."
